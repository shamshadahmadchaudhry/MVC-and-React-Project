import { OuterClick } from './OuterClick';

export default OuterClick;