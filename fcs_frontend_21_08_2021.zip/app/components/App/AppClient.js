import React, { useEffect } from 'react';
import { hot } from 'react-hot-loader'
import { BrowserRouter as Router } from 'react-router-dom';
import { useSelector, useDispatch } from "react-redux"
import AppLayout from './../../layout/default';
import { RoutedContent } from './../../routes';
import { UserDataRequest, CompanyListingRequest } from '../../redux/actions/index'

const basePath = process.env.BASE_PATH || '/';

const AppClient = () => {
    const dispatch = useDispatch();
    useEffect(()=>{
        localStorage.getItem('token') && dispatch(UserDataRequest());
        localStorage.getItem('token') && dispatch(CompanyListingRequest());

    },[])
    return (
        <Router basename={ basePath }>
            <AppLayout>
                <RoutedContent />
            </AppLayout>
        </Router>
    );
}

 

export default hot(module)(AppClient);