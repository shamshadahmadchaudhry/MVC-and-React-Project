import { SidebarMenu } from './SidebarMenu';
import { SidebarMenuItem } from './SidebarMenuItem';

SidebarMenu.Item = SidebarMenuItem;

export default SidebarMenu;
