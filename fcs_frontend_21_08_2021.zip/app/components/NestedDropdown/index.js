import { NestedDropdown } from './NestedDropdown';
import { NestedDropdownSubmenu } from './NestedDropdownSubmenu';

NestedDropdown.Submenu = NestedDropdownSubmenu;

export default NestedDropdown;
