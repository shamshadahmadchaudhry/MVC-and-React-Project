import { Wizard } from './Wizard';
import { WizardStep } from './WizardStep';

Wizard.Step = WizardStep;

export default Wizard;
