import React from 'react';

export const FloatGridContext = React.createContext();
