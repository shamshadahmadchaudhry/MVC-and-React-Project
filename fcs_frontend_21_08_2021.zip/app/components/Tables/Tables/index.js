import Tables from './Tables';

export default Tables; 