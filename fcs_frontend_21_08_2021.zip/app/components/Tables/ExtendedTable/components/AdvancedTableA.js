import React from 'react';
import BootstrapTable from 'react-bootstrap-table-next';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import _ from 'lodash';
import paginationFactory from 'react-bootstrap-table2-paginator';
import { ButtonGroup } from './../../../../components';
import { CustomExportCSV } from './CustomExportButton';
import { CustomSearch } from './CustomSearch';
import filterFactory from 'react-bootstrap-table2-filter';

import { CustomPaginationPanel } from './CustomPaginationPanel';
import { CustomSizePerPageButton } from './CustomSizePerPageButton';
import { CustomPaginationTotal } from './CustomPaginationTotal';


const AdvancedTableA = (props) => {
    const customTotal = (from, to, size) => (
        <span className="react-bootstrap-table-pagination-total">
            Showing { from} to { to} of { size} Results
        </span>
    );

    const pagination = (length, pageSize) => {
        let pazination = [];
        let pageCount = length / pageSize;

        for (let i = 0; i < length; i++) {
            pazination({ text: 1 })
        }
    }

    const options = {
        paginationSize: 5,
        pageStartIndex: 0,
        //alwaysShowAllBtns: true, // Always show next and previous button
        // withFirstAndLast: false, // Hide the going to First and Last page button
        // hideSizePerPage: true, // Hide the sizePerPage dropdown always
        // hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
        firstPageText: 'First',
        prePageText: 'Back',
        nextPageText: 'Next',
        lastPageText: 'Last',
        nextPageTitle: 'First page',
        prePageTitle: 'Pre page',
        firstPageTitle: 'Next page',
        lastPageTitle: 'Last page',
        showTotal: true,
        paginationTotalRenderer: customTotal,
        disablePageTitle: true,
        sizePerPageList: [{
            text: '5', value: 5
        }, {
            text: '10', value: 10
        }, {
            text: 'All', value: props.rowData.length
        }] // A numeric array is also available. the purpose of above example is custom the text
    };

    const paginationDef = paginationFactory({
        paginationSize: 10,
        showTotal: true,
        pageListRenderer: (props) => (
            <CustomPaginationPanel {...props} size="sm" className="ml-md-auto mt-2 mt-md-0" />
        ),
        sizePerPageRenderer: (props) => (
            <CustomSizePerPageButton {...props} />
        ),
        paginationTotalRenderer: (from, to, size) => (
            <CustomPaginationTotal {...{ from, to, size }} />
        )
    });

    return (
        <ToolkitProvider
            keyField="user_master_id"
            columns={props.headers}
            data={props.rowData}
            search
            exportCSV
        >
            {
                props => (
                    <React.Fragment>
                        <div className="d-flex justify-content-end align-items-center mb-2">
                            <h6 className="my-0">
                                AdvancedTable A
                            </h6>
                            <div className="d-flex ml-auto">
                                <CustomSearch
                                    className="mr-2"
                                    {...props.searchProps}
                                />
                                <ButtonGroup>
                                    <CustomExportCSV
                                        {...props.csvProps}
                                    >
                                        Export
                                    </CustomExportCSV>

                                </ButtonGroup>
                            </div>
                        </div>
                        <BootstrapTable
                            classes="table-responsive"
                            bordered={false}
                            pagination={paginationFactory(options)}
                            responsive
                            filter={filterFactory()}
                            {...props.baseProps}
                        />
                    </React.Fragment>
                )
            }
        </ToolkitProvider>
    )
}

export default AdvancedTableA