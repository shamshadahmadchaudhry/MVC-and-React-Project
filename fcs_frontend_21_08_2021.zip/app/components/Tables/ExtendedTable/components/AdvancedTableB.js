import React, { useState } from 'react';
import BootstrapTable from 'react-bootstrap-table-next';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import moment from 'moment';
import _ from 'lodash';
import filterFactory, { textFilter } from 'react-bootstrap-table2-filter';

import {
    ButtonGroup,
    Row,
    Col
} from './../../../../components';
import { CustomExportCSV } from './CustomExportButton';
import { CustomSearch } from './CustomSearch';



const AdvancedTableB = (props) => {
    const [showExpandColumn, setShowExpandColumn] = useState(false);

    const expandRow = {
        onlyOneExpanding: true,
        renderer: row => (
            <table>
                <thead>
                    <tr>
                        {
                            props.headers.map((item, index) => (
                                <th>{item.text}</th>
                            ))
                        }

                    </tr>
                </thead>
                <tbody>
                    {
                        props.rowData.map((row, rowId) => (
                            <tr>
                                {
                                    props.headers.map((item, index) => (
                                        <td>{row[item.dataField]}</td>
                                    ))
                                }
                            </tr>
                        ))
                    }
                </tbody>
            </table>
        )
    }

    return (
        <ToolkitProvider
            keyField="user_master_id"
            data={props.rowData}
            columns={props.headers}
            search
            exportCSV
        >
            {
                props => (
                    <React.Fragment>
                        <div className="d-flex justify-content-end align-items-center mb-2">
                            <h6 className="my-0">
                                AdvancedTable B
                            </h6>
                            <div className="d-flex ml-auto">
                                <CustomSearch
                                    className="mr-2"
                                    {...props.searchProps}
                                />
                                <ButtonGroup>
                                    <CustomExportCSV
                                        {...props.csvProps}
                                    >
                                        Export
                                    </CustomExportCSV>

                                </ButtonGroup>
                            </div>
                        </div>
                        <BootstrapTable
                            classes="table-responsive-lg"
                            bordered={false}
                            expandRow={expandRow}
                            responsive
                            bootstrap4
                            hover
                            {...props.baseProps}
                        />
                    </React.Fragment>
                )
            }
        </ToolkitProvider>
    );
}

export default AdvancedTableB