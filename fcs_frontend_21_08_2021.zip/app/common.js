import * as CommonDashboardFuncs from '@owczar/dashboard-style--airframe';

export default CommonDashboardFuncs;