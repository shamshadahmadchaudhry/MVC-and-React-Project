import React, { useEffect, useRef, useState } from 'react'

import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    RequiredRule,
} from 'devextreme-react/data-grid';
import {
    Card, CardBody, Container, ButtonGroup, Button, Row, Col
} from '../../../components';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import '../../../styles/common.scss';
import CustomStore from 'devextreme/data/custom_store';
import { Configuration } from '../../commoncomponents/configurationfile';
import { getContainersConfigurationList, addConfiguration, deleteConfiguration, updateConfiguration } from '../../../services/containerconfigurationservice';
import AlertMessage from '../../commoncomponents/alertmessage';
import ConfirmBox from '../../commoncomponents/confirmbox';
import { getUnitofMeasures } from '../../../services/companyprofileservice';
import ContainerConfigurationSkeleton from '../skeleton/containerconfigurationskeleton';
let container_id = 0;
let container_name = 0;
let companyId = 0;
let unit_of_measures = 0;
let decimal = ".";

const ContainerConfigurations = (props) => {
    container_id = props.configurationType.containerId;
    console.log('container_id', container_id)
    container_name = props.configurationType.containerName;
    const datagridRef = useRef(null)
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [delmodal, setDelmodal] = useState(false);
    const [entitysizeid, SetEntitySizeId] = useState(0);
    const [company_id, setCompanyId] = useState(0);
    const [unitmeasures, setUnitMeasures] = useState('');
    const [skeleton, setSkeleton] = useState(false);
    toast.configure();
    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            UnitMeasures(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
            companyId = CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id
        }
        else {
            UnitMeasures(CompanyListingStatus?.result?.response?.result[0].company_id)
            companyId = CompanyListingStatus?.result?.response?.result[0].company_id
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    const UnitMeasures = async (company_id) => {
        const result = await getUnitofMeasures(company_id, userData?.user_type_id);
        setSkeleton(true)
        for (let i = 0; i < result.data.data.length; i++) {
            if (result.data.data[i].is_active == 1) {
                setUnitMeasures(result.data.data[i].small_unit)
                unit_of_measures = result.data.data[i].small_unit;
            }

        }
    }

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }
    const containerconfiguration_data = new CustomStore({
        key: 'entity_sizes_id',
        load: async function (loadOptions) {
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                    params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                }
            });
            params += `entity_type_id=${container_id}&`
            params += `company_id=${companyId}&`
            params = params.slice(0, -1);
            let response = await getContainersConfigurationList(params);
            datagridRef.current.instance.cancelEditData()
            console.log('response', response)
            return response;

        }
    });
    //============================================== End =====================================================

    //========= This code is used for show the action header label and show the filter button ===========
    const onCellPrepared = (e) => {
        if (e.rowType == 'header' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<b>Action</b>";
        }
        if (e.rowType == 'filter' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close text-danger'></i></button>";
            e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
        }
    }
    //======================== End =====================================================================
    const _SingleRow = async () => {
        datagridRef.current.instance.addRow()
    }
    //====================== This function is used to save update data ======================
    const onSaving = React.useCallback((e) => {
        e.cancel = true;
        SaveBin(e.changes, e.component);

    }, []);
    const SaveBin = async (body, component) => {
        try {
            let data = body[0]
            if (body[0].type === 'insert') {
                if (data.data.base === decimal || data.data.depth === decimal || data.data.height === decimal) {
                    toast.error(<AlertMessage type='error' title={`Save ${container_name}`}
                        message="Please enter numeric value" />, { autoClose: false });
                } else {
                    let container_data = {
                        "size_name": data.data.size_name,
                        "suffix": data.data.suffix,
                        "base": data.data.base,
                        "depth": data.data.depth,
                        "height": data.data.height,
                        "entity_type": container_id,
                        "company_id": companyId,
                        "entity_unit_measures": unit_of_measures
                    }
                    console.log('container_data', container_data)
                    const result = await addConfiguration(container_data);
                    if (result.data['status'] === true) {
                        toast.success(<AlertMessage type='success' title={`Save ${container_name}`}
                            message={result.data['message']} />, { autoClose: 4000 });
                    }
                    else {
                        toast.error(<AlertMessage type='error' title={`Save ${container_name}`}
                            message={result.data['message']} />, { autoClose: false });
                    }
                    await component.refresh(true);
                    component.cancelEditData();
                    return result;
                }

            } else if (body[0].type === 'update') {
                if (data.data.base === decimal || data.data.depth === decimal || data.data.height === decimal) {
                    toast.error(<AlertMessage type='error' title={`Update ${container_name}`}
                        message="Please enter numeric value" />, { autoClose: false });
                } else {
                    let container_data = {
                        "entity_sizes_id": data.key,
                        "size_name": data.data.size_name,
                        "suffix": data.data.suffix,
                        "base": data.data.base,
                        "depth": data.data.depth,
                        "height": data.data.height,
                        "entity_type": container_id,
                        "company_id": companyId,
                        "entity_unit_measures": unit_of_measures
                    }
                    const result = await updateConfiguration(container_data, userData.user_master_id);
                    if (result.data['status'] === false) {
                        toast.success(<AlertMessage type='success' title={`Update ${container_name}`}
                            message={result.data['message']} />, { autoClose: 4000 });
                    }
                    else {
                        toast.error(<AlertMessage type='error' title={`Update ${container_name}`}
                            message={result.data['message']} />, { autoClose: false });
                    }
                    await component.refresh(true);
                    component.cancelEditData();
                    return result;
                }
            }
            else {
                SetEntitySizeId(body[0].key)
                setDelmodal(true)
            }
        }
        catch (error) {
            console.log(error)
        }
    }
    //================================ End ===============================================
    //===================== This modal is used for the delete ============================
    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }
    //===================== End ===========================================================
    //========================= This funccction is used for the delete particular row ===========
    const deleteRow = async () => {
        let container_type = Configuration.entityType.bin;
        const result = await deleteConfiguration(entitysizeid, container_id, userData.user_master_id);
        setDelmodal(!delmodal)
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title={`Delete ${container_name}`}
                message={result.data['message']} />, { autoClose: 4000 });
        }
        else {
            toast.error(<AlertMessage type='error' title={`Delete ${container_name}`}
                message={result.data['message']} />, { autoClose: false });
        }
    }
    //======================== End =====================================================
    const onEditorPreparing = (e) => {
        if (e.parentType === "dataRow" && e.dataField === "size_name") {
            e.editorOptions.onKeyPress = function (args) {
                var event = args.event;
                if (!/^[a-zA-Z ]*$/.test(String.fromCharCode(event.keyCode)))
                    event.preventDefault();
            }
        }
        if (e.parentType === "dataRow" && e.dataField === "suffix") {
            e.editorOptions.onKeyPress = function (args) {
                var event = args.event;
                if (!/^[a-zA-Z ]*$/.test(String.fromCharCode(event.keyCode)))
                    event.preventDefault();
            }
        }
        if (e.parentType == 'dataRow' && e.dataField == 'base') {
            console.log(e)
            e.editorOptions.onKeyPress = function (args) {
                var event = args.event;
                if (!/^0|[1-9,\.]\d*$/.test(String.fromCharCode(event.keyCode)))
                    event.preventDefault();
            }
            e.editorName = "dxTextBox"
        }
        if (e.parentType == 'dataRow' && e.dataField == 'depth') {
            e.editorOptions.onKeyPress = function (args) {
                var event = args.event;
                if (!/^0|[1-9,\.]\d*$/.test(String.fromCharCode(event.keyCode)))
                    event.preventDefault();
            }
            e.editorName = "dxTextBox"
        }
        if (e.parentType == 'dataRow' && e.dataField == 'height') {
            e.editorOptions.onKeyPress = function (args) {
                var event = args.event;
                if (!/^0|[1-9,\.]\d*$/.test(String.fromCharCode(event.keyCode)))
                    event.preventDefault();
            }
            e.editorName = "dxTextBox"
        }
    }
    const _handleValue = async (e) => {
        e.data['base'] = 0
        e.data['depth'] = 0
        e.data['height'] = 0
    }
    const maxLength = { maxLength: 4 }
    return (

        <>
            {(skeleton === false) ?
                (
                    <ContainerConfigurationSkeleton />

                ) : (
                    <>
                        <Container className="margin-top">
                            You can manage {container_name.toLowerCase()} container configuration here.
                <Card className="mb-3" className="margin-top">
                                <CardBody>
                                    <h5 className='ml-3'>Manage {container_name} Sizes</h5>
                                    <Row>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col className="ml-5">
                                            <div className="container-fluid margin-bottoms" >
                                                <ButtonGroup>
                                                    <Button outline onClick={() => _SingleRow()}>
                                                        <i className="fa fa-fw fa-plus"></i>
                                                    </Button>
                                                </ButtonGroup>
                                            </div>
                                        </Col>
                                    </Row>
                                    {/* Start DataGrid */}
                                    <DataGrid id="grid-container"
                                        showBorders={true}
                                        dataSource={containerconfiguration_data}
                                        ref={datagridRef}
                                        keyExpr="entity_sizes_id"
                                        onCellPrepared={onCellPrepared}
                                        remoteOperations={true}
                                        allowColumnReordering={true}
                                        columnHidingEnabled={true}
                                        onSaving={onSaving}
                                        rowAlternationEnabled={true}
                                        columnHidingEnabled={true}
                                        onKeyDown={(e) => {
                                            var $event = e.event;
                                            if ($event.ctrlKey && $event.keyCode === 13) {
                                                $event.preventDefault();
                                            }

                                        }}
                                        onToolbarPreparing={(e) => {
                                            e.toolbarOptions.visible = false
                                        }}
                                        onInitNewRow={(e) => {
                                            _handleValue(e)
                                        }}
                                        onEditorPreparing={onEditorPreparing}
                                    >
                                        <Editing
                                            mode="row"
                                            useIcons={true}
                                            allowAdding={true}
                                            allowUpdating={true}
                                            allowDeleting={true}
                                            confirmDelete={false}
                                            onKeyDown={false}
                                        >
                                        </Editing>
                                        <Paging defaultPageSize={10} />
                                        <Pager
                                            showPageSizeSelector={true}
                                            allowedPageSizes={[5, 10, 15]}
                                            showInfo={true} />
                                        <FilterRow visible={true} />
                                        <Column dataField="size_name" caption="Size" >
                                            <RequiredRule />
                                        </Column>
                                        <Column dataField="suffix" caption="Naming Suffix">
                                            <RequiredRule />
                                        </Column>
                                        <Column dataField="base" caption={`Breadth (${unitmeasures}.)`} editorOptions={maxLength} >
                                            <RequiredRule />
                                        </Column>
                                        <Column dataField="depth" caption={`Depth (${unitmeasures}.)`} editorOptions={maxLength}>
                                            <RequiredRule />
                                        </Column>
                                        <Column dataField="height" caption={`Height (${unitmeasures}.)`} editorOptions={maxLength}>
                                            <RequiredRule />
                                        </Column>
                                    </DataGrid>
                                    {/* End DataGrid */}
                                    <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this ${container_name.toLowerCase()}`}
                                        onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title={`Delete ${container_name}`} />
                                </CardBody>
                            </Card>

                        </Container>
                    </>
                )}
        </>
    )

}

export default ContainerConfigurations
