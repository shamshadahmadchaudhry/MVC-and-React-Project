import React, { useEffect, useRef, useState } from 'react';
import { useSelector } from 'react-redux';
import { Link, useHistory, useLocation } from 'react-router-dom';
import { Configuration } from '../../commoncomponents/configurationfile';
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    RequiredRule,
    Lookup
} from 'devextreme-react/data-grid';

import {
    Navbar,
    FormGroup,
    Container,
    Row, Col,
    DropdownToggle,
    ThemeConsumer,
    Nav,
    Button,
    ButtonGroup,
    UncontrolledButtonDropdown,
    DropdownMenu,
    DropdownItem,
    Card,
    CardBody,
} from '../../../components';
import { zoneTypes, fetchLayoutName } from '../../../services/layoutservices'
import { addBay } from '../../../services/warehousemanagementservice'
import ConfirmBox from '../../commoncomponents/confirmbox';
import AlertMessage from '../../commoncomponents/alertmessage';
import { toast } from 'react-toastify';
let bay_name = '';
const AddBay = ({ locationId, addressId, aisleId, aisle_name, no_of_bays }) => {

    const location = useLocation();
    const history = useHistory();
    toast.configure()


    //console.log('nom',no_of_bays)

    let numrowsToadd = 0;
    let no_of_records = 0;
    const datagridRef = useRef(null)
    const [isLoading, setIsLoading] = useState(false);
    const [zonetypes, setZonetypes] = useState([])
    const [addbayOptions, setAddbayOptions] = useState([])
    const [disable, setDisable] = useState(true)
    const [editmode, setEditmode] = useState('row')
    const [delmodal, setDelmodal] = useState(false)
    const [numrows, setNumrows] = useState(0)
    const [companyId, setCompanyId] = useState(location.state.company_id)
    const [delkey, setDelkey] = useState(0);
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [allbays, setAllbays] = useState(JSON.parse(localStorage.getItem('bays')) || []);
    const [noofbays, setNoofbays] = useState(location.state.no_of_bays);
    let container_type = Configuration.entityType.bay;

    locationId = location.state.location_id;
    addressId = location.state.address_id;
    aisleId = location.state.aisle_id;
    aisle_name = location.state.aisle_name;
    // no_of_bays = location.state.no_of_bays;

    //For popup
    const [action, setAction] = useState('')
    const [bayname, setBayname] = useState('')
    const [baynamepop, setBaynamepop] = useState('1')
    const [popupstate, setPopupstate] = useState(false)
    const [selectedzoneid, setSelectedzoneid] = useState(6)

    /*ADD BAY MODAL POP UP*/
    const togglePopup = () => {
        setPopupstate(!popupstate);
    }

    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }

    const saveBaypop = async () => {
        if (!bayname.match(Configuration.alphanumeric)) {
            toast.error(<AlertMessage type='error' title='Error Saving Bay'
                message={'Please provide valid bay name'} />, { autoClose: 4000 });
        }
        else if (selectedzoneid == 0) {
            toast.error(<AlertMessage type='error' title='Error Saving Bay'
                message={'Please select zone type'} />, { autoClose: 4000 });
        }
        else {
            let body = {
                "bays": [{ 'bay_name': bayname, 'warehouse_zone_type_id': selectedzoneid }], created_by: userData.user_master_id, warehouse_address_id: addressId,
                warehouse_location_id: locationId, company_id: companyId, warehouse_aisle_id: aisleId
            }
            const result = await addBay(body, container_type)
            if (result.data.message.includes('exists')) {
                toast.error(<AlertMessage type='error' title='Error Saving Bay'
                    message={result.data.message} />, { autoClose: 4000 });
                setBayname('')
            }
            else {
                toast.success(<AlertMessage type='success' title='Bay Saved'
                    message={result.data.message} />, { autoClose: 4000 });
            }
        }
    }

    const deleteRow = () => {
        let baysLeft = allbays.filter((bay) => {
            console.log(delkey)
            return bay.id !== delkey;
        })
        console.log(baysLeft)
        setAllbays(baysLeft)
        setDelmodal(!delmodal)
        toast.success(<AlertMessage type='success' title='Bay Deleted'
            message='Bay has been deleted Successfully' />, { autoClose: 4000 });
    }
    const laodZonetypes = async () => {
        let zonetypesResp = await zoneTypes()
        console.log('Respo ', zonetypesResp)
        setZonetypes(zonetypesResp)
    }
    const loadbayoptions = () => {
        let bay = '';
        let bayOptions = []
        for (let i = 2; i <= 10; i++) {
            if (i === 1) {
                bay = 'Bay'
            }
            else {
                bay = ' Bays'
            }
            bayOptions.push({
                id: i,
                name: 'Add ' + i + bay
            })
        }
        setAddbayOptions(bayOptions)
    }
    useEffect(() => {
        _handledropdownItem(noofbays)
        laodZonetypes()
        loadbayoptions()
    }, [])

    useEffect(() => {
        localStorage.setItem('bays', JSON.stringify(allbays))
    }, [allbays]);

    useEffect(() => {
        setCompanyId(CompanyListingStatus?.result?.response?.result[0].company_id)
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    const fetchShelfValue = async (id, aisleId) => {
        no_of_records = id
        const result = await fetchLayoutName(Configuration.entityType.bay, companyId, no_of_records, locationId, addressId, aisleId);
        //console.log('Result', result)
        return result;
    }

    //Add single Shelf
    const _SingleRow = async () => {
        if (allbays.length === 0) {
            const result = await fetchShelfValue(1, aisleId)
            datagridRef.current.instance.cancelEditData()
            bay_name = result.data[0]['bay_name']
            datagridRef.current.instance.addRow()
            setNumrows(1)
        } else {
            toast.warning(<AlertMessage type='warning' title='Save current data'
                message='Please Save current Bay data to add more' />, { autoClose: 4000 });
        }
    }
    const _handledropdownItem = async (id) => {
        if (allbays.length === 0) {
            setEditmode('batch')
            setDisable(false)
            setNumrows(id)
            numrowsToadd = parseInt(id)
            console.log('addd', numrowsToadd)
            const result = await fetchShelfValue(parseInt(id), aisleId)
            console.log('rez', result)
            datagridRef.current.instance.cancelEditData()
            for (var i = 0; i < id; i++) {
                bay_name = result.data[i]['bay_name']
                datagridRef.current.instance.addRow()
            }
        } else {
            toast.warning(<AlertMessage type='warning' title='Save current data'
                message='Please Save current Bay data to add more' />, { autoClose: 4000 });
        }
    }

    const _handleName = async (e) => {
        e.data['bay_name'] = bay_name
    }
    const SaveBay = async (body, component) => {
        if (body[0].type === 'insert') {
            let bay_name = '';
            let zone_type = '';
            for (let i = 0; i < numrows; i++) {
                allbays.push({ id: body[i].data.__KEY__, bay_name: body[i].data.bay_name, warehouse_zone_type: body[i].data.warehouse_zone_type })
                //setID(id+1)
            }
            localStorage.setItem('bays', JSON.stringify(allbays));
            setAllbays(JSON.parse(localStorage.getItem('bays')) || []);
            toast.success(<AlertMessage type='success' title='Bay Saved'
                message='Bay has been Saved Successfully' />, { autoClose: 4000 });
            // await component.refresh(true);
            // component.cancelEditData();
            datagridRef.current.instance.cancelEditData();
            setEditmode('row');

        }
        else if (body[0].type === 'update') {
            let bay_name = '';
            let warehouse_zone_type = '';
            console.log('e', body)
            console.log('Update')
            if ('warehouse_zone_type' in body[0].data) {
                warehouse_zone_type = body[0].data.warehouse_zone_type
            }
            if ('bay_name' in body[0].data) {
                bay_name = body[0].data.bay_name
            }
            console.log('Bay', bay_name)
            console.log('Type', warehouse_zone_type)
            let updatedbay = allbays.map(bay => {
                if (bay.id === body[0].key.id) {
                    if (bay_name.length > 0) {
                        console.log('Updated bay', bay_name)
                        bay.bay_name = bay_name;
                    }
                    if (warehouse_zone_type.length > 0) {
                        console.log('Updated zone')
                        bay.warehouse_zone_type = warehouse_zone_type
                    }
                }
                return bay;
            })
            setAllbays(updatedbay)
            toast.success(<AlertMessage type='success' title='Bay Updated'
                message='Bay has been deleted Successfully' />, { autoClose: 4000 });
        }
        else {
            setDelkey(body[0].key.id)
            setDelmodal(true)
        }
    }

    const bay_data = allbays;
    return (
        <div>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <h4>Add bays to aisle {location.state.aisle_name}</h4>
                <ThemeConsumer>
                    {({ color }) => (
                        <div>
                            <Nav className='d-md-block'>
                                <span className="save-padding-add3plcompany">
                                    <Button outline color="secondary" onClick={() => {
                                        setAllbays([]);
                                        setTimeout(() => {
                                            history.push({
                                                pathname: '/warehouse/storageunit',
                                                state: {
                                                    locationcolumnstate: location.state.locationvisible,
                                                    shelfcolumnstate: location.state.shelfvisible
                                                }
                                            })
                                        }, 100);
                                    }}> Cancel </Button>

                                </span>
                                <Button type="button" disabled={allbays.length > 0 ? false : true} color={color} onClick={
                                    async () => {
                                        setIsLoading(true)
                                        //Loop through and save warehouse_zone_type_id in objects
                                        let zone_type_ids = allbays.map(bay => {
                                            for (let t = 0; t < zonetypes.length; t++) {
                                                if (bay.warehouse_zone_type == zonetypes[t].warehouse_zone_type) {
                                                    bay.warehouse_zone_type_id = zonetypes[t].warehouse_zone_type_id;
                                                }
                                            }
                                        })
                                        let body = {
                                            "bays": allbays, created_by: userData.user_master_id, warehouse_address_id: addressId,
                                            warehouse_location_id: locationId, company_id: companyId, warehouse_layout_aisle_id: location.state.aisle_id
                                        }
                                        //console.log('FINAL',body)
                                        const result = await addBay(body, container_type)
                                        if (result.data.message.includes('exists')) {
                                            toast.error(<AlertMessage type='error' title='Error Saving Bay'
                                                message={result.data.message} />, { autoClose: 4000 });
                                        }
                                        else {
                                            toast.success(<AlertMessage type='success' title='Bay Saved'
                                                message={result.data.message} />, { autoClose: 4000 });
                                            setAllbays([]);
                                        }
                                        console.log('Response', result);
                                        setIsLoading(false)
                                    }} >
                                    <i className="fa fa-floppy-o" aria-hidden="true"></i>  {'Save'}
                                    {isLoading && (
                                        <i
                                            className="fa fa-spinner fa-spin ml-1"
                                        />)}
                                </Button>
                            </Nav>
                        </div>
                    )}
                </ThemeConsumer>
            </Navbar>
            <Container>
                <p className='mt-3'>You can add multiple bay storage units here.</p>
                <Card className="mb-3" className="margin-top">
                    <CardBody>
                        <h5>Add Multiple Bays(s)</h5>
                        <div className="container-fluid">
                            <Row className='ml-5'>
                                <Col></Col>
                                <Col></Col>
                                <Col></Col>
                                <Col></Col>
                                <Col className='ml-5'>
                                    <ButtonGroup className='mb-2'>
                                        <Button outline className='ml-2' onClick={() => _SingleRow()}>
                                            <i className="fa fa-fw fa-plus"></i>
                                        </Button>
                                        <UncontrolledButtonDropdown direction="down">
                                            <DropdownToggle color="secondary" outline caret />
                                            <DropdownMenu right >
                                                {addbayOptions && addbayOptions.length > 0 ? (addbayOptions.map((item, index) => (
                                                    <DropdownItem key={index} onClick={() => _handledropdownItem(item.id)}>
                                                        {item.name}
                                                    </DropdownItem>
                                                ))) : (
                                                        ''
                                                    )}
                                            </DropdownMenu>
                                        </UncontrolledButtonDropdown>
                                        <Button outline className='ml-2' onClick={() => {
                                            datagridRef.current.instance.saveEditData();
                                            setNoofbays(0);

                                        }} disabled={disable}>
                                            <i className="dx-icon-save"></i>
                                        </Button>
                                        <Button outline onClick={() => { datagridRef.current.instance.cancelEditData(); setDisable(true); setEditmode('row') }} disabled={disable}>
                                            <i className="dx-icon-revert"></i>
                                        </Button>
                                    </ButtonGroup>
                                </Col>
                            </Row>
                        </div>
                        <div className="container-fluid">
                            <DataGrid id="grid-container"
                                showBorders={true}
                                dataSource={bay_data}
                                columnHidingEnabled={true}
                                ref={datagridRef}
                                onCellPrepared={(e) => {
                                    if (e.rowType == 'header' && e.column.command == "edit") {
                                        e.cellElement.innerHTML = "<b>Action</b>";
                                    }
                                    if (e.rowType == 'filter' && e.column.command == "edit") {
                                        e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1 ml-2'>Reset Filters <i class='fa fa-close text-danger'></i></button>";
                                        e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
                                    }
                                }}
                                remoteOperations={true}
                                rowAlternationEnabled={true}
                                allowColumnReordering={true}
                                onToolbarPreparing={(e) => {
                                    e.toolbarOptions.visible = false
                                }}
                                onSaving={(e) => {
                                    e.cancel = true;
                                    SaveBay(e.changes, e.component)
                                }}
                                onInitNewRow={(e) => {
                                    _handleName(e)

                                }}
                                onRowRemoving={async (e) => {
                                    e.cancel = true;
                                }}
                            >
                                <Editing
                                    mode={editmode}
                                    useIcons={true}
                                    allowDeleting={true}
                                    allowUpdating={true}
                                    confirmDelete={false}
                                >
                                </Editing>
                                <Paging defaultPageSize={10} />
                                <Pager
                                    showPageSizeSelector={true}
                                    allowedPageSizes={[10, 15, 20]}
                                    showInfo={true} />
                                <FilterRow visible={true} />
                                <Column dataField='bay_name' caption="Bay name">
                                    <RequiredRule />
                                </Column>
                                <Column dataField="warehouse_zone_type" caption="Zone type" >
                                    <RequiredRule />
                                    <Lookup dataSource={zonetypes} valueExpr="warehouse_zone_type" displayExpr="warehouse_zone_type" />
                                </Column>
                            </DataGrid>
                            <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this Bay`}
                                onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete Bay" />
                        </div>
                    </CardBody>
                </Card>
            </Container>
        </div>
    )
}

export default AddBay
