import React, { useEffect, useRef, useState } from 'react';
import { useSelector } from 'react-redux';
import { Link, useHistory, useLocation } from 'react-router-dom';
import { Configuration } from '../../commoncomponents/configurationfile';
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    RequiredRule,
    Lookup
} from 'devextreme-react/data-grid';

import {
    Navbar,
    FormGroup,
    Container,
    Row, Col,
    DropdownToggle,
    ThemeConsumer,
    Nav,
    Button,
    ButtonGroup,
    UncontrolledButtonDropdown,
    DropdownMenu,
    DropdownItem,
    Card,
    CardBody,
} from '../../../components';
import { zoneTypes, fetchLayoutName } from '../../../services/layoutservices'
import { addBay } from '../../../services/warehousemanagementservice'
import ConfirmBox from '../../commoncomponents/confirmbox';
import AlertMessage from '../../commoncomponents/alertmessage';
import { toast } from 'react-toastify';
let bay_name = '';
const AddBay = ({ locationId, addressId, aisleId, aisle_name, no_of_bays }) => {

    const location = useLocation();
    console.log('location...', location)
    const history = useHistory();
    toast.configure()


    //console.log('nom',no_of_bays)

    let numrowsToadd = 0;
    let no_of_records = 0;
    const datagridRef = useRef(null)
    const [isLoading, setIsLoading] = useState(false);
    const [zonetypes, setZonetypes] = useState([])
    const [addbayOptions, setAddbayOptions] = useState([])
    const [disable, setDisable] = useState(true)
    const [editmode, setEditmode] = useState('row')
    const [delmodal, setDelmodal] = useState(false)
    const [numrows, setNumrows] = useState(0)
    const [companyId, setCompanyId] = useState(location.state.company_id)
    const [delkey, setDelkey] = useState(0);
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [allbays, setAllbays] = useState(JSON.parse(localStorage.getItem('bays')) || []);
    const [noofbays, setNoofbays] = useState(location.state.no_of_bays);
    let container_type = Configuration.entityType.bay;

    locationId = location.state.location_id;
    addressId = location.state.address_id;
    aisleId = location.state.aisle_id;
    aisle_name = location.state.aisle_name;
    // no_of_bays = location.state.no_of_bays;

    //For popup
    const [action, setAction] = useState('')
    const [bayname, setBayname] = useState('')
    const [baynamepop, setBaynamepop] = useState('1')
    const [popupstate, setPopupstate] = useState(false)
    const [selectedzoneid, setSelectedzoneid] = useState(6)

    /*ADD BAY MODAL POP UP*/
    const togglePopup = () => {
        setPopupstate(!popupstate);
    }

    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }



    const deleteRow = () => {
        let baysLeft = allbays.filter((bay) => {
            console.log(delkey)
            return bay.id !== delkey;
        })
        console.log(baysLeft)
        setAllbays(baysLeft)
        setDelmodal(!delmodal)
        toast.success(<AlertMessage type='success' title='Bay Deleted'
            message='Bay has been deleted Successfully' />, { autoClose: 4000 });
    }
    const laodZonetypes = async () => {
        let zonetypesResp = await zoneTypes()
        console.log('Respo ', zonetypesResp)
        setZonetypes(zonetypesResp)
    }
    const loadbayoptions = () => {
        let bay = '';
        let bayOptions = []
        for (let i = 2; i <= 10; i++) {
            if (i === 1) {
                bay = 'Bay'
            }
            else {
                bay = ' Bays'
            }
            bayOptions.push({
                id: i,
                name: 'Add ' + i + bay
            })
        }
        setAddbayOptions(bayOptions)
    }
    useEffect(() => {
        _handledropdownItem(noofbays)
        laodZonetypes()
        loadbayoptions()
    }, [])

    useEffect(() => {
        localStorage.setItem('bays', JSON.stringify(allbays))
    }, [allbays]);

    useEffect(() => {
        setCompanyId(CompanyListingStatus?.result?.response?.result[0].company_id)
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    const fetchShelfValue = async (id, aisleId) => {
        no_of_records = id
        const result = await fetchLayoutName(Configuration.entityType.bay, companyId, no_of_records, locationId, addressId, aisleId);
        //console.log('Result', result)
        return result;
    }

    //Add single Shelf
    const _SingleRow = async () => {
        setAllbays([])
        setEditmode('batch')
        const result = await fetchShelfValue(1, aisleId)
        datagridRef.current.instance.cancelEditData()
        bay_name = result.data[0]['bay_name']
        datagridRef.current.instance.addRow()
        setNumrows(1)
    }
    const _handledropdownItem = async (id) => {
        setEditmode('batch')
        setDisable(false)
        setNumrows(id)
        numrowsToadd = parseInt(id)
        console.log('addd', numrowsToadd)
        const result = await fetchShelfValue(parseInt(id), aisleId)
        console.log('rez', result)
        datagridRef.current.instance.cancelEditData()
        for (var i = 0; i < id; i++) {
            bay_name = result.data[i]['bay_name']
            datagridRef.current.instance.addRow()
        }
    }

    const _handleName = async (e) => {
        e.data['bay_name'] = bay_name
    }
    const SaveBay = async (body, component) => {
        console.log('body', body)
        if (body.length > 0) {
            let data = body;
            if (body[0].type === 'insert') {
                setIsLoading(true)
                for (let i = 0; i < data.length; i++) {
                    allbays.push({ id: data[i].data.__KEY__, bay_name: data[i].data.bay_name, warehouse_zone_type_id: data[i].data.warehouse_zone_type_id })
                }
                let body = {
                    "bays": allbays, created_by: userData.user_master_id, warehouse_address_id: addressId,
                    warehouse_location_id: locationId, company_id: companyId, warehouse_layout_aisle_id: location.state.aisle_id
                }
                const result = await addBay(body, container_type)
                if (result.data.message.includes('exists')) {
                    toast.error(<AlertMessage type='error' title='Error Saving Bay'
                        message={result.data.message} />, { autoClose: 4000 });
                }
                else {
                    toast.success(<AlertMessage type='success' title='Bay Saved'
                        message={result.data.message} />, { autoClose: 4000 });
                    setAllbays([]);

                }
                setIsLoading(false)
                setEditmode('row');

            }
        } else {
            toast.error(<AlertMessage type='error' title='Bay'
                message='Please add atleast one bays.' />, { autoClose: 4000 });
        }
    }

    const bay_data = allbays;
    return (
        <div>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <h4>Add bays to aisle {location.state.aisle_name}</h4>
                <ThemeConsumer>
                    {({ color }) => (
                        <div>
                            <Nav className='d-md-block'>
                                <span className="save-padding-add3plcompany">
                                    <Button outline color="secondary" onClick={() => {
                                        setAllbays([]);
                                        setTimeout(() => {
                                            history.push({
                                                pathname: '/warehouse/storageunit',
                                                state: {
                                                    locationcolumnstate: location.state.locationvisible,
                                                    shelfcolumnstate: location.state.shelfvisible,
                                                    warehouse_location_id: location.state.location_id,
                                                    warehouse_address_id: location.state.address_id,
                                                    warehouse_location_name: location.state.warehouse_location_name,
                                                    warehouse_address_name: location.state.warehouse_address_name,
                                                }
                                            })
                                        }, 100);
                                    }}> Cancel </Button>

                                </span>
                                <Button color={color} className='ml-2' onClick={() => {
                                    datagridRef.current.instance.saveEditData();

                                }} disabled={isLoading}>
                                    <i className="fa fa-floppy-o" aria-hidden="true"></i>  {'Save'}
                                    {isLoading && (
                                        <i
                                            className="fa fa-spinner fa-spin ml-1"
                                        />)}
                                </Button>
                            </Nav>
                        </div>
                    )}
                </ThemeConsumer>
            </Navbar>
            <Container>
                <p className='mt-3'>You can add multiple bay storage units here.</p>
                <Card className="mb-3" className="margin-top">
                    <CardBody>
                        <h5>Add Multiple Bays(s)</h5>
                        <div className="container-fluid">
                            <Row className='ml-5'>
                                <Col></Col>
                                <Col></Col>
                                <Col></Col>
                                <Col></Col>
                                <Col className='ml-5'>
                                    <ButtonGroup className='mb-2'>
                                        <Button outline className='ml-2' onClick={() => _SingleRow()}>
                                            <i className="fa fa-fw fa-plus"></i>
                                        </Button>
                                        <UncontrolledButtonDropdown direction="down">
                                            <DropdownToggle color="secondary" outline caret />
                                            <DropdownMenu right >
                                                {addbayOptions && addbayOptions.length > 0 ? (addbayOptions.map((item, index) => (
                                                    <DropdownItem key={index} onClick={() => _handledropdownItem(item.id)}>
                                                        {item.name}
                                                    </DropdownItem>
                                                ))) : (
                                                        ''
                                                    )}
                                            </DropdownMenu>
                                        </UncontrolledButtonDropdown>
                                        {/* <Button outline className='ml-2' onClick={() => {
                                            datagridRef.current.instance.saveEditData();
                                            setNoofbays(0);

                                        }} disabled={disable}>
                                            <i className="dx-icon-save"></i>
                                        </Button> */}
                                        <Button outline onClick={() => { datagridRef.current.instance.cancelEditData(); setDisable(true); setEditmode('row') }} disabled={disable}>
                                            <i className="dx-icon-revert"></i>
                                        </Button>
                                    </ButtonGroup>
                                </Col>
                            </Row>
                        </div>
                        <div className="container-fluid">
                            <DataGrid id="grid-container"
                                showBorders={true}
                                dataSource={bay_data}
                                columnHidingEnabled={true}
                                ref={datagridRef}
                                onCellPrepared={(e) => {
                                    if (e.rowType == 'header' && e.column.command == "edit") {
                                        e.cellElement.innerHTML = "<b>Action</b>";
                                    }
                                    if (e.rowType == 'filter' && e.column.command == "edit") {
                                        e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1 ml-2'>Reset Filters <i class='fa fa-close text-danger'></i></button>";
                                        e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
                                    }
                                }}
                                remoteOperations={true}
                                rowAlternationEnabled={true}
                                allowColumnReordering={true}
                                onToolbarPreparing={(e) => {
                                    e.toolbarOptions.visible = false
                                }}
                                onSaving={(e) => {
                                    e.cancel = true;
                                    SaveBay(e.changes, e.component)
                                }}
                                onInitNewRow={(e) => {
                                    _handleName(e)

                                }}
                                onRowRemoving={async (e) => {
                                    e.cancel = true;
                                }}
                            >
                                <Editing
                                    mode={editmode}
                                    useIcons={true}
                                    allowDeleting={true}
                                    allowUpdating={true}
                                    confirmDelete={false}
                                >
                                </Editing>
                                <Paging defaultPageSize={10} />
                                <Pager
                                    showPageSizeSelector={true}
                                    allowedPageSizes={[10, 15, 20]}
                                    showInfo={true} />
                                <FilterRow visible={true} />
                                <Column dataField='bay_name' caption="Bay name">
                                    <RequiredRule />
                                </Column>
                                <Column dataField="warehouse_zone_type_id" caption="Zone type" >
                                    <RequiredRule />
                                    <Lookup dataSource={zonetypes} valueExpr="warehouse_zone_type_id" displayExpr="warehouse_zone_type" />
                                </Column>
                            </DataGrid>
                            <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this Bay`}
                                onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete Bay" />
                        </div>
                    </CardBody>
                </Card>
            </Container>
        </div>
    )
}

export default AddBay
