import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as yup from 'yup';
import React, { useState, useRef, useEffect } from 'react';
import { useHistory, Link, useLocation } from "react-router-dom";
import { useSelector } from 'react-redux'
import AddBaypopup from './addBaypopup';
import { Configuration } from '../../commoncomponents/configurationfile';
import DataGrid, {
    Column,
    Editing,
    Paging,
    Pager,
    FilterRow,
    ColumnChooser,
    GroupPanel
} from 'devextreme-react/data-grid';
import CustomStore from 'devextreme/data/custom_store';
import {
    Navbar,
    FormGroup,
    Row, Col,
    Button,
    Nav,
    Card,
    CardBody,
    Modal, CardTitle,
    ModalHeader, ModalBody,
    ModalFooter, InputGroupAddon,
    ThemeConsumer, InputGroup,
    Label,
    DropdownToggle,
    UncontrolledButtonDropdown, DropdownMenu, DropdownItem,
} from '../../../components';
import {
    getWarehouseLocationList,
    getBuildingDetailsList,
    addBay
} from '../../../services/warehousemanagementservice';
import { getEntityList, getBinList, getContainerTypeList } from '../../../services/binservice';
import { fetchContainerName } from '../../../services/containerservice';
import {
    temporaryWarehouseStorageUnit, addStorageUnitLocation, addStorageUnitContainercons,
    updateTempLocationStorageUnit, deleteTemporaryWarehouseStorageUnit, addTempLocationStorageUnit
} from '../../../services/storageunitservices';
import '../../../styles/common.scss';
import LayoutsSketeon from '../skeleton/layoutsskeleton'
import { toast } from 'react-toastify';
import AlertMessage from '../../commoncomponents/alertmessage';
import { zoneTypes } from '../../../services/layoutservices'
import { Typeahead } from 'react-bootstrap-typeahead';

import ConfirmBox from '../../../routes/commoncomponents/confirmbox';


const LocationStorageUnitPreview = () => {
    const Datagridref = useRef(null)
    let location = useLocation()
    console.log('location...', location)
    toast.configure()
    const history = useHistory();
    const [layoutTypeId, setLayoutTypeId] = useState(1)
    const [companyId, setCompanyId] = useState(0)
    const [locations, setLocations] = useState([])
    const [buildings, setBuildings] = useState([])
    const [activelocationId, setActivelocationId] = useState(0)
    const [activeaddressId, setActiveaddressId] = useState(0);
    const [aisleId, setAisleId] = useState(0);
    const [skeleton, setSkeleton] = useState(false)
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [delete_count, setDeleteCount] = useState(0)
    const [skip, setSkip] = useState(true)
    let editmode = 'row';
    let no_of_records = 1;
    //Bay
    //For popup
    const [bayname, setBayname] = useState('')

    const [zonetypes, setZonetypes] = useState([])
    //Shelf
    //For popup
    const [shelfname, setShelfname] = useState('')
    const [aislename, setAislename] = useState('')

    //Start state implementation for add new location storage unit
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [showHide, setShowHide] = useState(false);
    const [editShowHide, setEditShowHide] = useState(false);
    const [modal, setModal] = useState(false);
    const [editmodal, setEditModal] = useState(false);
    const [containerType, setContainerType] = useState([]);
    const [options, setoptions] = useState([]);
    const [boxSizeList, setBoxSizeList] = useState([]);
    const [locationStorageUnitId, setLocationStorageUnitId] = useState(0);
    const [locationStorateUnitName, setlocationStorateUnitName] = useState('');
    const [clearContainerAssociation, setclearContainerAssociation] = useState(false);
    const [locationBayId, setLocationBayId] = useState('');
    const [locationShelfId, setLocationShelfId] = useState('');
    const [isDisabled, setisDisabled] = useState(false);
    const [valid_count, setValidCount] = useState(0);
    const [invalid_count, setInValidCount] = useState(0);
    const [records_type, setRecordsType] = useState(0)
    const [locationType, setLocationType] = useState('Select Location')
    const [addressType, setAddressType] = useState('Select Address')
    const [isselect, setIsSelect] = useState(false)
    const [locationDetails, setLocationDetails] = useState({
        location_name: '', container_type_id: '', bay_storage_unit_id: 0,
        container_id: '', container_name: '', shelf_storage_unit_id: 0,
        entity_size_id: 0, warehouse_layout_aisle_id: 0,
    });
    const [loader, setLoader] = useState(false);
    const [showHidePopupControl, setShowHidePopupControl] = useState('')
    const [delmodal, setdelmodal] = useState(false)

    const resetLocationState = () => {
        setLocationDetails({
            ...locationDetails,
            container_type_id: '', bay_storage_unit_id: 0,
            container_id: '', container_name: '', shelf_storage_unit_id: 0,
            entity_size_id: 0, warehouse_layout_aisle_id: 0,
        });
    }

    const toggleAdd = async (bay_name, shelf_name, warehouse_aisle_name, bay_id, shelf_id, aisle_id,
        location_name, storage_unit_location_id, container_id, container_name, container_type_id, location_address, is_edit) => {

        resetLocationState();
        console.log('Datagridref.current.instance:->', Datagridref.current.instance);

        if (modal === false) {
            loadContainerType();
            if (!is_edit) {
                setShowHidePopupControl('assocontainer');
                fetchLocationName();
            } else {
                await bindContainer(container_type_id.toString());
                setLocationDetails({
                    ...locationDetails,
                    location_name: location_name,
                    container_type_id: container_type_id,
                    container_id: container_id,
                    container_name: container_name
                });
                setShowHidePopupControl('clearassociation');
                setisDisabled(true);
            }

            if (bay_name && shelf_name && warehouse_aisle_name) {
                setAislename(warehouse_aisle_name);
                setBayname(bay_name);
                setShelfname(shelf_name);
                setLocationShelfId(shelf_id)
                setLocationBayId(bay_id);
                setAisleId(aisle_id);
                setLocationStorageUnitId(storage_unit_location_id);
                setlocationStorateUnitName(location_name);
                setEditModal(is_edit)
            }
        }
        setModal(!modal);
    }

    const cancelPopup = (resetForm) => {
        if (resetForm) {
            resetForm();
        }
        setEditModal(false);
        setEditShowHide(false);
        setModal(!modal);
        setShowHide(false);
        resetLocationState();
        setisDisabled(false);
        setclearContainerAssociation(false);
    }

    const bindContainer = async (containerType) => {
        loadContainerSize(containerType);
        if (showHide) {
            fetchContainerNameDetails(containerType);
        }
        setLocationDetails({ ...locationDetails, container_type_id: containerType });
        let params = '';
        params += `?container_type=${containerType}&`
        params += `warehouse_location_id=${4}`
        let container_result = await getBinList(params);
        let arrayContainer = []
        if (containerType === Configuration.entityType.bin.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_bin_id;
                obj.container_name = item.bin_name;
                arrayContainer.push(obj)
            });
        } else if (containerType === Configuration.entityType.box.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_box_id;
                obj.container_name = item.box_name;
                arrayContainer.push(obj)
            });
        } else if (containerType === Configuration.entityType.cart.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_cart_id;
                obj.container_name = item.cart_name;
                arrayContainer.push(obj)
            });
        } else if (containerType === Configuration.entityType.pallete.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_pallete_id;
                obj.container_name = item.pallete_name;
                arrayContainer.push(obj)
            });
        } else if (containerType === Configuration.entityType.tote.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_tote_id;
                obj.container_name = item.tote_name;
                arrayContainer.push(obj)
            });
        }
        console.log('arrayContainer', arrayContainer)
        setoptions(arrayContainer);
    }

    const loadContainerType = async () => {
        let company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        const result = await getEntityList(`?company_id=${company_id}`);
        setContainerType(result.data.result)
    }

    const loadContainerSize = async (containerType) => {
        const result = await getContainerTypeList(containerType);
        setBoxSizeList(result.data.result)
    }

    const setContainerSizeId = async (e) => {
        setLocationDetails({ ...locationDetails, entity_size_id: e });
    }

    const fetchLocationName = async () => {
        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        const result = await fetchContainerName(Configuration.entityType.location, company_id, 1, 4);
        if (result) {
            setLocationDetails({ ...locationDetails, location_name: result.data[0]['location_name'] });
        }
    }

    const fetchContainerNameDetails = async (container_type_id) => {
        //setLocationDetails({ ...locationDetails, container_name: '' })
        let entity_name = ''
        if (container_type_id === Configuration.entityType.bin.toString()) {
            entity_name = 'bin_name';
        }
        else if (container_type_id === Configuration.entityType.box.toString()) {
            entity_name = 'box_name';
        }
        else if (container_type_id === Configuration.entityType.cart.toString()) {
            entity_name = 'cart_name';
        }
        else if (container_type_id === Configuration.entityType.pallete.toString()) {
            entity_name = 'pallete_name';
        }
        else if (container_type_id === Configuration.entityType.tote.toString()) {
            entity_name = 'tote_name';
        }

        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        const result = await fetchContainerName(container_type_id, company_id, 1, 4);
        if (result) {
            setLocationDetails({ ...locationDetails, container_name: result.data[0][entity_name], container_type_id: container_type_id });
        }
    }

    const saveLocation = async (values) => {
        let company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        let entity_name = locationDetails.container_type_id === Configuration.entityType.bin.toString() ? 'container_bin_id' :
            locationDetails.container_type_id === Configuration.entityType.box.toString() ? 'container_box_id' :
                locationDetails.container_type_id === Configuration.entityType.cart.toString() ? 'container_cart_id' :
                    locationDetails.container_type_id === Configuration.entityType.pallete.toString() ? 'container_pallete_id' :
                        locationDetails.container_type_id === Configuration.entityType.tote.toString() ? 'container_tote_id' : '';
        let container_id = locationDetails.container_id;
        if (showHide) {
            let body = {
                "containers":
                    [{ "container_name": locationDetails.container_name, entity_size_id: locationDetails.entity_size_id }]
                , created_by: userData.user_master_id, warehouse_location_id: activelocationId, company_id: company_id
            }
            const result = await addStorageUnitContainercons(body, locationDetails.container_type_id);
            if (result.data.status) {
                if (result.data.container_id.length > 0) {
                    container_id = result.data.container_id[0][entity_name]
                } else {
                    toast.error(<AlertMessage type='error' title='Container Error'
                        message={result.data.message} />, { autoClose: false });
                    return false;
                }
            }
        }

        let body = {
            locations: [
                {
                    "storage_unit_location_id": locationStorageUnitId,
                    "location_name": locationDetails.location_name,
                    "prefix": "0",
                    "value": parseInt(locationDetails.location_name),
                    "location_address": aislename + '-' + bayname + '-' + shelfname + '' + locationDetails.location_name,
                    "container_type_id": locationDetails.container_type_id,
                    "container_id": container_id,
                    "warehouse_layout_aisle_id": aisleId,
                    "bay_storage_unit_id": locationBayId,
                    "shelf_storage_unit_id": locationShelfId,
                    "is_clear_associate_container": clearContainerAssociation
                }],
            "created_by": userData.user_master_id,
            "warehouse_location_id": activelocationId,
            "warehouse_address_id": activeaddressId,
            "company_id": company_id
        }

        if (container_id || clearContainerAssociation) {
            if (locationStorageUnitId > 0) {
                const response = await updateTempLocationStorageUnit(Configuration.entityType.location, body)
                if (response.data['status'] === true) {
                    toast.success(<AlertMessage type='success' title='Update Box'
                        message={response.data['message']} />, { autoClose: 4000 });
                    setModal(!modal);
                    setLocationDetails({
                        location_name: '', container_type_id: '', bay_storage_unit_id: 0,
                        container_id: '', container_name: '', shelf_storage_unit_id: 0,
                        entity_size_id: 0, warehouse_layout_aisle_id: 0,
                    });
                    cancelPopup();
                    setclearContainerAssociation(false)
                }
                else {
                    toast.error(<AlertMessage type='error' title='Update Box'
                        message={response.data['message']} />, { autoClose: false });
                }
            } else {
                const response = await addStorageUnitLocation(body)
                if (response.data['status'] === true) {
                    toast.success(<AlertMessage type='success' title='Update Box'
                        message={response.data['message']} />, { autoClose: 4000 });
                    setModal(!modal);
                    setLocationDetails({
                        location_name: '', container_type_id: '', bay_storage_unit_id: 0,
                        container_id: '', container_name: '', shelf_storage_unit_id: 0,
                        entity_size_id: 0, warehouse_layout_aisle_id: 0,
                    });
                    cancelPopup();
                }
                else {
                    toast.error(<AlertMessage type='error' title='Update Box'
                        message={response.data['message']} />, { autoClose: false });
                }
            }
        } else {
            toast.error(<AlertMessage type='error' title='Container Error'
                message='Please select container' />, { autoClose: false });
        }
    }

    const singleSelections = (e) => {
        if (e && e.length) {
            setLocationDetails({ ...locationDetails, container_name: e[0].container_name, container_id: e[0].container_id });
        }
    }

    const showNewContainer = () => {
        if (!showHide) {
            setLocationDetails({
                ...locationDetails,
                container_id: '',
                container_name: '',
                container_type_id: ''
            });
            fetchContainerNameDetails(locationDetails.container_type_id.toString());
        }
        const showhidePopup = showHidePopupControl === 'newcontainer' ? 'assocontainer' : 'newcontainer'
        setShowHidePopupControl(showhidePopup);
        setShowHide(!showHide)
    }

    const showNewContainerEdit = () => {
        if (!showHide) {
            setLocationDetails({
                ...locationDetails,
                container_id: '',
                container_name: '',
                container_type_id: ''
            });
            fetchContainerNameDetails(locationDetails.container_type_id.toString());
        }
        const showhidePopup = showHidePopupControl === 'clearassociation' ? 'assocontainer'
            : showHidePopupControl === 'assocontainer' ? 'newcontainer' : 'assocontainer';
        setShowHidePopupControl(showhidePopup);
        setShowHide(!showHide)
    }

    const clearContainerAssociationWithLocation = () => {
        setLocationDetails({
            ...locationDetails,
            container_type_id: '',
            container_id: '',
            container_name: ''
        });
        setShowHidePopupControl('assocontainer');
        setisDisabled(false);
        setclearContainerAssociation(true);
        setEditShowHide(!editShowHide);
    }

    const onInputChange = (e) => {
        setLocationDetails({
            ...locationDetails,
            container_name: e
        });
    }

    const onLocationInputChange = (e) => {
        setLocationDetails({
            ...locationDetails,
            location_name: e
        });
    }

    const toggledelModal = (location_storage_id) => {
        setLocationStorageUnitId(location_storage_id);
        setdelmodal(!delmodal);
    }

    const deleteRow = async () => {
        const result = await deleteTemporaryWarehouseStorageUnit(Configuration.entityType.location, locationStorageUnitId, userData.user_master_id);
        setdelmodal(!delmodal)
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title='Delete Location Storage Unit'
                message={result.data['message']} />, { autoClose: 4000 });
        }
        else {
            toast.error(<AlertMessage type='error' title='Delete Location Storage Unit'
                message={result.data['message']} />, { autoClose: false });
        }
    }
    //End state implementation for location storage unit

    const laodZonetypes = async () => {
        let zonetypesResp = await zoneTypes()
        console.log('Respo ', zonetypesResp)
        setZonetypes(zonetypesResp)
    }

    useEffect(() => {
        laodZonetypes();
        loadContainerType();

    }, [])

    const _handleSaveStorageUnitData = async () => {
        setLoader(true)
        const result = await addTempLocationStorageUnit(Configuration.entityType.location);
        if (result.data['status'] === true) {
            // toast.success(<AlertMessage type='success' title='Save Location'
            //     message={result.data['message']} />, { autoClose: 4000 });
            // setLoader(false);
            history.push('warehouse/storageunit');
        }
        else {
            toast.error(<AlertMessage type='error' title='Save Location'
                message={result.data['message']} />, { autoClose: false });
            setLoader(false)
        }
    }

    useEffect(() => {
        setCompanyId(CompanyListingStatus?.result?.response?.result[0].company_id)
        let company_id = CompanyListingStatus?.result?.response?.result[0].company_id
        WarehouseLocations(company_id)
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    //Load buildings
    const loadBuildings = async (locationId) => {
        let params = `?warehouse_location_id=${locationId}`
        let buildingResp = await getBuildingDetailsList(params)
        setSkeleton(true)
        setBuildings(buildingResp.data)
        if (location.state != null && isselect === false) {
            setAddressType(location.state.warehouse_address_name)
            setActiveaddressId(location.state.warehouse_address_id)
        } else {
            setAddressType(buildingResp.data[0].building_alias)
            setActiveaddressId(buildingResp.data[0].warehouse_address_id)
        }
        //setActiveaddressId(buildingResp.data[0].warehouse_address_id)
    }
    //Load warehouse locations
    const WarehouseLocations = async (company_id) => {
        let params = `?company_id=${company_id}`
        let response = await getWarehouseLocationList(params)
        //Load Buildings for First warehouse location
        if (location.state != null) {
            setLocationType(location.state.warehouse_location_name)
            loadBuildings(location.state.warehouse_location_id)
            setActivelocationId(location.state.warehouse_location_id)
        } else {
            setLocationType(response.data[0].location_name)
            loadBuildings(response.data[0].warehouse_location_id)
            setActivelocationId(response.data[0].warehouse_location_id)
        }
        // loadBuildings(response.data[0].warehouse_location_id)
        // setActivelocationId(response.data[0].warehouse_location_id)
        setLocations(response.data)
        return response.data
    }

    useEffect(() => {
        setIsSelect(true)
        setAddressType('')
    }, [activelocationId])
    const _handleOnClick = (e) => {
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setLocationType(str)
        }
        else {
            setLocationType(e[1].name)
        }
        setActivelocationId(e[0].id)
        loadBuildings(e[0].id);
    }
    const _handlebuildingOnClick = (e) => {
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setAddressType(str)
        }
        else {
            setAddressType(e[1].name)
        }
        setActiveaddressId(e[0].id);
    }

    useEffect(() => {
        setLayoutTypeId(Configuration.entityType.zone)
    }, [])

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }

    const storageunit_data = new CustomStore({
        key: 'storage_unit_location_id',
        load: async function (loadOptions) {
            let count = 0;
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (skip === true) {
                    if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                        params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                    }
                } else {
                    if (count === 0) {
                        params += `skip=0&take=10&requireTotalCount=true&totalSummary=[]&`;
                    }
                }
                count++;
            });
            params += `warehouse_location_id=${activelocationId}&`
            params += `company_id=${companyId}&`
            params += `warehouse_address_id=${activeaddressId}&`
            params += `container_type=${Configuration.entityType.location}&`
            params += `validate_type=${records_type}&`
            params = params.slice(0, -1);
            let response = await temporaryWarehouseStorageUnit(params);
            setValidCount(response.validCount)
            setInValidCount(response.invalidCount)
            setDeleteCount(response.deleteCount)
            return response;

        },
        update: async (key, values) => {
        }
    })

    //Edit Delete Btn
    const editdelBtn = (e) => {
        return (
            <>
                <div>
                    <Button outline className='  b-0 p-0' onClick={
                        () => toggleAdd(
                            e.data.bay_name,
                            e.data.shelf_name,
                            e.data.warehouse_aisle_name,
                            e.data.bay_storage_unit_id,
                            e.data.shelf_storage_unit_id,
                            e.data.warehouse_layout_aisle_id,
                            e.data.location_name,
                            e.data.storage_unit_location_id,
                            e.data.container_id,
                            e.data.container_name,
                            e.data.container_type_id,
                            e.data.location_address,
                            true
                        )}>
                        <i className="fa fa-fw fa-pencil text-primary"></i>
                    </Button>
                    <Button outline className=' b-0 p-0' onClick=''>
                        <i className="fa fa-fw fa-trash text-danger" onClick={() => toggledelModal(e.data.storage_unit_location_id)} ></i>
                    </Button>
                </div>

            </>
        )
    }
    const _handleRecords = (recordsType, count) => {
        setRecordsType(recordsType);
        if (count > 10) {
            setSkip(true)
        } else {
            setSkip(false)
        }
        Datagridref.current.instance.refresh();
    }
    return (
        <div>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <h4>Import Storage Units - {localStorage.getItem("FileName")}</h4>
                <ThemeConsumer>
                    {({ color }) => (
                        <div>
                            <Nav className='d-md-block'>
                                <span className="save-padding-add3plcompany">
                                    <Link to={
                                        {
                                            pathname: '/warehouse/storageunit',
                                            state: {
                                                layout_name: location.state.layouName,
                                                layout_id: location.state.layouId,
                                                warehouse_location_id: location.state.warehouse_location_id,
                                                warehouse_address_id: location.state.warehouse_address_id,
                                                warehouse_location_name: location.state.warehouse_location_name,
                                                warehouse_address_name: location.state.warehouse_address_name,
                                            }
                                        }
                                    }
                                    >
                                        <Button outline color="secondary-custom" > Cancel </Button>
                                    </Link>
                                </span>
                                <Button color={color} type="button" disabled={loader} onClick={() => _handleSaveStorageUnitData()} >
                                    Import Locations ({valid_count})
                                    <span> </span>
                                    {loader && (
                                        <i
                                            className="fa fa-spinner fa-spin"
                                            style={{ marginRight: "5px" }}
                                        />
                                    )}
                                </Button>
                            </Nav>
                        </div>
                    )}
                </ThemeConsumer>
            </Navbar>
            <div className="container">
                {(skeleton === false) ?
                    (
                        <LayoutsSketeon />
                    ) : (
                        <>
                            <div className="container-fluid">
                                <Row>
                                    <Col lg={8} className="warehouse-margin mt-3 mb-1">
                                        <p>You can manage all warehouse storage unit here</p>
                                    </Col>
                                </Row>
                                <Row className="mt-1 mb-1">
                                    <Col lg={3}>
                                        <Card className="mb-3">
                                            <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.ValidateRecords, valid_count) }}>
                                                <CardBody>
                                                    <CardTitle tag="h6" className="mb-4"> Validated Records </CardTitle>
                                                    <div className="mb-3">
                                                        <h5>{valid_count}</h5>
                                                    </div>
                                                </CardBody>
                                            </a>
                                        </Card>
                                    </Col>
                                    <Col lg={3}>
                                        <Card className="mb-3">
                                            <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.ErrorRecords, invalid_count) }}>
                                                <CardBody>
                                                    <CardTitle tag="h6" className="mb-4"> Error Records </CardTitle>
                                                    <div className="mb-3">
                                                        <h5>{invalid_count}</h5>
                                                    </div>
                                                </CardBody>
                                            </a>
                                        </Card>
                                    </Col>
                                    <Col lg={3}>
                                        <Card className="mb-3">
                                            <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.ExcludedRecords, delete_count) }}>
                                                <CardBody>
                                                    <CardTitle tag="h6" className="mb-4"> Excluded Records </CardTitle>
                                                    <div className="mb-3">
                                                        <h5>{delete_count}</h5>
                                                    </div>
                                                </CardBody>
                                            </a>
                                        </Card>
                                    </Col>
                                    <Col lg={3}>
                                        <Card className="mb-3">
                                            <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.TotalRecords, (invalid_count + valid_count + delete_count)) }}>
                                                <CardBody>
                                                    <CardTitle tag="h6" className="mb-4"> Total Records </CardTitle>
                                                    <div className="mb-3">
                                                        <h5>{invalid_count + valid_count + delete_count}</h5>
                                                    </div>
                                                </CardBody>
                                            </a>
                                        </Card>
                                    </Col>
                                </Row>
                                <Row className='mb-4'>
                                    <Col lg={4}>
                                        <FormGroup>
                                            <label>Warehouse location</label>
                                            <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }} >
                                                <DropdownToggle caret color="secondary" outline type="select" className='form-control ml-3 warehouse-location-drp-width'>
                                                    {locationType}
                                                </DropdownToggle>
                                                <DropdownMenu persist >
                                                    {locations && locations.length > 0 ? (locations.map((item, index) => (
                                                        <DropdownItem onClick={() => { _handleOnClick([{ id: item.warehouse_location_id }, { name: item.location_name }]) }}>{item.location_name}</DropdownItem>
                                                    ))) : (
                                                            ''
                                                        )}
                                                </DropdownMenu>
                                            </UncontrolledButtonDropdown>
                                        </FormGroup>
                                    </Col>
                                    <Col lg={6}>
                                        <FormGroup className='bg-light'>
                                            <label>Building</label>
                                            <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }}>
                                                <DropdownToggle caret color="secondary" outline type="select" className='form-control ml-3 warehouse-location-drp-width'>
                                                    {addressType}
                                                </DropdownToggle>
                                                <DropdownMenu persist >
                                                    {buildings && buildings.length > 0 ? (buildings.map((item, index) => (
                                                        <DropdownItem onClick={() => { _handlebuildingOnClick([{ id: item.warehouse_address_id }, { name: item.building_alias }]) }}>{item.building_alias}</DropdownItem>
                                                    ))) : (
                                                            ''
                                                        )}
                                                </DropdownMenu>
                                            </UncontrolledButtonDropdown>
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Card className="mb-3" className="margin-preview">
                                    <CardBody>
                                        <DataGrid
                                            id="gridContainer"
                                            dataSource={storageunit_data}
                                            ref={Datagridref}
                                            allowColumnReordering={true}
                                            remoteOperations={true}
                                            columnAutoWidth={true}
                                            rowAlternationEnabled={true}
                                            //group={true}
                                            onToolbarPreparing={(e) => {
                                                e.toolbarOptions.visible = false
                                            }}
                                            showBorders={true}
                                            onCellPrepared={(e) => {
                                                if (e.rowType == 'header' && e.column.command == "edit") {
                                                    e.cellElement.innerText = " Actions ";
                                                }
                                                if (e.rowType == 'filter' && e.column.command == "edit") {
                                                    e.cellElement.innerHTML = "<button className='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close text-danger'></i></button>";
                                                    e.cellElement.onclick = () => { Datagridref.current.instance.clearFilter() }
                                                }
                                            }
                                            }

                                            onRowRemoving={async (e) => {
                                                e.cancel = true;
                                                // delStationId = e.data.warehouse_station_id
                                            }}
                                            onSaving={
                                                (e) => {
                                                    e.cancel = true;
                                                    //SaveStation(e.changes, e.component)
                                                }
                                            }
                                            onInitNewRow={(e) => {
                                                console.log('initrow', e)
                                                // _handleName(e)

                                            }}
                                        >
                                            <ColumnChooser
                                                enabled={true}
                                                mode='select' />
                                            <GroupPanel visible={true} />
                                            <Paging enabled={true}
                                                defaultPageSize={10} />
                                            <Pager
                                                showPageSizeSelector={true}
                                                allowedPageSizes={[10, 15, 20]}
                                                showInfo={true} />

                                            <Editing
                                                mode={editmode}
                                                confirmDelete={false} />
                                            <FilterRow visible={true} />
                                            <Column caption='Aisle' cssClass='text-center'>
                                                <Column dataField="warehouse_aisle_name" caption='Aisle name' cssClass='text-center' allowSorting={true} />
                                            </Column>

                                            <Column caption='Bay' cssClass='text-center'>
                                                <Column dataField="bay_name" caption='Bay name' cssClass='text-center' allowSorting={true} />
                                                <Column dataField="zone_type" caption='Zone type' allowSorting={false} />
                                            </Column>
                                            <Column caption='Shelf' cssClass='text-center'>
                                                <Column dataField="shelf_name" caption='Shelf name' cssClass='text-center' allowSorting={true} />
                                            </Column>
                                            <Column caption='Location' cssClass='text-center'>
                                                <Column dataField="location_name" cssClass='text-center' caption='Location name' allowSorting={true} />
                                                <Column dataField="location_address" caption='Location address' allowSorting={true} />
                                                <Column dataField="container_type" cssClass='text-center' allowSorting={false} />
                                                <Column dataField="container_name" cssClass='text-center' allowSorting={false} />
                                            </Column>
                                            <Column caption='Action' cellRender={editdelBtn} cssClass='text-center' allowHiding={false} />
                                        </DataGrid>
                                    </CardBody>
                                </Card>
                                <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this location?`}
                                    onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete location" />
                            </div>
                        </>
                    )}
            </div>


            {/* Add location popup */}
            <Modal isOpen={modal} toggle={toggleAdd} className="modal-outline-warning">
                <Formik
                    initialValues={locationDetails}
                    enableReinitialize={true}
                    validationSchema={yup.object().shape({
                        location_name: yup.string().nullable().required(`${Configuration.required} location name`),
                    })}
                    onSubmit={saveLocation}
                >
                    {({ errors, touched, values, resetForm }) => (
                        <Form>
                            <ModalHeader tag="h5">
                                <span>{editmodal ? 'Edit' : 'Add'} location to shelf {aislename}-{bayname}-{shelfname}</span>
                            </ModalHeader>
                            <ModalBody>
                                <FormGroup>
                                    <Label for="building_alias">
                                        Location name <span className="text-danger">*</span>
                                    </Label>
                                    <Field type="text"
                                        maxLength="6"
                                        placeholder="Enter location name"
                                        onChange={(e) => onLocationInputChange(e.target.value)}
                                        name="location_name"
                                        value={values.location_name}
                                        className={`${touched.location_name && errors.location_name && 'is-invalid'} bg-white form-control`} />
                                    {touched.location_name && errors.location_name &&
                                        <ErrorMessage name="location_name" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                <FormGroup>
                                    <Label for="state">
                                        Container Type
                                    </Label>
                                    {!editmodal &&
                                        <span className="float-right font-italic text-primary small"><a onClick={() => showNewContainerEdit()} color="link"
                                            style={{ cursor: "pointer" }}>
                                            {showHide ? 'Associate existing container' : 'Add new container'}</a></span>
                                    }
                                    {
                                        editmodal && <span className="float-right font-italic text-primary small">
                                            {!editShowHide &&
                                                <a onClick={() => clearContainerAssociationWithLocation()} color="link"
                                                    style={{ cursor: "pointer" }}>Clear association</a>
                                            }
                                            {
                                                editShowHide && <a onClick={() => showNewContainer()} color="link"
                                                    style={{ cursor: "pointer" }}>
                                                    {showHide ? 'Associate existing container' : 'Add new container'}</a>
                                            }
                                        </span>
                                    }
                                    <Field as="select" className="form-control"
                                        disabled={isDisabled}
                                        name="container_type_id" maxLength="100" id="state"
                                        onChange={(e) => {
                                            bindContainer(e.target.value)
                                        }}
                                        className={`${isDisabled ? '' : 'bg-white'} form-control`} >
                                        <option value="">Select container type</option>
                                        {
                                            containerType && containerType.length > 0 && containerType.map((entity, index) => (
                                                <option key={entity.entity_type_id + '' + index} value={entity.entity_type_id}>{entity.entity_type_name}</option>
                                            ))
                                        }
                                    </Field >
                                </FormGroup>
                                {showHidePopupControl === 'assocontainer' &&
                                    <FormGroup style={{ display: `${showHide ? 'none' : ''}` }}>
                                        <Label for="container_name"> Container name </Label>
                                        <InputGroup>
                                            <Typeahead
                                                //disabled={isDisabled}
                                                id="container_name"
                                                labelKey="container_name"
                                                onChange={singleSelections}
                                                options={options}
                                                name="container_name"
                                                className={`${isDisabled ? '' : 'bg-white'}`}
                                                defaultSelected={
                                                    options.filter(item => item.container_id
                                                        === locationDetails.container_id)}
                                                placeholder="Select container name..."
                                            />
                                            <InputGroupAddon addonType="append"  >
                                                <i className="fa fa-search ml-1"></i>
                                            </InputGroupAddon>
                                        </InputGroup>
                                    </FormGroup>
                                }
                                <div style={{ display: `${showHide ? '' : 'none'}` }}>
                                    <FormGroup>
                                        <Label for="container_size">
                                            Container Size
                                        </Label>
                                        <Field as="select" className="form-control"
                                            name="container_size_id" maxLength="100" id="container_size"
                                            className={`bg-white form-control`}
                                            onChange={(e) => {
                                                setContainerSizeId(e.target.value)
                                            }} >
                                            <option value="">Select container size</option>
                                            {
                                                boxSizeList && boxSizeList.length > 0 && boxSizeList.map((size, index) => (
                                                    <option key={size.entity_size_id + '' + index} value={size.entity_size_id}>{size.entity_size}</option>
                                                ))
                                            }
                                        </Field >
                                    </FormGroup>

                                </div>
                                {showHidePopupControl === 'newcontainer' &&
                                    <FormGroup>
                                        <Label for="container_name">
                                            Container name
                                        </Label>
                                        <Field type="text"
                                            maxLength="6"
                                            onChange={(e) => {
                                                onInputChange(e.target.value)
                                            }}
                                            className={`${isDisabled ? '' : 'bg-white'} form-control`}
                                            placeholder="Enter container name"
                                            disabled={isDisabled}
                                            name="container_name"
                                            value={values.container_name} />
                                    </FormGroup>
                                }
                                {
                                    showHidePopupControl === 'clearassociation' &&
                                    <FormGroup>
                                        <Label for="container_name">
                                            Container name
                                        </Label>
                                        <Field type="text"
                                            maxLength="6"
                                            onChange={(e) => {
                                                onInputChange(e.target.value)
                                            }}
                                            className={`${isDisabled ? '' : 'bg-white'} form-control`}
                                            placeholder="Enter container name"
                                            disabled={isDisabled}
                                            name="container_name"
                                            value={values.container_name} />
                                    </FormGroup>
                                }
                            </ModalBody>
                            <ModalFooter>
                                <button color="link" type="button" onClick={() => cancelPopup(resetForm)} className="btn btn-default text-warning">Cancel</button>
                                <ThemeConsumer>
                                    {
                                        ({ color }) => (
                                            <Button color={color} type="submit" className="btn btn-warning">
                                                {editmodal ? 'Update' : 'Add'}
                                            </Button>
                                        )
                                    }
                                </ThemeConsumer>

                            </ModalFooter>
                        </Form>
                    )}
                </Formik>
            </Modal>
        </div >
    )
}

export default LocationStorageUnitPreview;
