import React from 'react'
const Labels = ({pdf}) => {
    console.log('MEEEEEEEEEEEEEEEEE CALLED')
    return (
        <div>
            <p>KJHJHJHJHJHJHJHJHJHJH</p>
            {window.open(pdf)}
            {/* {window.print()} */}
        </div>
    )
}

export default Labels