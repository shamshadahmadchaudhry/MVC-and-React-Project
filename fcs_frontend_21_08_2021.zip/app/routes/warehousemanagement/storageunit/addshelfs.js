import React, { useEffect, useRef, useState } from 'react';
import { useSelector } from 'react-redux';
import { Link, useHistory, useLocation } from 'react-router-dom';
import AlertMessage from '../../commoncomponents/alertmessage';
import { Configuration } from '../../commoncomponents/configurationfile';
import { toast } from 'react-toastify';
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    RequiredRule,
    Lookup
} from 'devextreme-react/data-grid';
import { addShelf } from '../../../services/warehousemanagementservice'
import {
    Navbar,
    FormGroup,
    Container,
    Row,
    Col,
    DropdownToggle,
    ThemeConsumer,
    Nav,
    Button,
    ButtonGroup,
    UncontrolledButtonDropdown,
    DropdownMenu,
    DropdownItem,
    Card,
    CardBody,
} from '../../../components';
import { fetchLayoutName } from '../../../services/layoutservices'
import ConfirmBox from '../../commoncomponents/confirmbox';
import AddShelfpopup from './addShelfpopup';
let shelf_name = '';
let value = 0;
const AddShelf = ({ locationId, addressId, aisleId, bayId }) => {

    toast.configure();
    const history = useHistory();
    const location = useLocation();

    locationId = location.state.location_id;
    addressId = location.state.address_id;
    aisleId = location.state.aisle_id;;
    bayId = location.state.bay_id;
    console.log('visible sh', location.state.locationvisible)
    let no_of_records = 0
    let numrowsToadd = 0
    const datagridRef = useRef(null)
    const [isLoading, setIsLoading] = useState(false);
    const [addshelfOptions, setAddshelfOptions] = useState([])
    const [disable, setDisable] = useState(true)
    const [disablesubmit, setDisablesubmit] = useState(true)
    const [editmode, setEditmode] = useState('row')
    const [delmodal, setDelmodal] = useState(false)
    const [numrows, setNumrows] = useState(0)
    const [delkey, setDelkey] = useState(0)
    const [companyId, setCompanyId] = useState(0)
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [allshelfs, setAllshelf] = useState(JSON.parse(localStorage.getItem('shelfs')) || []);
    const [noofshelfs, setNoofshelfs] = useState(location.state.no_of_shelfs);
    const [haslocaldata, setHaslocaldata] = useState(false);

    //For popup
    const [action, setAction] = useState('')
    const [shelfname, setShelfname] = useState('')
    const [shlefnamepop, setShelfnamepop] = useState('A')
    const [popupstate, setPopupstate] = useState(false);

    let container_type = Configuration.entityType.shelf;
    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }

    /*ADD SHELF MODAL POP UP*/
    const togglePopup = () => {
        setPopupstate(!popupstate);
    }

    //Add Shelf
    const saveShelfpop = async () => {
        if (shelfname == '' || !(shelfname.match(Configuration.alphanumeric))) {
            toast.error(<AlertMessage type='error' title='Error Saving Shelf'
                message={'Please provide the shelf name'} />, { autoClose: 4000 });
        }
        else {
            let body = {
                "shelfs": [{ 'shelf_name': shelfname }], created_by: userData.user_master_id, warehouse_address_id: addressId,
                warehouse_location_id: locationId, company_id: location.state.company_id, warehouse_aisle_id: location.state.aisle_id, storage_unit_bay_id: location.state.bay_id
            }
            const result = await addShelf(body, container_type)
            if (result.data['status'] === false) {
                toast.error(<AlertMessage type='error' title='Error Saving Shelf'
                    message={result.data.message} />, { autoClose: 4000 });

            }
            else {
                toast.success(<AlertMessage type='success' title='Shelf Saved'
                    message={result.data.message} />, { autoClose: 4000 });
                setShelfname('')
            }
        }
    }

    /* */
    const deleteRow = () => {
        let shelfLeft = allshelfs.filter((shelf) => {
            return shelf.id !== delkey;
        })
        console.log(shelfLeft)
        setAllshelf(shelfLeft)
        setDelmodal(!delmodal)
        toast.success(<AlertMessage type='success' title='Shelf Deleted'
            message='Shelf has been deleted Successfully' />, { autoClose: 4000 });
    }

    const loadshelfoptions = () => {
        let shelf = '';
        let shelfOptions = []
        for (let i = 2; i <= 10; i++) {
            if (i === 1) {
                shelf = 'Shelf'
            }
            else {
                shelf = ' Shelfs'
            }
            shelfOptions.push({
                id: i,
                name: 'Add ' + i + shelf
            })
        }
        setAddshelfOptions(shelfOptions)
    }

    //Load options
    useEffect(() => {
        if (allshelfs.length === 0) {
            _handledropdownItem(noofshelfs)
        }
        else {
            toast.warning(<AlertMessage type='warning' title='Save current data'
                message='Please Save current Shelf data to add more' />, { autoClose: 4000 });
        }
        loadshelfoptions()
    }, []);

    //Set company Id
    useEffect(() => {
        setCompanyId(CompanyListingStatus?.result?.response?.result[0].company_id)
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result]);

    useEffect(() => {
        localStorage.setItem('shelfs', JSON.stringify(allshelfs))
    }, [allshelfs]);

    const fetchShelfValue = async (id, bayId) => {
        no_of_records = id
        const result = await fetchLayoutName(Configuration.entityType.shelf, location.state.company_id, no_of_records,
            locationId, addressId, bayId);
        console.log('Result', result)
        return result;
    }

    //Add single Shelf
    const _SingleRow = async () => {
        if (!haslocaldata && allshelfs.length === 0) {
            const result = await fetchShelfValue(1, bayId)
            datagridRef.current.instance.cancelEditData()
            shelf_name = result.data[0]['shelf_name']
            datagridRef.current.instance.addRow()
            setNumrows(1)
        }
        else {
            toast.warning(<AlertMessage type='warning' title='Save current data'
                message='Please Save current Shelf data to add more' />, { autoClose: 4000 });
        }

    }

    const _handledropdownItem = async (id) => {
        if (!haslocaldata && allshelfs.length === 0) {
            setEditmode('batch')
            setDisable(false)
            setNumrows(id)
            numrowsToadd = id
            const result = await fetchShelfValue(id, bayId);
            console.log('resss', result)
            datagridRef.current.instance.cancelEditData()
            for (var i = 0; i < id; i++) {
                shelf_name = result.data[i]['shelf_name'];
                value = result.data[i]['value'];
                datagridRef.current.instance.addRow()
            }
        }
        else {
            toast.warning(<AlertMessage type='warning' title='Save current data'
                message='Please Save current Shelf data to add more' />, { autoClose: 4000 });
        }
    }

    const _handleName = async (e) => {
        e.data['shelf_name'] = shelf_name
        e.data['value'] = value;
    }

    const SaveShelf = async (body, component) => {
        if (body[0].type === 'insert') {
            console.log("Shelf Body Data", body)
            for (let i = 0; i < numrows; i++) {
                allshelfs.push({ id: body[i].data.__KEY__, shelf_name: body[i].data.shelf_name, value: body[i].data.value })
            }
            localStorage.setItem('shelfs', JSON.stringify(allshelfs))
            toast.success(<AlertMessage type='success' title='Shelf Saved'
                message='Shelf has been Saved Successfully' />, { autoClose: 4000 });
            await component.refresh(true);
            component.cancelEditData();
            setEditmode('row')
            setDisablesubmit(false)
            setHaslocaldata(true)
        }
        else if (body[0].type === 'update') {
            let shelf_name = '';
            if ('warehouse_zone_type' in body[0].data) {
                warehouse_zone_type = body[0].data.warehouse_zone_type
            }
            if ('shelf_name' in body[0].data) {
                shelf_name = body[0].data.shelf_name
            }

            let updatedshelf = allshelfs.map(shelf => {
                if (shelf.id === body[0].key.id) {
                    if (shelf_name.length > 0) {
                        console.log('Updated shelf', shelf_name)
                        shelf.shelf_name = shelf_name;
                    }
                }
                return shelf;
            })
            setAllshelf(updatedshelf)
            toast.success(<AlertMessage type='success' title='Shelf Updated'
                message='Shelf has been deleted Successfully' />, { autoClose: false });
        }
        else {
            setDelkey(body[0].key.id)
            setDelmodal(true)
        }
    }
    const shelf_data = allshelfs
    return (
        <div>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <h4>Add shelf to bay {location.state.bay_name}</h4>
                <ThemeConsumer>
                    {({ color }) => (
                        <div>
                            <Nav className='d-md-block'>
                                <span className="save-padding-add3plcompany">
                                    <Button outline color="secondary" onClick={() => {
                                        setAllshelf([]);
                                        setDisablesubmit(true)
                                        setTimeout(() => {
                                            history.push({
                                                pathname: '/warehouse/storageunit',
                                                state: {
                                                    locationcolumnstate: location.state.locationvisible,
                                                    shelfcolumnstate: location.state.shelfvisible
                                                }
                                            })
                                        }, 100);
                                    }}> Cancel </Button>
                                </span>
                                <Button type="button" disabled={(!(disablesubmit) || (allshelfs.length > 0)) ? false : true} color={color} onClick={
                                    async () => {
                                        setIsLoading(true)
                                        //Loop through and save warehouse_zone_type_id in objects
                                        let body = {
                                            "shelfs": allshelfs, created_by: userData.user_master_id, warehouse_address_id: addressId,
                                            warehouse_location_id: locationId, company_id: companyId, warehouse_aisle_id: aisleId, storage_unit_bay_id: bayId
                                        }
                                        // console.log('FINAL', body)
                                        const result = await addShelf(body, container_type)
                                        if (result.data.message.includes('exists')) {
                                            toast.error(<AlertMessage type='error' title='Error Saving Shelf'
                                                message={result.data.message} />, { autoClose: 4000 });
                                        }
                                        else {
                                            toast.success(<AlertMessage type='success' title='Shelfs Saved'
                                                message={result.data.message} />, { autoClose: 4000 });
                                            setHaslocaldata(false)
                                            setAllshelf([]);
                                        }
                                        console.log('Response', result);
                                        setIsLoading(false)
                                    }
                                } >
                                    <i className="fa fa-floppy-o" aria-hidden="true"></i>  {'Save'}
                                    {isLoading && (
                                        <i
                                            className="fa fa-spinner fa-spin ml-1"
                                        />)}
                                </Button>
                            </Nav>
                        </div>
                    )}
                </ThemeConsumer>
            </Navbar>
            <Container>
                <p className='mt-3'>You can add multiple shelf storage units here.</p>
                <Card className="mb-3" className="margin-top">
                    <CardBody>

                        <h5>Add Multiple Shelf(s)</h5>
                        <div className="container-fluid">
                            <Row className='ml-5'>
                                <Col></Col>
                                <Col></Col>
                                <Col></Col>
                                <Col></Col>
                                <Col className='ml-5'>
                                    <ButtonGroup className='mb-2'>
                                        <Button outline className='ml-2' onClick={() => _SingleRow()}>
                                            <i className="fa fa-fw fa-plus"></i>
                                        </Button>
                                        <UncontrolledButtonDropdown direction="down">
                                            <DropdownToggle color="secondary" outline caret />
                                            <DropdownMenu right >
                                                {addshelfOptions && addshelfOptions.length > 0 ? (addshelfOptions.map((item, index) => (
                                                    <DropdownItem key={index} onClick={() => _handledropdownItem(item.id)}>
                                                        {item.name}
                                                    </DropdownItem>
                                                ))) : (
                                                        ''
                                                    )}
                                            </DropdownMenu>
                                        </UncontrolledButtonDropdown>
                                        <Button outline className='ml-2' onClick={() => {
                                            datagridRef.current.instance.saveEditData()
                                            setNoofshelfs(0);
                                            datagridRef.current.instance.cancelEditData();
                                            setHaslocaldata(true)
                                        }
                                        } disabled={disable}>
                                            <i className="dx-icon-save"></i>
                                        </Button>
                                        <Button outline onClick={() => { datagridRef.current.instance.cancelEditData(); setDisable(true); setEditmode('row') }} disabled={disable}>
                                            <i className="dx-icon-revert"></i>
                                        </Button>
                                    </ButtonGroup>
                                </Col>
                            </Row>
                        </div>
                        <div className="container-fluid">
                            <DataGrid id="grid-container"
                                showBorders={true}
                                dataSource={shelf_data}
                                columnHidingEnabled={true}
                                ref={datagridRef}
                                onCellPrepared={(e) => {
                                    if (e.rowType == 'header' && e.column.command == "edit") {
                                        e.cellElement.innerHTML = "<b>Action</b>";
                                    }
                                    if (e.rowType == 'filter' && e.column.command == "edit") {
                                        e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1 ml-2'>Reset Filters <i class='fa fa-close text-danger'></i></button>";
                                        e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
                                    }
                                }}
                                remoteOperations={true}
                                rowAlternationEnabled={true}
                                allowColumnReordering={true}
                                onToolbarPreparing={(e) => {
                                    e.toolbarOptions.visible = false
                                }}
                                onSaving={(e) => {
                                    e.cancel = true;
                                    SaveShelf(e.changes, e.component)
                                }}
                                onInitNewRow={(e) => {
                                    _handleName(e)

                                }}
                                onRowRemoving={async (e) => {
                                    e.cancel = true;
                                }}
                            >
                                <Editing
                                    mode={editmode}
                                    useIcons={true}
                                    allowDeleting={true}
                                    allowUpdating={true}
                                    confirmDelete={false}
                                >
                                </Editing>
                                <Paging defaultPageSize={10} />
                                <Pager
                                    showPageSizeSelector={true}
                                    allowedPageSizes={[10, 15, 20]}
                                    showInfo={true} />
                                <FilterRow visible={true} />
                                <Column dataField='shelf_name' caption="Shelf name">
                                    <RequiredRule />
                                </Column>
                                <Column dataField='value' visible={false} caption="Value" >
                                </Column>
                            </DataGrid>
                            <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this Shelf`}
                                onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete Shelf" />


                            <AddShelfpopup action={action} isOpen={popupstate}
                                message={
                                    <form>
                                        <div className='form-group'>
                                            <label>Shelf name <i className='text-danger'>*</i></label>
                                            <input type='text' name='shelfName' onChange={(e) => {
                                                if (action == 'edit') {
                                                    setShelfnamepop(e.target.value)
                                                }
                                                else {
                                                    setShelfname(e.target.value)
                                                }
                                            }} className='form-control' value={action === 'add' ? shelfname : shlefnamepop} />
                                        </div>
                                    </form>
                                }
                                onClose={togglePopup} onConfirm={action === 'add' && saveShelfpop} text={action === 'add' ? 'Add' : 'Update'}
                                title={action === 'add' ? `Add Shelf to bay A-10-1` : `Edit Shelf ${shelfname} of bay A10-1`} />
                        </div>
                    </CardBody>
                </Card>
            </Container>
        </div>
    )
}

export default AddShelf
