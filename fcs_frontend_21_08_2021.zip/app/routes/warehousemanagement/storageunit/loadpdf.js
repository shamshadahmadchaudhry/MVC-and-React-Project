import React from 'react';
import {useHistory,useLocation} from 'react-router-dom'

const Reactpdf = ({fileurl}) =>{
    const location = useLocation();
    return (
        <div>
            <h3>Iframe</h3>
            <iframe 
            src={location.state.pdfurl}>

            </iframe>
        </div>
    )
}
export default Reactpdf;