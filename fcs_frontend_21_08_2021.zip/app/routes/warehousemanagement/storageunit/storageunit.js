import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as yup from 'yup';
import React, { useState, useRef, useEffect } from 'react';
import { useHistory, useLocation } from "react-router-dom";
import { useSelector } from 'react-redux'
import AddBaypopup from './addBaypopup';
import Reactpdf from './loadpdf';
import { Configuration } from '../../commoncomponents/configurationfile';
import DataGrid, {
    Column,
    Editing,
    Paging,
    Pager,
    Lookup,
    RequiredRule,
    PatternRule,
    FilterRow,
    ColumnChooser,
    GroupPanel,
    Selection
} from 'devextreme-react/data-grid';
import SelectBox from 'devextreme-react/select-box';
import Menu from 'devextreme-react/menu';
import { Template } from 'devextreme-react/core/template';
import CustomStore from 'devextreme/data/custom_store';
import {
    Navbar,
    FormGroup,
    Container,
    Row, Col,
    DropdownToggle,
    Button,
    ButtonGroup,
    UncontrolledButtonDropdown,
    DropdownMenu,
    DropdownItem,
    CustomInput,
    Card,
    CardBody,
    Modal,
    ModalHeader, ModalBody,
    ModalFooter, InputGroupAddon,
    ThemeConsumer, InputGroup,
    Label
} from '../../../components';
import {
    getWarehouseLocationList,
    getBuildingDetailsList,
    addBay,
    addShelf,
    updateBay,
    updateShelf,
    getPapersizes,
    printLabels
} from '../../../services/warehousemanagementservice';
import { getEntityList, getBinList, getContainerTypeList } from '../../../services/binservice';
import { fetchContainerName } from '../../../services/containerservice';
import { getStorageunitList } from '../../../services/storageunitservices';
import '../../../styles/common.scss';
import LayoutsSketeon from '../skeleton/layoutsskeleton'
import { toast } from 'react-toastify';
import AlertMessage from '../../commoncomponents/alertmessage';
import { zoneTypes, fetchLayoutName } from '../../../services/layoutservices'
import AddShelfpopup from './addShelfpopup';
import { before, indexOf, isEmpty } from 'lodash';
import { Typeahead } from 'react-bootstrap-typeahead';
import {
    addStorageUnitLocation, addStorageUnitContainercons, updateStorageUnitLocation, deleteLocationStorageUnit,
    deleteBay, deleteShelf
}
    from '../../../services/storageunitservice';
import LayouImportDropdown from '../common/layoutimportdropdown';
import ConfirmBox from '../../../routes/commoncomponents/confirmbox';
import StorageUnitSkeleton from '../skeleton/storageunitskeleton';
import Printselectsizemodal from '../common/printSelectsizemodal';
import { CONFIG } from '../../../config'
import Labels from './labels'

const StorageUnit = () => {
    const Datagridref = useRef(null)
    const componentRef = useRef();
    const location = useLocation();
    toast.configure();
    const history = useHistory();
    const [entityType, setEntityType] = useState([])
    const [layoutTypeId, setLayoutTypeId] = useState(1)
    const [companyId, setCompanyId] = useState(0)
    const [locations, setLocations] = useState([])
    const [buildings, setBuildings] = useState([])
    const [activelocationId, setActivelocationId] = useState(0);
    const [activeaddressId, setActiveaddressId] = useState(0);
    const [aisleId, setAisleId] = useState(0);
    const [skeleton, setSkeleton] = useState(false);
    const [addbayOptions, setAddbayOptions] = useState([]);
    const [addshelfOptions, setAddshelfOptions] = useState([]);
    let bayOptions = [];
    const [screensize, setScreensize] = useState({
        matches: window.matchMedia("(min-width: 1200px)").matches
    });

    useEffect(() => {
        const handler = e => setScreensize({ matches: e.matches });
        window.matchMedia("(min-width: 1200px)").addListener(handler);
    }, [screensize.matches])


    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    let editmode = 'row';
    let no_of_records = 1;
    let locationVisible = true;
    let bayvisible = true;
    let shelfvisible = true;

    //Bay
    //For popup
    const [action, setAction] = useState('')
    const [bayname, setBayname] = useState('')
    const [baynamepop, setBaynamepop] = useState('1')
    const [popupstate, setPopupstate] = useState(false)
    const [selectedzoneid, setSelectedzoneid] = useState(0)
    const [activezoneId, setActivezoneId] = useState(0)
    const [zonetypes, setZonetypes] = useState([])
    //Shelf
    //For popup
    const [actionsh, setActionsh] = useState('')
    const [popupstatesh, setPopupstatesh] = useState(false)
    const [shelfname, setShelfname] = useState('');
    const [shelfValue, setShelfValue] = useState(0);
    const [shelfnamepop, setShelfnamepop] = useState('')
    const [aislename, setAislename] = useState('')
    const [bayId, setBayId] = useState(0);
    const [storagelocationId, setStoragelocationId] = useState(0);

    const [hideprops, setHideprops] = useState(true);
    const [zonename, setZonename] = useState('')
    const [baystorageId, setBaystorageId] = useState(0)
    const [shelfstorageId, setShelfstorageId] = useState(0)
    const [locationColumnvisible, setLocationColumnvisible] = useState(true)
    const [shelfcolumnvisible, setshelfcolumnvisible] = useState(true)
    const [bayColumnvisible, setBayColumnvisible] = useState(true)

    //Location popup
    const [actionlo, setActionlo] = useState('')
    const [popupstatelo, setPopupstatelo] = useState(false)
    const [locationname, setLocationname] = useState('')
    const [locationnamepop, setLocationnamepop] = useState('')

    //Select Size Modal State
    const [selectsizemodal, setSelectsizemodal] = useState(false)
    const [actionsize, setActionsize] = useState('')
    const [noLabeltoprint, setnoLabeltoprint] = useState('single')
    const [papersizes, setPapersizes] = useState([])
    const [iframeurl, setIframeurl] = useState("")
    const [isloading, setIsloading] = useState(false)
    const [locationType, setLocationType] = useState('Select Location')
    const [addressType, setAddressType] = useState('Select Address')
    const [isselect, setIsSelect] = useState(false)

    parent.postMessage({ action: 'receipt-loaded' });

    const printIframe = (id) => {
        const iframe = document.frames
            ? document.frames[id]
            : document.getElementById(id);
        const iframeWindow = iframe.contentWindow || iframe;

        iframe.focus();
        iframeWindow.print();

        return false;
    };

    const loadPaperSizes = async () => {
        let papersizesReq = await getPapersizes();
        setPapersizes(papersizesReq.data)
    }
    useEffect(() => {
        loadPaperSizes()
    }, [])
    const toggleSizeModal = () => {
        setIframeurl('')
        setSelectsizemodal(!selectsizemodal)
    }

    const send_print_request = async (active_entity, entity_ids, printallRecords) => {
        // console.log('ENTITY ID', entity_ids)
        // console.log('ACTIVE ENTITY',active_entity)
        // SEND PRINT REQUEST
        // console.log('X',x)
        // console.log('Y',y)
        // console.log('PAPER ID',paperid)
        const printdocument = await printLabels({
            paper_size_id: parseInt(paperid), company_id: companyId,
            location_id: activelocationId, location_address_id: activeaddressId, x_width: parseInt(x), y_height: parseInt(y),
            entity_type: active_entity.toString(), ids_list: entity_ids, print_all: printallRecords
        })

        console.log('PRINT DOC ', printdocument)

        if (printdocument.data.status) {
            let path = printdocument.data.pdf_file_path
            let html_url = printdocument.data.html_url
            // console.log('PATH RETURNED ',path)
            path = path.replace(/\\/g, "/");
            let indmedia = path.indexOf('media')
            let remPath = path.slice(indmedia)
            // console.log('REM path',remPath)
            // console.log('nEW PATH',path)
            let fullPath = CONFIG.BASE_URL + '/' + remPath;
            // console.log('FULL PATH', fullPath)
            let get_html_url = html_url + '?pdf_path=' + fullPath.substring(fullPath.indexOf('media'));
            // console.log('GET URL PATH',get_html_url.toString())
            setIframeurl(get_html_url, 'Print', 'left=200, top=200, width=950, height=500, toolbar=0, resizable=0');
            window.frames["labeliframe"].focus();
            setIsloading(false)
            // console.log('CONFIG.BASE_URL',CONFIG.BASE_URL)
            // console.log('Gen pdf path',printdocument.data.pdf_file_path)
            // console.log('WINFRAMES',window)
            // console.log('url',html_url)
            // console.log('pdf path',fullPath)
        }
    }

    const printSingleRowLabel = () => {
        if (size != '0') {
            setIsloading(true)
            let printallRecords = false;
            let active_entity = 0
            let entity_ids = []
            let data = Datagridref.current.instance.getSelectedRowKeys();
            if (locationColumnvisible) {
                active_entity = Configuration.entityType.location
                entity_ids.push(locationStorageUnitId);

            }
            else if (shelfcolumnvisible) {
                active_entity = Configuration.entityType.shelf
                entity_ids.push(shelfstorageId)
            }
            else {
                active_entity = Configuration.entityType.bay
                entity_ids.push(baystorageId)
            }
            if (data.length === totalRecord) {
                printallRecords = true
            }
            // SEND PRINT REQUEST
            send_print_request(active_entity, entity_ids, printallRecords)
        }
    }

    const printSelectedsizeLabel = async () => {
        if (size != '0') {
            setIsloading(true)
            let printallRecords = false;
            let data = Datagridref.current.instance.getSelectedRowKeys();
            let active_entity = 0
            let entity_ids = []
            if (locationColumnvisible) {
                let location_ids = []
                active_entity = Configuration.entityType.location
                for (let i = 0; i < data.length; i++) {
                    if (data[i].storage_unit_location_id != null) {
                        location_ids.push(data[i].storage_unit_location_id)
                    }
                }
                entity_ids = location_ids;
                // if(data.length === totalRecord){
                //     printallRecords = true
                // }
                // const printdocument = await printLabels({paper_size_id:1,company_id:companyId,
                //     location_id:activelocationId,location_address_id:activeaddressId,x_width:parseInt(x),y_height:parseInt(y),
                //     entity_type:Configuration.entityType.location,ids_list:location_ids,print_all:printallRecords})
                // console.log('RESPONSE ON PRINT REQUEST',printdocument)
                // console.log('LOCATION ID KEYS',location_ids)

            }
            else if (shelfcolumnvisible) {
                let shelf_ids = []
                active_entity = Configuration.entityType.shelf
                for (let i = 0; i < data.length; i++) {
                    if (data[i].shelf_storage_unit_id != null) {
                        shelf_ids.push(data[i].shelf_storage_unit_id)
                    }
                }
                entity_ids = shelf_ids
                // {
                //     "paper_size":5,
                //     "company_id":2,
                //     "location_id":1,
                //     "location_address_id":1,
                //     "x_width":4,
                //     "y_height":1,
                //     "entity_type":"5",
                //     "ids_list":[1,2,3]
                // }

                // console.log('GENERATING PDF',printdocument)
                // console.log('SHELF ID KEYS',shelf_ids)
            }
            else {
                let bay_ids = []
                active_entity = Configuration.entityType.bay
                for (let i = 0; i < data.length; i++) {
                    if (data[i].bay_storage_unit_id != null) {
                        bay_ids.push(data[i].bay_storage_unit_id)
                    }
                }
                entity_ids = bay_ids;
                // console.log('BAY ID KEYS',bay_ids)
            }
            if (data.length === totalRecord) {
                printallRecords = true
            }
            // SEND PRINT REQUEST
            send_print_request(active_entity, entity_ids, printallRecords)

            // if(data.length === totalRecord){
            //     printallRecords = true
            // }
            // console.log('X',x)
            // console.log('Y',y)
            // console.log('PAPER ID',paperid)
            // const printdocument = await printLabels({paper_size_id:parseInt(paperid),company_id:companyId,
            //     location_id:activelocationId,location_address_id:activeaddressId,x_width:parseInt(x),y_height:parseInt(y),
            //     entity_type:active_entity.toString(),ids_list:entity_ids,print_all:printallRecords})
            // //console.log('PRINT DOC ',printdocument.data)

            // if(printdocument.data.status){
            //     let path = printdocument.data.pdf_file_path
            //     let html_url = printdocument.data.html_url
            //     // console.log('PATH RETURNED ',path)
            //     path = path.replace(/\\/g, "/");
            //     let indmedia = path.indexOf('media')
            //     let remPath = path.slice(indmedia)
            //     // console.log('REM path',remPath)
            //     // console.log('nEW PATH',path)
            //     let fullPath = CONFIG.BASE_URL + '/' + remPath;
            //     // console.log('FULL PATH', fullPath)
            //     let get_html_url = html_url + '?pdf_path=' + fullPath.substring(fullPath.indexOf('media'));
            //     // console.log('GET URL PATH',get_html_url.toString())
            //     setIframeurl(get_html_url,'Print','left=200, top=200, width=950, height=500, toolbar=0, resizable=0');
            //     window.frames["labeliframe"].focus();
            //     // console.log('CONFIG.BASE_URL',CONFIG.BASE_URL)
            //     // console.log('Gen pdf path',printdocument.data.pdf_file_path)
            //     // console.log('WINFRAMES',window)
            //     // console.log('url',html_url)
            //     // console.log('pdf path',fullPath)
            // }

        }
        else {
            toast.error(<AlertMessage type="error" title="Select Paper Size"
                message="Please select paper size." />, { autoClose: 4000 });
        }

        // console.log('ROW KEYS',Datagridref.current.instance.getSelectedRowKeys()[0])
    }
    //All states for selection
    const [selectMode, setSelectMode] = useState('page')
    const [totalRecord, setTotalRecord] = useState(0)
    const [selectedRecords, setSelectedRecords] = useState(false)
    const [selectedAll, setSelectedAll] = useState(false)
    const [checkstatus, setCheckstatus] = useState(false)
    const [rownoselected, setRownoselected] = useState(0)
    const [x, setX] = useState(0)
    const [y, setY] = useState(0)
    const [size, setSize] = useState(0)
    const [paperid, setPaperid] = useState(0)
    const [addingrecord, setAddingrecord] = useState(false)
    const [selcount,setSelcount] = useState(0)
    const [checked,setChecked] = useState(false)

    //Selection Implementation
    const _handleSelectStatus = (checked) => {
        if (checked) {
            setCheckstatus(true)
            setSelectMode('page')
            setSelectedRecords(true)
            setChecked(true)
            Datagridref.current.instance.selectAll()
        }
        else {
            setCheckstatus(false)
            setSelectedAll(false)
            setSelectMode('page')
            setSelectedRecords(false)
            setChecked(false)
            // setRownoselected(0)
            Datagridref.current.instance.deselectAll()
        }

    }
    useEffect(() => {
        if (selectMode === 'allPages') {
            Datagridref.current.instance.deselectAll()
            Datagridref.current.instance.selectAll()
        }
    }), [selectMode]




    /*  Column visibility */
    let shelf_visible = true;
    let location_visible = true;
    if (location.state != null) {
        if (location.state.locationcolumnstate) {
            location_visible = true
        }
        else {
            location_visible = false
        }
        if (location.state.shelfcolumnstate) {
            shelf_visible = true
        }
        else {
            shelf_visible = false;
        }
    }
    useEffect(() => {
        if (location.state != null) {
            if (location.state.locationcolumnstate) {
                setLocationColumnvisible(true)
            }
            else {
                setLocationColumnvisible(false)
            }
            if (location.state.shelfcolumnstate) {
                setshelfcolumnvisible(true)
            }
            else {
                setshelfcolumnvisible(false)
            }
        }
    }, [])
    //Start state implementation for add new location storage unit
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [showHide, setShowHide] = useState(false);
    const [editShowHide, setEditShowHide] = useState(false);
    const [modal, setModal] = useState(false);
    const [editmodal, setEditModal] = useState(false);
    const [containerType, setContainerType] = useState([]);
    const [options, setoptions] = useState([]);
    const [boxSizeList, setBoxSizeList] = useState([]);
    const [locationStorageUnitId, setLocationStorageUnitId] = useState(0);
    const [locationStorateUnitName, setlocationStorateUnitName] = useState('');
    const [clearContainerAssociation, setclearContainerAssociation] = useState(false);
    const [locationBayId, setLocationBayId] = useState('');
    const [locationShelfId, setLocationShelfId] = useState('');
    const [isDisabled, setisDisabled] = useState(false);
    const [locationDetails, setLocationDetails] = useState({
        location_name: '', container_type_id: '', bay_storage_unit_id: 0,
        container_id: '', container_name: '', shelf_storage_unit_id: 0,
        entity_size_id: 0, warehouse_layout_aisle_id: 0,
    });
    const [delmodal, setDelmodal] = useState(false);

    const [showHidePopupControl, setShowHidePopupControl] = useState('')

    const toggledelModal = (locationStorageid) => {
        setLocationStorageUnitId(locationStorageid);
        setDelmodal(!delmodal);
    }

    const resetLocationState = () => {
        setLocationDetails({
            ...locationDetails,
            container_type_id: '', bay_storage_unit_id: 0,
            container_id: '', container_name: '', shelf_storage_unit_id: 0,
            entity_size_id: 0, warehouse_layout_aisle_id: 0,
        });
    }

    const toggleAdd = async (bay_name, shelf_name, warehouse_aisle_name, bay_id, shelf_id, aisle_id,
        location_name, storage_unit_location_id, container_id, container_name, container_type_id, location_address, is_edit) => {


        if (shelf_id) {
            resetLocationState();

            if (modal === false) {
                loadContainerType();
                if (bay_name && shelf_name && warehouse_aisle_name) {
                    setAislename(warehouse_aisle_name);
                    setBayname(bay_name);
                    setShelfname(shelf_name);
                    setLocationShelfId(shelf_id)
                    setLocationBayId(bay_id);
                    setAisleId(aisle_id);
                    setLocationStorageUnitId(storage_unit_location_id);
                    setlocationStorateUnitName(location_name);
                    setEditModal(is_edit)
                }
                if (!is_edit) {
                    setShowHidePopupControl('assocontainer');
                    fetchLocationName(shelf_id);
                } else {
                    await bindContainer(container_type_id ? container_type_id.toString() : 0);
                    if (container_name) {
                        setLocationDetails({
                            ...locationDetails,
                            location_name: location_name,
                            container_type_id: container_type_id,
                            container_id: container_id,
                            container_name: container_name
                        });
                        setShowHidePopupControl('clearassociation');
                        setisDisabled(true);
                    } else {
                        setLocationDetails({
                            ...locationDetails,
                            location_name: location_name,
                            container_type_id: '',
                            container_id: container_id,
                            container_name: container_name
                        });
                        setShowHidePopupControl('assocontainer');
                        setisDisabled(false);
                    }
                }
            }
            setModal(!modal);
        } else {
            toast.error(<AlertMessage type="error" title="Add Storage Location Error" message="No storage shelf available." />, { autoClose: 400 });
        }
    }

    const cancelPopup = (resetForm) => {
        if (resetForm) {
            resetForm();
        }
        setEditModal(false);
        setEditShowHide(false);
        setModal(!modal);
        setShowHide(false);
        resetLocationState();
        setisDisabled(false);
        setclearContainerAssociation(false);
    }

    const bindContainer = async (containerType) => {
        loadContainerSize(containerType);
        if (showHide) {
            fetchContainerNameDetails(containerType);
        }
        setLocationDetails({ ...locationDetails, container_type_id: containerType });
        let params = '';
        params += `?container_type=${containerType}&`
        params += `warehouse_location_id=${activelocationId}`
        let container_result = await getBinList(params);
        let arrayContainer = []
        if (containerType === Configuration.entityType.bin.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_bin_id;
                obj.container_name = item.bin_name;
                arrayContainer.push(obj)
            });
        } else if (containerType === Configuration.entityType.box.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_box_id;
                obj.container_name = item.box_name;
                arrayContainer.push(obj)
            });
        } else if (containerType === Configuration.entityType.cart.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_cart_id;
                obj.container_name = item.cart_name;
                arrayContainer.push(obj)
            });
        } else if (containerType === Configuration.entityType.pallete.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_pallete_id;
                obj.container_name = item.pallete_name;
                arrayContainer.push(obj)
            });
        } else if (containerType === Configuration.entityType.tote.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_tote_id;
                obj.container_name = item.tote_name;
                arrayContainer.push(obj)
            });
        }
        setoptions(arrayContainer);
    }

    const loadContainerType = async () => {
        let company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        const result = await getEntityList(`?company_id=${companyId}`);
        console.log('Result', result)
        setContainerType(result.data.result)
    }

    const loadContainerSize = async (containerType) => {
        const result = await getContainerTypeList(containerType, companyId);
        setBoxSizeList(result.data.result)
    }

    const setContainerSizeId = async (e) => {
        setLocationDetails({ ...locationDetails, entity_size_id: e });
    }

    const fetchLocationName = async (shelf_id) => {
        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        const result = await fetchContainerName(Configuration.entityType.location, company_id, 1, activelocationId, activeaddressId, shelf_id);
        if (result) {
            setLocationDetails({ ...locationDetails, location_name: result.data[0]['location_name'] });
        }
    }

    const fetchContainerNameDetails = async (container_type_id) => {
        //setLocationDetails({ ...locationDetails, container_name: '' })
        let entity_name = ''
        if (container_type_id === Configuration.entityType.bin.toString()) {
            entity_name = 'bin_name';
        }
        else if (container_type_id === Configuration.entityType.box.toString()) {
            entity_name = 'box_name';
        }
        else if (container_type_id === Configuration.entityType.cart.toString()) {
            entity_name = 'cart_name';
        }
        else if (container_type_id === Configuration.entityType.pallete.toString()) {
            entity_name = 'pallete_name';
        }
        else if (container_type_id === Configuration.entityType.tote.toString()) {
            entity_name = 'tote_name';
        }

        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        const result = await fetchContainerName(container_type_id, company_id, 1, 4);
        if (result) {
            setLocationDetails({ ...locationDetails, container_name: result.data[0][entity_name], container_type_id: container_type_id });
        }
    }

    const saveLocation = async (values) => {
        let company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        let entity_name = locationDetails.container_type_id === Configuration.entityType.bin.toString() ? 'container_bin_id' :
            locationDetails.container_type_id === Configuration.entityType.box.toString() ? 'container_box_id' :
                locationDetails.container_type_id === Configuration.entityType.cart.toString() ? 'container_cart_id' :
                    locationDetails.container_type_id === Configuration.entityType.pallete.toString() ? 'container_pallete_id' :
                        locationDetails.container_type_id === Configuration.entityType.tote.toString() ? 'container_tote_id' : '';
        let container_id = locationDetails.container_id;
        if (showHide) {
            let body = {
                "containers":
                    [{ "container_name": locationDetails.container_name, entity_size_id: locationDetails.entity_size_id }]
                , created_by: userData.user_master_id, warehouse_location_id: activelocationId, company_id: company_id
            }
            const result = await addStorageUnitContainercons(body, locationDetails.container_type_id);
            if (result.data.status) {
                if (result.data.container_id.length > 0) {
                    container_id = result.data.container_id[0][entity_name]
                } else {
                    toast.error(<AlertMessage type='error' title='Container Error'
                        message={result.data.message} />, { autoClose: false });
                    return false;
                }
            }
        }

        let body = {
            locations: [
                {
                    "storage_unit_location_id": locationStorageUnitId,
                    "location_name": locationDetails.location_name,
                    "prefix": "0",
                    "value": parseInt(locationDetails.location_name),
                    "location_address": aislename + '-' + bayname + '-' + shelfname + '' + locationDetails.location_name,
                    "container_type_id": locationDetails.container_type_id,
                    "container_id": container_id ? container_id : 0,
                    "warehouse_layout_aisle_id": aisleId,
                    "bay_storage_unit_id": locationBayId,
                    "shelf_storage_unit_id": locationShelfId,
                    "is_clear_associate_container": false
                }],
            "created_by": userData.user_master_id,
            "warehouse_location_id": activelocationId,
            "warehouse_address_id": activeaddressId,
            "company_id": company_id
        }

        if (locationStorageUnitId > 0) {
            const response = await updateStorageUnitLocation(body)
            if (response.data['status'] === true) {
                toast.success(<AlertMessage type='success' title='Update Box'
                    message={response.data['message']} />, { autoClose: 4000 });
                setModal(!modal);
                setLocationDetails({
                    location_name: '', container_type_id: '', bay_storage_unit_id: 0,
                    container_id: '', container_name: '', shelf_storage_unit_id: 0,
                    entity_size_id: 0, warehouse_layout_aisle_id: 0,
                });
                cancelPopup();
                setclearContainerAssociation(false)
            }
            else {
                toast.error(<AlertMessage type='error' title='Update Box'
                    message={response.data['message']} />, { autoClose: false });
            }
        } else {
            const response = await addStorageUnitLocation(body)
            if (response.data['status'] === true) {
                toast.success(<AlertMessage type='success' title='Update Box'
                    message={response.data['message']} />, { autoClose: 4000 });
                setModal(!modal);
                setLocationDetails({
                    location_name: '', container_type_id: '', bay_storage_unit_id: 0,
                    container_id: '', container_name: '', shelf_storage_unit_id: 0,
                    entity_size_id: 0, warehouse_layout_aisle_id: 0,
                });
                cancelPopup();
            }
            else {
                toast.error(<AlertMessage type='error' title='Update Box'
                    message={response.data['message']} />, { autoClose: false });
            }
        }

    }

    const singleSelections = (e) => {
        if (e && e.length) {
            setLocationDetails({ ...locationDetails, container_name: e[0].container_name, container_id: e[0].container_id });
        }
    }

    const showNewContainer = () => {
        //if (!showHide) {
        resetContainerType();
        //}
        const showhidePopup = showHidePopupControl === 'newcontainer' ? 'assocontainer' : 'newcontainer'
        setShowHidePopupControl(showhidePopup);
        setShowHide(!showHide)
    }

    const resetContainerType = () => {
        setLocationDetails({
            ...locationDetails,
            container_id: '',
            container_name: '',
            container_type_id: ''
        });
        setBoxSizeList([]);
        setoptions([]);
    }

    const showNewContainerEdit = () => {
        //if (!showHide) {
        // setLocationDetails({
        //     ...locationDetails,
        //     container_id: '',
        //     container_name: '',
        //     container_type_id: ''
        // });
        resetContainerType();
        // if (locationDetails.container_type_id) {
        //     fetchContainerNameDetails(locationDetails.container_type_id.toString());
        // }
        //}
        const showhidePopup = showHidePopupControl === 'clearassociation' ? 'assocontainer'
            : showHidePopupControl === 'assocontainer' ? 'newcontainer' : 'assocontainer';
        setShowHidePopupControl(showhidePopup);
        setShowHide(!showHide)
    }

    const clearContainerAssociationWithLocation = async () => {
        let body = {
            locations: [
                {
                    "storage_unit_location_id": locationStorageUnitId,
                    "location_name": locationDetails.location_name,
                    "prefix": "0",
                    "value": parseInt(locationDetails.location_name),
                    "location_address": aislename + '-' + bayname + '-' + shelfname + '' + locationDetails.location_name,
                    "container_type_id": locationDetails.container_type_id,
                    "container_id": locationDetails.container_id,
                    "warehouse_layout_aisle_id": aisleId,
                    "bay_storage_unit_id": locationBayId,
                    "shelf_storage_unit_id": locationShelfId,
                    "is_clear_associate_container": true
                }],
            "created_by": userData.user_master_id,
            "warehouse_location_id": activelocationId,
            "warehouse_address_id": activeaddressId,
            "company_id": companyId
        }
        if (locationStorageUnitId > 0) {
            const response = await updateStorageUnitLocation(body)
            if (response.data['status'] === true) {
                toast.success(<AlertMessage type='success' title='Update Box'
                    message={response.data['message']} />, { autoClose: 4000 });
                //setModal(!modal);
                setLocationDetails({
                    location_name: '', container_type_id: '', bay_storage_unit_id: 0,
                    container_id: '', container_name: '', shelf_storage_unit_id: 0,
                    entity_size_id: 0, warehouse_layout_aisle_id: 0,
                });
                //cancelPopup();
                setclearContainerAssociation(false)
            }
            else {
                toast.error(<AlertMessage type='error' title='Update Box'
                    message={response.data['message']} />, { autoClose: false });
            }
        }
        setLocationDetails({
            ...locationDetails,
            container_type_id: '',
            container_id: '',
            container_name: ''
        });
        setShowHidePopupControl('assocontainer');
        setisDisabled(false);
        setclearContainerAssociation(true);
        setEditShowHide(!editShowHide);
    }

    const onInputChange = (e) => {
        setLocationDetails({
            ...locationDetails,
            container_name: e
        });
    }

    const onLocationInputChange = (e) => {
        setLocationDetails({
            ...locationDetails,
            location_name: e
        });
    }

    const deleteRow = async () => {
        const result = await deleteLocationStorageUnit(Configuration.entityType.location, locationStorageUnitId, userData.user_master_id);
        setDelmodal(!delmodal)
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title='Delete Location Storage Unit'
                message={result.data['message']} />, { autoClose: 4000 });
        }
        else {
            toast.error(<AlertMessage type='error' title='Delete Location Storage Unit'
                message={result.data['message']} />, { autoClose: false });
        }
    }
    //End state implementation for location storage unit

    /*ADD BAY MODAL POP UP*/
    const loadbayoptions = () => {
        let bay = '';
        for (let i = 2; i <= 10; i++) {
            if (i === 1) {
                bay = 'Bay'
            }
            else {
                bay = ' Bays'
            }
            bayOptions.push({
                id: i,
                name: 'Add ' + i + bay
            })
        }
        setAddbayOptions(bayOptions)
    }

    const loadshelfoptions = () => {
        let shelf = '';
        let shelfOptions = []
        for (let i = 2; i <= 10; i++) {
            if (i === 1) {
                shelf = 'Shelf'
            }
            else {
                shelf = ' Shelfs'
            }
            shelfOptions.push({
                id: i,
                name: 'Add ' + i + shelf
            })
        }
        setAddshelfOptions(shelfOptions)
    }

    useEffect(() => {
        loadshelfoptions();
        loadbayoptions();
    }, [])

    const togglePopup = () => {
        setPopupstate(!popupstate);
    }

    const togglePopuplo = () => {
        setPopupstatelo(!popupstatelo);
    }

    const deleteStorageShelf = async () => {
        console.log('storage shelf id ', shelfstorageId)
        const result = await deleteShelf({ shelf_storage_unit_id: shelfstorageId, modified_by: userData.user_master_id });
        setDelmodal(!delmodal)
        // console.log('del',result)
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title='Shelf Deleted'
                message={result.data['message']} />, { autoClose: 4000 })
            setDelmodal(false)
        }
        else {
            toast.error(<AlertMessage type='error' title='Error deleting Shelf'
                message={result.data['message']} />, { autoClose: false })
        }

    }

    const deleteStorageBay = async () => {
        console.log('storage bay id ', storagelocationId)
        const result = await deleteBay({ bay_storage_unit_id: baystorageId, modified_by: userData.user_master_id });
        setDelmodal(!delmodal)
        console.log('del', result)
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title='Bay deleted'
                message={result.data['message']} />, { autoClose: 4000 })
            setDelmodal(false)
        }
        else {
            toast.error(<AlertMessage type='error' title='Error deleting Bay'
                message={result.data['message']} />, { autoClose: false })
        }
    }

    const saveShelfpop = async () => {
        if (shelfname === '' || !(shelfname.match(Configuration.alphanumeric))) {
            toast.error(<AlertMessage type='error' title='Error Saving Shelf'
                message={'Please provide the shelf name'} />, { autoClose: false });
        }
        else {
            let body = {
                "shelfs": [{ 'shelf_name': shelfname, 'value': shelfValue }], created_by: userData.user_master_id,
                warehouse_address_id: activeaddressId, warehouse_location_id: activelocationId,
                company_id: companyId, warehouse_aisle_id: aisleId, storage_unit_bay_id: bayId
            }
            const result = await addShelf(body, Configuration.entityType.shelf)
            console.log('result shelf', result)
            if (result.data['status'] === false) {
                toast.error(<AlertMessage type='error' title='Error Saving Shelf'
                    message={result.data.message} />, { autoClose: false });
            }
            else if (result.data.error) {
                toast.error(<AlertMessage type='error' title='Error Saving Shelf'
                    message={result.data.message} />, { autoClose: false });
            }
            else {
                toast.success(<AlertMessage type='success' title='Shelf Saved'
                    message={result.data.message} />, { autoClose: 4000 });
                setShelfname('')
                togglePopupsh();
            }
        }

    }

    //Update Shelf
    const updateShelfpop = async () => {
        if (!bayname.match(Configuration.alphanumeric)) {
            toast.error(<AlertMessage type='error' title='Error Saving Shelf'
                message={'Please provide valid bay name'} />, { autoClose: 4000 });
        }
        else {
            console.log('shelf nam', shelfname)
            console.log('shelf pop', shelfnamepop)
            const result =
                await updateShelf({
                    shelf_storage_unit_id: shelfstorageId,
                    warehouse_address_id: activeaddressId,
                    warehouse_location_id: activelocationId,
                    shelf_name: shelfnamepop,
                    company_id: companyId,
                    created_by: userData.user_master_id
                });
            console.log('Result', result)
            if (result.data.message.includes('exist')) {
                toast.error(<AlertMessage type='error' title='Error Updating Shelf'
                    message={result.data.message} />, { autoClose: false });
                setBayname('')
            }
            else if (result.data.error) {
                toast.error(<AlertMessage type='error' title='Error Updating Shelf'
                    message={result.data.message} />, { autoClose: false });
            }
            else {
                toast.success(<AlertMessage type='success' title='Shelf Updated'
                    message={result.data.message} />, { autoClose: 4000 });
                togglePopupsh();
            }
        }
    }

    //Save bay
    const saveBaypop = async () => {
        // console.log(selectedzoneid)
        if (!bayname.match(Configuration.alphanumeric)) {
            toast.error(<AlertMessage type='error' title='Error Saving Bay'
                message={'Please provide valid bay name'} />, { autoClose: false });
        }
        else if (selectedzoneid == 0) {
            toast.error(<AlertMessage type='error' title='Error Saving Bay'
                message={'Please select zone type'} />, { autoClose: false });
        }
        else {
            let body = {
                "bays": [{ 'bay_name': bayname, 'warehouse_zone_type_id': selectedzoneid }],
                created_by: userData.user_master_id, warehouse_address_id: activeaddressId,
                warehouse_location_id: activelocationId, company_id: companyId, warehouse_layout_aisle_id: aisleId
            }
            const result = await addBay(body, Configuration.entityType.bay)
            if (result.data.message.includes('exists')) {
                toast.error(<AlertMessage type='error' title='Error Saving Bay'
                    message={result.data.message} />, { autoClose: false });
                setBayname('')

            }
            else {
                toast.success(<AlertMessage type='success' title='Bay Saved'
                    message={result.data.message} />, { autoClose: 4000 });
                togglePopup();
            }
        }
    }
    //Update Bay
    const updateBaypop = async () => {
        if (!bayname.match(Configuration.alphanumeric)) {
            toast.error(<AlertMessage type='error' title='Error Saving Bay'
                message={'Please provide valid bay name'} />, { autoClose: 4000 });
        }
        else if (selectedzoneid == 0) {
            toast.error(<AlertMessage type='error' title='Error Saving Bay'
                message={'Please select zone type'} />, { autoClose: 4000 });
        }
        else {
            const result =
                await updateBay({
                    bay_storage_unit_id: baystorageId,
                    bay_name: bayname,
                    warehouse_address_id: activeaddressId,
                    warehouse_location_id: activelocationId,
                    warehouse_zone_type_id: selectedzoneid,
                    company_id: companyId,
                    created_by: userData.user_master_id
                })
            if (result.data.message.includes('exist')) {
                toast.error(<AlertMessage type='error' title='Error Saving Bay'
                    message={result.data.message} />, { autoClose: 4000 });
            }
            else if (result.data.error) {
                toast.error(<AlertMessage type='error' title='Error Saving Bay'
                    message={result.data.message} />, { autoClose: 4000 });
            }
            else {
                toast.success(<AlertMessage type='success' title='Bay Saved'
                    message={result.data.message} />, { autoClose: 4000 });
                setBayname('')
                togglePopup();
            }
        }
    }

    const laodZonetypes = async () => {
        let zonetypesResp = await zoneTypes()
        console.log('Respo ', zonetypesResp)
        setZonetypes(zonetypesResp)
    }

    useEffect(() => {
        laodZonetypes();
        loadContainerType();

    }, [])

    /*ADD SHELF MODAL POP UP*/
    const togglePopupsh = () => {
        setPopupstatesh(!popupstatesh);
    }

    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            setCompanyId(CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id)
            WarehouseLocations(CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id)
        } else {
            setCompanyId(CompanyListingStatus?.result?.response?.result[0].company_id)
            WarehouseLocations(CompanyListingStatus?.result?.response?.result[0].company_id)
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    //Load buildings
    const loadBuildings = async (locationId) => {
        console.log('LOCATE', locationId)
        let params = `?warehouse_location_id=${locationId}`
        let buildingResp = await getBuildingDetailsList(params)
        setSkeleton(true)
        setBuildings(buildingResp.data)
        //setActiveaddressId(buildingResp.data[0].warehouse_address_id)
        if (location.state != null && isselect === false) {
            setAddressType(location.state.warehouse_address_name)
            setActiveaddressId(location.state.warehouse_address_id)
        } else {
            setAddressType(buildingResp.data[0].building_alias)
            setActiveaddressId(buildingResp.data[0].warehouse_address_id)
        }
    }
    //Load warehouse locations
    const WarehouseLocations = async (company_id) => {
        let params = `?company_id=${company_id}`
        let response = await getWarehouseLocationList(params)
        //Load Buildings for First warehouse location
        if (location.state != null) {
            setLocationType(location.state.warehouse_location_name)
            loadBuildings(location.state.warehouse_location_id)
            setActivelocationId(location.state.warehouse_location_id)
        } else {
            loadBuildings(response.data[0].warehouse_location_id)
            setLocationType(response.data[0].location_name)
            setActivelocationId(response.data[0].warehouse_location_id)
        }
        // loadBuildings(response.data[0].warehouse_location_id)
        // setActivelocationId(response.data[0].warehouse_location_id)
        setLocations(response.data)
        return response.data
    }

    useEffect(() => {
        setIsSelect(true)
        setAddressType('')
    }, [activelocationId])
    const _handleOnClick = (e) => {
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setLocationType(str)
        }
        else {
            setLocationType(e[1].name)
        }
        setActivelocationId(e[0].id)
        loadBuildings(e[0].id);
    }
    const _handlebuildingOnClick = (e) => {
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setAddressType(str)
        }
        else {
            setAddressType(e[1].name)
        }
        setActiveaddressId(e[0].id);
    }

    useEffect(() => {
        setLayoutTypeId(Configuration.entityType.zone)
    }, [])

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }
    const shelfopts = [{
        id: 0,
        icon: 'fa fa-caret-down',
        items: addshelfOptions
    }
    ]
    const bayopts = [{
        id: 0,
        icon: 'fa fa-caret-down',
        items: addbayOptions
    }
    ]

    const storageunit_data = new CustomStore({
        key: '',
        load: async (loadOptions) => {
            let count = 0;
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary',
                'totalCount'
            ].forEach(function (i) {
                if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                    params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                }
                if (!loadOptions.filter && !loadOptions.sort && count === 0 && !loadOptions.skip && !loadOptions.take) {
                    params += `skip=0&take=${totalRecord}&requireTotalCount=true&totalSummary=[]&`;
                }
                if (loadOptions.filter && loadOptions['group'] !== null && count === 0) {
                    params += `skip=0&take=${totalRecord}&`;
                }
                count++;
            });
            params += `warehouse_location_id=${activelocationId}&warehouse_address_id=${activeaddressId}&company_id=${companyId}&`
            params = params.slice(0, -1);
            const StorageunitList = await getStorageunitList(params)
            setTotalRecord(StorageunitList.totalCount)
            return StorageunitList;

        },
        update: async (key, values) => {
        }
    })

    //Action button Render
    const aisleaddBtn = (e) => {
        // console.log('e',e)
        // if(e){

        // }
        return (
            <>
                <div>
                    <ButtonGroup className='mb-2'>
                        <Button outline className='ml-2 btn-sm b-0 p-1' onClick={
                            async () => {
                                const result = await fetchLayoutName(Configuration.entityType.bay, companyId, no_of_records, activelocationId
                                    , activeaddressId, e.data.warehouse_layout_aisle_id);

                                if (result?.data[0]?.bay_name) {
                                    setAislename(e.data.warehouse_aisle_name)
                                    setBayname(result.data[0].bay_name)
                                    setAisleId(e.data.warehouse_layout_aisle_id)
                                    setAction('add');
                                    setSelectedzoneid(0)
                                    setPopupstate(true);
                                } else {
                                    toast.error(<AlertMessage type="error" title="Add Bay Error" message="No aisle layout available." />, { autoClose: false });
                                }
                            }
                        }>
                            <i className="fa fa-fw fa-th-list"></i>
                            <sub><i className='text-success fa fa-plus-circle'></i></sub>
                        </Button>
                        {/* <UncontrolledButtonDropdown direction="down" onClick={() => {
                            // history.push({
                            //     pathname: '/addbays/',
                            //     state: {
                            //         location_id: activelocationId,
                            //         address_id: activeaddressId,
                            //         aisle_id: e.data.warehouse_layout_aisle_id,
                            //         aisle_name: e.data.warehouse_aisle_name
                            //     }

                            // });
                        }}>
                            <DropdownToggle color="secondary" outline caret className='b-0 p-1' />

                        </UncontrolledButtonDropdown> */}
                        {/* <UncontrolledButtonDropdown direction="down">
                            <DropdownToggle color="secondary" outline caret className='b-0 p-1'/>
                            <DropdownMenu right  style={{'z-index':'999','background-color':'green'}}>
                                {addbayOptions && addbayOptions.length > 0 ? (addbayOptions.map((item, index) => (
                                    <DropdownItem key={index} onClick={() => handleBayoptionchange(item.id,e.data.warehouse_layout_aisle_id)}>
                                        {item.name}
                                    </DropdownItem>
                                ))) : (
                                        ''
                                    )}
                            </DropdownMenu>
                        </UncontrolledButtonDropdown> */}
                        {/* <SelectBox items={addbayOptions} style={{'width':'100px'}} 
                        valueExpr='id' displayExpr='name' 
                        onValueChanged={(g)=>{handleBayoptionchange(g,e.data.warehouse_layout_aisle_id)}} /> */}
                        <Menu dataSource={bayopts}
                            style={{ 'width': '40px' }}
                            displayExpr='name'
                            submenuDirection={'auto'}
                            onItemClick={(k) => {
                                handleBayoptionchange(k.itemData.id, e.data.warehouse_layout_aisle_id, e.data.warehouse_aisle_name)
                            }}
                        />
                    </ButtonGroup>
                </div>

            </>
        )
    }
    const handleBayoptionchange = (e, g, aisle_name) => {
        if (e != 0) {
            history.push({
                pathname: '/addbays/',
                state: {
                    location_id: activelocationId,
                    address_id: activeaddressId,
                    aisle_id: g,
                    aisle_name: aisle_name,
                    no_of_bays: e,
                    company_id: companyId,
                    locationvisible: locationColumnvisible,
                    shelfvisible: shelfcolumnvisible,
                    warehouse_location_name: locationType,
                    warehouse_address_name: addressType
                }

            });
        }
    }
    //Add Bay Button
    const bayaddBtn = (e) => {
        //console.log(e.data)
        return (
            <>
                <div>

                    <ButtonGroup className='mb-2'>
                        <Button outline className='ml-2 btn-sm b-0 p-1'
                            onClick={
                                async () => {
                                    let no_of_records = 1;
                                    const result = await fetchLayoutName(Configuration.entityType.shelf, companyId, no_of_records,
                                        activelocationId, activeaddressId, e.data.bay_storage_unit_id);
                                    if (result?.data[0]?.shelf_name) {
                                        setAislename(e.data.warehouse_aisle_name)
                                        setAisleId(e.data.warehouse_layout_aisle_id)
                                        setBayname(e.data.bay_name)
                                        setBayId(e.data.bay_storage_unit_id)
                                        setShelfname(result.data[0].shelf_name)
                                        setShelfValue(result.data[0].value)
                                        setActionsh('add');
                                        setPopupstatesh(true)
                                    } else {
                                        toast.error(<AlertMessage type="error" title="Add Shelf Error" message="No storage bay available." />, { autoClose: false });
                                    }
                                }
                            }>
                            <i className="fa fa-fw fa-bars"></i>
                            <sub><i className='text-success fa fa-plus-circle'></i></sub>
                        </Button>
                        {/* <Button className='btn btn-sm bg-light text-dark b-0 p-1'>
                        <i className='fa fa-caret-down'></i>
                    </Button> */}
                        {/* <UncontrolledButtonDropdown direction="down" onClick={() => {
                            history.push({
                                pathname: '/addshelf/',
                                state: {
                                    location_id: activelocationId,
                                    address_id: activeaddressId,
                                    aisle_id: e.data.warehouse_layout_aisle_id,
                                    bay_id: e.data.bay_storage_unit_id,
                                }

                            });
                        }}>
                            <DropdownToggle color="secondary" outline caret className='b-0 p-1' />

                        </UncontrolledButtonDropdown> */}
                        {/* <UncontrolledButtonDropdown direction="down">
                            <DropdownToggle color="secondary" outline caret className='b-0 p-1'/>
                            <DropdownMenu right className='dropdown-menu'>
                                {addshelfOptions && addshelfOptions.length > 0 ? (addshelfOptions.map((item, index) => (
                                    <DropdownItem key={index} onClick={() => handleShelfoptionchange(item.id,e.data.warehouse_layout_aisle_id,e.data.bay_storage_unit_id)}>
                                        {item.name}
                                    </DropdownItem>
                                ))) : (
                                        ''
                                    )}
                            </DropdownMenu>
                        </UncontrolledButtonDropdown> */}
                        {/* <SelectBox items={addshelfOptions}  valueExpr='id' displayExpr='name' onValueChanged={(g)=>{
                        handleShelfoptionchange(g,e.data.warehouse_layout_aisle_id,e.data.bay_storage_unit_id)}} /> */}
                        <Menu dataSource={shelfopts}
                            style={{ 'width': '40px' }}
                            displayExpr='name'
                            submenuDirection={'auto'}
                            onItemClick={(k) => {
                                handleShelfoptionchange(k.itemData.id, e.data.warehouse_layout_aisle_id, e.data.bay_storage_unit_id, e.data.bay_name)
                            }}
                        />
                    </ButtonGroup>
                </div>

            </>
        )
    }
    const handleShelfoptionchange = (e, g, b, bay_name) => {
        if (e != 0) {
            history.push({
                pathname: '/addshelf/',
                state: {
                    location_id: activelocationId,
                    address_id: activeaddressId,
                    aisle_id: g,
                    bay_id: b,
                    bay_name: bay_name,
                    no_of_shelfs: e,
                    company_id: companyId,
                    locationvisible: locationColumnvisible,
                    shelfvisible: shelfcolumnvisible,
                    warehouse_location_name: locationType,
                    warehouse_address_name: addressType
                }

            });
        }
    }
    //Add Location Button
    const locationaddBtn = (e) => {
        return (
            <>
                <div>
                    <ButtonGroup className='mb-2 btn-sm'>
                        <Button outline className='ml-2 btn-sm' onClick={
                            () => toggleAdd(
                                e.data.bay_name,
                                e.data.shelf_name,
                                e.data.warehouse_aisle_name,
                                e.data.bay_storage_unit_id,
                                e.data.shelf_storage_unit_id,
                                e.data.warehouse_layout_aisle_id,
                                '',
                                0,
                                0,
                                '',
                                0,
                                '',
                                false
                            )
                        }>
                            <i className="fa fa-fw fa-plus"></i>
                        </Button>
                    </ButtonGroup>
                </div>

            </>
        )
    }

    //Edit Delete Btn
    const editdelBtn = (e) => {
        return (
            <>
                {/* PRINT BTN */}
                <Button outline className='  b-0 p-0' onClick={
                    async () => {
                        setnoLabeltoprint('single')
                        let visibleColumns = Datagridref.current.instance.getVisibleColumns()
                        let location = visibleColumns.find(column => column.dataField === 'location_name');
                        let shelf = visibleColumns.find(column => column.dataField === 'shelf_name');
                        let bay = visibleColumns.find(column => column.dataField === 'bay_name');

                        if (isEmpty(location)) {
                            locationVisible = false
                            setLocationColumnvisible(false)
                        }
                        else {
                            setLocationColumnvisible(true)
                            locationVisible = true
                        }
                        if (isEmpty(shelf)) {
                            setshelfcolumnvisible(false)
                            shelfvisible = false

                        }
                        else {
                            setshelfcolumnvisible(true)
                            shelfvisible = true

                        }
                        if (isEmpty(bay)) {
                            setBayColumnvisible(false)
                            bayvisible = false
                        }
                        else {
                            setBayColumnvisible(true)
                            bayvisible = true
                        }
                        if (locationVisible) {
                            if (e.data.location_name === null) {
                                toast.error(<AlertMessage type='error' title='Error Printing'
                                    message='No Location available' />, { autoClose: 4000 });
                            }
                            else {
                                //PRINT LOCATION HERE
                                setLocationStorageUnitId(e.data.storage_unit_location_id)
                                toggleSizeModal(true)
                            }
                        }
                        else if (shelfvisible) {
                            //PRINT SHELF HERE
                            // // Display Shelf pop up
                            // const result = await fetchLayoutName(Configuration.entityType.shelf, companyId, no_of_records, activelocationId,
                            //     activeaddressId, e.data.bay_storage_unit_id);
                            // setShelfstorageId(e.data.shelf_storage_unit_id)
                            // setAislename(e.data.warehouse_aisle_name)
                            // setBayname(e.data.bay_name)
                            // setShelfnamepop(e.data.shelf_name)
                            // setShelfname(result.data[0].shelf_name);
                            // setShelfValue(result.data[0].value);
                            // setActionsh('edit');
                            if (e.data.shelf_name === null) {
                                toast.error(<AlertMessage type='error' title='Error Printing Shelf Label'
                                    message='No Shelf associated to this bay' />, { autoClose: 4000 });
                            }
                            else {
                                setShelfstorageId(e.data.shelf_storage_unit_id)
                                toggleSizeModal(true)
                            }
                        }
                        else {

                            // // Display Bay pop up
                            // const result = await fetchLayoutName(Configuration.entityType.bay, companyId, no_of_records, activelocationId
                            //     , activeaddressId, e.data.warehouse_layout_aisle_id);
                            // setAislename(e.data.warehouse_aisle_name)
                            // setBayname(e.data.bay_name)
                            // setAction('edit');
                            // setZonename((e.data.zone_type))
                            // zonetypes.map(zonetype => {
                            //     if (zonetype.warehouse_zone_type === e.data.zone_type) {
                            //         setSelectedzoneid(zonetype.warehouse_zone_type_id)
                            //     }
                            // })
                            if (e.data.bay_name === null) {
                                toast.error(<AlertMessage type='error' title='Error Printing Bay Label'
                                    message='No Bay associated to Aisle' />, { autoClose: 4000 });
                            }
                            else {
                                setBaystorageId(e.data.bay_storage_unit_id)
                                toggleSizeModal(true)
                            }
                        }
                    }
                } disabled={selectedRecords || rownoselected > 1 ? true : false}>
                    <i className="dx-icon-print text-warning"></i>
                </Button>
                {/* ENT OF PRINT BTN */}

                <Button outline className='  b-0 p-0' onClick={
                    async () => {
                        let visibleColumns = Datagridref.current.instance.getVisibleColumns()
                        let location = visibleColumns.find(column => column.dataField === 'location_name');
                        let shelf = visibleColumns.find(column => column.dataField === 'shelf_name');
                        let bay = visibleColumns.find(column => column.dataField === 'bay_name');

                        if (isEmpty(location)) {
                            locationVisible = false
                            setLocationColumnvisible(false)
                        }
                        else {
                            setLocationColumnvisible(true)
                            locationVisible = true
                        }
                        if (isEmpty(shelf)) {
                            setshelfcolumnvisible(false)
                            shelfvisible = false

                        }
                        else {
                            setshelfcolumnvisible(true)
                            shelfvisible = true

                        }
                        if (isEmpty(bay)) {
                            setBayColumnvisible(false)
                            bayvisible = false
                        }
                        else {
                            setBayColumnvisible(true)
                            bayvisible = true
                        }
                        if (locationVisible) {
                            if (e.data.location_name === null) {
                                toast.error(<AlertMessage type='error' title='Error Editing Location'
                                    message='No Location available' />, { autoClose: 4000 });
                            }
                            else {
                                toggleAdd(
                                    e.data.bay_name,
                                    e.data.shelf_name,
                                    e.data.warehouse_aisle_name,
                                    e.data.bay_storage_unit_id,
                                    e.data.shelf_storage_unit_id,
                                    e.data.warehouse_layout_aisle_id,
                                    e.data.location_name,
                                    e.data.storage_unit_location_id,
                                    e.data.container_id,
                                    e.data.container_name,
                                    e.data.container_type_id,
                                    e.data.location_address,
                                    true
                                )
                            }
                        }
                        else if (shelfvisible) {
                            // Display Shelf pop up
                            const result = await fetchLayoutName(Configuration.entityType.shelf, companyId, no_of_records, activelocationId,
                                activeaddressId, e.data.bay_storage_unit_id);
                            setShelfstorageId(e.data.shelf_storage_unit_id)
                            setAislename(e.data.warehouse_aisle_name)
                            setBayname(e.data.bay_name)
                            setShelfnamepop(e.data.shelf_name)
                            setShelfname(result.data[0].shelf_name);
                            setShelfValue(result.data[0].value);
                            setActionsh('edit');
                            if (e.data.shelf_name === null) {
                                toast.error(<AlertMessage type='error' title='Error Editing Shelf'
                                    message='No Shelf associated to this bay' />, { autoClose: 4000 });
                            }
                            else {
                                setPopupstatesh(true)
                            }
                        }
                        else {
                            setBaystorageId(e.data.bay_storage_unit_id)
                            // Display Bay pop up
                            const result = await fetchLayoutName(Configuration.entityType.bay, companyId, no_of_records, activelocationId
                                , activeaddressId, e.data.warehouse_layout_aisle_id);
                            setAislename(e.data.warehouse_aisle_name)
                            setBayname(e.data.bay_name)
                            setAction('edit');
                            setZonename((e.data.zone_type))
                            zonetypes.map(zonetype => {
                                if (zonetype.warehouse_zone_type === e.data.zone_type) {
                                    setSelectedzoneid(zonetype.warehouse_zone_type_id)
                                }
                            })
                            if (e.data.bay_name === null) {
                                toast.error(<AlertMessage type='error' title='Error Editing Bay'
                                    message='No Bay associated to Aisle' />, { autoClose: 4000 });
                            }
                            else {
                                setPopupstate(true)
                            }
                        }
                    }
                } disabled={selectedRecords || rownoselected > 1 ? true : false}>
                    <i className="fa fa-fw fa-pencil text-primary"></i>
                </Button>
                <Button outline className=' b-0 p-0' onClick={
                    () => {
                        let visibleColumns = Datagridref.current.instance.getVisibleColumns()
                        let location = visibleColumns.find(column => column.dataField === 'location_name');
                        let shelf = visibleColumns.find(column => column.dataField === 'shelf_name');
                        let bay = visibleColumns.find(column => column.dataField === 'bay_name');

                        if (isEmpty(location)) {
                            locationVisible = false
                            setLocationColumnvisible(false)
                        }
                        else {
                            setLocationColumnvisible(true)
                            locationVisible = true
                        }
                        if (isEmpty(shelf)) {
                            setshelfcolumnvisible(false)
                            shelfvisible = false

                        }
                        else {
                            setshelfcolumnvisible(true)
                            shelfvisible = true

                        }
                        if (isEmpty(bay)) {
                            setBayColumnvisible(false)
                            bayvisible = false
                        }
                        else {
                            setBayColumnvisible(true)
                            bayvisible = true
                        }
                        if (locationVisible) {
                            if (e.data.storage_unit_location_id == null) {
                                toast.error(<AlertMessage type='error' title='Error Deleting Location'
                                    message='No storage location available' />, { autoClose: 4000 });
                            }
                            else {
                                toggledelModal(e.data.storage_unit_location_id)
                            }

                        }
                        else if (shelfvisible) {
                            setShelfstorageId(e.data.shelf_storage_unit_id)
                            if (e.data.shelf_storage_unit_id == null) {
                                toast.error(<AlertMessage type='error' title='Error Deleting Shelf'
                                    message='No Shelf available' />, { autoClose: 4000 });
                            }
                            else {
                                setLocationBayId(e.data.bay_storage_unit_id);
                                setDelmodal(true)
                            }
                        }
                        else if (bayvisible) {
                            setBaystorageId(e.data.bay_storage_unit_id)
                            if (e.data.bay_storage_unit_id == null) {
                                toast.error(<AlertMessage type='error' title='Error Deleting Bay'
                                    message='No Bay available' />, { autoClose: 4000 });
                            }
                            else {
                                setLocationShelfId(e.data.shelf_storage_unit_id);
                                setDelmodal(true)
                            }
                        }
                    }
                } disabled={selectedRecords || rownoselected > 1 ? true : false}>
                    <i className="fa fa-fw fa-trash text-danger"></i></Button>
            </>
        )
    }

    useEffect(() => {
        toolBarItemRender();
    }, [])

    const onToolbarPreparing = (e) => {
        e.toolbarOptions.items.unshift({
            location: 'before',
            template: ''//'importBtn'
        });
    }
    const toolBarItemRender = () => {
        return (
            <Row>
                <Col></Col>
                <Col></Col>
                <Col></Col>
                <Col></Col>
                <Col className='ml-5'>
                    <div className="container-fluid margin-bottoms" >
                        <ButtonGroup>
                            <LayouImportDropdown containertype={Configuration.entityType.location}
                                containername="location storage unit" warehouse_location_id={activelocationId}
                                warehouse_address_id={activeaddressId} companyId={companyId} warehouse_location_name={locationType}
                                warehouse_address_name={addressType} />
                        </ButtonGroup>
                        <Button outline onClick={() => { Datagridref.current.instance.showColumnChooser(); }}>
                            <i className="dx-icon dx-icon-column-chooser"></i>
                        </Button>
                    </div>
                </Col>
            </Row>
        )
    }

    console.log('PPSUZE', papersizes)

    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div>
                    <UncontrolledButtonDropdown>
                        <DropdownToggle color="link" className="pl-0 pb-0 btn-profile sidebar__link" >
                            <h4>Storage Unit</h4>
                        </DropdownToggle>
                    </UncontrolledButtonDropdown>
                </div>
            </Navbar>
            <div>
                {(skeleton === false) ?
                    (
                        <>
                            <LayoutsSketeon />
                            <StorageUnitSkeleton />
                        </>
                    ) : (
                        <>
                            <div className="container-fluid mt-0 mb-5">
                                <Container>
                                    <Row>
                                        <Col lg={8} className="warehouse-margin mt-3 mb-1">
                                            <p>You can manage all warehouse storage unit here</p>
                                        </Col>
                                    </Row>

                                    <Row className='mb-4'>
                                        <Col lg={4}>
                                            <FormGroup>
                                                <label>Warehouse location</label>
                                                <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }} >
                                                    <DropdownToggle caret color="secondary" outline type="select" className='form-control ml-3 warehouse-location-drp-width'>
                                                        {locationType}
                                                    </DropdownToggle>
                                                    <DropdownMenu persist >
                                                        {locations && locations.length > 0 ? (locations.map((item, index) => (
                                                            <DropdownItem onClick={() => { _handleOnClick([{ id: item.warehouse_location_id }, { name: item.location_name }]) }}>{item.location_name}</DropdownItem>
                                                        ))) : (
                                                                ''
                                                            )}
                                                    </DropdownMenu>
                                                </UncontrolledButtonDropdown>
                                            </FormGroup>
                                        </Col>
                                        <Col lg={6}>
                                            <FormGroup className='bg-light'>
                                                <label>Building</label>
                                                <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }}>
                                                    <DropdownToggle caret color="secondary" outline type="select" className='form-control ml-3 warehouse-location-drp-width'>
                                                        {addressType}
                                                    </DropdownToggle>
                                                    <DropdownMenu persist >
                                                        {buildings && buildings.length > 0 ? (buildings.map((item, index) => (
                                                            <DropdownItem onClick={() => { _handlebuildingOnClick([{ id: item.warehouse_address_id }, { name: item.building_alias }]) }}>{item.building_alias}</DropdownItem>
                                                        ))) : (
                                                                ''
                                                            )}
                                                    </DropdownMenu>
                                                </UncontrolledButtonDropdown>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </Container>
                                <div className='container margin-preview'>
                                    <Card>
                                        <CardBody>
                                            <Row className='mb-0 pb-0'>
                                                <Col lg={5} className='mt-2 ml-4'>
                                                    <FormGroup>
                                                        <ThemeConsumer>
                                                            {({ color }) => (
                                                                <CustomInput type="checkbox" color={color}
                                                                    checked={checkstatus}
                                                                    onChange={(e) => { _handleSelectStatus(e.target.checked) }} id="select" name="select" inline
                                                                    disabled={totalRecord > 0 ? false : true} />
                                                            )}
                                                        </ThemeConsumer>
                                                        {((selectedRecords) && (!selectedAll)) ? (
                                                            <span className='ml-2'>{selcount}
                                                                {locationColumnvisible ? ' locations ' :
                                                                    shelfcolumnvisible ? ' shelfs ' :
                                                                        bayColumnvisible ? ' bays ' : ''
                                                                }

                                                     selected</span>
                                                        ) : ''

                                                        }
                                                        {((selectedRecords) && (selectedAll)) ?
                                                            (
                                                                <span className=''>All records selected</span>
                                                            ) : ''

                                                        }


                                                        {((selectedRecords) && (!selectedAll) && (checked)) ? (
                                                            <span className=''>
                                                                <button className='btn p-0 m-2 btn-default text-primary'
                                                                    onClick={
                                                                        () => {
                                                                            setSelectedAll(true)
                                                                            setSelectMode('allPages');
                                                                        }
                                                                    }>Select all {totalRecord}
                                                                    {
                                                                        locationColumnvisible ? ' locations ' :
                                                                            shelfcolumnvisible ? ' shelfs ' :
                                                                                bayColumnvisible ? ' bays ' : ''
                                                                    }
                                                                </button>
                                                            </span>
                                                        ) : ''
                                                        }
                                                        {((selectedRecords) && (selectedAll)) ?
                                                            (
                                                                <span className=''>
                                                                    <button className='btn p-0 m-2 btn-default text-primary'
                                                                        onClick={
                                                                            () => {

                                                                                setSelectMode('page');
                                                                                Datagridref.current.instance.deselectAll()
                                                                                setSelectedAll(false)
                                                                                setCheckstatus(false)
                                                                                setTimeout(() => {
                                                                                    Datagridref.current.instance.selectAll()
                                                                                    setCheckstatus(true)
                                                                                }, 1000)
                                                                            }
                                                                        }>Select current page record </button>
                                                                </span>
                                                            ) : ''
                                                        }
                                                        {(selectedRecords) && (
                                                            <button className='btn ml-1 b-0  bg-light  dx-icon-print'
                                                                onClick={() => {
                                                                    setnoLabeltoprint('multiple')
                                                                    setSelectsizemodal(true)
                                                                }}>

                                                            </button>
                                                        )}

                                                    </FormGroup>
                                                </Col>

                                                {(selectedRecords && locationColumnvisible) && (
                                                    <Col></Col>
                                                )}
                                                {(selectedRecords && !locationColumnvisible) && (
                                                    <Col></Col>
                                                )}
                                                <Col className='ml-5 mb-0 pull-right' >
                                                    <div className={selectedRecords ? 'hide-props' : ''}>
                                                        <div className="container-fluid margin-bottoms m-300">
                                                            <ButtonGroup>
                                                                <LayouImportDropdown containertype={Configuration.entityType.location}
                                                                    containername="location storage unit" warehouse_location_id={activelocationId}
                                                                    warehouse_address_id={activeaddressId} companyId={companyId} warehouse_location_name={locationType}
                                                                    warehouse_address_name={addressType} />
                                                            </ButtonGroup>
                                                            <Button outline onClick={() => { Datagridref.current.instance.showColumnChooser(); }}>
                                                                <i className="dx-icon dx-icon-column-chooser"></i>
                                                            </Button>
                                                        </div>
                                                    </div>
                                                </Col>
                                            </Row>

                                            <div className="container-fluid">
                                                <iframe name="labeliframe" id='labeliframe' title='labeliframe'
                                                    src={iframeurl}
                                                    className='hide-props'
                                                ></iframe>
                                                <DataGrid
                                                    id="gridContainer"
                                                    dataSource={storageunit_data}
                                                    ref={Datagridref}
                                                    allowColumnReordering={true}
                                                    remoteOperations={true}
                                                    columnAutoWidth={true}
                                                    onInitNewRow={() => {
                                                        setAddingrecord(true)
                                                    }}
                                                    onRowInserted={() => {
                                                        setAddingrecord(false)
                                                    }}
                                                    onEditCanceled={() => {
                                                        setAddingrecord(false)
                                                    }}
                                                    onSelectionChanged={(e)=>{
                                                        if(e.selectedRowKeys.length > 0){
                                                            if(e.selectedRowKeys.length === 1){
                                                                setSelectedRecords(false)
                                                            }
                                                            else{
                                                            setSelectedRecords(true)
                                                            setSelcount(e.selectedRowKeys.length)
                                                            }
                                                        }
                                                        else{
                                                            setSelectedRecords(false)
                                                        }
                                                    }
                                                }
                                                    columnHidingEnabled={!screensize.matches ? true : false}

                                                    rowAlternationEnabled={true}
                                                    group={true}
                                                    onToolbarPreparing={(e) => { { onToolbarPreparing(e) } }}
                                                    showBorders={true}
                                                    onCellPrepared={(e) => {
                                                        let visibleColumns = Datagridref.current.instance.getVisibleColumns()
                                                        let location = visibleColumns.find(column => column.dataField === 'location_name');
                                                        let shelf = visibleColumns.find(column => column.dataField === 'shelf_name');
                                                        let bay = visibleColumns.find(column => column.dataField === 'bay_name');

                                                        if (isEmpty(location)) {
                                                            locationVisible = false
                                                            setLocationColumnvisible(false)
                                                        }
                                                        else {
                                                            setLocationColumnvisible(true)
                                                            locationVisible = true
                                                        }
                                                        if (isEmpty(shelf)) {
                                                            setshelfcolumnvisible(false)
                                                            shelfvisible = false

                                                        }
                                                        else {
                                                            setshelfcolumnvisible(true)
                                                            shelfvisible = true

                                                        }
                                                        if (isEmpty(bay)) {
                                                            setBayColumnvisible(false)
                                                            bayvisible = false
                                                        }
                                                        else {
                                                            setBayColumnvisible(true)
                                                            bayvisible = true
                                                        }
                                                        if (e.rowType == 'header' && e.column.command == "edit") {
                                                            e.cellElement.innerText = " Actions ";
                                                        }
                                                        if (e.rowType == 'filter' && e.column.command == "edit") {
                                                            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close text-danger'></i></button>";
                                                            e.cellElement.onclick = () => { Datagridref.current.instance.clearFilter() }
                                                        }
                                                        if (e.rowType == 'header' && e.column.type == "selection") {
                                                            e.cellElement.innerHTML = "";
                                                        }
                                                    }
                                                    }
                                                    onRowRemoving={async (e) => {
                                                        e.cancel = true;
                                                    }}
                                                    onSaving={
                                                        (e) => {
                                                            e.cancel = true;
                                                        }
                                                    }
                                                >
                                                    <ColumnChooser
                                                        enabled={false}
                                                        mode='select' />
                                                    <GroupPanel visible={true}
                                                        emptyPanelText={!screensize.matches ? 'Drag column here to group' : 'Drag subheader column here to group by that column'} />
                                                    <Paging enabled={true}
                                                        defaultPageSize={10} />
                                                    <Pager
                                                        showPageSizeSelector={true}
                                                        allowedPageSizes={[10, 15, 20]}
                                                        showInfo={true} />

                                                    <Editing
                                                        mode={editmode}
                                                        confirmDelete={false} />
                                                    <FilterRow visible={true} />
                                                    <Selection
                                                        mode="multiple"
                                                        allowSelectAll={true}
                                                        selectAllMode={selectMode}
                                                        showCheckBoxesMode='always'
                                                    />
                                                    <Column caption='Aisle' cssClass='text-center' showInColumnChooser={false}>
                                                        <Column dataField="warehouse_aisle_name" caption='Aisle name' cssClass='text-center' allowSorting={true} />
                                                        <Column caption='Action' visible={bayColumnvisible} cellRender={aisleaddBtn} cssClass='text-center' allowHiding={true} />
                                                    </Column>

                                                    <Column caption='Bay' cssClass='text-center' showInColumnChooser={false}>
                                                        <Column dataField="bay_name" caption='Bay name' cssClass='text-center' allowSorting={true} />
                                                        <Column dataField="zone_type" caption='Zone type' allowSorting={false} />
                                                        <Column caption='Action' visible={shelfcolumnvisible} cellRender={bayaddBtn} cssClass='text-center' allowHiding={true} />
                                                    </Column>
                                                    <Column caption='Shelf' visible={shelfcolumnvisible} cssClass='text-center'>
                                                        <Column dataField="shelf_name" caption='Shelf name' cssClass='text-center' allowSorting={true} />
                                                        <Column caption='Action' visible={locationColumnvisible} cellRender={locationaddBtn} cssClass='text-center loct' allowHiding={true} />
                                                    </Column>
                                                    <Column caption='Location' visible={locationColumnvisible} cssClass='text-center'>
                                                        <Column dataField="location_name" cssClass='text-center' caption='Location name' allowSorting={true} />
                                                        <Column dataField="location_address" caption='Location address' allowSorting={true} />
                                                        <Column dataField="container_type" cssClass='text-center' allowSorting={true} />
                                                        <Column dataField="container_name" cssClass='text-center' allowSorting={false} />
                                                    </Column>
                                                    <Column caption='Action' cellRender={editdelBtn} cssClass='text-center' allowHiding={false} showInColumnChooser={false} />
                                                    <Template name='importBtn' render={toolBarItemRender} />
                                                </DataGrid>
                                                {/* Addbay popup*/}
                                                <AddBaypopup action={action} isOpen={popupstate}
                                                    message={
                                                        <form>
                                                            <div className='form-group'>
                                                                <label>Bay name <i className='text-danger'>*</i></label>
                                                                <input type='text' name='bayName' onChange={(e) => {
                                                                    setBayname(e.target.value)
                                                                }} className='form-control' value={action == 'add' ? bayname : bayname} />
                                                            </div>
                                                            <div className='form-group'>
                                                                <label>Zone type <i className='text-danger'>*</i></label>
                                                                <select className='form-control' onChange={(e) => { setSelectedzoneid(e.target.value) }}>
                                                                    <option value={0}>Select zone type</option>
                                                                    {zonetypes.map(zonetype => (
                                                                        <option value={zonetype.warehouse_zone_type_id}

                                                                            selected={(action == 'edit' && zonetype.warehouse_zone_type == zonename) && true}
                                                                        >
                                                                            {zonetype.warehouse_zone_type}
                                                                        </option>
                                                                    ))
                                                                    }
                                                                </select>
                                                            </div>
                                                        </form>

                                                    }
                                                    onClose={togglePopup} onConfirm={action === 'add' ? saveBaypop : updateBaypop} text={action === 'add' ? 'Add' : 'Update'}
                                                    title={action === 'add' ? `Add bay to aisle ${aislename}` : `Edit bay 1 of aisle ${aislename}`} />

                                                {/* Add Shelf Pop up */}
                                                <AddShelfpopup action={actionsh} isOpen={popupstatesh}
                                                    message={
                                                        <form>
                                                            <div className='form-group'>
                                                                <label>Shelf name <i className='text-danger'>*</i></label>
                                                                <input type='text' name='shelfName' onChange={(e) => {
                                                                    if (actionsh == 'edit') {
                                                                        setShelfnamepop(e.target.value)
                                                                    }
                                                                    else {
                                                                        setShelfname(e.target.value)
                                                                    }
                                                                }} className='form-control' value={actionsh === 'add' ? shelfname : shelfnamepop} />
                                                            </div>
                                                        </form>
                                                    }
                                                    onClose={togglePopupsh} onConfirm={actionsh === 'add' ? saveShelfpop : updateShelfpop} text={actionsh === 'add' ? 'Add' : 'Update'}
                                                    title={actionsh === 'add' ? `Add Shelf to bay ${aislename}-${bayname}` : `Edit Shelf ${shelfname} of bay ${aislename}-${bayname}`} />

                                                {/* Location Popup */}
                                                <AddBaypopup action={actionlo} isOpen={popupstatelo}
                                                    message={
                                                        <form>
                                                            <div className='form-group'>
                                                                <label>Location name <i className='text-danger'>*</i></label>
                                                                <input type='text' name='locationName' onChange={(e) => {
                                                                    setLocationname(e.target.value)
                                                                }} className='form-control' value={actionlo === 'add' ? locationname : locationnamepop} />
                                                            </div>
                                                            <div className='form-group'>
                                                                <label>Container type  <i onClick={
                                                                    () => {
                                                                        setHideprops(!hideprops);
                                                                    }}
                                                                    className='float-right text-primary' style={{ 'margin-left': '220px' }}>
                                                                    <small>
                                                                        {(hideprops) ? 'Add new conatiner' : 'Associate with existing'}
                                                                        {/* { (actionlo == 'edit' && hideprops)? 'Add new conatiner':'Associate with existing'} */}
                                                                    </small>
                                                                </i>
                                                                </label>
                                                                <select className='form-control' onChange={(e) => { setSelectedzoneid(e.target.value) }}>
                                                                    <option value={0}>Select container type</option>
                                                                    {zonetypes.map(zonetype => (
                                                                        <option value={zonetype.warehouse_zone_type_id}
                                                                            selected={(actionlo == 'edit' && zonetype.warehouse_zone_type_id == selectedzoneid) && true}>
                                                                            {zonetype.warehouse_zone_type}
                                                                        </option>
                                                                    ))
                                                                    }
                                                                </select>
                                                            </div>
                                                            <div className={hideprops ? '' : 'hide-search'}>
                                                                <label>Container name</label>
                                                                <div className="input-group">

                                                                    <input type="text" className="form-control" placeholder="Search container" />
                                                                    <div className="input-group-append">
                                                                        <button className="btn btn-sm btn-secondary bg-light text-dark" type="button">
                                                                            <i className="fa fa-search"></i>
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            {actionlo == 'add' || actionlo == 'edit' ?
                                                                (<div className={hideprops ? 'hide-props' : ''}>
                                                                    <div className='form-group'>
                                                                        <label>Bin size </label>
                                                                        <select className='form-control' onChange={(e) => { setSelectedzoneid(e.target.value) }}>
                                                                            <option value={0}>Select container type</option>
                                                                            {zonetypes.map(zonetype => (
                                                                                <option value={zonetype.warehouse_zone_type_id}
                                                                                    selected={(actionlo == 'edit' && zonetype.warehouse_zone_type_id == selectedzoneid) && true}>
                                                                                    {zonetype.warehouse_zone_type}
                                                                                </option>
                                                                            ))
                                                                            }
                                                                        </select>
                                                                    </div>
                                                                    <div className='form-group'>
                                                                        <label>Bin name</label>
                                                                        <input type='text' name='' className='form-control' />
                                                                    </div>
                                                                </div>
                                                                ) : ''
                                                            }

                                                        </form>
                                                    }
                                                    onClose={togglePopuplo} onConfirm={saveBaypop} text={actionlo === 'add' ? 'Add' : 'Update'}
                                                    title={actionlo === 'add' ? `Add Location to aisle ${aislename} - ${bayname}-${shelfname}`
                                                        : `Edit Location ${aislename} - ${bayname}-${shelfname}`} />
                                                <ConfirmBox isOpen={delmodal} message={locationColumnvisible ? 'Are you sure you want to delete this location' :
                                                    shelfcolumnvisible ? 'Are you sure you want to delete this shelf' :
                                                        bayColumnvisible ? 'Are you sure you want to delete this bay' : ''}
                                                    onClose={toggledelModal} onConfirm={
                                                        locationColumnvisible ? deleteRow :
                                                            shelfcolumnvisible ? deleteStorageShelf :
                                                                bayColumnvisible ? deleteStorageBay : ''} text="Delete" title={locationColumnvisible ? 'Delete Location' :
                                                                    shelfcolumnvisible ? 'Delete Shelf' :
                                                                        bayColumnvisible ? 'Delete Bay' : ''} />
                                            </div>
                                        </CardBody>
                                    </Card>
                                </div>
                            </div>
                        </>
                    )}
            </div>


            {/* Add location popup */}
            <Modal isOpen={modal} toggle={toggleAdd} className="modal-outline-warning">
                <Formik
                    initialValues={locationDetails}
                    enableReinitialize={true}
                    validationSchema={yup.object().shape({
                        location_name: yup.string().nullable().required(`${Configuration.required} location name`),
                    })}
                    onSubmit={saveLocation}
                >
                    {({ errors, touched, values, resetForm }) => (
                        <Form>
                            <ModalHeader tag="h5">
                                <span>{editmodal ? 'Edit' : 'Add'} location to shelf {aislename}-{bayname}-{shelfname}</span>
                            </ModalHeader>
                            <ModalBody>
                                <FormGroup>
                                    <Label for="building_alias">
                                        Location name <span className="text-danger">*</span>
                                    </Label>
                                    <Field type="text"
                                        maxLength="6"
                                        onChange={(e) => onLocationInputChange(e.target.value)}
                                        placeholder="Enter location name"
                                        name="location_name"
                                        value={values.location_name}
                                        className={`${touched.location_name && errors.location_name && 'is-invalid'} bg-white form-control`} />
                                    {touched.location_name && errors.location_name &&
                                        <ErrorMessage name="location_name" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                <FormGroup>
                                    <Label for="state">
                                        Container Type
                                    </Label>
                                    {!editmodal &&
                                        <span className="float-right font-italic text-primary small"><a onClick={() => showNewContainerEdit()} color="link"
                                            style={{ cursor: "pointer" }}>
                                            {showHide ? 'Associate existing container' : 'Add new container'}</a></span>
                                    }
                                    {

                                        editmodal && (<span className="float-right font-italic text-primary small">
                                            {showHidePopupControl === 'clearassociation' ?
                                                <a onClick={() => clearContainerAssociationWithLocation()} color="link"
                                                    style={{ cursor: "pointer" }}>Clear association</a>
                                                :
                                                <a onClick={() => showNewContainer()} color="link"
                                                    style={{ cursor: "pointer" }}>
                                                    {showHidePopupControl === 'newcontainer' ? 'Associate existing container' : 'Add new container'}</a>
                                            }

                                        </span>)
                                    }
                                    <Field as="select" className="form-control"
                                        disabled={isDisabled}
                                        name="container_type_id" maxLength="100" id="state"
                                        onChange={(e) => {
                                            bindContainer(e.target.value)
                                        }}
                                        className={`${isDisabled ? '' : 'bg-white'} form-control`} >
                                        <option value="">Select container type</option>
                                        {
                                            containerType && containerType.length > 0 && containerType.map((entity, index) => (
                                                <option key={entity.entity_type_id + '' + index} value={entity.entity_type_id}>{entity.entity_type_name}</option>
                                            ))
                                        }
                                    </Field >
                                </FormGroup>
                                {showHidePopupControl === 'assocontainer' &&
                                    <FormGroup style={{ display: `${showHide ? 'none' : ''}` }}>
                                        <Label for="container_name"> Container name </Label>
                                        <InputGroup>
                                            <Typeahead
                                                //disabled={isDisabled}
                                                id="container_name"
                                                labelKey="container_name"
                                                onChange={singleSelections}
                                                options={options}
                                                name="container_name"
                                                className={`${isDisabled ? '' : 'bg-white'}`}
                                                defaultSelected={
                                                    options.filter(item => item.container_id
                                                        === locationDetails.container_id)}
                                                placeholder="Select container name..."
                                            />
                                            <InputGroupAddon addonType="append"  >
                                                <i className="fa fa-search ml-1"></i>
                                            </InputGroupAddon>
                                        </InputGroup>
                                    </FormGroup>
                                }
                                <div style={{ display: `${showHide ? '' : 'none'}` }}>
                                    <FormGroup>
                                        <Label for="container_size">
                                            Container Size
                                        </Label>
                                        <Field as="select" className="form-control"
                                            name="container_size_id" maxLength="100" id="container_size"
                                            className={`bg-white form-control`}
                                            onChange={(e) => {
                                                setContainerSizeId(e.target.value)
                                            }} >
                                            <option value="">Select container size</option>
                                            {
                                                boxSizeList && boxSizeList.length > 0 && boxSizeList.map((size, index) => (
                                                    <option key={size.entity_size_id + '' + index} value={size.entity_size_id}>{size.entity_size}</option>
                                                ))
                                            }
                                        </Field >
                                    </FormGroup>

                                </div>
                                {showHidePopupControl === 'newcontainer' &&
                                    <FormGroup>
                                        <Label for="container_name">
                                            Container name
                                        </Label>
                                        <Field type="text"
                                            maxLength="6"
                                            onChange={(e) => {
                                                onInputChange(e.target.value)
                                            }}
                                            className={`${isDisabled ? '' : 'bg-white'} form-control`}
                                            placeholder="Enter container name"
                                            disabled={isDisabled}
                                            name="container_name"
                                            value={values.container_name} />
                                    </FormGroup>
                                }
                                {
                                    showHidePopupControl === 'clearassociation' &&
                                    <FormGroup>
                                        <Label for="container_name">
                                            Container name
                                        </Label>
                                        <Field type="text"
                                            maxLength="6"
                                            onChange={(e) => {
                                                onInputChange(e.target.value)
                                            }}
                                            className={`${isDisabled ? '' : 'bg-white'} form-control`}
                                            placeholder="Enter container name"
                                            disabled={isDisabled}
                                            name="container_name"
                                            value={values.container_name} />
                                    </FormGroup>
                                }
                            </ModalBody>
                            <ModalFooter>
                                <button color="link" type="button" onClick={() => cancelPopup(resetForm)} className="btn btn-default text-warning">Cancel</button>
                                <ThemeConsumer>
                                    {
                                        ({ color }) => (
                                            <Button color={color} type="submit" className="btn btn-warning">
                                                {editmodal ? 'Update' : 'Add'}
                                            </Button>
                                        )
                                    }
                                </ThemeConsumer>

                            </ModalFooter>
                        </Form>
                    )}
                </Formik>
            </Modal>
            {/* Select size Modal */}
            <Printselectsizemodal action={actionsize} isOpen={selectsizemodal}
                message={
                    <form>
                        <div className='form-group'>
                            <label>Select size <i className='text-danger'>*</i></label>
                            <select className='form-control' onChange={(e) => {
                                setSize(e.target.value)
                                if (e.target.value != 0) {
                                    let sel_value = e.target.value
                                    let hind = sel_value.indexOf("-")
                                    let xind = sel_value.indexOf("X")
                                    let page_size_id = sel_value.substring(hind + 1)
                                    let x = sel_value.slice(0, xind)
                                    let y = sel_value.slice(xind + 1, hind)
                                    setX(x)
                                    setY(y)
                                    setIframeurl('')
                                    setPaperid(page_size_id)
                                }

                            }}>
                                <option value='0'>Select paper size</option>
                                {papersizes.map(papersize => (
                                    <option id={papersize.pdf_page_size_id}
                                        value={papersize.size + '-' + papersize.pdf_page_size_id}
                                    /* hidden={
                                         (locationColumnvisible && (papersize.size === '4.0X1.0' || papersize.size === '4X6')) ? false:
                                         shelfcolumnvisible && papersize.size === '4X6' ? false:
                                         bayColumnvisible && papersize.size === '4X6' ? false:true}*/
                                    >{papersize.width} x {papersize.height}</option>
                                ))}
                            </select>
                        </div>
                    </form>
                }
                onClose={toggleSizeModal} onConfirm={noLabeltoprint === 'single' ? printSingleRowLabel : printSelectedsizeLabel}
                text={'Print'}
                title={'Print Labels'} />
        </ >

    )
}

export default StorageUnit;