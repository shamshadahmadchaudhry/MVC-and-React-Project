
import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as yup from 'yup';
import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import {
    Modal,
    ModalHeader, ModalBody,
    ModalFooter, InputGroupAddon,
    ThemeConsumer, InputGroup,
    Button, FormGroup, Label
} from '../../../components';
import { Configuration } from '../../commoncomponents/configurationfile';
import { getEntityList } from '../../../services/binservice';
import { fetchContainerName } from '../../../services/containerservice';
import { Typeahead } from 'react-bootstrap-typeahead';
import { getBinList, getContainerTypeList } from '../../../services/binservice';
import { addStorageUnitLocation } from '../../../services/storageunitservice';
import { toast } from 'react-toastify';
import AlertMessage from '../../commoncomponents/alertmessage';

//let company_id = 0;
const LocationList = () => {
    toast.configure();
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [showHide, setShowHide] = useState(false);
    const [modal, setModal] = useState(false);
    const [editmodal, setEditModal] = useState(false);
    const [entityType, setEntityType] = useState([]);
    const [options, setoptions] = useState([]);
    const [boxSizeList, setBoxSizeList] = useState([]);
    const [locationDetails, setLocationDetails] = useState({
        location_name: '', container_type_id: '',
        container_id: '', container_name: '',
        entity_size_id: 0
    });

    useEffect(() => {
        loadentityType();
    }, []);

    const bindContainer = async (containerType) => {
        loadBoxSize(containerType);
        if (showHide) {
            fetchContainerNameDetails(containerType);
        }
        setLocationDetails({ ...locationDetails, container_type_id: containerType });
        let params = '';
        params += `?container_type=${containerType}&`
        params += `warehouse_location_id=${4}`
        let container_result = await getBinList(params);
        let arrayContainer = []
        if (containerType === Configuration.entityType.bin.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_bin_id;
                obj.container_name = item.bin_name;
                arrayContainer.push(obj)
            });
        } else if (containerType === Configuration.entityType.box.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_box_id;
                obj.container_name = item.box_name;
                arrayContainer.push(obj)
            });
        } else if (containerType === Configuration.entityType.cart.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_cart_id;
                obj.container_name = item.cart_name;
                arrayContainer.push(obj)
            });
        } else if (containerType === Configuration.entityType.pallete.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_pallete_id;
                obj.container_name = item.pallete_name;
                arrayContainer.push(obj)
            });
        } else if (containerType === Configuration.entityType.tote.toString()) {
            container_result?.data.map(item => {
                let obj = {}
                obj.container_id = item.container_tote_id;
                obj.container_name = item.tote_name;
                arrayContainer.push(obj)
            });
        }
        setoptions(arrayContainer);
    }

    const setContainerSizeId = async (e) => {
        setLocationDetails({ ...locationDetails, entity_size_id: e });
    }

    const loadentityType = async () => {
        let company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        const result = await getEntityList(`?company_id=${company_id}`);
        setEntityType(result.data.result)
    }

    const loadBoxSize = async (containerType) => {
        const result = await getContainerTypeList(containerType);
        setBoxSizeList(result.data.result)
    }

    const toggleAdd = () => {
        if (modal === false) {
            fetchLocationName();
            loadentityType();

        }
        setModal(!modal);
    }

    const cancelPopup = (resetForm) => {
        resetForm();
        setModal(!modal);
    }

    const toggleEdit = () => {
        setEditModal(!editmodal);
    }

    const fetchLocationName = async () => {
        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        const result = await fetchContainerName(Configuration.entityType.location, company_id, 1, 4);
        setLocationDetails({ ...locationDetails, location_name: result.data[0]['location_name'] });
    }

    const fetchContainerNameDetails = async (container_type_id) => {
        let entity_name = ''
        if (container_type_id === Configuration.entityType.bin)
            entity_name = 'bin_name';
        else if (container_type_id === Configuration.entityType.box)
            entity_name = 'box_name';
        else if (container_type_id === Configuration.entityType.cart)
            entity_name = 'cart_name';
        else if (container_type_id === Configuration.entityType.pallete)
            entity_name = 'pallete_name';
        else if (container_type_id === Configuration.entityType.tote)
            entity_name = 'tote_name';

        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        const result = await fetchContainerName(container_type_id, company_id, 1, 4);
        if (result.data) {
            setLocationDetails({ ...locationDetails, container_name: result.data[0][entity_name] });
        }
    }

    const saveLocation = async (values) => {
        let company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        if (showHide) {
            let body = { "boxes": body, created_by: userData.user_master_id, warehouse_location_id: active_location_id, company_id: company_id }
            const result = await addContainer(body, Configuration.entityType.box);
        }
        let body = {
            locations: [
                {
                    "location_name": locationDetails.location_name,
                    "prefix": "0",
                    "value": parseInt(locationDetails.location_name),
                    "location_address": "A1-BA1-SH1",
                    "container_type_id": locationDetails.container_type_id,
                    "container_id": locationDetails.container_id,
                    "warehouse_layout_aisle_id": 1,
                    "bay_storage_unit_id": 1,
                    "shelf_storage_unit_id": 1
                }],
            "created_by": userData.user_master_id,
            "warehouse_location_id": 4,
            "warehouse_address_id": 4,
            "company_id": company_id
        }
        // const response = await addStorageUnitLocation(body)
        // if (response.data['status'] === true) {
        //     toast.success(<AlertMessage type='success' title='Update Box'
        //         message={response.data['message']} />, { autoClose: 4000 });
        //     setModal(!modal)
        // }
        // else {
        //     toast.error(<AlertMessage type='error' title='Update Box'
        //         message={response.data['message']} />, { autoClose: false });
        // }
    }

    const singleSelections = (e) => {
        console.log('Selected values=>', e)
        console.log('v', locationDetails)
        if (e && e.length) {
            setLocationDetails({ ...locationDetails, container_name: e[0].container_name, container_id: e[0].container_id });
        }
    }

    const showNewContainer = () => {
        if (!showHide) {
            fetchContainerNameDetails(parseInt(locationDetails.container_type_id));
        }
        setShowHide(!showHide)
    }

    return (
        <div>
            <button className='btn btn-warning btn-sm pull-right mb-1 ml-2 mr-1' onClick={toggleAdd} >
                <i className='fa fa-plus'></i> Add Location</button>
            <button className='btn btn-warning btn-sm pull-right mb-1' >
                <i className='fa fa-edit'></i> Edit Location</button>


            <Modal isOpen={modal} toggle={toggleAdd} className="modal-outline-warning">
                <Formik
                    initialValues={locationDetails}
                    enableReinitialize={true}
                    validationSchema={yup.object().shape({
                        location_name: yup.string().nullable().required(`${Configuration.required} location name`),
                    })}
                    onSubmit={saveLocation}
                >
                    {({ errors, touched, values, resetForm }) => (
                        <Form>
                            <ModalHeader tag="h5">
                                <span>Add location to shelf A10-BA1-SH1</span>
                            </ModalHeader>
                            <ModalBody>
                                <FormGroup>
                                    <Label for="building_alias">
                                        Location name <span className="text-danger">*</span>
                                    </Label>
                                    <Field type="text"
                                        maxLength="6"
                                        placeholder="Enter location name"
                                        name="location_name"
                                        value={values.location_name}
                                        className={`${touched.location_name && errors.location_name && 'is-invalid'} bg-white form-control`} />
                                    {touched.location_name && errors.location_name &&
                                        <ErrorMessage name="location_name" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                <FormGroup>
                                    <Label for="state">
                                        Container Type <span className="text-danger">*</span>
                                    </Label>
                                    <span className="float-right small"><a onClick={() => showNewContainer()} color="link"
                                        style={{ cursor: "pointer" }}>{showHide ? 'Associate existing container' : 'Add new container'}</a></span>
                                    <Field as="select" className="form-control"
                                        name="container_type_id" maxLength="100" id="state"
                                        onChange={(e) => {
                                            bindContainer(e.target.value)
                                        }}
                                        className={`bg-white form-control`} >
                                        <option value="">Select container type</option>
                                        {
                                            entityType && entityType.length > 0 && entityType.map((entity, index) => (
                                                <option key={entity.entity_type_id + '' + index} value={entity.entity_type_id}>{entity.entity_type_name}</option>
                                            ))
                                        }
                                    </Field >
                                </FormGroup>
                                <FormGroup style={{ display: `${showHide ? 'none' : ''}` }}>
                                    <Label for="container_name"> Container name </Label>
                                    <InputGroup>
                                        <Typeahead
                                            id="container_name"
                                            labelKey="container_name"
                                            onChange={singleSelections}
                                            options={options}
                                            name="container_name"
                                            placeholder="Select container name..."
                                        />
                                        <InputGroupAddon addonType="append"  >
                                            <i className="fa fa-search ml-1"></i>
                                        </InputGroupAddon>
                                    </InputGroup>
                                </FormGroup>
                                <div style={{ display: `${showHide ? '' : 'none'}` }}>
                                    <FormGroup>
                                        <Label for="container_size">
                                            Container Size <span className="text-danger">*</span>
                                        </Label>
                                        <Field as="select" className="form-control"
                                            name="container_size_id" maxLength="100" id="container_size"
                                            className={`bg-white form-control`}
                                            onChange={(e) => {
                                                setContainerSizeId(e.target.value)
                                            }} >
                                            <option value="">Select container size</option>
                                            {
                                                boxSizeList && boxSizeList.length > 0 && boxSizeList.map((size, index) => (
                                                    <option key={size.entity_size_id + '' + index} value={size.entity_size_id}>{size.entity_size}</option>
                                                ))
                                            }
                                        </Field >
                                    </FormGroup>
                                    <FormGroup>
                                        <Label for="building_alias">
                                            Container name <span className="text-danger">*</span>
                                        </Label>
                                        <Field type="text"
                                            maxLength="6"
                                            placeholder="Enter container name"
                                            name="container_name"
                                            value={values.container_name}
                                            className={`bg-white form-control`} />
                                    </FormGroup>
                                </div>
                            </ModalBody>
                            <ModalFooter>
                                <button color="link" type="button" onClick={() => cancelPopup(resetForm)} className="btn btn-default text-warning">Cancel</button>
                                <ThemeConsumer>
                                    {
                                        ({ color }) => (
                                            <Button color={color} type="submit" className="btn btn-warning">
                                                Add
                                            </Button>
                                        )
                                    }
                                </ThemeConsumer>

                            </ModalFooter>
                        </Form>
                    )}
                </Formik>
            </Modal>

            <Modal isOpen={editmodal} toggle={toggleEdit} className="modal-outline-warning">
            </Modal>
        </div >
    )
}

export default LocationList
