import React from 'react'

function addlocations() {
    return (
        <div>

        </div>
    )
}

export default addlocations
