import React, { useState, useRef, useEffect } from 'react'
import DataGrid,
{
    Column,
    MasterDetail,
    Editing,
    Pager,
    Paging,
    FilterRow,
    Grouping,
    GroupPanel,
    RequiredRule,
    RemoteOperations,
    Selection
} from 'devextreme-react/data-grid';
import { Navbar, ThemeConsumer, Nav, Button, Container, Card, CardBody, Row, Col } from '../../components';
import Buildings from './Buildings';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import AlertMessage from '../commoncomponents/alertmessage';
import '../../styles/common.scss';
import CustomStore from 'devextreme/data/custom_store';
import ConfirmBox from '../commoncomponents/confirmbox';
import WarehouseLocationSkeleton from '../skeletenview/warehouselocationskeleton';
import { getWarehouseLocationList, updateWareHouseLocation, deleteWareHouseLocation } from '../../services/warehousemanagementservice';


const WarehouselocationList = () => {
    const datagridRef = useRef(null)
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [delmodal, setDelmodal] = useState(false);
    const [isactiveEdit, setIsactiveEdit] = useState(false)
    const [warehouse_location_id, setWarehouselLocationId] = useState(0);
    const [teststate, setTeststate] = useState(0)
    const [screensize, setScreensize] = useState({
        matches: window.matchMedia("(min-width: 1200px)").matches
    });
    useEffect(() => {
        const handler = e => setScreensize({ matches: e.matches });
        window.matchMedia("(min-width: 1200px)").addListener(handler);
    }, [screensize.matches])
    toast.configure();

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }

    const warehouse_data = new CustomStore({
        key: 'warehouse_location_id',
        load: async function (loadOptions) {
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                    params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                }
            });

            let company_id = 0
            if (CompanyListingStatus?.result?.response?.result.length > 1) {
                company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
            } else {
                company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
                console.log('compid', company_id)
            }
            params += `company_id=${company_id}&`
            params = params.slice(0, -1);
            console.log('params', params)
            let response = await getWarehouseLocationList(params);
            return response;

        },
        update: async (key, values) => {
            console.log(datagridRef.current.instance)
            try {
                let requestData = {
                    warehouse_location_id: key,
                    location_name: values.location_name,
                    modified_by: userData.user_master_id
                }
                const result = await updateWareHouseLocation(requestData);
                if (result.data['status'] === true) {
                    toast.success(<AlertMessage type='success' title='Update Warehouse Location'
                        message={result.data['data']} />, { autoClose: 4000 });
                    setIsactiveEdit(false)
                }
                else {
                    toast.error(<AlertMessage type='error' title='Warehouse Location'
                        message={result.data['data']} />, { autoClose: false });
                }
            }
            catch (error) {
                console.log(error)
            }
        },
        remove: async (key) => {
            setWarehouselLocationId(key)
        }
    });
    //============================================== end =====================================================

    //===============This code is used for the particular row from the warehouse list location start==================
    const deleteRow = async () => {
        const result = await deleteWareHouseLocation({ warehouse_location_id: warehouse_location_id, modified_by: userData.user_master_id });
        setDelmodal(!delmodal)
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title='Warehouse Location'
                message={result.data['data']} />, { autoClose: false })
        }
        else {
            toast.error(<AlertMessage type='error' title='Warehouse Location'
                message={result.data['data']} />, { autoClose: false })
        }
    }
    //================================================== end =====================================================

    //=========This code is used for set the modal popup start===========
    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }
    //========= end ===========

    //=========This code is used for set the delete icon in the list start===========
    const isDelete = (is_delete) => {
        return is_delete && ['FALSE'].indexOf(is_delete.trim().toUpperCase()) >= 0;
    }

    const allowDeleting = (e) => {
        console.log('e.row.data.is_delete', e.row.data.is_delete)
        return !isDelete(e.row.data.is_delete);
    }
    //========= end ===========

    //=========This code is used for set the header bold in the list start===========
    const renderLocationNameHeader = () => {
        return <b>Location name</b>;
    }
    const renderCityHeader = () => {
        return <b>City</b>;
    }
    const renderStateHeader = () => {
        return <b>State</b>;
    }
    const renderZipCodeHeader = () => {
        return <b>Zip Code</b>;
    }
    const renderCountryHeader = () => {
        return <b>Country</b>;
    }
    //========= end ===========

    //=========This code is used for set the action header in the list start===========
    const onCellPrepared = (e) => {
        if (e.rowType == 'header' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<b>Action</b>";
        }
        if (e.rowType == 'filter' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close dx-link-delete'></i></button>";
            e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
        }
    }

    const buildingRender = (props) => {
        // if(datagridRef.current.instance.hasEditData() && (isactiveEdit)){
        //     alert('Please save the changes you have made');
        // }
        // if(!datagridRef.current.instance.hasEditData() && isactiveEdit){
        //     datagridRef.current.instance.cancelEditData()
        //     setIsactiveEdit(false)
        // }
        // if(!isactiveEdit || !datagridRef.current.instance.hasEditData()){
        return (
            <Buildings {...props} />
        )
        // }
    }
    //========= end ===========
    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow add-navbar-stylex'>
                <div className="btn-group title-text-stylec">

                    <h4>Warehouse Locations</h4>
                </div>

                <ThemeConsumer>
                    {({ color }) => (
                        <div>
                            <Nav className='d-md-block'>
                                <span className="save-padding-add3plcompany">
                                    <Link to='/addlocations'>
                                        <Button color={color}> <span className="fa fa-plus"></span> Add Warehouse Location</Button>
                                    </Link>
                                </span>
                            </Nav>
                        </div>
                    )}
                </ThemeConsumer>
            </Navbar>
            <div className="container margin-top">
                {(CompanyListingStatus.isLoading === true) ?
                    (
                        <WarehouseLocationSkeleton />
                    ) : (
                        <>
                            <Row className='pt-0'>
                                <Col lg={12} className="warehouse-margin">
                                    <p>Manage all the warehouse locations of your company here.</p>
                                </Col>

                            </Row>
                            <Card className="mb-3">
                                <CardBody>

                                    <div className="container-fluid">
                                        <DataGrid id="grid-container"
                                            showBorders={true}
                                            dataSource={warehouse_data}
                                            ref={datagridRef}
                                            onCellPrepared={onCellPrepared}
                                            columnHidingEnabled={!screensize.matches ? true : false}
                                            remoteOperations={true}
                                            columnAutoWidth={true}
                                            // onSelectionChanged={(e)=>{
                                            //     setTeststate(e.selectedRowKeys)
                                            // }

                                            // }
                                            allowColumnReordering={true}
                                            // group={true}
                                            onEditingStart={(e) => {
                                                e.cancel = true;
                                                if (isactiveEdit) {
                                                    alert('Please save or cancel previous changes to continue')
                                                }
                                                else {
                                                    e.cancel = false;
                                                    setIsactiveEdit(true)
                                                }
                                            }}
                                            onEditCanceled={() => {
                                                setIsactiveEdit(false)
                                            }}
                                            onRowUpdated={() => {
                                                console.log('Updated')
                                            }}
                                            onSaved={() => {
                                                setIsactiveEdit(false)
                                            }}
                                            onRowRemoving={async (e) => {
                                                e.cancel = true;
                                                setWarehouselLocationId(e.data.warehouse_location_id)
                                                setDelmodal(true)
                                            }}
                                        >
                                            <RemoteOperations groupPaging={true} />
                                            <Editing
                                                mode="row"
                                                useIcons={true}
                                                allowUpdating={true}
                                                allowDeleting={allowDeleting}
                                                confirmDelete={false}
                                            >
                                            </Editing>
                                            {/* <Selection mode="multiple"
                                            showCheckBoxesMode='always' /> */}
                                            <GroupPanel visible={true}
                                                emptyPanelText={!screensize.matches ? 'Drag column here to group' : 'Drag a column header here to group by that column'} />
                                            {/* <Grouping autoExpandAll={autoExpandAll} /> */}
                                            <Paging defaultPageSize={10} />
                                            <Pager
                                                showPageSizeSelector={true}
                                                allowedPageSizes={[5, 10, 20]}
                                                showInfo={true} />
                                            <FilterRow visible={true} />
                                            <Column dataField="location_name"
                                                headerCellRender={renderLocationNameHeader} allowGrouping={true}>
                                                <RequiredRule />
                                            </Column>
                                            <Column dataField="city" allowEditing={false}
                                                headerCellRender={renderCityHeader}
                                                allowGrouping={true}
                                            />
                                            <Column dataField="state" allowEditing={false}
                                                headerCellRender={renderStateHeader} />
                                            <Column dataField="zip_code" allowEditing={false}
                                                headerCellRender={renderZipCodeHeader} />
                                            <Column dataField="country" allowEditing={false}
                                                headerCellRender={renderCountryHeader} />
                                            <MasterDetail
                                                enabled={isactiveEdit ? false : true}
                                                //component={Buildings}
                                                render={buildingRender}
                                            />
                                        </DataGrid>
                                    </div>
                                </CardBody>
                            </Card>
                            <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this warehouse location`}
                                onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete Warehouse Location" />
                        </>
                    )
                }

            </div>
        </>
    )

}

export default WarehouselocationList
