import React, { useState, useRef, useEffect } from 'react';
import { useSelector } from 'react-redux'
import { Configuration } from '../../commoncomponents/configurationfile';
import {
    getWarehouseLocationList,
    getBuildingDetailsList,
} from '../../../services/warehousemanagementservice';
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    Lookup,
    RequiredRule,
} from 'devextreme-react/data-grid';
import {
    Navbar,
    FormGroup,
    Card, CardBody, Container, ButtonGroup, Button, DropdownToggle,
    UncontrolledButtonDropdown, DropdownMenu, DropdownItem, Row, Col
} from '../../../components'
import '../../../styles/common.scss';
import { useLocation } from 'react-router-dom';
import {
    fetchTripName, getTripList, fetchTripType, fetchTripPriority, addTrip,
    updateTrip, deleteTrip
} from '../../../services/trip/tripservice';
import CustomStore from 'devextreme/data/custom_store';
import ConfirmBox from '../../commoncomponents/confirmbox';
import { toast } from 'react-toastify';
import AlertMessage from '../../commoncomponents/alertmessage';
import TripSkeleton from '../../warehousemanagement/skeleton/tripskeleton';
let Trip_name = '';
let companyId = 0;
let activelocationId = 0;
let activeaddressId = 0;
const Trip = () => {
    const location = useLocation()
    const datagridRef = useRef(null)
    const [locations, setLocations] = useState([])
    const [buildings, setBuildings] = useState([])
    const [disable, setDisable] = useState(true);
    const [showButton, setShowButton] = useState(false)
    const [mode, setMode] = useState('row');
    const [tripType, setTripType] = useState([])
    const [tripPriority, setTripPriority] = useState([])
    const [delmodal, setDelmodal] = useState(false);
    const [deltripid, setTripId] = useState(0);
    const [totalcount, setTotalCount] = useState(0)
    const [marginleft, setMarginLeft] = useState(114)
    const [locationType, setLocationType] = useState('Select Location')
    const [addressType, setAddressType] = useState('Select Address')
    const [isselect, setIsSelect] = useState(false)
    const [skeleton, setSkeleton] = useState(false)
    toast.configure();
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);

    const binDropdownData = [{ id: 2, name: "Add 2 Trips" }, { id: 3, name: "Add 3 Trips" },
    { id: 4, name: "Add 4 Trips" }, { id: 5, name: "Add 5 Trips" }, { id: 6, name: "Add 6 Trips" }, { id: 7, name: "Add 7 Trips" },
    { id: 8, name: "Add 8 Trips" }, { id: 9, name: "Add 9 Trips" }, { id: 10, name: "Add 10 Trips" }]

    useEffect(() => {
        loadTripType()
        loadTripPriority()
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            WarehouseLocations(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
            companyId = CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id
        }
        else {
            WarehouseLocations(CompanyListingStatus?.result?.response?.result[0].company_id)
            companyId = CompanyListingStatus?.result?.response?.result[0].company_id
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])


    const loadTripType = async () => {
        let TripType = await fetchTripType()
        setSkeleton(true)
        console.log('TripType', TripType.data.data)
        setTripType(TripType.data.data)
    }
    const loadTripPriority = async () => {
        let TripPriority = await fetchTripPriority()
        console.log('TripPriority', TripPriority.data.data)
        setTripPriority(TripPriority.data.data)
    }


    //Load buildings
    const loadBuildings = async (locationId) => {
        let params = `?warehouse_location_id=${locationId}`
        let buildingResp = await getBuildingDetailsList(params)
        setBuildings(buildingResp.data)
        activeaddressId = buildingResp.data[0].warehouse_address_id
        setAddressType(buildingResp.data[0].building_alias)

    }
    //Load warehouse locations
    const WarehouseLocations = async (company_id) => {
        let params = `?company_id=${company_id}`
        let response = await getWarehouseLocationList(params)
        loadBuildings(response.data[0].warehouse_location_id)
        activelocationId = response.data[0].warehouse_location_id
        setLocationType(response.data[0].location_name)
        setLocations(response.data)
        return response.data
    }

    useEffect(() => {
        setIsSelect(true)
        setAddressType('')
    }, [activelocationId])
    const _handleOnClick = (e) => {
        datagridRef.current.instance.cancelEditData();
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setLocationType(str)
        }
        else {
            setLocationType(e[1].name)
        }
        activelocationId = e[0].id
        loadBuildings(e[0].id);
    }
    const _handlebuildingOnClick = (e) => {
        datagridRef.current.instance.cancelEditData();
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setAddressType(str)
        }
        else {
            setAddressType(e[1].name)
        }
        activeaddressId = e[0].id
    }
    const getTripName = async (id) => {
        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        const result = await fetchTripName(company_id, id, activelocationId, activeaddressId);
        return result;
    }
    const _SingleRow = async () => {
        setMode('row')
        const result = await getTripName(1)
        datagridRef.current.instance.cancelEditData()
        Trip_name = result.data[0].Trip_name;
        datagridRef.current.instance.addRow()
    }
    const _handledropdownItem = async (id) => {
        setMarginLeft(66)
        setShowButton(true)
        setMode('batch')
        setDisable(false)
        const result = await getTripName(id)
        datagridRef.current.instance.cancelEditData()
        for (var i = 0; i < id; i++) {
            Trip_name = result.data[i]['Trip_name']
            datagridRef.current.instance.addRow()
            console.log('Trip_name', Trip_name)
        }

    }
    const _handleName = async (e) => {
        e.data['trip_name'] = Trip_name
    }

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }

    const trip_data = new CustomStore({
        key: 'trip_master_id',
        load: async function (loadOptions) {
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                    params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                }
            });
            params += `company_id=${companyId}&`
            params += `warehouse_location_id=${activelocationId}&`
            params += `warehouse_address_id=${activeaddressId}&`
            params = params.slice(0, -1);
            let response = await getTripList(params);
            setTotalCount(response.totalCount)
            return response;

        }
    });
    //========= This code is used for show the action header label and show the filter button ===========
    const onCellPrepared = (e) => {
        if (e.rowType == 'header' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<b>Action</b>";
        }
        if (e.rowType == 'filter' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close dx-link-delete'></i></button>";
            e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
        }
    }
    //======================== End =====================================================================

    const onSaving = React.useCallback((e) => {
        e.cancel = true;
        SaveTrip(e.changes, e.component);

    }, []);
    const SaveTrip = async (body, component) => {
        console.log('activeaddressId.................', activeaddressId)
        console.log('activelocationId.................', activelocationId)
        try {
            let data = body[0]
            if (body[0].type === 'insert') {
                body = {
                    "trips": body, created_by: userData.user_master_id, warehouse_location_id: activelocationId,
                    company_id: companyId, warehouse_address_id: activeaddressId
                }
                const result = await addTrip(body);
                setMode('row')
                setDisable(true)
                if (result.data['status'] === true) {
                    toast.success(<AlertMessage type='success' title='Save Trip'
                        message={result.data['message']} />, { autoClose: 4000 });
                    setShowButton(false)
                }
                else {
                    toast.error(<AlertMessage type='error' title='Save Trip'
                        message={result.data['message']} />, { autoClose: false });
                }
                datagridRef.current.instance.cancelEditData();
                await component.refresh(true);
                // component.cancelEditData();
                return result;
            } else if (body[0].type === 'update') {
                let update_data = {
                    trip_master_id: data.key,
                    type_id: data.data.trip_type_id,
                    priority_id: data.data.trip_priority_id,
                    estimated_time: data.data.estimated_time,
                    warehouse_address_id: activeaddressId,
                    warehouse_location_id: activelocationId,
                    company_id: companyId,
                    created_by: userData.user_master_id,
                }
                const result = await updateTrip(update_data);
                if (result.data['status'] === true) {
                    toast.success(<AlertMessage type='success' title='Update Trip'
                        message={result.data['message']} />, { autoClose: 4000 });
                }
                else {
                    toast.error(<AlertMessage type='error' title='Update Trip'
                        message={result.data['message']} />, { autoClose: false });
                }
                await component.refresh(true);
                component.cancelEditData();
                return result;
            }
            else {
                setTripId(body[0].key)
                setDelmodal(true)
            }
        }
        catch (error) {
            console.log(error)
        }
    }
    //===================== This modal is used for the delete ============================
    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }

    //========================= This funccction is used for the delete particular row ===========
    const deleteRow = async () => {
        const result = await deleteTrip(deltripid);
        setDelmodal(!delmodal)
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title='Delete Trip'
                message={result.data['message']} />, { autoClose: 4000 });
        }
        else {
            toast.error(<AlertMessage type='error' title='Delete Trip'
                message={result.data['message']} />, { autoClose: false });
        }
    }
    //======================== End =====================================================
    const onEditorPreparing = (e) => {
        if (e.parentType == 'dataRow' && e.dataField == 'estimated_time') {
            e.editorOptions.onKeyPress = function (args) {
                var event = args.event;
                if (!/^0|[1-9]\d*$/.test(String.fromCharCode(event.keyCode)))
                    event.preventDefault();
            }
            e.editorName = "dxTextBox"
        }
    }
    const maxLength = { maxLength: 3 }
    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div style={{ justifyContent: 'flex-start', display: 'inline-flex' }}>
                    <h4>Trips</h4>
                </div>
            </Navbar>
            {(skeleton === false) ?
                (
                    <TripSkeleton />
                ) : (
                    <>
                        <Container className="mb-5">
                            <Row>
                                <Col lg={12} className="warehouse-margin mt-3 mb-1">
                                    <p>Select warehouse location to create trips under it. </p>
                                </Col>
                            </Row>
                            <Row className='mb-1'>
                                <Col lg={4} className='mb-1'>
                                    <FormGroup>
                                        <label>Warehouse location</label>
                                        <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }} >
                                            <DropdownToggle caret color="secondary" outline type="select" className='form-control ml-3 warehouse-location-drp-width'>
                                                {locationType}
                                            </DropdownToggle>
                                            <DropdownMenu persist >
                                                {locations && locations.length > 0 ? (locations.map((item, index) => (
                                                    <DropdownItem onClick={() => { _handleOnClick([{ id: item.warehouse_location_id }, { name: item.location_name }]) }}>{item.location_name}</DropdownItem>
                                                ))) : (
                                                        ''
                                                    )}
                                            </DropdownMenu>
                                        </UncontrolledButtonDropdown>
                                    </FormGroup>
                                </Col>
                                <Col lg={6}>
                                    <FormGroup className='bg-light'>
                                        <label>Building</label>
                                        <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }}>
                                            <DropdownToggle caret color="secondary" outline type="select" className='form-control ml-3 warehouse-location-drp-width'>
                                                {addressType}
                                            </DropdownToggle>
                                            <DropdownMenu persist >
                                                {buildings && buildings.length > 0 ? (buildings.map((item, index) => (
                                                    <DropdownItem onClick={() => { _handlebuildingOnClick([{ id: item.warehouse_address_id }, { name: item.building_alias }]) }}>{item.building_alias}</DropdownItem>
                                                ))) : (
                                                        ''
                                                    )}
                                            </DropdownMenu>
                                        </UncontrolledButtonDropdown>
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Card className="mb-3" className="margin-list">
                                <CardBody>
                                    <h5 className='ml-3'>Manage Trips</h5>
                                    {/* This code is used for the prepopulating data and save the data and also refresh the data */}
                                    <Row>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col className='ml-5'>
                                            <div className="container-fluid margin-bottoms" >
                                                <ButtonGroup>
                                                    <ButtonGroup style={{ marginLeft: `${marginleft}%` }}>
                                                        <Button outline onClick={() => _SingleRow()} className='ml-2'>
                                                            <i className="fa fa-fw fa-plus"></i>
                                                        </Button>
                                                        <UncontrolledButtonDropdown direction="down">
                                                            <DropdownToggle color="secondary" outline caret />
                                                            <DropdownMenu right>
                                                                {binDropdownData && binDropdownData.length > 0 ? (binDropdownData.map((item, index) => (
                                                                    <DropdownItem onClick={() => _handledropdownItem(item.id)}>
                                                                        {item.name}
                                                                    </DropdownItem>
                                                                ))) : (
                                                                        ''
                                                                    )}
                                                            </DropdownMenu>
                                                        </UncontrolledButtonDropdown>
                                                    </ButtonGroup>
                                                    <ButtonGroup style={{ visibility: showButton ? 'visible' : 'hidden' }}>
                                                        <Button outline className='ml-2' onClick={() => { datagridRef.current.instance.saveEditData(); setMarginLeft(115) }} disabled={disable} >
                                                            <i className="dx-icon-save dx-link-save"></i>
                                                        </Button>
                                                        <Button outline onClick={() => { datagridRef.current.instance.cancelEditData(); setDisable(true); setMode('row'); setShowButton(false); setMarginLeft(115) }} disabled={disable}>
                                                            <i className="dx-icon-revert dx-cancel-edit"></i>
                                                        </Button>
                                                    </ButtonGroup>
                                                </ButtonGroup>
                                            </div>
                                        </Col>
                                    </Row>
                                    {/* ================ End =====================*/}
                                    <div className="container-fluid">
                                        <DataGrid id="grid-container"
                                            showBorders={true}
                                            dataSource={trip_data}
                                            ref={datagridRef}
                                            keyExpr="trip_master_id"
                                            onCellPrepared={onCellPrepared}
                                            remoteOperations={true}
                                            allowColumnReordering={true}
                                            onSaving={onSaving}
                                            onInitNewRow={(e) => {
                                                _handleName(e)
                                            }}
                                            rowAlternationEnabled={true}
                                            onToolbarPreparing={(e) => {
                                                e.toolbarOptions.visible = false
                                            }}
                                            onEditorPreparing={onEditorPreparing}
                                        >
                                            <Editing
                                                mode={mode}
                                                useIcons={true}
                                                allowUpdating={true}
                                                allowDeleting={true}
                                                confirmDelete={false}
                                            >
                                            </Editing>
                                            <Paging defaultPageSize={10} />
                                            <Pager
                                                showPageSizeSelector={totalcount > 10 ? true : false}
                                                allowedPageSizes={[10, 15, 20]}
                                                showInfo={true} />
                                            <FilterRow visible={true} />
                                            <Column dataField="trip_name" caption="Trip name" allowEditing={false}  >
                                                <RequiredRule />
                                            </Column>
                                            <Column dataField="trip_type_id" caption="Type">
                                                <RequiredRule />
                                                <Lookup dataSource={tripType} valueExpr="trip_type_id" displayExpr="trip_type_name" />
                                            </Column>
                                            <Column dataField="trip_priority_id" caption="Priority">
                                                <Lookup dataSource={tripPriority} valueExpr="trip_priority_id" displayExpr="priority_name" />
                                                <RequiredRule />
                                            </Column>
                                            <Column dataField="estimated_time" caption="Estimated time (min.)"
                                                editorOptions={maxLength}
                                                alignment="center">
                                                <RequiredRule />
                                            </Column>
                                        </DataGrid>
                                    </div>
                                    <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this trip`}
                                        onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete Trip" />
                                </CardBody>
                            </Card>
                        </Container>
                    </>
                )}
        </>

    )
}


export default Trip;
