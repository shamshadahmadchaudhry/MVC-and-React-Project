import React, { useEffect, useRef, useState } from 'react';
import {
    getUserTripList, TimerStart, UserStatusUpdate
} from '../../../services/trip/usertripservice';
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    RequiredRule,
    Button as Btndevextreme
} from 'devextreme-react/data-grid';
import {
    Navbar,
    FormGroup,
    Card, CardBody, Container, ButtonGroup, Button, DropdownToggle,
    UncontrolledButtonDropdown, DropdownMenu, DropdownItem, Row, Col,
    ThemeConsumer,
    Nav
} from '../../../components'
import { useSelector } from 'react-redux'
import '../../../styles/common.scss';
let company_id = 0;
const TripDetails = () => {
    const datagridRef = useRef(null)
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data)
    const [userTripList, setUserTripList] = useState([])


    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div style={{ justifyContent: 'flex-start', display: 'inline-flex' }}>
                    <h4>Trip Details</h4>
                </div>
                <ThemeConsumer>
                    {({ color }) => (
                        <div>
                            <Nav className='d-md-block'>
                                <span className="save-padding-add3plcompany">
                                    <Button color={color}>  Finish <span className="fa fa-font-awesome icon-margin-left"></span></Button>
                                </span>
                            </Nav>
                        </div>
                    )}
                </ThemeConsumer>
            </Navbar>
            <Container className="mb-5">
                <Row>
                    <Col lg={12} className="warehouse-margin mt-3 mb-1">
                        <p>You can view all trip details here.</p>
                    </Col>
                </Row>
                <Row>
                    <Col>Trip Type : Order</Col>
                    <Col>Priority : High Priority</Col>
                    <Col>Estimated Time : 60 min.</Col>
                    <Col>Assigned By : Esra Arnason</Col>
                    <Col>Elapsed Time : 00:55:12</Col>
                </Row>
                <div className="mt-1">
                    <DataGrid id="grid-container"
                        showBorders={true}
                        dataSource={userTripList}
                        ref={datagridRef}
                        keyExpr="trip_scheduling_id"
                        remoteOperations={true}
                        allowColumnReordering={true}
                        rowAlternationEnabled={true}
                        onToolbarPreparing={(e) => {
                            e.toolbarOptions.visible = false
                        }}
                    >
                    </DataGrid>
                </div>
            </Container>
        </>
    )
}
export default TripDetails;