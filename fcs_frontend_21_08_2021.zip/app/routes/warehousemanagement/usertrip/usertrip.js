import React, { useEffect, useRef, useState } from 'react';
import {
    getUserTripList, TimerStart, UserStatusUpdate
} from '../../../services/trip/usertripservice';
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    RequiredRule,
    Button as Btndevextreme
} from 'devextreme-react/data-grid';
import {
    Navbar,
    FormGroup,
    Card, CardBody, Container, ButtonGroup, Button, DropdownToggle,
    UncontrolledButtonDropdown, DropdownMenu, DropdownItem, Row, Col,
    ThemeConsumer
} from '../../../components'
import { useSelector } from 'react-redux'
import '../../../styles/common.scss';
import { useHistory } from 'react-router-dom';
let company_id = 0;
const UserTrip = () => {
    let history = useHistory()
    const datagridRef = useRef(null)
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data)
    const [userTripList, setUserTripList] = useState([])
    const [showStart, setShowStart] = useState("")
    const [showButtons, setShowButtons] = useState("none")
    const [showResume, setShowResume] = useState("none")
    const [showPause, setShowPause] = useState("")
    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id, user_master_id
            loadUserTripList(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id, user_master_id)
        }
        else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id, userData.user_master_id
            loadUserTripList(CompanyListingStatus?.result?.response?.result[0].company_id, userData.user_master_id)
        }
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])
    const loadUserTripList = async (company_id, user_id) => {
        let UserTripList = await getUserTripList(company_id, user_id)
        console.log('UserTripList', UserTripList)
        setUserTripList(UserTripList.data.data)
    }
    const _handleStart = () => {
        loadUserTripList(company_id, userData.user_master_id)
        setShowStart("none")
        setShowButtons("")
    }
    const _handleResume = async () => {
        loadUserTripList(company_id, userData.user_master_id)
        setShowResume("none")
        setShowPause("")
        await UserStatusUpdate(1, 1)
    }
    const _handlePause = async () => {
        loadUserTripList(company_id, userData.user_master_id)
        setShowResume("")
        setShowPause("none")
        await UserStatusUpdate(1, 2)
    }
    const _handleFinish = async () => {
        // await TimerStart(e.row.data.trip_scheduling_id, 0)
        await TimerStart(1, 1)
    }
    const _btnhandleStart = async (e) => {
        await TimerStart(e.row.data.trip_scheduling_id, 0)
        history.push('/tripdetails')
    }
    const _btnhandleViewStatus = () => {

    }


    const isPlay = (is_play) => {
        console.log('is_play', is_play)
        return is_play && ['FALSE'].indexOf(is_play.trim().toUpperCase()) >= 0;
    }

    const _render = (e) => {
        console.log('shamshad', e.row.data.is_play)
        return !isPlay(e.row.data.is_play);
    }
    const onCellPrepared = (e) => {
        if (e.rowType == 'data' && e.column.caption == "Action") {
            console.log('e', e)
            // if (e.data.is_play == "False") {
            // console.log('e.data.is_play', e.data)
            // console.log('e.data.is_play', e.data.is_play)
            // debugger;
            e.column.buttons[0].cssClass = 'fa fa-play-circle'
            console.log('e.rowIndex', e.rowIndex)
            if (e.rowIndex == 0) {
                // console.log('e.data.is_play', e.data.is_play)
                // //console.log('e', e)
                // console.log('e.data.is_play', e.data.is_play)
                //console.log('e.column.buttons', e.column.buttons)
                // console.log('if e.column.buttons[0].hint', e.column.buttons[0].hint)
                // console.log('if e.data.is_play', e.data.is_play)
                console.log('shamshad')
                e.column.buttons[0].cssClass = ''
                // console.log('e.column.buttons[0].cssClass', e.column.buttons[0].cssClass)
            }
            if (e.rowIndex == 1) {
                e.column.buttons[0].cssClass = ''
            }
            // else {
            //     // console.log('else e.column.buttons[0].hint', e.column.buttons[0].hint)
            //     // console.log('else e.data.is_play', e.data.is_play)
            //     console.log('habib')
            //     e.column.buttons[0].cssClass = ''
            // }
            //console.log('e.data.is_play', e.data.is_play)
        }
    }

    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div style={{ justifyContent: 'flex-start', display: 'inline-flex' }}>
                    <h4>My Trips</h4>
                </div>
            </Navbar>
            <Container className="mb-5">
                <Row>
                    <Col lg={12} className="warehouse-margin mt-3 mb-1">
                        <p>You can manage assigned task here.</p>
                    </Col>
                </Row>
                <Row>
                    <Col lg={9}>
                        <Card style={{ height: "53px" }}>
                            <CardBody style={{ padding: "0.95rem" }}>
                                {userData && userData.first_name + ' ' + userData.last_name}
                            </CardBody>
                        </Card>
                    </Col>
                    <Col lg={3}>
                        <div style={{ display: showStart }}>
                            <ThemeConsumer>
                                {({ color }) => (
                                    <Button type="button" onClick={() => _handleStart()} className="btn-start"
                                    >
                                        Start <i class="fa fa-play mr-2 icon-margin-left"></i>
                                    </Button>
                                )}
                            </ThemeConsumer>
                        </div>
                        <div style={{ display: showButtons }}>
                            <ThemeConsumer>
                                {({ color }) => (
                                    <>
                                        <FormGroup>
                                            <span style={{ display: showPause }}>
                                                <Button color={color} type="button" className="btn-pause btn-sm" onClick={() => _handlePause()}
                                                >
                                                    Pause <i class="fa fa-pause icon-margin-left" aria-hidden="true"></i>
                                                </Button>
                                            </span>
                                            <span style={{ display: showResume }}>
                                                <Button type="button" className="btn-resume btn-sm" onClick={() => _handleResume()}
                                                >
                                                    Resume <i class="fa fa-play mr-2 icon-margin-left"></i>
                                                </Button>
                                            </span>
                                            <Button type="button" className="btn-finish btn-sm" onClick={() => _handleFinish()}
                                            >
                                                Finish <i class="fa fa-font-awesome icon-margin-left" aria-hidden="true"></i>
                                            </Button>
                                        </FormGroup>
                                    </>
                                )}
                            </ThemeConsumer>
                        </div>
                    </Col>
                </Row>
                <div className="mt-1">
                    <DataGrid id="grid-container"
                        showBorders={true}
                        dataSource={userTripList}
                        ref={datagridRef}
                        keyExpr="trip_scheduling_id"
                        remoteOperations={true}
                        allowColumnReordering={true}
                        rowAlternationEnabled={true}
                        onToolbarPreparing={(e) => {
                            e.toolbarOptions.visible = false
                        }}
                        onCellPrepared={onCellPrepared}
                    >
                        <Editing
                            mode="row"
                            useIcons={true}
                        >
                        </Editing>
                        <FilterRow visible={true} />
                        <Column dataField="trip_name" caption="Trip name" allowEditing={false}  >
                            <RequiredRule />
                        </Column>
                        <Column dataField="type" caption="Type">
                        </Column>
                        <Column dataField="priority" caption="Priority">
                        </Column>
                        <Column dataField="estimated_time" caption="Estimated time (min.)"
                            alignment="center">
                        </Column>
                        <Column dataField="assigned_by" caption="Assigned by">
                        </Column>
                        <Column dataField="estimated_starting_time" caption="Assigned on">
                        </Column>
                        {/* render={(e) => _render(e)} */}
                        <Column type="buttons" caption="Action">

                            <Btndevextreme hint="Start" cssClass="fa fa-play-circle" onClick={(e) => _btnhandleStart(e)}
                            />
                            <Btndevextreme hint="File" cssClass="fa fa-file" onClick={(e) => _btnhandleViewStatus(e)}
                            />
                        </Column>
                    </DataGrid>
                </div>
            </Container>
        </>
    )
}
export default UserTrip;