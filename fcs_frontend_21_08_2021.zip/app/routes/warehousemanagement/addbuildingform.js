import React, { useState } from 'react';
import { toast } from 'react-toastify';
import { verifyAddress, addBuildingAddress } from '../../services/warehousemanagementservice';
import AlertMessage from '../commoncomponents/alertmessage';
import {
  ThemeConsumer, Button, Modal, ModalHeader, ModalBody, ModalFooter
  , Card, CardBody
} from '../../components';
import { Configuration } from '../commoncomponents/configurationfile';
const AddBuildingForm = ({ zipcode, state, city, warehouseLocationId, reload }) => {
  const [modal, setModal] = useState(false);
  const [addressDetails, setaddressDetails] = useState({});
  const [isAddressLoading, setisAddressLoading] = useState(false);

  const [buildingdetails, setBuildingdetails] = useState({
    building_alias: '',
    address_line1: '',
    address_line2: '',
    capacity: ''
  })
  const [address, setAddress] = useState('')
  const [error, setError] = useState({
    alias_err: '',
    address1_err: '',
    address2_err: '',
    capacity_err: ''
  });
  const [formIsValid, setformIsValid] = useState(false);
  toast.configure();
  const handleChange = (e) => {
    setBuildingdetails({ ...buildingdetails, [e.target.name]: e.target.value });
  }

  // Toggle popup for address standardize
  const toggle = () => {
    setModal(!modal);
    setisAddressLoading(false);
  }

  const standardizeAddress = async () => {
    if (buildingdetails.building_alias != '' && buildingdetails.address_line1 != '' && buildingdetails.address_line2 != '' && buildingdetails.capacity != '') {
      if (buildingdetails.address_line2.match(Configuration.alphanumComaSpace)
        && buildingdetails.address_line1.match(Configuration.alphanumComaSpace)
        && buildingdetails.capacity.match(Configuration.decimal)
        && buildingdetails.building_alias.match(Configuration.alphanumericSpace)) {
        setisAddressLoading(true);
        let response = await verifyAddress({
          Address1: buildingdetails.address_line1,
          Address2: buildingdetails.address_line2,
          zip_code: zipcode,
          state: state,
          city: city
        });
        console.log(response)
        if (response.data && response.data.length > 0) {
          let address = response.data[0];
          setaddressDetails(address);
          setBuildingdetails({
            warehouse_location_id: warehouseLocationId,
            building_alias: buildingdetails.building_alias,
            address_line1: address.Address1, address_line2: address.Address2,
            zip_code: zipcode, capacity: buildingdetails.capacity,
            city: address.city, state: address.state
          });
          setModal(!modal);
        } else {
          toast.error(<AlertMessage type='error' title='Invalid Standardize'
            message={'Please put correct address for standardize'} />, { autoClose: false });
        }
        setisAddressLoading(false);
      }
      else {
        toast.error(<AlertMessage type='error' title='Error Adding Address'
          message='Invalid user input' />, { autoClose: false });
      }
    }
    else {
      toast.error(<AlertMessage type='error' title='Error Adding Address'
        message='All fields are required' />, { autoClose: false });
    }
  }

  // Add standardized address into building list
  const addLocation = async () => {
    setModal(!modal);
    let building = {
      warehouse_location_id: warehouseLocationId,
      building_alias: buildingdetails.building_alias,
      capacity: buildingdetails.capacity,
      address_line_1: buildingdetails.address_line1,
      address_line_2: buildingdetails.address_line2,
      city: buildingdetails.city,
      state: buildingdetails.state,
      country: buildingdetails.country,
      zip_code: buildingdetails.zip_code,
    }
    let response = await addBuildingAddress(building);
    if (response.data.status) {
      toast.success(<AlertMessage type='success' title='New Building Added'
        message={'New building added to the list successfully!'} />, { autoClose: 4000 });
      reload(2);
    } else {
      toast.error(<AlertMessage type='error' title='Error Standardizing Address'
        message={response.data.data} />, { autoClose: false });
      reload(1);
    }
    setBuildingdetails({
      zip_code: '', country: '',
      building_alias: '', city: '', state: '',
      address_line1: '', address_line2: '', capacity: ''
    });
  }




  //Validators 
  // Validate alias
  const validateAlias = () => {
    if (!buildingdetails.building_alias.match(Configuration.alphanumericSpace)) {
      setError({
        alias_err: 'Please enter your building alias'
      })
      setformIsValid(false);
    }
    else {
      setError({
        alias_err: ''
      })
      setformIsValid(true);
    }
  }
  // Validate Address Line 1
  const validateAddress1 = () => {
    if (!buildingdetails.address_line1.match(Configuration.alphanumComaSpace)) {
      setError({
        address1_err: 'Please enter valid address line 1'
      })
      setformIsValid(false);
    }
    else {
      setError({
        address1_err: ''
      })
      setformIsValid(true);
    }
  }
  // Validate Address Line 2
  const validateAddress2 = () => {
    if (!buildingdetails.address_line2.match(Configuration.alphanumComaSpace)) {
      setError({
        address2_err: 'Please enter valid address line 2'
      })
      setformIsValid(false);
    }
    else {
      setError({
        address2_err: ''
      })
      setformIsValid(true);
    }
  }
  // Validate Address Line 1
  const validateCapacity = () => {
    if (!buildingdetails.capacity.match(Configuration.decimal)) {
      setError({
        capacity_err: 'Please enter valid capacity'
      })
      setformIsValid(false);
    }
    else {
      setError({
        capacity_err: ''
      })
      setformIsValid(true);
    }
  }

  return (
    <div className=" pt-1 pb-3 ">
      <Card>
        <CardBody>
          <h6 >Add Building</h6>
          <form className='form-inline'>
            <div className="form-group">
              <input type='text' name='building_alias' size='23' onChange={handleChange}
                value={buildingdetails.building_alias}
                onBlur={validateAlias}
                placeholder='Building alias' className='form-control' />
            </div>
            <div className='form-group ml-1'>
              <input type='text' placeholder='Address Line 1'
                value={buildingdetails.address_line1}
                size='23' onChange={handleChange} onBlur={validateAddress1}
                name='address_line1' className='form-control' />
            </div>
            <div className='form-group ml-1'>
              <input type='text' placeholder='Address Line 2' name='address_line2'
                size="25" onBlur={validateAddress2} onChange={handleChange}
                value={buildingdetails.address_line2} className='form-control' />
            </div>
            <div className='form-group ml-1'>
              <input type='text' placeholder='Capacity' size='14'
                onChange={handleChange} onBlur={validateCapacity}
                value={buildingdetails.capacity}
                name='capacity' className='form-control' />
            </div>
            <ThemeConsumer>
              {({ color }) => (
                <Button type='button' color={color} className='ml-2' onClick={() => standardizeAddress()}>
                  <i className='fa fa-check-circle-o'></i> Standardize
                  {isAddressLoading && (
                    <i
                      className="fa fa-spinner fa-spin ml-1"
                    />)}
                </Button>
              )}
            </ThemeConsumer>
          </form>
          <div className='row'>
            <div className='1'></div>
            <div className="col-11">
              <div className="row">
                  <div className='col-2 ml-1'><small className='text-danger'>{error.alias_err}</small></div>
                  <div className="col-1"></div>
                  <div className='col-2 pl-0'><small className='text-danger'>{error.address1_err}</small></div>
                  <div className='col-1 pr-0'></div>
                  <div className='col-2 ml-0 pl-0'><small className='text-danger'>{error.address2_err}</small></div>
                  <div className='col-2 ml-5 pl-4'><small className='text-danger'>{error.capacity_err}</small></div>
              </div>
            </div>
            </div>
        </CardBody>
      </Card>
      {/* Start modal  for show standardize address */}
      <Modal isOpen={modal} toggle={toggle} size="md" className="modal-outline">
        <ModalHeader tag="h5">
          Standardized building address
                            </ModalHeader>
        <ModalBody style={{ alignSelf: "center" }}>
          {addressDetails &&
            <>
              <div className="text-center">
                <p className='mb-0'>{addressDetails.Address1} &nbsp; {addressDetails.Address2}</p>
                <p>{addressDetails.city} &nbsp; {addressDetails.state} &nbsp; {addressDetails.zipcode} USA</p>
              </div>
            </>
          }

        </ModalBody>
        <ModalFooter>
          <button type="button" onClick={toggle} color="link" className="btn btn-default text-warning">Cancel</button>
          <ThemeConsumer>
            {
              ({ color }) => (
                <Button type="button" color={color} onClick={() => addLocation()}>Add</Button>
              )
            }
          </ThemeConsumer>
        </ModalFooter>
      </Modal>
      {/* End modal  for show standardize address */}
    </div>
  )
}

export default AddBuildingForm;
