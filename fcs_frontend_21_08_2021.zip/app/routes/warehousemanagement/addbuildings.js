import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as yup from 'yup';
import {
    InputGroupAddon, ThemeConsumer, Button, Modal, ModalHeader, ModalBody, ModalFooter
    , Card, CardBody, CardTitle, FormGroup, Label, InputGroup
} from '../../components';
import { toast } from 'react-toastify';
import { Configuration } from '../commoncomponents/configurationfile';
import { AddBuildingRequest } from '../../redux/actions';
import AlertMessage from '../commoncomponents/alertmessage';
import { verifyAddress } from '../../services/warehousemanagementservice';
import { PromptIfDirtyWarehouse } from '../commoncomponents/userpromt';

const AddBuildings = (props) => {
    const [isAddressLoading, setisAddressLoading] = useState(false);
    const [modal, setModal] = useState(false);
    const [buildingDetails, setbuildingDetails] = useState({
        zip_code: '', country: 'USA', is_delete: false,
        is_edit: false, building_alias: '', city: '', state: '',
        address_line1: '', address_line2: '', building_capacity: ''
    });
    const dispatch = useDispatch();
    const [addressDetails, setaddressDetails] = useState({});

    // Toggle popup for address standardize
    const toggle = () => {
        setModal(!modal);
        setisAddressLoading(false);
    }

    // Integrate API for validate address which calls when user clicks on standerized address button.
    const standardizeAddress = async (values) => {
        setisAddressLoading(true);
        let location = JSON.parse(localStorage.getItem('location'));
        let response = await verifyAddress({
            Address1: values.address_line1,
            Address2: values.address_line2,
            zip_code: location.zipcode,
            state: location.state,
            city: location.city
        });

        if (response.data && response.data.length > 0) {
            let address = response.data[0];
            setaddressDetails(address);
            setbuildingDetails({
                building_alias: values.building_alias, is_edit: false,
                address_line1: address.Address1, address_line2: address.Address2,
                zip_code: address.zipcode, building_capacity: values.building_capacity,
                city: address.city, state: address.state, is_delete: false
            });
            setModal(!modal);
        } else {
            toast.error(<AlertMessage type='error' title='Invalid Standardize'
                message={'Please put correct address for standardize'} />, { autoClose: 1200 });
        }
        setisAddressLoading(false);
    }

    // Add standardized address into building list
    const addLocation = (resetForm, values) => {
        let buildingList = JSON.parse(localStorage.getItem('buildings')) || [];
        setModal(!modal);
        let building = {
            building_id: buildingList.length + 1,
            building_alias: buildingDetails.building_alias,
            address_line1: buildingDetails.address_line1,
            address_line2: buildingDetails.address_line2,
            is_edit: false,
            building_capacity: buildingDetails.building_capacity,
            city: buildingDetails.city,
            state: buildingDetails.state,
            country: buildingDetails.country,
            zip_code: buildingDetails.zip_code,
            is_delete: false
        }
        if (buildingList.filter(item => item.building_alias === buildingDetails.building_alias).length == 0) {
            buildingList.push(building)
            localStorage.setItem('buildings', JSON.stringify(buildingList));
            dispatch(AddBuildingRequest());
            toast.success(<AlertMessage type='success' title='New Building Added'
                message={'New building added to the list successfully!'} />, { autoClose: 4000 });
        } else {
            toast.error(<AlertMessage type='error' title='Duplicate'
                message={'This building already present in list'} />, { autoClose: false });
        }

        setbuildingDetails({
            zip_code: '', country: '', is_delete: false,
            is_edit: false, building_alias: '', city: '', state: '',
            address_line1: '', address_line2: '', building_capacity: ''
        });
        resetForm();
    }

    // Clear building details form
    const clearForm = (resetForm) => {
        resetForm();
    }

    // Show red border if password invalid for passwword field
    let invalidPassword = {
        borderRadius: '3px',
        border: '1px solid',
        borderColor: '#ED1C24'
    };

    return (
        <>
            <Formik
                initialValues={buildingDetails}
                validationSchema={yup.object().shape({
                    building_alias: yup.string().nullable().required(`${Configuration.required} building alias`),
                    address_line1: yup.string().nullable().required(`${Configuration.required} address line 1`),
                    address_line2: yup.string().nullable().required(`${Configuration.required} address line 2`),
                    building_capacity: yup.string().nullable().required(`${Configuration.required} building capacity`).matches(Configuration.decimal, 'Building capacity contains only numeric character.')

                })}
                onSubmit={standardizeAddress}
            >
                {({ errors, touched, values, resetForm }) => (
                    <Form>
                        <PromptIfDirtyWarehouse />
                        <Card>
                            <CardBody>
                                <div className="d-flex mb-4">
                                    <CardTitle tag="h5">
                                        Building
                                                </CardTitle>
                                    <span className="ml-auto align-self-start small">
                                        Fields mark as <span className="text-danger">*</span> is required.
                                                </span>
                                </div>
                                <FormGroup>
                                    <Label for="building_alias">
                                        Building Alias <span className="text-danger">*</span>
                                    </Label>
                                    <Field type="text"
                                        maxLength="100"
                                        placeholder="Enter alias"
                                        name="building_alias"
                                        value={values.building_alias}
                                        className={`${touched.building_alias && errors.building_alias && 'is-invalid'} bg-white form-control`} />
                                    {touched.building_alias && errors.building_alias &&
                                        <ErrorMessage name="building_alias" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                <FormGroup>
                                    <Label for="address_line1">
                                        Address line 1<span className="text-danger">*</span>
                                    </Label>
                                    <Field type="text"
                                        placeholder="Enter address line 1"
                                        name="address_line1"
                                        maxLength={250}
                                        value={values.address_line1}
                                        className={`${touched.address_line1 && errors.address_line1 && 'is-invalid'} bg-white form-control`} />
                                    {touched.address_line1 && errors.address_line1 &&
                                        <ErrorMessage name="address_line1" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                <FormGroup>
                                    <Label for="address_line2">
                                        Address line 2<span className="text-danger">*</span>
                                    </Label>
                                    <Field type="text"
                                        placeholder="Enter address line 2"
                                        name="address_line2"
                                        maxLength={250}
                                        value={values.address_line2}
                                        className={`${touched.address_line2 && errors.address_line2 && 'is-invalid'} bg-white form-control`} />
                                    {touched.address_line2 && errors.address_line2 &&
                                        <ErrorMessage name="address_line2" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                <FormGroup>
                                    <Label for="building_capacity">Building capacity</Label><span className="text-danger">*</span>
                                    <InputGroup style={touched.building_capacity && errors.building_capacity && invalidPassword} >
                                        <Field type="text"
                                            name="building_capacity"
                                            className='bg-white form-control'
                                            placeholder="Enter warehouse capacity" />
                                        <InputGroupAddon addonType="append"  >
                                            {props.unitOfMeasures}
                                        </InputGroupAddon>
                                    </InputGroup>
                                    {touched.building_capacity && errors.building_capacity &&
                                        <ErrorMessage name="building_capacity" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                <ThemeConsumer>
                                    {({ color }) => (
                                        <div className="float-right">
                                            <span className="save-padding-add3plcompany">
                                                <Button type="button" outline color="secondary-custom" onClick={() => clearForm(resetForm)} > Clear </Button>
                                            </span>
                                            <Button type="submit" disabled={isAddressLoading} color={color} >
                                                <i className="fa fa-check-circle-o" aria-hidden="true"></i>  {'Standardize Address'}
                                                {isAddressLoading && (
                                                    <i
                                                        className="fa fa-spinner fa-spin ml-1"
                                                    />)}
                                            </Button>
                                        </div>
                                    )}
                                </ThemeConsumer>
                            </CardBody>
                        </Card>
                        {/* Start modal  for show standardize address */}
                        <Modal isOpen={modal} toggle={toggle} size="md" className="modal-outline">
                            <ModalHeader tag="h5">
                                Standardized building address
                            </ModalHeader>
                            <ModalBody style={{ alignSelf: "center" }}>
                                {addressDetails &&
                                    <>
                                        <div className="text-center">
                                            <p className='mb-0'>{addressDetails.Address1} &nbsp; {addressDetails.Address2}</p>
                                            <p>{addressDetails.city} &nbsp; {addressDetails.state} &nbsp; {addressDetails.zipcode} USA</p>
                                        </div>
                                    </>
                                }

                            </ModalBody>
                            <ModalFooter>

                                <ThemeConsumer>
                                    {
                                        ({ color }) => (
                                            <>
                                                <Button type="button" onClick={toggle} outline color="secondary-custom" >Cancel</Button>
                                                <Button type="button" color={color} onClick={() => addLocation(resetForm)}>Add</Button>
                                            </>
                                        )
                                    }
                                </ThemeConsumer>
                            </ModalFooter>
                        </Modal>
                        {/* End modal  for show standardize address */}
                    </Form>
                )}

            </Formik>
        </>
    )
}
export default AddBuildings