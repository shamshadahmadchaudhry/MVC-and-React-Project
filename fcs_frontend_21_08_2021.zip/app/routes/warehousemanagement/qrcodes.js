import React from 'react'

const Qrcodes = () => {
    return (
        <div>
            
        </div>
    )
}

export default Qrcodes