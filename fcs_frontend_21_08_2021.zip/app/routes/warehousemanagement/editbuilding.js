import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import {
    InputGroupAddon, ThemeConsumer, Button, Modal, ModalHeader, ModalBody, ModalFooter
    , Card, CardBody, CardTitle, FormGroup, Label, InputGroup
} from '../../components';
import { toast } from 'react-toastify';
import * as yup from 'yup';
import { useSelector } from 'react-redux';
import { Configuration } from '../commoncomponents/configurationfile';
import { AddBuildingRequest } from '../../redux/actions';
import AlertMessage from '../commoncomponents/alertmessage';
import { verifyAddress } from '../../services/warehousemanagementservice';
import { PromptIfDirtyWarehouse } from '../commoncomponents/userpromt';

const EditBuildings = (props) => {
    const buildingList = useSelector(state => state.AddBuilding?.buildings);
    const [isEditLoading, setIsEditLoading] = useState(false);
    const [addressDetails, setaddressDetails] = useState({});
    const [modal, setModal] = useState(false);
    const [unitOfMeasures, setUnitMeasures] = useState('');
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [buildingDetails, setbuildingDetails] = useState({
        zip_code: '', country: 'USA',
        is_edit: false, building_alias: '', city: '', state: '',
        address_line1: '', address_line2: '', building_capacity: ''
    });
    const dispatch = useDispatch();

    // Load selected company details
    const toggle = () => {
        setModal(!modal);
        setIsEditLoading(false)
    }

    // Retrieve data for edit to selected building
    useEffect(() => {
        console.log("Building Name:--->", props.buildingName)
        let buildingData = buildingList.find(item => item.building_alias === props.buildingName);
        setbuildingDetails(buildingData);
        UnitMeasures();
    }, [])

    const UnitMeasures = async () => {
        let company_id = 0;
        if (CompanyListingStatus?.result?.response?.result.length > 1)
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id
        else
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        const result = await getUnitofMeasures(company_id, userData?.user_type_id);
        if (!result.data.error) {
            for (let i = 0; i < result.data.data.length; i++) {
                if (result.data.data[i].is_active == 1) {
                    setUnitMeasures(result.data.data[i].cubic_unit);
                    break;
                }
            }
        }
    }

    // Integrate API for validate address which calls when user clicks on standerized address button.
    const standardizeAddress = async (values) => {
        setIsEditLoading(true);
        let location = JSON.parse(localStorage.getItem('location'));
        let response = await verifyAddress({
            Address1: values.address_line1,
            Address2: values.address_line2,
            zip_code: location.zipcode,
            state: location.state,
            city: location.city
        });

        if (response.data && response.data.length > 0) {
            let address = response.data[0];
            setaddressDetails(address);
            setbuildingDetails({
                building_alias: values.building_alias, is_edit: false,
                address_line1: address.Address1, address_line2: address.Address2,
                zip_code: address.zipcode, building_capacity: values.building_capacity,
                city: address.city, state: address.state
            });
            setModal(!modal);
        } else {
            toast.error(<AlertMessage type='error' title='Invalid Standardize'
                message={'Please put correct address for standardize'} />, { autoClose: false });
        }
        cancelEdit();
        setIsEditLoading(false);
    }

    // Update building details for selected building
    const addLocation = () => {
        let buildingList = JSON.parse(localStorage.getItem('buildings')) || [];
        setModal(!modal);
        let selectedIndex = buildingList.findIndex(item => item.building_alias === props.buildingName);

        buildingList[selectedIndex].building_alias = buildingDetails.building_alias;
        buildingList[selectedIndex].address_line1 = buildingDetails.address_line1;
        buildingList[selectedIndex].address_line2 = buildingDetails.address_line2;
        buildingList[selectedIndex].is_edit = false;
        buildingList[selectedIndex].building_capacity = buildingDetails.building_capacity;
        buildingList[selectedIndex].city = buildingDetails.city;
        buildingList[selectedIndex].state = buildingDetails.state;
        buildingList[selectedIndex].country = buildingDetails.country;
        buildingList[selectedIndex].zip_code = buildingDetails.zip_code;

        localStorage.setItem('buildings', JSON.stringify(buildingList));

        toast.success(<AlertMessage type='success' title='New Building Added'
            message={'New building added to the list successfully!'} />, { autoClose: 4000 });
        dispatch(AddBuildingRequest());
    }

    return (
        <>
            <Formik
                initialValues={buildingDetails}
                enableReinitialize={true}
                validationSchema={yup.object().shape({
                    building_alias: yup.string().nullable().required(`${Configuration.required} building alias`),
                    address_line1: yup.string().nullable().required(`${Configuration.required} address line 1`)
                })}
                onSubmit={standardizeAddress}
            >
                {({ errors, touched, values }) => (
                    <Form>
                        <PromptIfDirtyWarehouse />
                        <ThemeConsumer>
                            {({ color }) => (
                                <Card type="border" color={`warning`}>
                                    {console.log('Color----->', color)}
                                    <CardBody>
                                        <div className="d-flex mb-4">
                                            <CardTitle tag="h5">
                                                Edit Building
                                                </CardTitle>
                                            <span className="ml-auto align-self-start small">
                                                Fields mark as <span className="text-danger">*</span> is required.
                                                </span>
                                        </div>
                                        <FormGroup>
                                            <Label for="building_alias">
                                                Building Alias <span className="text-danger">*</span>
                                            </Label>
                                            <Field type="text"
                                                placeholder="Enter alias"
                                                name="building_alias"
                                                value={values.building_alias}
                                                className={`${touched.building_alias && errors.building_alias && 'is-invalid'} bg-white form-control`} />
                                            {touched.building_alias && errors.building_alias &&
                                                <ErrorMessage name="building_alias" component="span" className="text-danger"></ErrorMessage>
                                            }
                                        </FormGroup>
                                        <FormGroup>
                                            <Label for="address_line1">
                                                Address line 1<span className="text-danger">*</span>
                                            </Label>
                                            <Field type="text"
                                                placeholder="Enter address line 1"
                                                name="address_line1"
                                                value={values.address_line1}
                                                className={`${touched.address_line1 && errors.address_line1 && 'is-invalid'} bg-white form-control`} />
                                            {touched.address_line1 && errors.address_line1 &&
                                                <ErrorMessage name="address_line1" component="span" className="text-danger"></ErrorMessage>
                                            }
                                        </FormGroup>
                                        <FormGroup>
                                            <Label for="address_line2">
                                                Address line 2
                                    </Label>
                                            <Field type="text"
                                                placeholder="Enter address line 2"
                                                name="address_line2"
                                                value={values.address_line2}
                                                className='bg-white form-control' />
                                        </FormGroup>
                                        <FormGroup>
                                            <Label for="building_capacity">Building capacity</Label>
                                            <InputGroup >
                                                <Field type="text"
                                                    name="building_capacity"
                                                    className='bg-white form-control'
                                                    placeholder="Enter warehouse capacity" />
                                                <InputGroupAddon addonType="append"  >
                                                    {unitOfMeasures}
                                                </InputGroupAddon>
                                            </InputGroup>
                                        </FormGroup>
                                        <ThemeConsumer>
                                            {({ color }) => (
                                                <div className="float-right">
                                                    <span className="save-padding-add3plcompany">
                                                        <Button type="button" outline color="secondary-custom" onClick={() => props.cancel()} > Cancel </Button>
                                                    </span>
                                                    <Button type="submit" disabled={isEditLoading} color={color} >
                                                        <i className="fa fa-check-circle-o" aria-hidden="true"></i>  {'Standardize Address'}
                                                        {isEditLoading && (
                                                            <i
                                                                className="fa fa-spinner fa-spin ml-1"
                                                            />)}
                                                    </Button>
                                                </div>
                                            )}
                                        </ThemeConsumer>
                                    </CardBody>
                                </Card>
                            )}
                        </ThemeConsumer>
                    </Form>
                )}
            </Formik>
            {/* Start modal  for show standardize address */}
            <Modal isOpen={modal} toggle={toggle} size={'md'} className="modal-outline">
                <ModalHeader tag="h5">
                    Standardized building address
                </ModalHeader>
                <ModalBody>
                    {addressDetails && <>

                        <div className="text-center">
                            <p className='mb-0'>{addressDetails.Address1} &nbsp; {addressDetails.Address2}</p>
                            <p>{addressDetails.city} &nbsp; {addressDetails.state} &nbsp; {addressDetails.zipcode} USA</p>
                        </div>
                    </>
                    }
                </ModalBody>
                <ModalFooter>
                    <ThemeConsumer>
                        {
                            ({ color }) => (
                                <>
                                    <Button type="button" onClick={toggle} outline color="secondary-custom" >
                                        Cancel
                    </Button>

                                    <Button color={color} onClick={() => addLocation()} >Update</Button>
                                </>
                            )
                        }
                    </ThemeConsumer>
                </ModalFooter>
            </Modal>
            {/* End modal  for show standardize address */}
        </>
    )
}
export default EditBuildings