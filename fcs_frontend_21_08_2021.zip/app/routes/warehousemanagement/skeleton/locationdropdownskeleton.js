import Skeleton from 'react-loading-skeleton';
import React from 'react';
import {
    Row,
    Col,
    Media,
    Card,
    CardBody,
    Container
} from '../../../components';
import '../../../styles/skeleton.scss';
const LocationDropdownSkeleton = () => {
    return (
        <Container className="margin-top">
            <Row className="margin-top-textbox">
                <Col lg={12}>
                    <Skeleton width={400} />
                </Col>
                <Col lg={12}>
                    <Skeleton width={200} height={30} />
                </Col>
            </Row>
        </Container>
    )
}
export default LocationDropdownSkeleton;