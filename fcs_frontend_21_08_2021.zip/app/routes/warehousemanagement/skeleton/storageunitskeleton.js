import Skeleton from 'react-loading-skeleton';
import React from 'react';
import {
    Row,
    Col,
    Card,
    CardBody,
    Container, FormGroup
} from '../../../components';
import '../../../styles/skeleton.scss';
const StorageUnitSkeleton = () => {
    return (
        <Container className="margin-top">


            <Row>

                <Col lg={12}>
                    <div className="margin-top-textbox"></div>
                    <Card>
                        <CardBody>
                            <div style={{ margin: "0.7%" }}>
                                <div style={{ textAlign: "right" }}>
                                    <Skeleton width={40} height={30} />  <Skeleton width={40} height={30} />
                                </div>
                            </div>
                            <div className="margin-top-textbox"></div>

                            <Row>

                                <Col lg={12}>
                                    {/* This code is used for the label */}
                                    <Skeleton width={300} />
                                </Col>
                            </Row>

                            <Row>

                                <table className="table">
                                    <thead>
                                        <tr>
                                            <th><Skeleton width={150} /></th>
                                            <th><Skeleton width={150} /></th>
                                            <th><Skeleton width={150} /></th>
                                            <th><Skeleton width={150} /></th>

                                        </tr>
                                        <tr>
                                            <th><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></th>
                                            <th><Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /></th>
                                            <th><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></th>
                                            <th><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /></td>
                                            <td> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /></td>
                                            <td> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /></td>
                                            <td> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /></td>
                                            <td> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /></td>
                                            <td> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /></td>
                                            <td> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /></td>
                                            <td> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /></td>
                                            <td> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /></td>
                                            <td> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /> <Skeleton width={80} height={25} /></td>
                                            <td> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                            <td><Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /> <Skeleton width={100} height={25} /></td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></td>
                                            <td></td>
                                            <td></td>
                                            <td ><div className="margin-left-footer"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                        </tr>
                                    </tbody>
                                </table>

                            </Row>


                        </CardBody>
                    </Card>
                </Col>
            </Row>
        </Container>
    )
}
export default StorageUnitSkeleton;