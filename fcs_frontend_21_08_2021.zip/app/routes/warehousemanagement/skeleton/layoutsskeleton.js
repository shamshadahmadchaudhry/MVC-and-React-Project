import Skeleton from 'react-loading-skeleton';
import React from 'react';
import {
    Row,
    Col,
    Container, FormGroup
} from '../../../components';
import '../../../styles/skeleton.scss';
const LayoutsSkeleton = () => {
    return (
        <Container className="margin-top">
            <Row>
                <Col lg={12} >
                    <Skeleton width={400} />
                </Col>
            </Row>
            <Row className='mb-4'>
                <Col lg={4}>
                    <form className='form-inline'>
                        <FormGroup>
                            <label style={{ marginRight: "10px" }}> <Skeleton width={100} /></label>
                            <Skeleton width={200} height={30} />
                        </FormGroup>
                    </form>
                </Col>
                <Col lg={6}>
                    <form className='form-inline'>
                        <FormGroup className='bg-light'>
                            <label style={{ marginRight: "10px" }}> <Skeleton width={100} /></label>
                            <Skeleton width={200} height={30} />
                        </FormGroup>
                    </form>
                </Col>
            </Row>
        </Container>
    )
}
export default LayoutsSkeleton;