import Skeleton from 'react-loading-skeleton';
import React from 'react';
import {
    Row,
    Col,
    Media,
    Card,
    CardBody,
    Container, FormGroup
} from '../../../components';
import '../../../styles/skeleton.scss';
const ZoneSkeletons = () => {
    return (
        <Container className="margin-top">
            <Row>
                <Col lg={12}>
                    <Card>
                        <CardBody>
                            <div style={{ margin: "0.7%" }}>
                                <div style={{ textAlign: "right" }}>
                                    <Skeleton width={40} height={30} />  <Skeleton width={40} height={30} /> <Skeleton width={40} height={30} />  <Skeleton width={40} height={30} />
                                </div>
                                <div className="margin-top-textbox"></div>
                                <Row>

                                    <table className="table">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <Skeleton width={150} />
                                                </th>
                                                <th>
                                                    <Skeleton width={150} />
                                                </th>
                                                <th><div className="margin-left-bin">
                                                    <Skeleton width={150} />
                                                </div>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><Skeleton width={15} height={25} /></td>
                                                <td><Skeleton width={15} height={25} /></td>
                                                <td><div className="margin-left-bin"><Skeleton width={100} height={25} /></div></td>
                                            </tr>
                                            <tr>
                                                <td><Skeleton width={50} height={25} /></td>
                                                <td> <Skeleton width={150} /></td>
                                                <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                            </tr>
                                            <tr>
                                                <td><Skeleton width={50} height={25} /></td>
                                                <td> <Skeleton width={150} /></td>
                                                <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                            </tr>
                                            <tr>
                                                <td><Skeleton width={50} height={25} /></td>
                                                <td> <Skeleton width={150} /></td>
                                                <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                            </tr>
                                            <tr>
                                                <td><Skeleton width={50} height={25} /></td>
                                                <td> <Skeleton width={150} /></td>
                                                <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                            </tr>
                                            <tr>
                                                <td><Skeleton width={50} height={25} /></td>
                                                <td> <Skeleton width={150} /></td>
                                                <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                            </tr>
                                            <tr>
                                                <td><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></td>
                                                <td></td>
                                                <td ><div className="margin-left-footer"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                            </tr>
                                        </tbody>
                                    </table>






                                </Row>
                            </div>
                        </CardBody>
                    </Card>
                </Col>
            </Row>
        </Container>
    )
}
export default ZoneSkeletons;