import Skeleton from 'react-loading-skeleton';
import React from 'react';
import {
    Row,
    Col,
    Media,
    Card,
    CardBody,
    Container, FormGroup
} from '../../../components';
import '../../../styles/skeleton.scss';

const LogoSkeleton = () => {
    return (
        <Skeleton width={170} height={50} />
    )
}
export default LogoSkeleton;