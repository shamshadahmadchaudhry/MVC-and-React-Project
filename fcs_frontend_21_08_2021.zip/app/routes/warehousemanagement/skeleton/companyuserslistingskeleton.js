import Skeleton from 'react-loading-skeleton';
import React from 'react';
import {
    Row,
    Col,
    Media,
    Card,
    CardBody,
    Container
} from '../../../components';
import '../../../styles/skeleton.scss';
const CompanyUsersListingSkeleton = () => {
    return (
        <div className="container">

            <div style={{ margin: "0.7%" }}>
                <div style={{ textAlign: "right" }}>


                    <Skeleton width={40} height={30} />  <Skeleton width={40} height={30} />
                </div>


                <div style={{ marginTop: '30px' }}>
                    <Card style={{ textAlign: 'center' }}>
                        <CardBody>
                            <Row>

                                <table className="table">
                                    <thead>
                                        <tr>
                                            <th>
                                                <Skeleton width={110} />
                                            </th>
                                            <th>
                                                <Skeleton width={110} />
                                            </th>
                                            <th>
                                                <Skeleton width={110} />
                                            </th>
                                            <th>
                                                <Skeleton width={110} />
                                            </th>
                                            <th>
                                                <Skeleton width={110} />
                                            </th>
                                            <th>
                                                <Skeleton width={110} />
                                            </th>
                                            <th><div className="margin-left-bin">
                                                <Skeleton width={110} />
                                            </div>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><Skeleton width={15} height={25} /></td>
                                            <td><Skeleton width={15} height={25} /></td>
                                            <td><Skeleton width={15} height={25} /></td>
                                            <td><Skeleton width={15} height={25} /></td>
                                            <td></td>
                                            <td></td>
                                            <td>
                                                <div className="margin-left-box">
                                                    <Skeleton width={80} />
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={110} /></td>
                                            <td><Skeleton width={110} /></td>
                                            <td><Skeleton width={110} /></td>
                                            <td><Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={110} /></td>
                                            <td><Skeleton width={110} /></td>
                                            <td><Skeleton width={110} /></td>
                                            <td><Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={110} /></td>
                                            <td><Skeleton width={110} /></td>
                                            <td><Skeleton width={110} /></td>
                                            <td><Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                        </tr>
                                        <tr>
                                            <td><Skeleton width={110} /></td>
                                            <td><Skeleton width={110} /></td>
                                            <td><Skeleton width={110} /></td>
                                            <td><Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                        </tr>
                                        <tr>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                        </tr>
                                        <tr>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                        </tr>
                                        <tr>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                        </tr>
                                        <tr>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                        </tr>
                                        <tr>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                        </tr>
                                        <tr>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td> <Skeleton width={110} /></td>
                                            <td><div className="margin-left-bin"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                        </tr>
                                        <tr>

                                            <td><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td ><div className="margin-left-footer"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                        </tr>
                                    </tbody>
                                </table>

                            </Row>
                        </CardBody>
                    </Card>
                </div>
            </div>

        </div>

    )
}
export default CompanyUsersListingSkeleton;