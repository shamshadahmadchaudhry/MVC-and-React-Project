import Skeleton from 'react-loading-skeleton';
import React from 'react';
import {
    Row,
    Col,
    Media,
    Card,
    CardBody,
    Container
} from '../../../components';
import '../../../styles/skeleton.scss';
const CompanyListsSkeleton = (props) => {
    return (
        <>
            <Container className="margin-top">
                <Row className="margin-top-textbox">
                    <Col lg={12}>
                        <Skeleton width={400} />
                    </Col>
                </Row>
            </Container>
            <div className="container margin-top">
                <Card className="mb-3" className="margin-top">
                    <CardBody>
                        <div className="container-fluid">
                            <Card style={{ textAlign: 'center' }}>
                                <CardBody>
                                    <Row>

                                        <table className="table">
                                            <thead>
                                                <tr>
                                                    <th>
                                                        <div className="align-content-left">
                                                            <Skeleton width={150} />
                                                        </div>
                                                    </th>
                                                    <th><Skeleton width={150} /></th>
                                                    <th>
                                                        <div className="margin-left-box">
                                                            <Skeleton width={150} />
                                                        </div>
                                                    </th>


                                                </tr>
                                                <tr>
                                                    <th>
                                                        <div className="align-content-left">
                                                            <Skeleton width={15} height={25} />
                                                        </div>
                                                    </th>
                                                    <th><Skeleton width={15} height={25} /></th>
                                                    <th>
                                                        <div className="margin-left-box">
                                                            <Skeleton width={15} height={25} />
                                                        </div>
                                                    </th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>

                                                    <td>
                                                        <div className="align-content-left">
                                                            <Skeleton width={150} />
                                                        </div>
                                                    </td>
                                                    <td> <Skeleton width={150} /></td>
                                                    <td><div className="margin-left-box"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div className="align-content-left">
                                                            <Skeleton width={150} />
                                                        </div>
                                                    </td>
                                                    <td> <Skeleton width={150} /></td>
                                                    <td><div className="margin-left-box"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                                </tr>
                                                <tr>

                                                    <td>
                                                        <div className="align-content-left">
                                                            <Skeleton width={150} />
                                                        </div>
                                                    </td>
                                                    <td> <Skeleton width={150} /></td>
                                                    <td><div className="margin-left-box"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                                </tr>
                                                <tr>

                                                    <td>
                                                        <div className="align-content-left">
                                                            <Skeleton width={150} />
                                                        </div>
                                                    </td>
                                                    <td> <Skeleton width={150} /></td>
                                                    <td><div className="margin-left-box"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                                </tr>
                                                <tr>

                                                    <td>
                                                        <div className="align-content-left">
                                                            <Skeleton width={150} />
                                                        </div>
                                                    </td>
                                                    <td> <Skeleton width={150} /></td>
                                                    <td><div className="margin-left-box"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                                </tr>
                                                <tr>

                                                    <td>
                                                        <div className="align-content-left">
                                                            <Skeleton width={150} />
                                                        </div>
                                                    </td>
                                                    <td> <Skeleton width={150} /></td>
                                                    <td><div className="margin-left-box"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                                </tr>
                                                <tr>

                                                    <td>
                                                        <div className="align-content-left">
                                                            <Skeleton width={150} />
                                                        </div>
                                                    </td>
                                                    <td> <Skeleton width={150} /></td>
                                                    <td><div className="margin-left-box"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                                </tr>
                                                <tr>

                                                    <td>
                                                        <div className="align-content-left">
                                                            <Skeleton width={150} />
                                                        </div>
                                                    </td>
                                                    <td> <Skeleton width={150} /></td>
                                                    <td><div className="margin-left-box"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                                </tr>
                                                <tr>

                                                    <td>
                                                        <div className="align-content-left">
                                                            <Skeleton width={150} />
                                                        </div>
                                                    </td>
                                                    <td> <Skeleton width={150} /></td>
                                                    <td><div className="margin-left-box"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                                </tr>
                                                <tr>

                                                    <td>
                                                        <div className="align-content-left">
                                                            <Skeleton width={150} />
                                                        </div>
                                                    </td>
                                                    <td> <Skeleton width={150} /></td>
                                                    <td><div className="margin-left-box"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                                </tr>
                                                <tr>

                                                    <td><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></td>
                                                    <td></td>
                                                    <td ><div className="margin-left-footer"><Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /> <Skeleton width={30} height={25} /></div></td>
                                                </tr>
                                            </tbody>
                                        </table>

                                    </Row>

                                </CardBody>
                            </Card>
                        </div>
                    </CardBody>
                </Card>

            </div>

        </>
    )
}
export default CompanyListsSkeleton;