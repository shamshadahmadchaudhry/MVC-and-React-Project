import React, { useState, useRef, useEffect } from 'react';
import { useSelector } from 'react-redux'
import Toggle from 'react-toggle'
import { toast } from 'react-toastify';
import AlertMessage from '../../commoncomponents/alertmessage';
import { Configuration } from '../../commoncomponents/configurationfile';
import {
    Navbar,
    FormGroup,
    Container,
    Row, Col, DropdownToggle,
    Button,
    ButtonGroup,
    UncontrolledButtonDropdown,
    DropdownMenu,
    DropdownItem, Card, CardBody, Conf, CustomInput
} from '../../../components';
import ConfirmBox from '../../commoncomponents/confirmbox';
import DataGrid, {
    Column,
    Editing,
    Paging,
    Pager,
    Lookup,
    RequiredRule,
    PatternRule,
    FilterRow,
    Selection,
    Button as Btndx
} from 'devextreme-react/data-grid';
import {
    getWarehouseLocationList,
    getBuildingDetailsList,
    getStationsList,
    getStationTypes, updatestationStatus,
    getPapersizes,
    printLabels
} from '../../../services/warehousemanagementservice';

import { addStation, deleteStation, updateStation } from '../../../services/stationservices'
import { fetchLayoutName } from '../../../services/layoutservices'
import CustomStore from 'devextreme/data/custom_store';
import StationsSkeleton from '../skeleton/stationsskeleton';
import Printselectsizemodal from '../common/printSelectsizemodal';
import LayoutImportDropdown from '../common/layoutimportdropdown';
import '../../../styles/common.scss';
import { CONFIG } from '../../../config'
import { useLocation } from 'react-router-dom';

let station_name = '';
const Stations = () => {
    const Datagridref = useRef(null)
    let location = useLocation()
    toast.configure()
    const [companyId, setCompanyId] = useState(0)
    const [delmodal, setDelmodal] = useState(false);
    const [locations, setLocations] = useState([])
    const [buildings, setBuildings] = useState([])
    const [activelocationId, setActivelocationId] = useState(0)
    const [activeaddressId, setActiveaddressId] = useState(0)
    const [stationtypes, setStationtypes] = useState([])
    const [delStationid, SetDelstationid] = useState(0)
    const [addstationOptions, setAddstationOptions] = useState([])
    const [editmode, setEditmode] = useState('row')
    const [disable, setDisable] = useState(true);
    const [numrows, setNumrows] = useState(0);
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [skeleton, setSkeleton] = useState(false)
    const [showButton, setShowButton] = useState(false)
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    let station = '';

    let station_types = ''
    let numrowsToadd = 0

    //All states for selection
    const [selectMode, setSelectMode] = useState('page')
    const [totalRecords, setTotalRecords] = useState(0)
    const [selectedRecords, setSelectedRecords] = useState(false)
    const [selectedAll, setSelectedAll] = useState(false)
    const [papersizes, setPapersizes] = useState([])
    const [x, setX] = useState(0)
    const [y, setY] = useState(0)
    const [size, setSize] = useState(0)
    const [paperid, setPaperid] = useState(0)
    const [iframeurl, setIframeurl] = useState("")
    const [stationId, setStationId] = useState(0)
    const [noLabeltoprint, setnoLabeltoprint] = useState('single')
    const [addingrecord, setAddingrecord] = useState(false)
    const [selcount,setSelcount] = useState(0)
    const [checked,setChecked] = useState(false)

    //Selection Implementation
    const _handleSelectStatus = (checked) => {
        if (checked) {
            setSelectMode('page')
            setSelectedRecords(true)
            setChecked(true)
            Datagridref.current.instance.selectAll()
        }
        else {
            setSelectedAll(false)
            setSelectMode('page')
            setSelectedRecords(false)
            setChecked(false)
            Datagridref.current.instance.deselectAll()
        }

    }
    const loadPaperSizes = async () => {
        let papersizesReq = await getPapersizes();
        setPapersizes(papersizesReq.data)
        // console.log('PAPER SIZES', papersizesReq.data)
    }

    useEffect(() => {
        loadPaperSizes()
    }, [])

    useEffect(() => {
        if (selectMode === 'page') {
            setSelectMode('page')
        }
        else if (selectMode === 'allPages') {
            console.log('ALL PAGES')
            setSelectMode('allPages')
            Datagridref.current.instance.deselectAll()
            Datagridref.current.instance.selectAll()
        }
    }), [selectMode]
    //Select Size Modal State
    const [selectsizemodal, setSelectsizemodal] = useState(false)
    const [actionsize, setActionsize] = useState('')
    const toggleSizeModal = () => {
        setSize(0)
        setIframeurl('')
        setSelectsizemodal(!selectsizemodal)
    }
    const displayPopup = (e) => {
        console.log(e.row.data.warehouse_station_id)
        setStationId(e.row.data.warehouse_station_id)
        setnoLabeltoprint('single')
        toggleSizeModal(true)
    }
    const send_print_request = async (active_entity, entity_ids, printallRecords) => {
        const printdocument = await printLabels({
            paper_size_id: parseInt(paperid), company_id: companyId,
            location_id: activelocationId, location_address_id: activeaddressId, x_width: parseInt(x), y_height: parseInt(y),
            entity_type: active_entity.toString(), ids_list: entity_ids, print_all: printallRecords
        })

        console.log('PRINT DOC RESPONSE ', printdocument)

        if (printdocument.data.status) {
            let path = printdocument.data.pdf_file_path
            let html_url = printdocument.data.html_url
            path = path.replace(/\\/g, "/");
            let indmedia = path.indexOf('media')
            let remPath = path.slice(indmedia)
            let fullPath = CONFIG.BASE_URL + '/' + remPath;
            let get_html_url = html_url + '?pdf_path=' + fullPath.substring(fullPath.indexOf('media'));
            setIframeurl(get_html_url, 'Print', 'left=200, top=200, width=950, height=500, toolbar=0, resizable=0');
            window.frames["labeliframe"].focus();
        }
    }
    const printSelectedsizeLabel = () => {
        console.log('Selected Row keys = ', Datagridref.current.instance.getSelectedRowKeys())
        if (size != '0') {
            let printallRecords = false;
            let active_entity = Configuration.entityType.station
            let entity_ids = []
            let data = Datagridref.current.instance.getSelectedRowKeys();
            for (let i = 0; i < data.length; i++) {
                if (data[i] != null) {
                    entity_ids.push(data[i])
                }
            }
            setSelectsizemodal(true)
            if (data.length === totalRecords) {
                printallRecords = true
            }
            console.log('ENTITY IDS', entity_ids)
            send_print_request(active_entity, entity_ids, printallRecords)
        }
        else {
            toast.error(<AlertMessage type="error" title="Select Paper Size"
                message="Please select paper size." />, { autoClose: 4000 });
        }
    }
    const printSingleRowLabel = () => {
        if (size != '0') {
            let printallRecords = false;
            let active_entity = Configuration.entityType.station
            let entity_ids = []
            let data = Datagridref.current.instance.getSelectedRowKeys();
            entity_ids.push(stationId)
            setSelectsizemodal(true)
            if (data.length === totalRecords) {
                printallRecords = true
            }
            // SEND PRINT REQUEST
            send_print_request(active_entity, entity_ids, printallRecords)
        }
        else {
            toast.error(<AlertMessage type="error" title="Select Paper Size"
                message="Please select paper size." />, { autoClose: 4000 });
        }
    }
    //End of Selection code
    /*
    TOOLBAR */

    const loadAddOptions = () => {
        let stationOptions = []
        for (let i = 2; i <= 10; i++) {
            if (i === 1) {
                station = ' Station'
            }
            else {
                station = ' Stations'
            }
            stationOptions.push({
                id: i,
                name: 'Add ' + i + station
            })
        }

        setAddstationOptions(stationOptions)
    }
    useEffect(() => {
        loadAddOptions()
    }, []);

    useEffect(() => {
        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        setCompanyId(company_id);
        WarehouseLocations(company_id)
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    //Load buildings
    const loadBuildings = async (locationId) => {
        let params = `?warehouse_location_id=${locationId}`
        let buildingResp = await getBuildingDetailsList(params)
        setSkeleton(true)
        setBuildings(buildingResp.data)
        if (location.state != null && isselect === false) {
            setAddressType(location.state.warehouse_address_name)
            setActiveaddressId(location.state.warehouse_address_id)
        } else {
            setAddressType(buildingResp.data[0].building_alias)
            setActiveaddressId(buildingResp.data[0].warehouse_address_id)
        }
    }
    //Load warehouse locations
    const WarehouseLocations = async (company_id) => {
        let params = `?company_id=${company_id}`
        let response = await getWarehouseLocationList(params)
        //Load Buildings for First warehouse location
        if (location.state != null) {
            setLocationType(location.state.warehouse_location_name)
            loadBuildings(location.state.warehouse_location_id)
            setActivelocationId(location.state.warehouse_location_id)
        } else {
            loadBuildings(response.data[0].warehouse_location_id)
            setLocationType(response.data[0].location_name)
            setActivelocationId(response.data[0].warehouse_location_id)
        }
        setLocations(response.data)
        return response.data

    }
    const deleteRow = async () => {
        let deleteresp = await deleteStation({ warehouse_station_id: delStationid });
        setDelmodal(!delmodal)
        toast.success(<AlertMessage type='success' title='Station Deleted'
            message='Station has been deleted Successfully' />, { autoClose: 4000 });
    }
    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }
    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }
    const stations_data = new CustomStore({
        key: 'warehouse_station_id',
        load: async (loadOptions) => {
            let count = 0;
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary',
            ].forEach(function (i) {
                if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                    params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                }
                if (!loadOptions.filter && !loadOptions.sort && count === 0 && !loadOptions.skip && !loadOptions.take) {
                    params += `skip=0&take=${totalRecords}&requireTotalCount=true&totalSummary=[]&`;
                }
                if (loadOptions.filter && loadOptions['group'] !== null && count === 0) {
                    params += `skip=0&take=${totalRecords}&`;
                }
                count++;
            });
            params += `warehouse_location_id=${activelocationId}&warehouse_address_id=${activeaddressId}&company_id=${companyId}&`
            params = params.slice(0, -1);
            const StationList = await getStationsList(params)
            setTotalRecords(StationList.totalCount)
            return StationList

        },
        update: async (key, values) => {
        }
    })
    const handleTogglechange = async (c, e) => {
        let isEnable = 0;
        let warehouse_station_id = c.data.warehouse_station_id
        //If toggle button is enabled
        if (e.target.checked) {
            isEnable = 1
        }
        //If toggle button is disabled
        else {
            isEnable = 0;
        }
        let updateEnableResp = await updatestationStatus({
            'warehouse_station_id': warehouse_station_id,
            'is_enabled': isEnable
        })
    }

    const ToggleBtn = (e) => {
        let isChecked = false;
        if (e.data.is_enabled == 1) {
            isChecked = true
        }
        else {
            isChecked = false;
        }
        return (
            <>
                <Toggle
                    id='status'
                    defaultChecked={isChecked}
                    onChange={(g) => handleTogglechange(e, g)} disabled={selectedRecords ? true : false} />
                <label htmlFor='status'></label>
            </>
        )

    }

    useEffect(() => {
        setIsSelect(true)
        setAddressType('')
    }, [activelocationId])
    const _handleOnClick = (e) => {
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setLocationType(str)
        }
        else {
            setLocationType(e[1].name)
        }
        setActivelocationId(e[0].id)
        loadBuildings(e[0].id);
    }
    const _handlebuildingOnClick = (e) => {
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setAddressType(str)
        }
        else {
            setAddressType(e[1].name)
        }
        setActiveaddressId(e[0].id);
    }
    let sp = []
    const loadStationtypes = async () => {
        let typesResp = await getStationTypes();
        setStationtypes(typesResp)
        sp = typesResp
        console.log('TYPES', typesResp)
    }
    useEffect(() => {
        loadStationtypes()
    }, [])

    /* SAVE STATION */
    const SaveStation = async (body, component) => {
        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        try {
            let body2 = []
            let container_type = Configuration.entityType.station
            // console.log('NUMBER',numrowsToadd)
            let x = []
            let type_active = ''
            let s_id = 0
            if (body[0].type === 'insert') {
                for (let i = 0; i < numrows; i++) {
                    type_active = body[i].data.warehouse_station_type;
                    x = stationtypes.filter(obj => {
                        return obj.warehouse_station_type == type_active
                    })
                    s_id = x[0].warehouse_station_type_id;
                    body[i].data.warehouse_station_type_id = s_id
                    body2.push(body[i].data)
                }
                body = {
                    "stations": body2, created_by: userData.user_master_id, warehouse_address_id: activeaddressId,
                    warehouse_location_id: activelocationId, company_id: company_id
                }
                //console.log('body ------- ', body)
                const result = await addStation(body, container_type);
                if (result.data['status'] === true) {
                    toast.success(<AlertMessage type='success' title='Station Added'
                        message={result.data['message']} />, { autoClose: 4000 });
                    setEditmode('row')
                    setDisable(true);
                    setShowButton(false);
                    datagridRef.current.instance.cancelEditData();
                }
                else if (result.data['status'] === false) {
                    toast.error(<AlertMessage type='error' title='Station Already exist'
                        message={result.data['message']} />, { autoClose: false });
                }
                else {
                    toast.error(<AlertMessage type='error' title='Error Saving Station'
                        message={result.data['message']} />, { autoClose: false });
                }
                await component.refresh(true);
                component.cancelEditData();
                return result;
            }
            else if (body[0].type === 'update') {
                let station_id = body[0].key
                let station_name = '';
                let station_type_id = 0
                let updateResp = ''
                if (body[0].data.warehouse_station_type) {
                    let x = stationtypes.filter(obj => {
                        return obj.warehouse_station_type == body[0].data.warehouse_station_type
                    })
                    let s_id = x[0].warehouse_station_type_id;
                    station_type_id = s_id
                }
                if (body[0].data.warehouse_station_name) {
                    station_name = body[0].data.warehouse_station_name
                }
                if (station_type_id > 0 && station_name != '') {
                    let updateResp = await updateStation({
                        warehouse_station_id: station_id,
                        warehouse_address_id: activeaddressId,
                        warehouse_location_id: activelocationId,
                        company_id: companyId,
                        warehouse_station_name: station_name,
                        station_type_id: station_type_id
                        , created_by: userData.user_master_id
                    })
                }
                else if (station_type_id > 0) {
                    updateResp = await updateStation({
                        warehouse_station_id: station_id,
                        warehouse_address_id: activeaddressId,
                        warehouse_location_id: activelocationId,
                        company_id: companyId,
                        station_type_id: station_type_id
                        , created_by: userData.user_master_id
                    })
                }
                else {
                    updateResp = await updateStation({
                        warehouse_station_id: station_id,
                        warehouse_address_id: activeaddressId,
                        warehouse_location_id: activelocationId,
                        company_id: companyId,
                        warehouse_station_name: station_name
                        , created_by: userData.user_master_id
                    })
                }
                if (updateResp.data.success) {
                    toast.success(<AlertMessage type='success' title='Station detail Updated'
                        message='Station details updated successfully' />, { autoClose: 4000 });
                    await component.refresh(true);
                    component.cancelEditData();
                    return result;
                }
                else {
                    toast.error(<AlertMessage type='error' title='Error Updating Station'
                        message={updateResp.data.message} />, { autoClose: false });
                }

            }
            else {
                if (!selectedRecords) {
                    SetDelstationid(body[0].key)
                    setDelmodal(true)
                }
            }
        }
        catch (error) {
            console.log(error)
        }
    }

    //Add one row to table
    const _SingleRow = async () => {
        numrowsToadd = 1
        const result = await fetchContainerValue(numrowsToadd)
        Datagridref.current.instance.cancelEditData()
        // console.log('REZULT ', result)
        station_name = result.data[0]['station_name']
        Datagridref.current.instance.addRow()
        setNumrows(1)

    }
    const fetchContainerValue = async (id) => {
        let no_of_records = id
        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        const result = await fetchLayoutName(Configuration.entityType.station, company_id, no_of_records, activelocationId, activeaddressId);
        return result;
    }
    const _handleName = async (e) => {
        e.data['warehouse_station_name'] = station_name
    }
    const _handledropdownItem = async (item) => {
        setShowButton(true)
        setEditmode('batch')
        setDisable(false)
        setNumrows(item.id)
        const result = await fetchContainerValue(item.id)
        numrowsToadd = item.id
        Datagridref.current.instance.cancelEditData()
        for (var i = 0; i < item.id; i++) {
            station_name = result.data[i]['station_name']
            Datagridref.current.instance.addRow()
        }

    }


    return (
        <>

            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow add-navbar-styles'>
                <div className="btn-group title-text-styles">
                    <h4>Stations</h4>
                </div>

            </Navbar>
            {(skeleton === false) ?
                (
                    <StationsSkeleton />
                ) : (
                    <>
                        <Container className="mb-4">
                            <Row>
                                <Col lg={12} className="warehouse-margin mt-3 mb-1">
                                    <p>Select warehouse location and building to manage stations within them</p>
                                </Col>
                            </Row>
                            <Row className='mb-4'>
                                <Col lg={4}>
                                    <FormGroup>
                                        <label>Warehouse location</label>
                                        <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }} >
                                            <DropdownToggle caret color="secondary" outline type="select" className='form-control ml-3 warehouse-location-drp-width'>
                                                {locationType}
                                            </DropdownToggle>
                                            <DropdownMenu persist >
                                                {locations && locations.length > 0 ? (locations.map((item, index) => (
                                                    <DropdownItem onClick={() => { _handleOnClick([{ id: item.warehouse_location_id }, { name: item.location_name }]) }}>{item.location_name}</DropdownItem>
                                                ))) : (
                                                        ''
                                                    )}
                                            </DropdownMenu>
                                        </UncontrolledButtonDropdown>
                                    </FormGroup>
                                </Col>
                                <Col lg={6}>
                                    <FormGroup className='bg-light'>
                                        <label>Building</label>
                                        <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }}>
                                            <DropdownToggle caret color="secondary" outline type="select" className='form-control ml-3 warehouse-location-drp-width'>
                                                {addressType}
                                            </DropdownToggle>
                                            <DropdownMenu persist >
                                                {buildings && buildings.length > 0 ? (buildings.map((item, index) => (
                                                    <DropdownItem onClick={() => { _handlebuildingOnClick([{ id: item.warehouse_address_id }, { name: item.building_alias }]) }}>{item.building_alias}</DropdownItem>
                                                ))) : (
                                                        ''
                                                    )}
                                            </DropdownMenu>
                                        </UncontrolledButtonDropdown>
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Card className='margin-preview'>
                                <CardBody>
                                    <Row>
                                        <Col lg={5} className='ml-4 mt-2'>
                                            <FormGroup>

                                                <CustomInput type="checkbox" onChange={(e) => { _handleSelectStatus(e.target.checked) }} id="selet" name="select" inline
                                                    disabled={totalRecords > 0 ? false : true} />
                                                {((selectedRecords) && (!selectedAll)) ? (
                                                    <span className='ml-2'>{Datagridref.current.instance.getSelectedRowKeys().length} Stations Selected</span>
                                                ) : ''

                                                }
                                                {((selectedRecords) && (selectedAll)) ?
                                                    (
                                                        <span className='ml-2'>All records selected</span>
                                                    ) : ''

                                                }
                                                {((selectedRecords) && (!selectedAll) && (checked)) ? (
                                                    <span className=''>
                                                        <button className='btn p-0 ml-2 mr-2 btn-default text-primary'
                                                            onClick={
                                                                () => {
                                                                    setSelectedAll(true)
                                                                    setSelectMode('allPages');
                                                                }
                                                            }>Select All {totalRecords} Stations </button>
                                                    </span>
                                                ) : ''
                                                }
                                                {((selectedRecords) && (selectedAll)) ?
                                                    (
                                                        <span className=''>
                                                            <button className='btn p-0 m-2 btn-default text-primary'
                                                                onClick={
                                                                    () => {
                                                                        setSelectedAll(false)
                                                                        setSelectMode('page');
                                                                        Datagridref.current.instance.deselectAll()
                                                                        setTimeout(() => {
                                                                            Datagridref.current.instance.selectAll()
                                                                        }, 1000);
                                                                    }
                                                                }>Select current page record </button>
                                                        </span>
                                                    ) : ''
                                                }
                                                {selectedRecords && (
                                                    <button onClick={() => {
                                                        setnoLabeltoprint('multiple')
                                                        setSelectsizemodal(true)
                                                    }}
                                                        className='ml-0 btn b-0 bg-light dx-icon-print'>

                                                    </button>
                                                )}
                                            </FormGroup>
                                        </Col>
                                        <Col></Col>
                                        <Col>
                                            <div className='m-8'>
                                                <div className={selectedRecords ? 'hide-props' : ''}>
                                                    <ButtonGroup >
                                                        <LayoutImportDropdown containertype={Configuration.entityType.station} containername={"Station"}
                                                            company_id={companyId} warehouse_location_id={activelocationId} warehouse_address_id={activeaddressId}
                                                            warehouse_location_name={locationType} warehouse_address_name={addressType} />
                                                        <Button outline className='ml-2' onClick={() => _SingleRow()}>
                                                            <i className="fa fa-fw fa-plus"></i>
                                                        </Button>
                                                        <UncontrolledButtonDropdown direction="down">
                                                            <DropdownToggle color="secondary" outline caret />
                                                            <DropdownMenu right>
                                                                {addstationOptions && addstationOptions.length > 0 ? (addstationOptions.map((item, index) => (
                                                                    <DropdownItem key={index} onClick={() => _handledropdownItem(item)}>
                                                                        {item.name}
                                                                    </DropdownItem>
                                                                ))) : (
                                                                        ''
                                                                    )}
                                                            </DropdownMenu>
                                                        </UncontrolledButtonDropdown>
                                                        <ButtonGroup className={showButton ? '' : 'hide-props'}>
                                                            <Button outline className='ml-1' onClick={() => { Datagridref.current.instance.saveEditData() }} disabled={disable}>
                                                                <i className="dx-icon-save dx-link-save"></i>
                                                            </Button>
                                                            <Button outline onClick={() => { Datagridref.current.instance.cancelEditData(); setDisable(true); setEditmode('row'); setShowButton(false) }} disabled={disable}>
                                                                <i className="dx-icon-revert dx-cancel-edit"></i>
                                                            </Button>
                                                        </ButtonGroup>
                                                    </ButtonGroup>
                                                </div>
                                            </div>
                                        </Col>
                                    </Row>
                                    <div className="container-fluid">
                                        <iframe name="labeliframe" id='labeliframe' title='labeliframe'
                                            src={iframeurl}
                                            className='hide-props'
                                        ></iframe>
                                        <DataGrid
                                            id="gridContainer"
                                            dataSource={stations_data}
                                            ref={Datagridref}
                                            allowColumnReordering={true}
                                            remoteOperations={true}
                                            columnHidingEnabled={true}
                                            columnAutoWidth={true}
                                            rowAlternationEnabled={true}
                                            onRowInserted={() => {
                                                setAddingrecord(false)
                                            }}
                                            onEditCanceled={() => {
                                                setAddingrecord(false)
                                            }}
                                            onEditingStart={(e) => {
                                                e.cancel = selectedRecords ? true : false
                                            }}
                                            onToolbarPreparing={(e) => {
                                                e.toolbarOptions.visible = false
                                            }}
                                            onSelectionChanged={(e)=>{
                                                if(e.selectedRowKeys.length > 0){
                                                    if(e.selectedRowKeys.length === 1){
                                                        setSelectedRecords(false)
                                                    }
                                                    else{
                                                    setSelectedRecords(true)
                                                    setSelcount(e.selectedRowKeys.length)
                                                    }
                                                }
                                            }}
                                            showBorders={true}
                                            onCellPrepared={(e) => {
                                                if (e.rowType == 'header' && e.column.command == "edit") {
                                                    e.cellElement.innerText = " Actions ";
                                                }
                                                if (e.rowType == 'filter' && e.column.command == "edit") {
                                                    e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close dx-link-delete'></i></button>";
                                                    e.cellElement.onclick = () => { Datagridref.current.instance.clearFilter() }
                                                }
                                                if (e.rowType == 'header' && e.column.type == "selection") {
                                                    e.cellElement.innerHTML = "";
                                                }
                                            }
                                            }
                                            onRowUpdating={async (e) => {
                                                let station_name = '';
                                                let station_type_id = 0;
                                                let station_id = e.oldData.warehouse_station_id;
                                                if (e.newData.warehouse_station_name) {
                                                    station_name = e.newData.warehouse_station_name;
                                                }
                                                else {
                                                    station_name = e.oldData.warehouse_station_name;
                                                }
                                                if (e.newData.warehouse_station_type != undefined) {
                                                    station_type_id = e.newData.warehouse_station_type.station_type_id
                                                }
                                                else {
                                                    let station_type_name = e.oldData.warehouse_station_type
                                                    let idObj = stationtypes.filter(obj => {
                                                        return obj.station_name == station_type_name
                                                    })
                                                    station_type_id = idObj[0].station_type_id
                                                }
                                                let updateResp = await updateStation({
                                                    warehouse_station_id: station_id,
                                                    warehouse_address_id: activeaddressId,
                                                    warehouse_location_id: activelocationId,
                                                    company_id: companyId,
                                                    warehouse_station_name: station_name,
                                                    station_type_id: station_type_id
                                                })
                                                toast.success(<AlertMessage type='success' title='Station detail Updated'
                                                    message='Station details updated successfully' />, { autoClose: 4000 });
                                            }
                                            }
                                            onSaving={
                                                (e) => {
                                                    e.cancel = true;
                                                    SaveStation(e.changes, e.component)
                                                }
                                            }
                                            onInitNewRow={(e) => {
                                                setAddingrecord(true)
                                                _handleName(e)

                                            }}
                                        >

                                            <Paging enabled={true}
                                                defaultPageSize={10} />
                                            <Pager
                                                showPageSizeSelector={true}
                                                allowedPageSizes={[10, 15, 20]}
                                                showInfo={true} />
                                            <Editing
                                                mode={editmode}
                                                allowUpdating={true}
                                                allowDeleting={true}
                                                confirmDelete={false} />
                                            <Selection
                                                mode="multiple"
                                                allowSelectAll={true}
                                                selectAllMode={selectMode}
                                                showCheckBoxesMode='always'
                                            />
                                            <FilterRow visible={true} />
                                            <Column caption="Status" cellRender={ToggleBtn} allowEditing={false} hidingPriority={0} />
                                            <Column dataField="warehouse_station_name" caption='Station name' hidingPriority={2} width={180} allowSorting={true}>
                                                <RequiredRule />
                                                <PatternRule
                                                    message={'Please enter valid station name'}
                                                    pattern={Configuration.alphanumeric} />
                                            </Column>
                                            <Column dataField="warehouse_station_type" caption="Station type" allowSorting={true} hidingPriority={1}>
                                                <RequiredRule />
                                                <Lookup dataSource={stationtypes} valueExpr='warehouse_station_type' displayExpr='warehouse_station_type' />
                                            </Column>
                                            <Column type="buttons" width={110}>
                                                {!addingrecord && (
                                                    <Btndx hint="Print" icon="print" onClick={(e) => {
                                                        if (!selectedRecords) {
                                                            displayPopup(e)
                                                        }
                                                    }} />
                                                )}

                                                <Btndx name="edit" />
                                                <Btndx name="delete" />

                                            </Column>
                                        </DataGrid>
                                        <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this station`}
                                            onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete Station" />
                                    </div>
                                </CardBody>
                            </Card>
                        </Container>
                        {/* Select size Modal */}
                        <Printselectsizemodal action={actionsize} isOpen={selectsizemodal}
                            message={
                                <form>
                                    <div className='form-group'>
                                        <label>Select size <i className='text-danger'>*</i></label>
                                        <select className='form-control' onChange={(e) => {
                                            setSize(e.target.value)
                                            if (e.target.value != 0) {
                                                let sel_value = e.target.value
                                                let hind = sel_value.indexOf("-")
                                                let xind = sel_value.indexOf("X")
                                                let page_size_id = sel_value.substring(hind + 1)
                                                let x = sel_value.slice(0, xind)
                                                let y = sel_value.slice(xind + 1, hind)
                                                setX(x)
                                                setY(y);
                                                setIframeurl('');
                                                setPaperid(page_size_id)
                                            }

                                        }}>
                                            <option value='0'>Select paper size</option>
                                            {papersizes.map(papersize => (
                                                <option id={papersize.pdf_page_size_id}
                                                    value={papersize.size + '-' + papersize.pdf_page_size_id}
                                                >{papersize.width} x {papersize.height}</option>
                                            ))}
                                        </select>
                                    </div>
                                </form>
                            }
                            onClose={toggleSizeModal} onConfirm={noLabeltoprint === 'single' ? printSingleRowLabel : printSelectedsizeLabel} text={'Print'}
                            title={'Print Labels'} />
                    </>
                )}
        </>
    )
}

export default Stations;