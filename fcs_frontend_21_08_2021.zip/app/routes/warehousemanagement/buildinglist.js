import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { CardHeader, Row, Card, CardBody, Col } from '../../components';
import { AddBuildingRequest } from '../../redux/actions';
import ConfirmBox from '../commoncomponents/confirmbox';
import { toast } from 'react-toastify';
import AlertMessage from '../commoncomponents/alertmessage';
import EditBuildings from './editbuilding';

//Create a reusable component for card based list for building addresses
const BuildingList = () => {
    const buildingList = useSelector(state => state.AddBuilding?.buildings);
    const [selectedBuilding, setisSelectedBuilding] = useState('');
    const [editBuilding, setisEditBuilding] = useState('');
    const [modal, setmodal] = useState(false);
    const dispatch = useDispatch();

    // Open and close confirm box for delete buildings from list
    const confirmToggle = (building_name) => {
        setisSelectedBuilding(building_name);
        buildingList.map(item => {
            if (building_name === item.building_alias) {
                item.is_delete = true;
                return item;
            } else {
                item.is_delete = false;
                return item;
            }
        });
        setmodal(!modal);
    }

    // Edit buildings details
    const editBuildingFunction = (building_name) => {
        buildingList.map(item => {
            if (item.building_alias === building_name) {
                item.is_edit = true;
                return item;
            } else {
                item.is_edit = false;
                return item;
            }
        });
        localStorage.setItem('buildings', JSON.stringify(buildingList));
        dispatch(AddBuildingRequest());
        setisEditBuilding(building_name);
    }

    // Implement delete building functionality
    const onConfirm = () => {
        setmodal(!modal);
        let buildingList = JSON.parse(localStorage.getItem('buildings'));
        buildingList.pop(selectedBuilding);
        localStorage.setItem('buildings', JSON.stringify(buildingList));
        setisSelectedBuilding('');
        dispatch(AddBuildingRequest());
        toast.success(<AlertMessage type='success' title='Building Removed'
            message={`${selectedBuilding} building removed successfully!`} />, { autoClose: 4000 })
    }

    // Cancel edit mode for selected building
    const cancelEdit = () => {
        buildingList.map(item => {
            if (item.building_alias === editBuilding) {
                item.is_edit = false;
                return item;
            } else {
                item.is_edit = false;
                return item;
            }
        });
        setisEditBuilding('');
        dispatch(AddBuildingRequest());
    }

    return (
        <>
            <Row className="margin-top">
                {
                    buildingList && buildingList.length > 0 && buildingList.map((building, index) => (
                        building.is_edit && editBuilding ? <Col lg="6" key={index}><EditBuildings buildingName={editBuilding} cancel={cancelEdit} /> </Col> :
                            <Col lg="6" className="margin-top" key={index}>
                                <Card type="border" color={`${building.is_delete ? 'danger' : ''}`} className="mb-3">
                                    <CardHeader className={`${building.is_delete ? 'bg-danger text-white' : 'card-header'} `} tag="h6">
                                        {building.building_alias}
                                        <span className={'float-right'} >
                                            <a style={{ cursor: "pointer" }} onClick={() => editBuildingFunction(building.building_alias)} ><i className={'fa fa-edit mr-2 text-default'}></i></a>
                                            <a style={{ cursor: "pointer" }} onClick={() => confirmToggle(building.building_alias)} ><i className={'fa fa-trash mr-1 text-danger'}></i></a>
                                        </span>
                                    </CardHeader>
                                    <CardBody>
                                        <Row>
                                            <Col lg={3}>Capacity</Col>
                                            <Col lg={9}><span className='text-dark'>{building.building_capacity} Cubic Feet</span></Col>
                                        </Row>
                                        <Row>
                                            <Col lg={3}>Address</Col>
                                            <Col lg={9}><span className='text-dark'>{building.address_line1} &nbsp; {building.address_line2}
                                                {building.city} {building.state} {building.zip_code}, {building.country}</span></Col>
                                        </Row>
                                    </CardBody>
                                </Card>
                            </Col>
                    ))
                }
            </Row>
            <ConfirmBox isOpen={modal} message={`Are you sure you want to delete building ${selectedBuilding}?`}
                onClose={confirmToggle} onConfirm={onConfirm} text="Delete" title="Delete Building" />
        </>
    )
}

export default BuildingList
