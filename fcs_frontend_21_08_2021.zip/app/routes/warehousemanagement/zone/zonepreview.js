import React, { useEffect, useRef, useState } from 'react'
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    RequiredRule,
    Lookup
} from 'devextreme-react/data-grid';
import {
    Card, CardBody, Button, Navbar,
    FormGroup,
    Container,
    Row, Col,
    ThemeConsumer,
    Nav
} from '../../../../components';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import '../../../../styles/common.scss';
import AlertMessage from '../../../commoncomponents/alertmessage';
import CustomStore from 'devextreme/data/custom_store';
import { Configuration } from '../../../commoncomponents/configurationfile';
import { zoneTypes } from '../../../../services/layoutservices';
import { getTempZoneList } from '../../../../services/previewservice/layoutservice/previewzoneservice'
import ConfirmBox from '../../../commoncomponents/confirmbox';
import {
    getWarehouseLocationList,
    getBuildingDetailsList,
} from '../../../../services/warehousemanagementservice';
import { Link, useHistory } from 'react-router-dom';

const ZonePreview = (props) => {
    let history = useHistory();
    const datagridRef = useRef(null)
    const [layoutTypeId, setLayoutTypeId] = useState(1)
    const [companyId, setCompanyId] = useState(0)
    const [locations, setLocations] = useState([])
    const [buildings, setBuildings] = useState([])
    const [activelocationId, setActivelocationId] = useState(0)
    const [activeaddressId, setActiveaddressId] = useState(0)
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [zonetypes, setZonetypes] = useState([])
    const [delmodal, setDelmodal] = useState(false);
    const [delTempZoneId, SetDelTempZoneId] = useState(0)
    const [disable, setDisable] = useState(true)
    toast.configure();

    useEffect(() => {
        setCompanyId(CompanyListingStatus?.result?.response?.result[0].company_id)
        let company_id = CompanyListingStatus?.result?.response?.result[0].company_id
        WarehouseLocations(company_id)
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    //Load buildings
    const loadBuildings = async (locationId) => {
        let params = `?warehouse_location_id=${locationId}`
        let buildingResp = await getBuildingDetailsList(params)
        setBuildings(buildingResp.data)
        setActiveaddressId(buildingResp.data[0].warehouse_address_id)
    }
    //Load warehouse locations
    const WarehouseLocations = async (company_id) => {
        let params = `?company_id=${company_id}`
        let response = await getWarehouseLocationList(params)
        loadBuildings(response.data[0].warehouse_location_id)
        setActivelocationId(response.data[0].warehouse_location_id)
        setLocations(response.data)
        return response.data
    }
    const _handleLocationChange = (e) => {
        let locationId = e.target.value;
        setActivelocationId(locationId)
        loadBuildings(locationId);
    }
    const _handleBuildingchange = (e) => {
        let building_address_id = e.target.value;
        setActiveaddressId(building_address_id);
        console.log('Active location id', activelocationId)
        console.log('Active address id', building_address_id)
    }

    useEffect(() => {
        setLayoutTypeId(Configuration.entityType.zone)
    }, [])



    const laodZonetypes = async () => {
        let zonetypesResp = await zoneTypes()
        setZonetypes(zonetypesResp)
    }

    useEffect(() => {
        laodZonetypes()
    }, [])

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }

    const temp_zone_data = new CustomStore({
        key: 'warehouse_zone_id',
        load: async function (loadOptions) {
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                    params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                }
            });
            params += `warehouse_location_id=${activelocationId}&`
            params += `company_id=${companyId}&`
            params += `warehouse_address_id=${activeaddressId}&`
            params += `container_type=${Configuration.entityType.zone}&`
            params = params.slice(0, -1);
            let response = await getTempZoneList(params);
            console.log('response', response)
            return response;

        }
    });


    const onCellPrepared = (e) => {
        if (e.rowType == 'header' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<b>Action</b>";
        }
        if (e.rowType == 'filter' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close text-danger'></i></button>";
            e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
        }
    }
    const deleteRow = async () => {
        let deleteresp = await deleteZone({ warehouse_zone_id: delStationid });
        setDelmodal(!delmodal)
        toast.success(<AlertMessage type='success' title='Zone Deleted'
            message='Zone has been deleted Successfully' />, { autoClose: 4000 });
    }
    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }

    const onSaving = (e) => {
        e.cancel = true;
        console.log('e.changes', e.changes)
        SaveZone(e.changes, e.component)
    }

    const SaveZone = async (body, component) => {

        try {
            if (body[0].type === 'update') {

            }
            else {
                console.log('del', body[0].key)
                SetDelTempZoneId(body[0].key)
                setDelmodal(true)
            }
        }
        catch (error) {
            console.log(error)
        }
    }
    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <h4>Import Zones - BuildingOne.xlsx</h4>
                <ThemeConsumer>
                    {({ color }) => (
                        <div>
                            <Nav className='d-md-block'>
                                <span className="save-padding-add3plcompany">
                                    <Link to='/warehouse/locations'>
                                        <Button outline color="secondary-custom" > Cancel </Button>
                                    </Link>
                                </span>
                                <Button color={color} type="button"  >
                                    Import Zones
                                </Button>
                            </Nav>
                        </div>
                    )}
                </ThemeConsumer>
            </Navbar>
            <Container className="mb-5">
                <Row>
                    <Col lg={12} className="warehouse-margin mt-4 mb-2">
                        <p>Select warehouse location and building to import zones within them</p>
                    </Col>
                </Row>
                <Row className='mb-4'>
                    <Col lg={4}>
                        <form className='form-inline'>
                            <FormGroup>
                                <label>Warehouse location</label>
                                <select className='form-control ml-3 warehouse-location-drp-width' onChange={_handleLocationChange}>
                                    {locations && locations.length > 0 ? (locations.map((item, index) => (
                                        <option key={index}
                                            id={`location-${item.warehouse_location_id}`}
                                            value={`${item.warehouse_location_id}`}>
                                            {item.location_name}
                                        </option>
                                    ))) : (
                                            ''
                                        )}

                                </select>
                            </FormGroup>
                        </form>
                    </Col>
                    <Col lg={6}>
                        <form className='form-inline'>
                            <FormGroup className='bg-light'>
                                <label>Building</label>
                                <select className='form-control ml-3 bg-light' onChange={_handleBuildingchange}>
                                    {buildings && buildings.length > 0 ? (buildings.map((item, index) => (
                                        <option key={index}
                                            id={`building-${item.warehouse_address_id}`}
                                            value={`${item.warehouse_address_id}`} selected={item.warehouse_address_id == activeaddressId ? 'true' : 'false'}>
                                            {item.building_alias}
                                        </option>
                                    ))) : (
                                            ''
                                        )}
                                </select>
                            </FormGroup>
                        </form>
                    </Col>
                </Row>
                <Card className="mb-3" className="margin-top">
                    <CardBody>
                        <div className="container-fluid">
                            <DataGrid id="grid-container"
                                showBorders={true}
                                dataSource={temp_zone_data}
                                ref={datagridRef}
                                onCellPrepared={onCellPrepared}
                                remoteOperations={true}
                                allowColumnReordering={true}
                                columnHidingEnabled={true}
                                rowAlternationEnabled={true}
                                columnHidingEnabled={true}
                                onToolbarPreparing={(e) => {
                                    e.toolbarOptions.visible = false
                                }}
                                onSaving={onSaving}
                                onRowRemoving={async (e) => {
                                    e.cancel = true;
                                    delStationId = e.data.warehouse_zone_id
                                }}
                            >
                                <Editing
                                    mode="row"
                                    useIcons={true}
                                    allowDeleting={true}
                                    allowUpdating={true}
                                    confirmDelete={false}
                                >
                                </Editing>
                                <Paging defaultPageSize={10} />
                                <Pager
                                    showPageSizeSelector={true}
                                    allowedPageSizes={[10, 15, 20]}
                                    showInfo={true} />
                                <FilterRow visible={true} />
                                <Column dataField="warehouse_zone_name" caption="Zone name" onChange={(e) => { console.log('hi') }} >
                                    <RequiredRule />
                                </Column>
                                <Column dataField="warehouse_zone_type" caption="Zone type" >
                                    <Lookup dataSource={zonetypes} valueExpr="warehouse_zone_type" displayExpr="warehouse_zone_type" />
                                    <RequiredRule />
                                </Column>
                            </DataGrid>
                            <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this temporary zone`}
                                onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete Temporary Zone" />
                        </div>
                    </CardBody>
                </Card>
            </Container>
        </>
    )
}

export default ZonePreview
