import React, { useEffect, useRef, useState } from 'react'
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    Lookup,
    RequiredRule,
} from 'devextreme-react/data-grid';
import {
    Card, CardBody, Container, ButtonGroup, Button, DropdownToggle,
    UncontrolledButtonDropdown, DropdownMenu, DropdownItem, Row, Col,
    Navbar, ThemeConsumer, Nav, CardTitle
} from '../../../../components';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import '../../../../styles/common.scss';
import CustomStore from 'devextreme/data/custom_store';
import { Configuration } from '../../../commoncomponents/configurationfile';
import { getContainerList, deleteContainer, addContainer, UpdateContainer } from '../../../../services/previewservice/containerservice/containerpreviewservice';
import AlertMessage from '../../../commoncomponents/alertmessage';
import ConfirmBox from '../../../commoncomponents/confirmbox';
import { getWarehouseLocationList } from '../../../../services/warehousemanagementservice';
import { getContainerTypeList } from '../../../../services/binservice';
import { Link, useHistory, useLocation } from 'react-router-dom';

import ContainerConfigurationPreviewSkeleton from '../../skeleton/containerpreviewskeleton';

let active_warehouse_location_id = 0;
let container_type = 0;
let scontainer_name = ''
let ccontainer_name = ''
let warehouse_location_id = 0;
let companyId = 0;
let records_type = 0;
const ContainerPreview = () => {
    warehouse_location_id = localStorage.getItem("warehouse_location_id");
    container_type = localStorage.getItem("ContainerType")
    scontainer_name = localStorage.getItem("ContainerName").toLowerCase()
    ccontainer_name = localStorage.getItem("ContainerName")
    const datagridRef = useRef(null)
    const location = useLocation()
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [containerTypeList, setContainerTypeList] = useState([]);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [delmodal, setDelmodal] = useState(false);
    const [delbinid, SetBinId] = useState(0)
    const [loader, setLoader] = useState(false);
    const [valid_count, setValidCount] = useState(0)
    const [invalid_count, setInValidCount] = useState(0)
    const [locationType, setLocationType] = useState('Select Location')
    const [locationTypeId, setLocationTypeId] = useState(0)
    const [locationList, setLocationList] = useState([])
    const [skeleton, setSkeleton] = useState(false);
    const [delete_count, setDeleteCount] = useState(0)
    const [skip, setSkip] = useState(true)
    toast.configure();

    // if (location.state != null) {
    //     useEffect(() => {
    //         warehouse_location_id = location.state.warehouseLocationId;
    //         container_type = location.state.container_id
    //         scontainer_name = location.state.container_name
    //         ccontainer_name = location.state.container_name
    //         // setBinType(location.state.container_name)
    //         // setContainerType(location.state.container_id);
    //     }, [])
    // }

    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            loadBinSize(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
            LocationList(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
            companyId = CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id
        }
        else {
            loadBinSize(CompanyListingStatus?.result?.response?.result[0].company_id)
            LocationList(CompanyListingStatus?.result?.response?.result[0].company_id)
            companyId = CompanyListingStatus?.result?.response?.result[0].company_id
        }
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    const loadBinSize = async (company_id) => {
        const result = await getContainerTypeList(container_type, company_id);
        setContainerTypeList(result.data.result)
    }

    // useEffect(() => {
    //     let company_id = CompanyListingStatus?.result?.response?.result[0].company_id
    //     LocationList(company_id)
    // }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    const LocationList = async (company_id) => {
        const result = await getWarehouseLocationList(`?company_id=${company_id}`);
        setSkeleton(true)
        setLocationList(result.data)
        if (location.state != null) {
            setLocationTypeId(location.state.warehouseLocationId)
            warehouse_location_id = location.state.warehouseLocationId;
            setLocationType(location.state.warehouseLocationName)
        } else {
            setLocationTypeId(result.data[0].warehouse_location_id);
            warehouse_location_id = result.data[0].warehouse_location_id;
            setLocationType(result.data[0].location_name)
        }
    }

    const _handleOnClick = (e) => {
        localStorage.setItem("warehouse_location_id", "");
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setLocationType(str)
        }
        else {
            setLocationType(e[1].name)
        }
        setLocationTypeId(e[0].id)
        localStorage.setItem("warehouse_location_id", e[0].id);
        // warehouse_location_id = e[0].id;
    }

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }
    // useEffect(() => {
    //     setCompanyId(CompanyListingStatus?.result?.response?.result[0].company_id)
    // }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    const bin_data = new CustomStore({
        key: `container_${scontainer_name}_id`,
        load: async function (loadOptions) {
            let count = 0;
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (skip === true) {
                    if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                        params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                    }
                } else {
                    if (count === 0) {
                        params += `skip=0&take=10&requireTotalCount=true&totalSummary=[]&`;
                    }
                }
                count++;
            });
            params += `container_type=${container_type}&`
            params += `warehouse_location_id=${warehouse_location_id}&`
            params += `company_id=${companyId}&`
            params += `validate_type=${records_type}&`
            params = params.slice(0, -1);
            let response = await getContainerList(params);
            setValidCount(response.validCount)
            setInValidCount(response.invalidCount)
            setDeleteCount(response.deleteCount)
            return response;

        }
    });
    //============================================== End =====================================================

    //========= This code is used for show the action header label and show the filter button ===========
    const onCellPrepared = (e) => {
        if (e.rowType == 'header' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<b>Action</b>";
        }
        if (e.rowType == 'filter' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close text-danger'></i></button>";
            e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
        }
    }
    //======================== End =====================================================================
    //====================== This function is used to save update data ======================
    const onSaving = React.useCallback((e) => {
        e.cancel = true;
        SaveBin(e.changes, e.component);

    }, []);
    const SaveBin = async (body, component) => {
        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        try {
            if (body[0].type === 'update') {
                console.log('container_type', typeof (container_type))
                console.log('Configuration.entityType.bin', typeof (Configuration.entityType.cart))
                if (parseInt(container_type) == Configuration.entityType.bin) {
                    body = { "bins": body, created_by: userData.user_master_id, warehouse_location_id: locationTypeId, company_id: companyId }
                }
                if (parseInt(container_type) == Configuration.entityType.box) {
                    body = { "boxes": body, created_by: userData.user_master_id, warehouse_location_id: locationTypeId, company_id: companyId }
                }
                if (parseInt(container_type) == Configuration.entityType.cart) {
                    body = { "carts": body, created_by: userData.user_master_id, warehouse_location_id: locationTypeId, company_id: companyId }
                }
                if (parseInt(container_type) == Configuration.entityType.pallete) {
                    body = { "palletes": body, created_by: userData.user_master_id, warehouse_location_id: locationTypeId, company_id: companyId }
                }
                if (parseInt(container_type) == Configuration.entityType.tote) {
                    body = { "totes": body, created_by: userData.user_master_id, warehouse_location_id: locationTypeId, company_id: companyId }
                }
                const result = await UpdateContainer(body, container_type);
                if (result.data['status'] === true) {
                    toast.success(<AlertMessage type='success' title={`Update ${localStorage.getItem("ContainerName")}`}
                        message={result.data['message']} />, { autoClose: 4000 });
                }
                else {
                    toast.error(<AlertMessage type='error' title={`Update ${localStorage.getItem("ContainerName")}`}
                        message={result.data['message']} />, { autoClose: false });
                }
                await component.refresh(true);
                component.cancelEditData();
                return result;
            }
            else {
                SetBinId(body[0].key)
                setDelmodal(true)
            }
        }
        catch (error) {
            console.log(error)
        }
    }
    //================================ End ===============================================
    //===================== This modal is used for the delete ============================
    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }
    //===================== End ===========================================================
    //========================= This funccction is used for the delete particular row ===========
    const deleteRow = async () => {
        const result = await deleteContainer(container_type, delbinid, userData.user_master_id);
        setDelmodal(!delmodal)
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title={`Delete ${localStorage.getItem("ContainerName")}`}
                message={result.data['message']} />, { autoClose: 4000 });
        }
        else {
            toast.error(<AlertMessage type='error' title={`Delete ${localStorage.getItem("ContainerName")}`}
                message={result.data['message']} />, { autoClose: false });
        }
    }
    //======================== End =====================================================
    const _handleSaveContainerData = async () => {
        setLoader(true)
        const result = await addContainer(container_type);
        console.log('result', result)
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title={`Save ${localStorage.getItem("ContainerName")}`}
                message={result.data['message']} />, { autoClose: 4000 });
            setLoader(false)
        }
        else {
            toast.error(<AlertMessage type='error' title={`Save ${localStorage.getItem("ContainerName")}`}
                message={result.data['message']} />, { autoClose: false });
            setLoader(false)
        }
    }
    const _handleRecords = (recordsType, count) => {
        records_type = recordsType
        if (count > 10) {
            setSkip(true)
        } else {
            setSkip(false)
        }
        datagridRef.current.instance.refresh();
    }
    return (

        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <h4>Import {localStorage.getItem("ContainerName")} - {localStorage.getItem("ContainerFileName")}</h4>
                <ThemeConsumer>
                    {({ color }) => (
                        <div>
                            <Nav className='d-md-block'>
                                <span className="save-padding-add3plcompany">
                                    <Link to=
                                        {
                                            {
                                                pathname: '/warehouse/movablecontainer',
                                                state: {
                                                    container_name: location.state.containerName,
                                                    container_id: location.state.containerId,
                                                    warehouse_location_id: location.state.warehouseLocationId,
                                                    warehouse_location_name: location.state.warehouseLocationName
                                                }
                                            }}>
                                        <Button outline color="secondary-custom" > Cancel </Button>
                                    </Link>
                                </span>
                                <Button color={color} type="button" disabled={loader} onClick={() => _handleSaveContainerData()} >
                                    Import  {localStorage.getItem("ContainerName")} ({valid_count})
                                    <span> </span>
                                    {loader && (
                                        <i
                                            className="fa fa-spinner fa-spin"
                                            style={{ marginRight: "5px" }}
                                        />
                                    )}
                                </Button>
                            </Nav>
                        </div>
                    )}
                </ThemeConsumer>
            </Navbar>
            {(skeleton === false) ?
                (
                    <ContainerConfigurationPreviewSkeleton />

                ) : (
                    <>
                        <Container className="margin-top">
                            <p>{`Select warehouse location to import ${scontainer_name} within them`}</p>
                            <Row className="margin-top">
                                <Col lg={3}>
                                    <Card className="mb-3">
                                        <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.ValidateRecords, valid_count) }}>
                                            <CardBody>
                                                <CardTitle tag="h6" className="mb-4"> Validated Records </CardTitle>
                                                <div className="mb-3">
                                                    <h5>{valid_count}</h5>
                                                </div>
                                            </CardBody>
                                        </a>
                                    </Card>
                                </Col>
                                <Col lg={3}>
                                    <Card className="mb-3">
                                        <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.ErrorRecords, invalid_count) }}>
                                            <CardBody>
                                                <CardTitle tag="h6" className="mb-4"> Error Records </CardTitle>
                                                <div className="mb-3">
                                                    <h5>{invalid_count}</h5>
                                                </div>
                                            </CardBody>
                                        </a>
                                    </Card>
                                </Col>
                                <Col lg={3}>
                                    <Card className="mb-3">
                                        <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.ExcludedRecords, delete_count) }}>
                                            <CardBody>
                                                <CardTitle tag="h6" className="mb-4"> Excluded Records </CardTitle>
                                                <div className="mb-3">
                                                    <h5>{delete_count}</h5>
                                                </div>
                                            </CardBody>
                                        </a>
                                    </Card>
                                </Col>
                                <Col lg={3}>
                                    <Card className="mb-3">
                                        <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.TotalRecords, (invalid_count + valid_count + delete_count)) }}>
                                            <CardBody>
                                                <CardTitle tag="h6" className="mb-4"> Total Records </CardTitle>
                                                <div className="mb-3">
                                                    <h5>{invalid_count + valid_count + delete_count}</h5>
                                                </div>
                                            </CardBody>
                                        </a>
                                    </Card>
                                </Col>
                            </Row>
                            <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }}>
                                <DropdownToggle caret color="secondary" outline type="select" style={{ width: "20%" }}>
                                    {locationType}
                                </DropdownToggle>
                                <DropdownMenu persist >
                                    {locationList && locationList.length > 0 ? (locationList.map((item, index) => (
                                        <DropdownItem onClick={() => { _handleOnClick([{ id: item.warehouse_location_id }, { name: item.location_name }]) }}>{item.location_name}</DropdownItem>
                                    ))) : (
                                            ''
                                        )}
                                </DropdownMenu>
                            </UncontrolledButtonDropdown>
                            <Card className="mb-3" className="margin-top">
                                <CardBody>
                                    {/* Start DataGrid */}
                                    <div className="container-fluid">
                                        <DataGrid id="grid-container"
                                            showBorders={true}
                                            dataSource={bin_data}
                                            ref={datagridRef}
                                            keyExpr="container_bin_id"
                                            onCellPrepared={onCellPrepared}
                                            remoteOperations={true}
                                            allowColumnReordering={true}
                                            onSaving={onSaving}
                                            // columnHidingEnabled={true}
                                            rowAlternationEnabled={true}
                                            onToolbarPreparing={(e) => {
                                                e.toolbarOptions.visible = false
                                            }}
                                        >
                                            <Editing
                                                mode="row"
                                                useIcons={true}
                                                allowUpdating={true}
                                                allowDeleting={true}
                                                confirmDelete={false}
                                            >
                                            </Editing>
                                            <Paging defaultPageSize={10} />
                                            <Pager
                                                showPageSizeSelector={true}
                                                allowedPageSizes={[10, 15, 20]}
                                                showInfo={true} />
                                            <FilterRow visible={true} />
                                            <Column dataField={`${scontainer_name}_name`} caption={`${ccontainer_name} name`} >
                                                <RequiredRule />
                                            </Column>
                                            <Column dataField="entity_size_id" caption={`${ccontainer_name} size`}>
                                                <Lookup dataSource={containerTypeList} valueExpr="entity_size_id" displayExpr="entity_size" />
                                                <RequiredRule />
                                            </Column>
                                        </DataGrid>
                                    </div>
                                    {/* End DataGrid */}
                                    <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this ${localStorage.getItem("ContainerName")}`}
                                        onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title={`Delete ${localStorage.getItem("ContainerName")}`} />
                                </CardBody>
                            </Card>

                        </Container>
                    </>
                )}
        </>
    )

}

export default ContainerPreview
