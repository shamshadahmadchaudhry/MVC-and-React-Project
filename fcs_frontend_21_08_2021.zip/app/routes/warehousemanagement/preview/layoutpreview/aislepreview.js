import React, { useEffect, useRef, useState } from 'react'
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    RequiredRule,
    Lookup
} from 'devextreme-react/data-grid';
import {
    Card, CardBody, ButtonGroup, Button, DropdownToggle,
    UncontrolledButtonDropdown, DropdownMenu, DropdownItem, Navbar,
    FormGroup,
    Container,
    Row, Col,
    ThemeConsumer,
    Nav,
    CardTitle
} from '../../../../components';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import '../../../../styles/common.scss';
import AlertMessage from '../../../commoncomponents/alertmessage';
import CustomStore from 'devextreme/data/custom_store';
import { Configuration } from '../../../commoncomponents/configurationfile';
import { zoneTypes } from '../../../../services/layoutservices';
import { getTempLayouList, addLayout, deleteLayout, UpdateLayout } from '../../../../services/previewservice/layoutservice/previewlayoutservice'
import ConfirmBox from '../../../commoncomponents/confirmbox';
import {
    getWarehouseLocationList,
    getBuildingDetailsList,
} from '../../../../services/warehousemanagementservice';
import { Link, useLocation } from 'react-router-dom';
import AislePreviewSkeleton from '../../skeleton/aislepreviewskeleton';
let companyId = 0;
const AislePreview = () => {
    const datagridRef = useRef(null)
    const location = useLocation()
    const [locations, setLocations] = useState([])
    const [buildings, setBuildings] = useState([])
    const [activelocationId, setActivelocationId] = useState(0)
    const [activeaddressId, setActiveaddressId] = useState(0)
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [delmodal, setDelmodal] = useState(false);
    const [delTempAisleId, setDelTempAisleId] = useState(0)
    const [valid_count, setValidCount] = useState(0)
    const [invalid_count, setInValidCount] = useState(0)
    const [loader, setLoader] = useState(false);
    const [skeleton, setSkeleton] = useState(false);
    const [records_type, setRecordsType] = useState(0)
    const [delete_count, setDeleteCount] = useState(0)
    const [skip, setSkip] = useState(true)
    const [locationType, setLocationType] = useState('Select Location')
    const [addressType, setAddressType] = useState('Select Address')
    const [isselect, setIsSelect] = useState(false)
    toast.configure();

    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            WarehouseLocations(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
            companyId = CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id
        }
        else {
            WarehouseLocations(CompanyListingStatus?.result?.response?.result[0].company_id)
            companyId = CompanyListingStatus?.result?.response?.result[0].company_id
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    //Load buildings
    const loadBuildings = async (locationId) => {
        let params = `?warehouse_location_id=${locationId}`
        let buildingResp = await getBuildingDetailsList(params)
        setSkeleton(true)
        setBuildings(buildingResp.data)
        if (location.state != null && isselect === false) {
            setAddressType(location.state.warehouse_address_name)
            setActiveaddressId(location.state.warehouse_address_id)
        } else {
            setAddressType(buildingResp.data[0].building_alias)
            setActiveaddressId(buildingResp.data[0].warehouse_address_id)
        }
    }
    //Load warehouse locations
    const WarehouseLocations = async (company_id) => {
        let params = `?company_id=${company_id}`
        let response = await getWarehouseLocationList(params)
        if (location.state != null) {
            setLocationType(location.state.warehouse_location_name)
            loadBuildings(location.state.warehouse_location_id)
            setActivelocationId(location.state.warehouse_location_id)
        } else {
            setLocationType(response.data[0].location_name)
            loadBuildings(response.data[0].warehouse_location_id)
            setActivelocationId(response.data[0].warehouse_location_id)
        }
        setLocations(response.data)
        return response.data
    }
    useEffect(() => {
        setIsSelect(true)
        setAddressType('')
    }, [activelocationId])
    const _handleOnClick = (e) => {
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setLocationType(str)
        }
        else {
            setLocationType(e[1].name)
        }
        setActivelocationId(e[0].id)
        loadBuildings(e[0].id);
    }
    const _handlebuildingOnClick = (e) => {
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setAddressType(str)
        }
        else {
            setAddressType(e[1].name)
        }
        setActiveaddressId(e[0].id);
    }

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }

    const temp_aisle_data = new CustomStore({
        key: 'warehouse_aisle_id',
        load: async function (loadOptions) {
            let count = 0;
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (skip === true) {
                    if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                        params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                    }
                } else {
                    if (count === 0) {
                        params += `skip=0&take=10&requireTotalCount=true&totalSummary=[]&`;
                    }
                }
                count++;
            });
            params += `warehouse_location_id=${activelocationId}&`
            params += `company_id=${companyId}&`
            params += `warehouse_address_id=${activeaddressId}&`
            params += `container_type=${Configuration.entityType.aisle}&`
            params += `validate_type=${records_type}&`
            params = params.slice(0, -1);
            let response = await getTempLayouList(params);
            setValidCount(response.validCount)
            setInValidCount(response.invalidCount)
            setDeleteCount(response.deleteCount)
            return response;

        }
    });


    const onCellPrepared = (e) => {
        if (e.rowType == 'header' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<b>Action</b>";
        }
        if (e.rowType == 'filter' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close text-danger'></i></button>";
            e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
        }
    }
    const deleteRow = async () => {
        const result = await deleteLayout(Configuration.entityType.aisle, delTempAisleId);
        setDelmodal(!delmodal)
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title='Delete Aisle'
                message={result.data['message']} />, { autoClose: 4000 });
        }
        else {
            toast.error(<AlertMessage type='error' title='Delete Aisle'
                message={result.data['message']} />, { autoClose: false });
        }
    }
    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }

    const _handleSaveZoneData = async () => {
        setLoader(true)
        const result = await addLayout(Configuration.entityType.aisle);
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title='Save Aisle'
                message={result.data['message']} />, { autoClose: 4000 });
            setLoader(false)
        }
        else {
            toast.error(<AlertMessage type='error' title='Save Aisle'
                message={result.data['message']} />, { autoClose: false });
            setLoader(false)
        }
    }
    const onSaving = (e) => {
        e.cancel = true;
        SaveAisle(e.changes, e.component)
    }

    const SaveAisle = async (body, component) => {
        try {
            let data = body[0]
            if (body[0].type === 'update') {
                let body = {
                    warehouse_aisle_id: data.key,
                    warehouse_address_id: activeaddressId,
                    warehouse_location_id: activelocationId,
                    company_id: companyId,
                    created_by: userData.user_master_id,
                    warehouse_aisle_name: data.data.warehouse_aisle_name,
                }
                console.log('body', body)
                const result = await UpdateLayout(Configuration.entityType.aisle, body);
                if (result.data['status'] === true) {
                    toast.success(<AlertMessage type='success' title='Save Zone'
                        message={result.data['message']} />, { autoClose: 4000 });
                    setLoader(false)
                }
                else {
                    toast.error(<AlertMessage type='error' title='Save Zone'
                        message={result.data['message']} />, { autoClose: false });
                    setLoader(false)
                }
                await component.refresh(true);
                component.cancelEditData();
                return result;
            }
            else {
                console.log('del', body[0].key)
                setDelTempAisleId(body[0].key)
                setDelmodal(true)
            }
        }
        catch (error) {
            console.log(error)
        }
    }
    const _handleRecords = (recordsType, count) => {
        setRecordsType(recordsType);
        if (count > 10) {
            setSkip(true)
        } else {
            setSkip(false)
        }
        datagridRef.current.instance.refresh();
    }
    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <h4>Import Aisle - {localStorage.getItem("FileName")}</h4>
                <ThemeConsumer>
                    {({ color }) => (
                        <div>
                            <Nav className='d-md-block'>
                                <span className="save-padding-add3plcompany">
                                    <Link to={
                                        {
                                            pathname: '/warehouse/layouts',
                                            state: {
                                                layout_name: location.state.layouName,
                                                layout_id: location.state.layouId,
                                                warehouse_location_id: location.state.warehouse_location_id,
                                                warehouse_address_id: location.state.warehouse_address_id,
                                                warehouse_location_name: location.state.warehouse_location_name,
                                                warehouse_address_name: location.state.warehouse_address_name,
                                            }
                                        }}>
                                        <Button outline color="secondary-custom" > Cancel </Button>
                                    </Link>
                                </span>
                                <Button color={color} type="button" disabled={loader} onClick={() => _handleSaveZoneData()} >
                                    Import Aisle ({valid_count})
                                    <span> </span>
                                    {loader && (
                                        <i
                                            className="fa fa-spinner fa-spin"
                                            style={{ marginRight: "5px" }}
                                        />
                                    )}
                                </Button>
                            </Nav>
                        </div>
                    )}
                </ThemeConsumer>
            </Navbar>
            {(skeleton === false) ?
                (
                    <AislePreviewSkeleton />

                ) : (
                    <>
                        <Container className="mb-5">
                            <Row>
                                <Col lg={12} className="mt-3 mb-1">
                                    <p>Select warehouse location and building to import aisle within them</p>
                                </Col>
                            </Row>
                            <Row className="mt-1 mb-1">
                                <Col lg={3}>
                                    <Card className="mb-3">
                                        <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.ValidateRecords, valid_count) }}>
                                            <CardBody>
                                                <CardTitle tag="h6" className="mb-4"> Validated Records </CardTitle>
                                                <div className="mb-3">
                                                    <h5>{valid_count}</h5>
                                                </div>
                                            </CardBody>
                                        </a>
                                    </Card>
                                </Col>
                                <Col lg={3}>
                                    <Card className="mb-3">
                                        <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.ErrorRecords, invalid_count) }}>
                                            <CardBody>
                                                <CardTitle tag="h6" className="mb-4"> Error Records </CardTitle>
                                                <div className="mb-3">
                                                    <h5>{invalid_count}</h5>
                                                </div>
                                            </CardBody>
                                        </a>
                                    </Card>
                                </Col>
                                <Col lg={3}>
                                    <Card className="mb-3">
                                        <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.ExcludedRecords, delete_count) }}>
                                            <CardBody>
                                                <CardTitle tag="h6" className="mb-4"> Excluded Records </CardTitle>
                                                <div className="mb-3">
                                                    <h5>{delete_count}</h5>
                                                </div>
                                            </CardBody>
                                        </a>
                                    </Card>
                                </Col>
                                <Col lg={3}>
                                    <Card className="mb-3">
                                        <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.TotalRecords, (invalid_count + valid_count + delete_count)) }}>
                                            <CardBody>
                                                <CardTitle tag="h6" className="mb-4"> Total Records </CardTitle>
                                                <div className="mb-3">
                                                    <h5>{invalid_count + valid_count + delete_count}</h5>
                                                </div>
                                            </CardBody>
                                        </a>
                                    </Card>
                                </Col>
                            </Row>
                            <Row className='mb-4'>
                                <Col lg={4}>
                                    <FormGroup>
                                        <label>Warehouse location</label>
                                        <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }} >
                                            <DropdownToggle caret color="secondary" outline type="select" className='form-control ml-3 warehouse-location-drp-width'>
                                                {locationType}
                                            </DropdownToggle>
                                            <DropdownMenu persist >
                                                {locations && locations.length > 0 ? (locations.map((item, index) => (
                                                    <DropdownItem onClick={() => { _handleOnClick([{ id: item.warehouse_location_id }, { name: item.location_name }]) }}>{item.location_name}</DropdownItem>
                                                ))) : (
                                                        ''
                                                    )}
                                            </DropdownMenu>
                                        </UncontrolledButtonDropdown>
                                    </FormGroup>
                                </Col>
                                <Col lg={6}>
                                    <FormGroup className='bg-light'>
                                        <label>Building</label>
                                        <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }}>
                                            <DropdownToggle caret color="secondary" outline type="select" className='form-control ml-3 warehouse-location-drp-width'>
                                                {addressType}
                                            </DropdownToggle>
                                            <DropdownMenu persist >
                                                {buildings && buildings.length > 0 ? (buildings.map((item, index) => (
                                                    <DropdownItem onClick={() => { _handlebuildingOnClick([{ id: item.warehouse_address_id }, { name: item.building_alias }]) }}>{item.building_alias}</DropdownItem>
                                                ))) : (
                                                        ''
                                                    )}
                                            </DropdownMenu>
                                        </UncontrolledButtonDropdown>
                                    </FormGroup>
                                </Col>
                            </Row>

                            <Card className="mb-3" className="margin-preview">
                                <CardBody>
                                    <div className="container-fluid">
                                        <DataGrid id="grid-container"
                                            showBorders={true}
                                            dataSource={temp_aisle_data}
                                            ref={datagridRef}
                                            onCellPrepared={onCellPrepared}
                                            remoteOperations={true}
                                            allowColumnReordering={true}
                                            columnHidingEnabled={true}
                                            rowAlternationEnabled={true}
                                            columnHidingEnabled={true}
                                            onToolbarPreparing={(e) => {
                                                e.toolbarOptions.visible = false
                                            }}
                                            onSaving={onSaving}
                                            onRowRemoving={async (e) => {
                                                e.cancel = true;
                                                delStationId = e.data.warehouse_aisle_id
                                            }}
                                        >
                                            <Editing
                                                mode="row"
                                                useIcons={true}
                                                allowDeleting={true}
                                                allowUpdating={true}
                                                confirmDelete={false}
                                            >
                                            </Editing>
                                            <Paging defaultPageSize={10} />
                                            <Pager
                                                showPageSizeSelector={true}
                                                allowedPageSizes={[10, 15, 20]}
                                                showInfo={true} />
                                            <FilterRow visible={true} />
                                            <Column dataField="warehouse_aisle_name" caption="Aisle name"  >
                                                <RequiredRule />
                                            </Column>
                                        </DataGrid>
                                        <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this temporary aisle`}
                                            onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete Temporary Aisle" />
                                    </div>
                                </CardBody>
                            </Card>
                        </Container>
                    </>
                )}
        </>
    )
}

export default AislePreview
