import React, { useEffect, useRef, useState } from 'react'
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    Lookup,
    RequiredRule,
    Selection,
    Button as Btndx
} from 'devextreme-react/data-grid';
import {
    Card, CardBody, ButtonGroup, Button, DropdownToggle,
    UncontrolledButtonDropdown, DropdownMenu, DropdownItem, Container, Row, Col, FormGroup, CustomInput
} from '../../../components';

import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import '../../../styles/common.scss';
import AlertMessage from '../../commoncomponents/alertmessage';
import { Configuration } from '../../commoncomponents/configurationfile';
import CustomStore from 'devextreme/data/custom_store';
import { getBinList, getContainerTypeList } from '../../../services/binservice';
import {
    getPapersizes,
    printLabels
} from '../../../services/warehousemanagementservice';
import {
    addContainer, updateContainer, deleteContainer, fetchContainerName
} from '../../../services/containerservice';
import CartPalleteToteSkeleton from '../skeleton/cartpalletetoteskeleton';
import ConfirmBox from '../../commoncomponents/confirmbox';
import ImportDropdown from '../common/importdropdown';
import { CONFIG } from '../../../config'
import Printselectsizemodal from '../common/printSelectsizemodal';

let active_location_id = 0
let container_name = ''
const CartList = (props) => {
    const datagridRef = useRef(null)
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [containerTypeList, setContainerTypeList] = useState([])
    const [cartData, setCartData] = useState([])
    const [mode, setMode] = useState('row')
    const [skeleton, setSkeleton] = useState(false)
    const [disable, setDisable] = useState(true);
    const [delmodal, setDelmodal] = useState(false);
    const [delcartid, SetCartId] = useState(0)
    const [showButton, setShowButton] = useState(false)
    toast.configure();

    //All states for selection
    const [selectMode, setSelectMode] = useState('page')
    const [totalRecords, setTotalRecords] = useState(0)
    const [selectedRecords, setSelectedRecords] = useState(false)
    const [selectedAll, setSelectedAll] = useState(false)
    const [cartId, setCartId] = useState(0)
    const [labelType, setLabelType] = useState('single')

    const [papersizes, setPapersizes] = useState([])
    const [x, setX] = useState(0)
    const [y, setY] = useState(0)
    const [size, setSize] = useState(0)
    const [paperid, setPaperid] = useState(0)
    const [iframeurl, setIframeurl] = useState("")
    const [addingrecord, setAddingrecord] = useState(false)
    const [companyId, setCompanyId] = useState(0)
    const [selcount, setSelcount] = useState(0)
    const [checked, setChecked] = useState(false)

    //Selection Implementation
    const _handleSelectStatus = (checked) => {
        if (checked) {
            setSelectMode('page')
            setSelectedRecords(true)
            setChecked(true)
            datagridRef.current.instance.selectAll()
        }
        else {
            setSelectedAll(false)
            setSelectMode('page')
            setSelectedRecords(false)
            setChecked(false)
            datagridRef.current.instance.deselectAll()
        }

    }
    const loadPaperSizes = async () => {
        let papersizesReq = await getPapersizes();
        setPapersizes(papersizesReq.data)
    }

    useEffect(() => {
        loadPaperSizes()
    }, [])

    useEffect(() => {
        if (selectMode === 'page') {
            setSelectMode('page')
        }
        else if (selectMode === 'allPages') {
            setSelectMode('allPages')
            datagridRef.current.instance.deselectAll()
            datagridRef.current.instance.selectAll()
        }
    }), [selectMode]

    //Select Size Modal State
    const [selectsizemodal, setSelectsizemodal] = useState(false)
    const [actionsize, setActionsize] = useState('')

    const toggleSizeModal = () => {
        setSize(0)
        setSelectsizemodal(!selectsizemodal)
    }
    const send_print_request = async (active_entity, entity_ids, printallRecords) => {
        let activeaddressId = 0
        const printdocument = await printLabels({
            paper_size_id: parseInt(paperid), company_id: companyId,
            location_id: active_location_id, location_address_id: activeaddressId, x_width: parseInt(x), y_height: parseInt(y),
            entity_type: active_entity.toString(), ids_list: entity_ids, print_all: printallRecords
        })

        console.log('PRINT DOC ', printdocument)

        if (printdocument.data.status) {
            let path = printdocument.data.pdf_file_path
            let html_url = printdocument.data.html_url
            path = path.replace(/\\/g, "/");
            let indmedia = path.indexOf('media')
            let remPath = path.slice(indmedia)
            let fullPath = CONFIG.BASE_URL + '/' + remPath;
            let get_html_url = html_url + '?pdf_path=' + fullPath.substring(fullPath.indexOf('media'));
            setIframeurl(get_html_url, 'Print', 'left=200, top=200, width=950, height=500, toolbar=0, resizable=0');
            window.frames["labeliframe"].focus();
        }
    }
    const printSelectedsizeLabel = () => {
        console.log('Selected Row keys = ', datagridRef.current.instance.getSelectedRowKeys())
        if (size != '0') {
            let printallRecords = false;
            let active_entity = Configuration.entityType.cart
            let entity_ids = []
            let data = datagridRef.current.instance.getSelectedRowKeys();
            for (let i = 0; i < data.length; i++) {
                if (data[i] != null) {
                    entity_ids.push(data[i])
                }
            }
            setSelectsizemodal(true)
            if (data.length === totalRecords) {
                printallRecords = true
            }
            console.log('ENTITY IDS', entity_ids)
            send_print_request(active_entity, entity_ids, printallRecords)
        }
        else {
            toast.error(<AlertMessage type="error" title="Select Paper Size"
                message="Please select paper size." />, { autoClose: 4000 });
        }
    }
    const printSingleRowLabel = () => {
        if (size != '0') {
            let printallRecords = false;
            let active_entity = Configuration.entityType.cart
            let entity_ids = []
            let data = datagridRef.current.instance.getSelectedRowKeys();
            entity_ids.push(cartId)
            setSelectsizemodal(true)
            if (data.length === totalRecords) {
                printallRecords = true
            }
            // SEND PRINT REQUEST
            send_print_request(active_entity, entity_ids, printallRecords)
        }
        else {
            toast.error(<AlertMessage type="error" title="Select Paper Size"
                message="Please select paper size." />, { autoClose: 4000 });
        }
    }
    //End of Selection code
    // useEffect(() => {
    //     loadCartSize(CompanyListingStatus?.result?.response?.result[0].company_id)
    //     loadCart()
    // }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])
    useEffect(() => {
        loadCart()
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            loadCartSize(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
        }
        else {
            loadCartSize(CompanyListingStatus?.result?.response?.result[0].company_id)
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])
    active_location_id = props.locationId;
    //==================== This function is used for the load tote size ==================================== 
    const loadCartSize = async (company_id) => {
        const result = await getContainerTypeList(Configuration.entityType.cart, company_id);
        setSkeleton(true)
        setContainerTypeList(result.data.result)
    }
    //==================End====================================================================================
    //=================== This code is used for the bind dropdownlist for prepopulating data ===================
    const loadCart = () => {
        const CartData = [{ id: 2, name: "Add 2 Carts" }, { id: 3, name: "Add 3 Carts" }, { id: 4, name: "Add 4 Carts" }, { id: 5, name: "Add 5 Carts" },
        { id: 6, name: "Add 6 Carts" }, { id: 7, name: "Add 7 Carts" }, { id: 8, name: "Add 8 Carts" }, { id: 9, name: "Add 9 Carts" }, { id: 10, name: "Add 10 Carts" }]
        setCartData(CartData)
    }
    //=================== End ====================================================================================
    //================= This code is used to load the bin list =================================================
    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }
    const bin_data = new CustomStore({
        key: 'container_cart_id',
        load: async function (loadOptions) {
            let params = '?';
            let count = 0;
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                    params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                }
                if (!loadOptions.filter && !loadOptions.sort && count === 0 && !loadOptions.skip && !loadOptions.take) {
                    params += `skip=0&take=${totalRecords}&requireTotalCount=true&totalSummary=[]&`;
                }
                count++;
            });
            params += `container_type=${Configuration.entityType.cart}&`
            params += `warehouse_location_id=${active_location_id}&`
            params = params.slice(0, -1);
            let cartList = await getBinList(params);
            setTotalRecords(cartList.totalCount)
            return cartList;

        }
    });
    //============================================== End ===================================================== 
    //========= This code is used for show the action header label and show the filter button ===========
    const onCellPrepared = (e) => {
        console.log('TJ', e.column)
        if (e.rowType == 'header' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<b>Action</b>";
        }
        if (e.rowType == 'filter' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close dx-link-delete'></i></button>";
            e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
        }
        if (e.rowType == 'header' && e.column.type == "selection") {
            e.cellElement.innerHTML = "";
        }
    }
    //========================= End ===============================================================
    //================ This code is used for the prepopulating data and bind it into bin list textbox ==========
    const fetchContainerValue = async (id) => {
        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        const result = await fetchContainerName(Configuration.entityType.cart, company_id, id, active_location_id);
        return result;
    }
    const _handledropdownItem = async (id) => {
        setShowButton(true)
        setMode('batch')
        setDisable(false)
        const result = await fetchContainerValue(id)
        datagridRef.current.instance.cancelEditData()
        for (var i = 0; i < id; i++) {
            console.log('result', result)
            container_name = result.data[i]['cart_name']
            datagridRef.current.instance.addRow()
        }
    }
    const _SingleRow = async () => {
        setMode('row')
        const result = await fetchContainerValue(1)
        datagridRef.current.instance.cancelEditData()
        container_name = result.data[0]['cart_name']
        datagridRef.current.instance.addRow()
    }
    const _handleName = async (e) => {
        e.data['cart_name'] = container_name
    }
    //========================= End ===============================================================
    //====================== This function is used to save update data ======================
    const onSaving = React.useCallback((e) => {
        e.cancel = true;
        SaveBox(e.changes, e.component)
    }, []);

    const SaveBox = async (body, component) => {
        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        try {
            if (body[0].type === 'insert') {
                body = {
                    "carts": body, created_by: userData.user_master_id,
                    warehouse_location_id: active_location_id,
                    company_id: company_id
                }
                const result = await addContainer(body, Configuration.entityType.cart);
                setMode('row')
                setDisable(true)
                if (result.data['status'] === true && result.data['message_type'] === 0) {
                    toast.success(<AlertMessage type='success' title='Save Cart'
                        message={result.data['message']} />, { autoClose: 4000 });
                    setShowButton(false);
                    datagridRef.current.instance.cancelEditData();
                }
                else {
                    toast.error(<AlertMessage type='error' title='Save Cart'
                        message={result.data['message']} />, { autoClose: false });
                }
                await component.refresh(true);
                component.cancelEditData();
                return result;
            } else if (body[0].type === 'update') {

                body = { "carts": body, created_by: userData.user_master_id, warehouse_location_id: active_location_id, company_id: company_id }
                const result = await updateContainer(body, Configuration.entityType.cart);
                if (result.data['status'] === true) {
                    toast.success(<AlertMessage type='success' title='Update Cart'
                        message={result.data['message']} />, { autoClose: 4000 });
                }
                else {
                    toast.error(<AlertMessage type='error' title='Update Cart'
                        message={result.data['message']} />, { autoClose: false });
                }
                await component.refresh(true);
                component.cancelEditData();
                return result;
            }
            else {
                SetCartId(body[0].key)
                setDelmodal(true)
            }
        }
        catch (error) {
            console.log(error)
        }
    }
    //===================================== End ======================================================= 
    //===================== This modal is used for the delete ============================
    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }
    //===================== End ===========================================================
    //========================= This funccction is used for the delete particular row ===========
    const deleteRow = async () => {
        const result = await deleteContainer(Configuration.entityType.cart, delcartid, userData.user_master_id);
        setDelmodal(!delmodal)
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title='Delete Cart'
                message={result.data['message']} />, { autoClose: 4000 });
        }
        else {
            toast.error(<AlertMessage type='error' title='Delete Cart'
                message={result.data['message']} />, { autoClose: false });
        }
    }
    //======================== End =====================================================
    return (
        <>
            {(skeleton === false) ?
                (
                    <CartPalleteToteSkeleton />
                ) : (
                    <>
                        <Container className="margin-top mb-4">
                            <Card className="mb-3" className="margin-top">
                                <CardBody>
                                    <h5 className='ml-3'>Manage Carts</h5>
                                    {/* This code is used for the prepopulating data and save the data and also refresh the data */}
                                    <Row>
                                        <Col lg={6} className='ml-4 mt-2'>
                                            <FormGroup>
                                                <CustomInput type="checkbox" className='ml-1' onChange={(e) => { _handleSelectStatus(e.target.checked) }}
                                                    id="select" name="select" inline disabled={totalRecords > 0 ? false : true} />
                                                {((selectedRecords) && (!selectedAll)) ? (
                                                    <span className='ml-2'>{selcount} Carts Selected</span>
                                                ) : ''

                                                }
                                                {((selectedRecords) && (selectedAll)) ?
                                                    (
                                                        <span className='ml-2'>All records selected</span>
                                                    ) : ''

                                                }

                                                {((selectedRecords) && ((!selectedAll) && (totalRecords > 10) && (checked))) ? (
                                                    <span className=''>
                                                        <button className='btn p-0 m-2 btn-default text-primary'
                                                            onClick={
                                                                () => {
                                                                    setSelectedAll(true)
                                                                    setSelectMode('allPages');
                                                                }
                                                            }>Select All {totalRecords} Carts </button>
                                                    </span>
                                                ) : ''
                                                }
                                                {((selectedRecords) && (selectedAll)) ?
                                                    (
                                                        <span className=''>
                                                            <button className='btn p-0 m-2 btn-default text-primary'
                                                                onClick={
                                                                    () => {
                                                                        setSelectedAll(false)
                                                                        setSelectMode('page');
                                                                        datagridRef.current.instance.deselectAll()
                                                                        setTimeout(() => {
                                                                            datagridRef.current.instance.selectAll()
                                                                        }, 1000);
                                                                    }
                                                                }>Select current page record </button>
                                                        </span>
                                                    ) : ''
                                                }
                                                {selectedRecords && (
                                                    <button onClick={() => {
                                                        setLabelType('multiple')
                                                        setSelectsizemodal(true)
                                                    }}
                                                        className='ml-1 btn b-0 bg-light dx-icon-print'>
                                                    </button>
                                                )}

                                            </FormGroup>
                                        </Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col className='ml-5'>
                                            <div className="container-fluid margin-bottoms">
                                                <div className={selectedRecords ? 'hide-props' : ''}>
                                                    <ButtonGroup>
                                                        <ImportDropdown containertype={Configuration.entityType.cart} containername={"Cart"}
                                                            locationid={active_location_id} locationName={props.locationName} />
                                                        <Button outline onClick={() => _SingleRow()} className='ml-2'>
                                                            <i className="fa fa-fw fa-plus"></i>
                                                        </Button>
                                                        <UncontrolledButtonDropdown direction="down">
                                                            <DropdownToggle color="secondary" outline caret />
                                                            <DropdownMenu right>
                                                                {cartData && cartData.length > 0 ? (cartData.map((item, index) => (
                                                                    <DropdownItem onClick={() => _handledropdownItem(item.id)}>
                                                                        {item.name}
                                                                    </DropdownItem>
                                                                ))) : (
                                                                        ''
                                                                    )}
                                                            </DropdownMenu>
                                                        </UncontrolledButtonDropdown>
                                                        <ButtonGroup className={showButton ? '' : 'hide-props'}>
                                                            <Button outline className='ml-2' onClick={() => { datagridRef.current.instance.saveEditData() }} disabled={disable}>
                                                                <i className="dx-icon-save dx-link-save"></i>
                                                            </Button>
                                                            <Button outline onClick={() => { datagridRef.current.instance.cancelEditData(); setDisable(true); setMode('row'); setShowButton(false) }} disabled={disable}>
                                                                <i className="dx-icon-revert dx-cancel-edit"></i>
                                                            </Button>
                                                        </ButtonGroup>
                                                    </ButtonGroup>
                                                </div>
                                            </div>
                                        </Col>
                                    </Row>
                                    {/* ================ End =====================*/}
                                    {/* Start DataGrid */}
                                    <div className="container-fluid">
                                        <iframe name="labeliframe" id='labeliframe' title='labeliframe'
                                            src={iframeurl}
                                            className='hide-props'
                                        ></iframe>
                                        <DataGrid id="grid-container"
                                            showBorders={true}
                                            dataSource={bin_data}
                                            ref={datagridRef}
                                            keyExpr="container_cart_id"
                                            onCellPrepared={onCellPrepared}
                                            // columnHidingEnabled={true}
                                            remoteOperations={true}
                                            allowColumnReordering={true}
                                            onSaving={onSaving}
                                            onInitNewRow={(e) => {
                                                setAddingrecord(true)
                                                _handleName(e)
                                            }}
                                            onRowInserted={() => {
                                                setAddingrecord(false)
                                            }}
                                            onEditCanceled={() => {
                                                setAddingrecord(false)
                                            }}
                                            onEditingStart={(e) => {
                                                e.cancel = selectedRecords ? true : false
                                            }}
                                            onSelectionChanged={(e) => {
                                                if (e.selectedRowKeys.length > 0) {
                                                    if (e.selectedRowKeys.length === 1) {
                                                        setSelectedRecords(false)
                                                    }
                                                    else {
                                                        setSelectedRecords(true)
                                                        setSelcount(e.selectedRowKeys.length)
                                                    }
                                                }
                                            }}
                                            rowAlternationEnabled={true}
                                            onToolbarPreparing={(e) => {
                                                e.toolbarOptions.visible = false
                                            }}
                                        >
                                            <Editing
                                                mode={mode}
                                                useIcons={true}
                                                allowUpdating={true}
                                                allowDeleting={true}
                                                confirmDelete={false}
                                            >
                                            </Editing>
                                            <Selection
                                                mode="multiple"
                                                allowSelectAll={true}
                                                selectAllMode={selectMode}
                                                showCheckBoxesMode='always'
                                            />
                                            <Paging defaultPageSize={10} />
                                            <Pager
                                                showPageSizeSelector={true}
                                                allowedPageSizes={[10, 15, 20]}
                                                showInfo={true} />
                                            <FilterRow visible={true} />
                                            <Column dataField="cart_name" caption="Cart Name"> </Column>
                                            <Column dataField="entity_size_id" caption="Cart Size">
                                                <Lookup dataSource={containerTypeList} valueExpr="entity_size_id" displayExpr="entity_size" />
                                                <RequiredRule />
                                            </Column>
                                            <Column type="buttons">
                                                <Btndx hint="Print" icon="print" onClick={(e) => {
                                                    if (!selectedRecords) {
                                                        setLabelType('single')
                                                        setCartId(e.row.data.container_cart_id)
                                                        toggleSizeModal(true)
                                                    }
                                                }} />
                                                <Btndx name="edit" />
                                                <Btndx name="delete"
                                                // onClick={
                                                //     (e) => {
                                                //         if (!selectedRecords) {
                                                //             SetCartId(e.row.data.container_cart_id)
                                                //             setDelmodal(true)
                                                //         }
                                                //     }
                                                // }
                                                />
                                            </Column>
                                        </DataGrid>
                                    </div>
                                    {/* End DataGrid */}
                                    <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this cart`}
                                        onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete Box" />

                                </CardBody>
                            </Card>

                        </Container>
                    </>
                )}
            <Printselectsizemodal action={actionsize} isOpen={selectsizemodal}
                message={
                    <form>
                        <div className='form-group'>
                            <label>Select size <i className='text-danger'>*</i></label>
                            <select className='form-control' onChange={(e) => {
                                setSize(e.target.value)
                                if (e.target.value != 0) {
                                    let sel_value = e.target.value
                                    let hind = sel_value.indexOf("-")
                                    let xind = sel_value.indexOf("X")
                                    let page_size_id = sel_value.substring(hind + 1)
                                    let x = sel_value.slice(0, xind)
                                    let y = sel_value.slice(xind + 1, hind)
                                    setX(x)
                                    setY(y); setIframeurl('');
                                    setPaperid(page_size_id)
                                }

                            }}>
                                <option value='0'>Select paper size</option>
                                {papersizes.map(papersize => (
                                    <option id={papersize.pdf_page_size_id}
                                        value={papersize.size + '-' + papersize.pdf_page_size_id}
                                    /* hidden={
                                         (papersize.size === '4X6' || papersize.size === '4X1' || papersize.size === '3X1') ? false:true
                                     }*/
                                    >{papersize.width} x {papersize.height}</option>
                                ))}
                            </select>
                        </div>
                    </form>
                }
                onClose={toggleSizeModal} onConfirm={labelType === 'single' ? printSingleRowLabel : printSelectedsizeLabel} text={'Print'}
                title={'Print Labels'} />
        </>
    )
}

export default CartList
