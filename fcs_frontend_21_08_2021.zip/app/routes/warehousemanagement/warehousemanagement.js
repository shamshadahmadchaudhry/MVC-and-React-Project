import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import {
    Container, Row, Col, ThemeConsumer, Button, Navbar, Nav, InputGroupAddon
    , Card, CardBody, CardTitle, FormGroup, Label, InputGroup
} from '../../components';
import AddBuildings from './addbuildings';
import BuildingList from './buildinglist';
import * as yup from 'yup';
import { AddBuildingRequest, StateListRequest } from '../../redux/actions';
import { Configuration } from '../commoncomponents/configurationfile';
import { ToastContainer, toast } from 'react-toastify';
import { addWarehouseLocations, verifyZipCode } from '../../services/warehousemanagementservice';
import ConfirmBox from '../commoncomponents/confirmbox';
import AlertMessage from '../commoncomponents/alertmessage';
import { Link, useHistory } from 'react-router-dom';
import { PromptIfDirtyWarehouse } from '../commoncomponents/userpromt';
import { getUnitofMeasures } from '../../services/companyprofileservice';

const WarehouseManagement = () => {
    let history = useHistory();
    const dispatch = useDispatch();
    const [isLoading, setIsLoading] = useState(false);
    const [isNextLoading, setIsNextLoading] = useState(false);
    const [zipcodeLoader, setzipcodeLoader] = useState(false);
    const [isValidZipcode, setisValidZipcode] = useState(false);
    const [isNext, setisNext] = useState(JSON.parse(localStorage.getItem('locationDetails')) ? true : false);
    const buildingList = useSelector(state => state.AddBuilding?.buildings);
    const [isEdit, setisEdit] = useState(false);
    const [showBuilding, setshowBuilding] = useState(false);
    const [modal, setmodal] = useState(false);
    const [unitOfMeasures, setUnitMeasures] = useState('');
    const StateListStatus = useSelector(state => state?.stateList?.isSuccess && state?.stateList?.data?.response?.data);
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);

    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [companyData, setCompanyData] = useState(0);
    const [locationDetails, setlocationDetails] = useState({ location_name: '', zip_code: '', country: '1', state: '', city: '' });

    useEffect(() => {
        localStorage.removeItem('buildings');
        setisNext(false);
        localStorage.removeItem('location');
        localStorage.removeItem('locationDetails');
        dispatch(AddBuildingRequest());
        dispatch(StateListRequest());
    }, []);

    // Load selected company details
    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1)
            setCompanyData(CompanyListingStatus?.result?.response?.result?.find(val => val.is_default))
        else
            setCompanyData(CompanyListingStatus?.result?.response?.result[0])
        UnitMeasures();
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    // On warehouse edit confirm remove all building details and reset the warehouse location form
    const onConfirm = (resetForm) => {
        setisEdit(false);
        setisNext(false)
        setshowBuilding(false);
        resetForm();
        setmodal(!modal);
        localStorage.removeItem('buildings');
        localStorage.removeItem('locationDetails');
        localStorage.removeItem('location');
        dispatch(AddBuildingRequest());
    }

    // Open and close confirm box modal
    const confirmToggle = () => {
        buildingList.map(item => {
            item.is_delete = false;
            return item;
        })
        setmodal(!modal);
    }

    // Add warehose location details and procced for next
    const addNewBuilding = (values) => {
        setIsNextLoading(true);
        setisEdit(true);
        setisNext(true)
        setshowBuilding(true);
        values.company_id = companyData.company_id;
        values.created_by = userData.user_master_id;
        localStorage.setItem('locationDetails', JSON.stringify(values));
        setIsNextLoading(false);
    }

    // Integrate API for city/state lookup in add warehouse section when tabout action performed on zipcode textbox
    const validateZipcode = async (e, setFieldValue) => {
        let zipCodeValue = e.target.value.match(Configuration.numeric);
        if (e.target.value) {
            setzipcodeLoader(true);
            try {
                let response = await verifyZipCode({ "zip_code": e.target.value })
                if (response.data && response.data.length > 0) {
                    let zipcodeDetails = response.data[0];
                    setFieldValue('city', zipcodeDetails.city);
                    setFieldValue('state', zipcodeDetails.state);
                    setFieldValue('zip_code', zipcodeDetails.zipcode);
                    localStorage.setItem('location', JSON.stringify(zipcodeDetails));
                    setzipcodeLoader(false);
                    setisValidZipcode(false);
                } else {
                    setFieldValue('city', '');
                    setFieldValue('state', '');
                    setzipcodeLoader(false);
                    setisValidZipcode(true);
                }
            } catch (err) {
                setFieldValue('city', '');
                setFieldValue('state', '');
                setzipcodeLoader(false);
                setisValidZipcode(true);
            }
        } else {
            return false;
        }
    }

    // Clear warehouse location form details
    const clearLocationForm = (resetForm) => {
        if (!isNext) {
            setisValidZipcode(false);
            localStorage.removeItem('locationDetails');
            resetForm();
        }
    }

    // Integrate API for warehouse details insert and update operation
    const saveLocationDetails = async () => {
        setIsLoading(true);
        let locationDetails = JSON.parse(localStorage.getItem('locationDetails')) || {}; // Get warehouse location details from localstorage. 
        let buildingList = JSON.parse(localStorage.getItem('buildings')) || []; // Get buildings details from local storage.

        if (!locationDetails) {
            toast.error(<AlertMessage type='error' title='Invalid inputs'
                message={'Please enter all required details.'} />, { autoClose: false });
            setIsLoading(false);
            return false;
        }

        if (buildingList.length > 0) {
            locationDetails.buildings = buildingList;
            let response = await addWarehouseLocations(locationDetails);
            if (response.data.status) {
                localStorage.removeItem('locationDetails');
                localStorage.removeItem('buildings');
                localStorage.removeItem('location');
                dispatch(AddBuildingRequest());
                setIsLoading(false);
                history.push('warehouse/locations');
            } else {
                toast.error(<AlertMessage type='error' title='Internal Error'
                    message={response.data.message} />, { autoClose: false });
            }
        } else {
            toast.error(<AlertMessage type='error' title='Building Not Found'
                message={'Please add atleast one building information.'} />, { autoClose: false });
        }
        setIsLoading(false);
    }

    // Edit warehouse location
    const editWarehouseLocation = () => {
        if (buildingList) {
            buildingList.map(item => {
                item.is_delete = true;
                return item;
            });
            setmodal(!modal);
        } else {
            setisEdit(false);
            setisNext(false)
            setshowBuilding(false);
        }
    }

    const UnitMeasures = async () => {
        let company_id = 0;
        if (CompanyListingStatus?.result?.response?.result.length > 1)
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id
        else
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        const result = await getUnitofMeasures(company_id, userData?.user_type_id);
        if (!result.data.error) {
            for (let i = 0; i < result.data.data.length; i++) {
                if (result.data.data[i].is_active == 1) {
                    setUnitMeasures(result.data.data[i].cubic_unit);
                    break;
                }
            }
        }
    }

    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div class="btn-group title-text-style">

                    <h4>Add Warehouse Location</h4>
                </div>

                <ThemeConsumer>
                    {({ color }) => (
                        <div>
                            <Nav className='d-md-block'>
                                <span className="save-padding-add3plcompany">
                                    <Link to='/warehouse/locations'>
                                        <Button outline color="secondary-custom" > Cancel </Button>
                                    </Link>
                                </span>
                                <Button type="button" disabled={isLoading || !buildingList} color={color} onClick={() => saveLocationDetails()} >
                                    <i className="fa fa-floppy-o" aria-hidden="true"></i>  {'Save'}
                                    {isLoading && (
                                        <i
                                            className="fa fa-spinner fa-spin ml-1"
                                        />)}
                                </Button>
                            </Nav>
                        </div>
                    )}
                </ThemeConsumer>
            </Navbar>
            <Container>
                <Row>
                    <Col lg={12} className="warehouse-margin">
                        <p>Add location information along with atleast one building information.</p>

                    </Col>
                </Row>
                <Row>
                    {/* Start warehouse location section  */}
                    <Col lg={6}>
                        <Formik
                            initialValues={locationDetails}
                            enableReinitialize={true}
                            validationSchema={yup.object().shape({
                                location_name: yup.string().nullable().required(`Please enter a warehouse name.`)
                                    .matches(Configuration.alphanumericSpace, 'Please enter a valid warehouse name.'),
                                country: yup.string().nullable().required(`Please select country`),
                                zip_code: yup.string().nullable().required(`${Configuration.required} zip code`)
                                    .matches(Configuration.numeric, 'Please enter a valid ZIP code.'),
                                state: yup.string().nullable().required(`Please select a state to proceed.`),
                                city: yup.string().nullable().required(`${Configuration.required} city name`)
                                    .matches(Configuration.alphabat, 'Please enter a valid city.')
                            })}
                            onSubmit={addNewBuilding}
                        >
                            {({ errors, touched, values, resetForm, setFieldValue }) => (
                                <Form>
                                    <PromptIfDirtyWarehouse />
                                    <Card>
                                        <CardBody>
                                            <div className="d-flex mb-4">
                                                <CardTitle tag="h5">
                                                    Warehouse Location
                                                </CardTitle>
                                                <span className="ml-auto align-self-start small">
                                                    Fields mark as <span className="text-danger">*</span> is required.
                                                </span>
                                            </div>
                                            <FormGroup>
                                                <Label for="location_name">
                                                    Location name <span className="text-danger">*</span>
                                                </Label>
                                                <Field type="text"
                                                    placeholder="Warehouse location 1"
                                                    name="location_name"
                                                    disabled={isNext}
                                                    value={values.location_name}
                                                    className={`${touched.location_name && errors.location_name && 'is-invalid'} ${isNext ? '' : 'bg-white'}  form-control`} />
                                                {touched.location_name && errors.location_name &&
                                                    <ErrorMessage name="location_name" component="span" className="text-danger"></ErrorMessage>
                                                }

                                            </FormGroup>
                                            <FormGroup>
                                                <Label for="country">
                                                    Country <span className="text-danger">*</span>
                                                </Label>
                                                <Field disabled={true} as="select" className="form-control"
                                                    name="country" id="country1"
                                                    className={`${touched.country && errors.country && 'is-invalid'} ${isNext ? '' : 'bg-white'} form-control`} >
                                                    <option value="1" selected={true} >USA</option>
                                                    <option value="0">Select Country</option>
                                                </Field >
                                                <ErrorMessage name="country" component="span" className="text-danger" />
                                            </FormGroup>
                                            <FormGroup>
                                                <Label for="zipcode">
                                                    ZIP Code <span className="text-danger">*</span>
                                                </Label>
                                                <InputGroup>
                                                    <Field type="text"
                                                        placeholder="Enter ZIP code"
                                                        name="zip_code"
                                                        maxLength="9"
                                                        disabled={isNext}
                                                        onBlur={(e) => validateZipcode(e, setFieldValue)}
                                                        value={values.zip_code}
                                                        className={`${((touched.zip_code && errors.zip_code) || isValidZipcode) && 'is-invalid'} ${isNext ? '' : 'bg-white'} form-control`} />
                                                    {zipcodeLoader && <InputGroupAddon addonType="append"  >
                                                        <i className="fa fa-spinner fa-spin ml-1"></i>
                                                    </InputGroupAddon>
                                                    }
                                                </InputGroup>
                                                {touched.zip_code && errors.zip_code &&
                                                    <ErrorMessage name="zip_code" component="span" className="text-danger"></ErrorMessage>
                                                }
                                                {isValidZipcode &&
                                                    <span className="text-danger">Please enter valid zip code</span>
                                                }
                                            </FormGroup>
                                            <FormGroup>
                                                <Label for="state">
                                                    State <span className="text-danger">*</span>
                                                </Label>
                                                <Field as="select" className="form-control"
                                                    name="state" maxLength="100" id="state"
                                                    disabled={isNext}
                                                    className={`${touched.state && errors.state && 'is-invalid'} ${isNext ? '' : 'bg-white'} form-control`} >
                                                    <option value="">Select State</option>
                                                    {
                                                        StateListStatus && StateListStatus.length > 0 && StateListStatus.map((state, index) => (
                                                            <option key={state.state_code + '' + index} value={state.state_code}>{state.state_name}</option>
                                                        ))
                                                    }
                                                </Field >
                                                <ErrorMessage name="state" component="span" className="text-danger" />
                                            </FormGroup>
                                            <FormGroup>
                                                <Label for="city">
                                                    City <span className="text-danger">*</span>
                                                </Label>
                                                <Field type="text"
                                                    placeholder="Enter city"
                                                    name="city"
                                                    disabled={isNext}
                                                    value={values.city}
                                                    className={`${touched.city && errors.city && 'is-invalid'} ${isNext ? '' : 'bg-white'} form-control`} />
                                                {touched.city && errors.city &&
                                                    <ErrorMessage name="city" component="span" className="text-danger"></ErrorMessage>
                                                }
                                            </FormGroup>
                                            <ThemeConsumer>
                                                {({ color }) => (
                                                    <div className="float-right">
                                                        <span className="save-padding-add3plcompany">
                                                            <Button onClick={() => clearLocationForm(resetForm)} type="button" outline color="secondary-custom" > Clear </Button>
                                                        </span>
                                                        {isEdit && <Button type="button" disabled={isLoading} color={color}
                                                            onClick={() => editWarehouseLocation()} >
                                                            <i className="fa fa-edit" aria-hidden="true"></i>  {'Edit'}
                                                            {isLoading && (
                                                                <i
                                                                    className="fa fa-spinner fa-spin ml-1"
                                                                />)}
                                                        </Button>
                                                        }
                                                        {!isEdit && <Button type="submit" disabled={isNextLoading} color={color}>
                                                            <i className="fa fa-chevron-right" aria-hidden="true"></i>  {'Next'}
                                                            {isLoading && (
                                                                <i
                                                                    className="fa fa-spinner fa-spin ml-1"
                                                                />)}
                                                        </Button>
                                                        }
                                                    </div>
                                                )}
                                            </ThemeConsumer>
                                        </CardBody>
                                    </Card>
                                    <ConfirmBox isOpen={modal} message={`Editing the warehouse location will delete all the associated buildings. Are you sure you want to proceed with edit?`}
                                        onClose={confirmToggle} onConfirm={() => onConfirm(resetForm)} text="Edit" title="Edit Warehouse Location" />
                                </Form>
                            )}
                        </Formik>
                    </Col>
                    {/* End warehouse location section */}
                    {/* Start building section */}
                    <Col lg={6}>
                        {
                            showBuilding ? <AddBuildings unitOfMeasures={unitOfMeasures} />
                                : <Card>
                                    <CardBody>
                                        <div className="d-flex mb-4">
                                            <CardTitle tag="h5"> Building</CardTitle>
                                        </div>
                                        <h6> Add location information to be able to add building.</h6>
                                    </CardBody>
                                </Card>
                        }
                    </Col>
                    {/* End building section */}
                </Row>

                {/* Start Building Listing */}
                <BuildingList />
                {/* End Buiding Listing */}
                <ToastContainer
                    position={'top-right'}
                    draggable={false}
                    hideProgressBar={true}
                />
            </Container>
        </>
    )
}

export default WarehouseManagement
