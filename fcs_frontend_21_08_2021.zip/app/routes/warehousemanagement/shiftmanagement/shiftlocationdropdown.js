import {
    DropdownToggle,
    DropdownMenu, DropdownItem, UncontrolledButtonDropdown
} from '../../../components';
import React, { useState, useEffect } from 'react';

import { useSelector } from 'react-redux';
import { getWarehouseLocationList } from '../../../services/warehousemanagementservice';


let company_id = 0;
const ShiftLocationDropdown = () => {
    let warehouse_location_id = 0;
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [locationList, setLocationList] = useState([])
    const [locationType, setLocationType] = useState('Select Location')
    const [locationTypeId, setLocationTypeId] = useState(0)
    const [skeleton, setSkeleton] = useState(false)

    
    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            loadLocationList(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
        }
        else {
            loadLocationList(CompanyListingStatus?.result?.response?.result[0].company_id)
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])
    //================ This function is used to load location list =============================
    const loadLocationList = async (company_id) => {
        const result = await getWarehouseLocationList(`?company_id=${company_id}`);
        setSkeleton(true)
        setLocationList(result.data)
        setLocationTypeId(result.data[0].warehouse_location_id);
        warehouse_location_id = result.data[0].warehouse_location_id;
        setLocationType(result.data[0].location_name)
    }


    const _handleOnClick = (e) => {
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setLocationType(str)
        }
        else {
            setLocationType(e[1].name)
        }

        setLocationTypeId(e[0].id)
        warehouse_location_id = e[0].id;
    }
    return (
        <>
            <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }}>
                <DropdownToggle caret color="secondary" outline type="select" className="warehouse-location-drp-width">
                    {locationType}
                </DropdownToggle>
                <DropdownMenu persist >
                    {locationList && locationList.length > 0 ? (locationList.map((item, index) => (
                        <DropdownItem onClick={() => { _handleOnClick([{ id: item.warehouse_location_id }, { name: item.location_name }]) }}>{item.location_name}</DropdownItem>
                        ))) : (
                                ''
                    )}
                </DropdownMenu>
            </UncontrolledButtonDropdown>
        </>
    )
}
export default ShiftLocationDropdown;
