import React, { useEffect, useRef, useState } from 'react'

import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    RequiredRule,
    Lookup,
} from 'devextreme-react/data-grid';
import {
    SelectBox,
    DateBox,
    Switch
} from 'devextreme-react';

import {
    Card, CardBody, Container, ButtonGroup, Button, Row, Col,
    DropdownToggle,
    DropdownMenu, DropdownItem, UncontrolledButtonDropdown,
    Navbar,
} from '../../../components';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import '../../../styles/common.scss';
import CustomStore from 'devextreme/data/custom_store';
import { Configuration } from '../../commoncomponents/configurationfile';
import { getShiftsByLocation, addShift, deleteShift, updateShift, setCompanyDefaultShift } from '../../../services/shiftmanagementservice';
import AlertMessage from '../../commoncomponents/alertmessage';
import ConfirmBox from '../../commoncomponents/confirmbox';
import { getWarehouseLocationList } from '../../../services/warehousemanagementservice';
import ShiftSkeleton from '../skeleton/shiftskeleton';
import { set } from 'lodash';

let company_id = 0;

// dont't know how to set companyId and warehouse locationId
let warehouse_location_id = 0;

let shiftDayList = [
    {
        "id": 0,
        "day": "Same Day"
    },
    {
        "id": 1,
        "day": "Next Day"
    }
]
const ShiftMasterComponent = (props) => {

    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [locationType, setLocationType] = useState('Select Location');
    const [locationList, setLocationList] = useState([]);
    const datagridRef = useRef(null);
    const [delmodal, setDelmodal] = useState(false);
    const [delShiftId, SetShiftId] = useState(0);

    const [startTimeValue, setStartTimeValue] = useState(0);
    const [endTimeValue, setEndTimeValue] = useState(0);

    //const [startTime, setStartTime] = useState('');
    const [rowEditing, setRowEditing] = useState(false);
    const [rowAdding, setRowAdding] = useState(false);
    const [isNextDay, setisNextDay] = useState(0);
    const [skeleton, setSkeleton] = useState(false);
    let isNextDayVal = 0;

    toast.configure();

    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            //set current company
            company_id = CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id

            LocationList(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
        }
        else {
            //set current company
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id

            LocationList(CompanyListingStatus?.result?.response?.result[0].company_id)
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    //================ This function is used to load location list =============================
    const LocationList = async (companyId) => {
        const result = await getWarehouseLocationList(`?company_id=${companyId}`);
        setSkeleton(true)
        setLocationList(result.data)
        warehouse_location_id = result.data[0].warehouse_location_id;
        setLocationType(result.data[0].location_name)
    }

    const _handleOnClick = (e) => {
        console.log('E', e)
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setLocationType(str)
        }
        else {
            setLocationType(e[1].name)
        }

        warehouse_location_id = e[0].id;
    }

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }

    /* get all shifts data for given comapny and warehouse location */
    const shiftmaster_data = new CustomStore({
        key: 'shift_master_id',
        load: async function (loadOptions) {
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                    params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                }
            });

            params += `company_id=${company_id}&`
            //console.log("warehouse_location_id........"+warehouse_location_id);
            params += `warehouse_location_id=${warehouse_location_id}`
            //params = params.slice(0, -1);
            let response = await getShiftsByLocation(params);
            //datagridRef.current.instance.cancelEditData()

            return response;

        }

    });

    const _SingleRow = async () => {
        datagridRef.current.instance.addRow()
    }

    const maxLength = { maxLength: 20 };

    const timeFormat = { type: 'time' };

    const validateTime = (startTime, endTime, isNextDayVal) => {
        let start_hours = parseInt(startTime.split(':')[0]);
        let start_minutes = parseInt(startTime.split(':')[1]);
        let end_hours = parseInt(endTime.split(':')[0]);
        let end_minutes = parseInt(endTime.split(':')[1]);
        let is_valid_shift = false;
        if (isNextDay === 0) {
            if (start_hours > end_hours) {
                is_valid_shift = false;
            } else if (start_hours === end_hours && start_minutes > end_minutes) {
                is_valid_shift = false;
            } else {
                is_valid_shift = true
            }
        }
        else {
            is_valid_shift = true;
        }
        return is_valid_shift;
    }

    const editStartTimeRender = (cell) => {
        return <DateBox
            width={150}
            type="time"
            value={startTimeValue}
            displayFormat="HH:mm:ss"
            onValueChanged={(t) => {
                // if (t !== '00:00:00') {
                console.log("t->", t.value);
                // var timeVal = t.value;
                // var t_h = t.getHours() < 10 ? "0" + t.getHours() : t.getHours();
                // var t_m = t.getMinutes() < 10 ? "0" + t.getMinutes() : t.getMinutes();
                // let s_t = t_h + ":" + t_m + ":00";
                cell.setValue(t.event.target.innerHTML);
                setStartTimeValue(t.event.target.innerHTML);
            }}
        />
    }

    const editEndTimeRender = (cell) => {

        let end_time = cell.value;
        let is_next_day = cell.data.is_next_day;
        //beacuse at the time of inserting new record, we don't have 'is_next_day', so we use this variable
        let is_next_day_default = null;
        if (is_next_day) {
            is_next_day_default = is_next_day;
        }
        else {
            is_next_day_default = 0;
        }


        return <div style={{ display: "flex" }}>
            <SelectBox
                style={{ marginRight: '10px' }}
                width={120}
                //defaultValue={shiftDayList[is_next_day_default].id}
                value={isNextDay}
                items={shiftDayList}
                valueExpr="id"
                displayExpr="day"
                onValueChanged={(e) => {
                    console.log('e.value:-', e.value)
                    console.log('isnextday:-', isNextDay)
                    setisNextDay(e.value);
                }}

            />

            <DateBox
                width={120}
                type="time"
                value={endTimeValue}
                displayFormat="HH:mm:ss"
                onValueChanged={(t) => {
                    cell.setValue(t.event.target.innerHTML)
                    setEndTimeValue(t.event.target.innerHTML)
                }
                }
            />
        </div>
    }

    const endTimeRender = (cell) => {

        //access value of 'is_next_day'
        let is_next_day = cell.data.is_next_day;

        if (is_next_day) {
            return <span>Next Day - {cell.value}</span>
        }
        else {
            return <span>Same Day - {cell.value}</span>
        }
    }

    const defaultOptionRender = (cell) => {
        let is_default = cell.value;
        let shift_master_id = cell.data.shift_master_id
        return <Switch
            defaultValue={is_default === 1}
            onValueChanged={(e) => {
                if (e.value) {
                    onDefaultShiftChanged(shift_master_id);
                }

            }}
        />
    }

    const onDefaultShiftChanged = async (shift_id) => {
        let data = {
            "shift_master_id": shift_id,
            "company_id": company_id,
            "warehouse_location_id": warehouse_location_id
        }

        let result = await setCompanyDefaultShift(data);
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success'
                message={result.data['message']} />, { autoClose: 4000 });
        }
        else {
            toast.error(<AlertMessage type='error'
                message={result.data['message']} />, { autoClose: false });
        }
        datagridRef.current.instance.refresh();

    }
    //====================== This function is used to save update data ======================
    const onSaving = (e) => {
        console.log('e', e)
        console.log('nEXT DAY', isNextDay);
        SaveBin(e.changes, e.component);
        e.cancel = true;
    }
    const SaveBin = async (body, component) => {
        try {

            let data = body[0]
            if (body[0].type === 'insert') {

                let end_time = data.data.end_time;
                let start_time = data.data.start_time;
                console.log('ISNEXTDAY', isNextDay)
                if (validateTime(start_time, end_time, isNextDayVal)) {
                    let shift_data = {
                        "shift_name": data.data.shift_name,
                        "start_time": start_time,
                        "end_time": end_time,
                        // "start_time": start_time.getHours() + ":" + start_time.getMinutes() + ":" + start_time.getSeconds(),
                        // "end_time": end_time.getHours() + ":" + end_time.getMinutes() + ":" + end_time.getSeconds(),
                        // user cannot set 'is_default' while inserting shift
                        "is_default": 0,
                        "is_next_day": isNextDay,
                        "company_id": company_id,
                        "warehouse_location_id": warehouse_location_id

                    }
                    //console.log(shift_data.company_id+" "+shift_data.warehouse_location_id);
                    const result = await addShift(shift_data);
                    if (result.data['status'] === true) {
                        toast.success(<AlertMessage type='success' title={`Save ${shift_data.shift_name}`}
                            message={result.data['message']} />, { autoClose: 4000 });
                    }
                    else {
                        toast.error(<AlertMessage type='error' title={`Save ${shift_data.shift_name}`}
                            message={result.data['message']} />, { autoClose: false });
                    }
                    await component.refresh(true);
                    component.cancelEditData();
                    return result;
                } else {
                    toast.error(<AlertMessage type='error' title={`Add Shift Failed`}
                        message={'Your shift start time is greater than end time'} />, { autoClose: false });
                    return false;
                }
            }
            else if (body[0].type === 'update') {
                //debugger;
                let primary_key = body[0].key
                let body_data = body[0].data
                let start_time = body_data?.start_time ? body_data.start_time : startTimeValue;
                let end_time = body_data?.end_time ? body_data.end_time : endTimeValue;
                // if (body_data.start_time) {
                //     start_time = body_data.start_time;
                //     //body_data.start_time.getHours() + ":" + body_data.start_time.getMinutes() + ":" + body_data.start_time.getSeconds();
                // }
                // if (body_data.end_time) {
                //     end_time = body_data.end_time;
                //     //body_data.end_time.getHours() + ":" + body_data.end_time.getMinutes() + ":" + body_data.end_time.getSeconds();
                // }
                // if (start_time && end_time) {
                //     validateTime(start_time, end_time, isNextDay);
                // }
                console.log(body)
                if (validateTime(start_time, end_time, isNextDay)) {
                    const result = await updateShift({
                        shift_master_id: primary_key,
                        data: body_data,
                        start_time: start_time,
                        end_time: end_time
                    });
                    if (result.data['status'] === true) {
                        toast.success(<AlertMessage type='success' title='Update Shift'
                            message={result.data['message']} />, { autoClose: 4000 });
                    }
                    else {
                        toast.error(<AlertMessage type='error' title='Update Shift'
                            message={result.data['message']} />, { autoClose: false });
                    }
                    await component.refresh(true);
                    component.cancelEditData();
                    return result;
                } else {
                    toast.error(<AlertMessage type='error' title={`Update Shift Failed`}
                        message={'Your shift start time is greater than end time'} />, { autoClose: false });
                    return false;
                }
            }

            else {
                SetShiftId(body[0].key)
                setDelmodal(true)
            }
        }
        catch (error) {
            console.log(error)
        }
    }

    //===================== This modal is used for the delete ============================
    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }
    //===================== End ===========================================================
    //========================= This funccction is used for the delete particular row ===========
    const deleteRow = async () => {

        const result = await deleteShift(`?shift_master_id=${delShiftId}`);
        setDelmodal(!delmodal)

        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title='Delete Shift'
                message={result.data['message']} />, { autoClose: 4000 });
        }
        else {
            toast.error(<AlertMessage type='error' title='Delete Shift'
                message={result.data['message']} />, { autoClose: false });
        }

    }

    useEffect(() => {
        setisNextDay(isNextDay)
        //console.log('NXT',isNextDay)
    }, [isNextDay])

    const onCellPrepared = (e) => {
        if (e.rowType == 'header' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<b>Action</b>";
        }
        if (e.rowType == 'filter' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close dx-link-delete'></i></button>";
            e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
        }
        if (e.rowType === 'data' && e.column.name === 'is_default') {
            if (rowAdding && e.data?.shift_master_id === undefined) {
                e.cellElement.innerHTML = '';
            }
            if ((rowEditing && delShiftId === e.key)) {
                e.cellElement.innerHTML = '';
            }
        } else if (e.rowType === 'filter' && e.column.name === 'is_default') {
            e.cellElement.innerHTML = '';
        }
    }
    const onEditorPreparing = (e) => {
        if (e.parentType === "dataRow" && e.dataField === "shift_name") {
            e.editorOptions.onKeyPress = function (args) {
                var event = args.event;
                if (!/^[a-zA-Z ]*$/.test(String.fromCharCode(event.keyCode)))
                    event.preventDefault();
            }
        }
    }
    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div style={{ justifyContent: 'flex-start', display: 'inline-flex' }}>
                    <h4>Shifts</h4>
                </div>
            </Navbar>
            {(skeleton === false) ?
                (
                    <ShiftSkeleton />

                ) : (
                    <>
                        <Container className="margin-top">
                            You can create new shifts here.
                <Row className="margin-top">
                                <Col lg={4}>
                                    Warehouse Location &nbsp;
                        <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }}>
                                        <DropdownToggle caret color="secondary" outline type="select" className="warehouse-location-drp-width">
                                            {locationType}
                                        </DropdownToggle>
                                        <DropdownMenu persist >
                                            {locationList && locationList.length > 0 ? (locationList.map((item, index) => (
                                                <DropdownItem onClick={
                                                    () => {
                                                        _handleOnClick([{ id: item.warehouse_location_id }, { name: item.location_name }])
                                                    }}>{item.location_name}
                                                </DropdownItem>
                                            ))) : (
                                                    ''
                                                )}
                                        </DropdownMenu>
                                    </UncontrolledButtonDropdown>
                                </Col>
                                <Col lg={8}>

                                </Col>
                            </Row>
                            <Card className="mb-3" className="margin-top">
                                <CardBody>
                                    <h5>Manage shifts</h5>
                                    <Row>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col></Col>
                                        <Col className="ml-5">
                                            <div className="container-fluid margin-bottoms" >
                                                <ButtonGroup style={{ marginLeft: `36%` }}>
                                                    <Button outline onClick={() => _SingleRow()}>
                                                        <i className="fa fa-fw fa-plus"></i>
                                                    </Button>
                                                </ButtonGroup>
                                            </div>
                                        </Col>
                                    </Row>

                                    <DataGrid id="grid-container"
                                        showBorders={true}
                                        dataSource={shiftmaster_data}
                                        ref={datagridRef}
                                        keyExpr="shift_master_id"
                                        onCellPrepared={(e) => {
                                            debugger
                                            if (e.rowType === 'data' && e.column.name === 'is_default') {
                                                if (rowAdding && e.data?.shift_master_id === undefined) {
                                                    e.cellElement.innerHTML = '';
                                                }
                                                if ((rowEditing && delShiftId === e.key)) {
                                                    e.cellElement.innerHTML = '';
                                                }
                                            } else if (e.rowType === 'filter' && e.column.name === 'is_default') {
                                                e.cellElement.innerHTML = '';
                                            }
                                        }}
                                        onCellPrepared={onCellPrepared}
                                        remoteOperations={true}
                                        allowColumnReordering={true}
                                        columnHidingEnabled={true}

                                        onSaving={onSaving}
                                        rowAlternationEnabled={true}
                                        columnHidingEnabled={true}

                                        onToolbarPreparing={(e) => {
                                            e.toolbarOptions.visible = false
                                        }}
                                        onEditingStart={(e) => {
                                            setStartTimeValue(e.data.start_time);
                                            setEndTimeValue(e.data.end_time);
                                            setisNextDay(e.data.is_next_day);
                                            SetShiftId(e.key);
                                            setRowEditing(true);
                                            console.log("editing start", e)
                                        }}
                                        onInitNewRow={(e) => {
                                            var current_date = new Date();
                                            let current_time = current_date.getHours() + ":" + current_date.getMinutes() + ":00";
                                            var curr_time = current_date.getTime();
                                            setStartTimeValue(curr_time)
                                            setEndTimeValue(curr_time)
                                            SetShiftId(0);
                                            setRowAdding(true);
                                        }}
                                        onEditCanceling={(e) => {
                                            setRowAdding(false);
                                            setRowEditing(false);
                                        }}
                                    //onEditorPreparing={onEditorPreparing}
                                    >
                                        <Editing
                                            mode="row"
                                            useIcons={true}
                                            allowAdding={true}
                                            allowUpdating={true}
                                            allowDeleting={true}
                                            confirmDelete={false}
                                            onKeyDown={false}
                                        >
                                        </Editing>

                                        <Paging defaultPageSize={10} />

                                        <Pager
                                            showPageSizeSelector={true}
                                            allowedPageSizes={[5, 10, 15]}
                                            showInfo={true} />
                                        <FilterRow visible={true} />

                                        <Column dataField="shift_name" caption="Name" editorOptions={maxLength}>
                                            <RequiredRule />
                                        </Column>
                                        <Column dataField="start_time"
                                            editCellRender={editStartTimeRender}
                                            allowFiltering={false}
                                            allowSorting={false}
                                        >
                                            <RequiredRule />
                                        </Column>

                                        <Column dataField="end_time" caption='End Time'
                                            editCellRender={editEndTimeRender}
                                            cellRender={endTimeRender}
                                            allowFiltering={false}
                                            allowSorting={false}
                                        >
                                            <RequiredRule />
                                        </Column>

                                        <Column
                                            alignment="center"
                                            dataField="is_default"
                                            caption="Default"
                                            allowEditing={false}
                                            cellRender={defaultOptionRender}
                                            allowFiltering={false}
                                            allowSorting={false}
                                        >

                                        </Column>

                                    </DataGrid>
                                    <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this shift`}
                                        onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete Shift" />
                                </CardBody>
                            </Card>
                        </Container>
                    </>
                )}
        </>
    )

}

export default ShiftMasterComponent
