import SelectBox from 'devextreme-react/select-box';
import React, { useState,useEffect } from 'react';
import {getShiftsByLocation} from '../../../services/shiftmanagementservice';


const ShiftDropdown=()=>{

    // these values should be set from redux store
    let company_id=0,warehouse_location_id=0;

    const [shiftList,setShiftList]=useState([]);
    const [shiftValue,changeShift]=useState(shiftList[0]);

    // write code for getting shifts by 'company_id' and 'warehouse_location_id'
    const loadShiftList = async (company_id,warehouse_location_id) => {
    
        const result = await getShiftsByLocation(
            `?company_id=${company_id}&warehouse_location_id=${warehouse_location_id}`);
        setShiftList(result.data)
        
    }

    // load Shifts
    useEffect(() => {
        loadShiftList(company_id,warehouse_location_id);
    })

    const onShiftChange=(e)=>{

        changeShift(e.value)
    }

    return(
            <SelectBox
                items={shiftList}
                value={shiftValue}
                placeholder="Choose Shift"
                onValueChanged={onShiftChange}
            >
            </SelectBox>
        )
}       

export default ShiftDropdown;