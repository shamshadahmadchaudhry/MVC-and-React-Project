import React, { useEffect, useRef, useState } from 'react'

import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    RequiredRule,
    Lookup,
} from 'devextreme-react/data-grid';
import {
    SelectBox,
    DateBox,
    Switch
} from 'devextreme-react';

import {
    Card, CardBody, Container, ButtonGroup, Button, Row, Col,
    DropdownToggle,
    DropdownMenu, DropdownItem, UncontrolledButtonDropdown,
    Navbar
} from '../../../components';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import '../../../styles/common.scss';
import CustomStore from 'devextreme/data/custom_store';
import { Configuration } from '../../commoncomponents/configurationfile';
import { getAllUserShifts, updateUserShift } from '../../../services/employeeshiftservice';
import AlertMessage from '../../commoncomponents/alertmessage';
import ConfirmBox from '../../commoncomponents/confirmbox';
import { getWarehouseLocationList } from '../../../services/warehousemanagementservice';
import { getShiftsByLocation } from '../../../services/shiftmanagementservice';
import { useHistory } from 'react-router-dom';
import EmployeeShiftSkeleton from '../skeleton/employeeshiftskeleton';
let company_id = 0;

let warehouse_location_id = 0;

const EmployeeShiftComponent = (props) => {
    let history = useHistory();
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [locationType, setLocationType] = useState('Select Location')
    const [locationList, setLocationList] = useState([])
    const datagridRef = useRef(null);
    const [allShifts, setAllShifts] = useState([])
    const [skeleton, setSkeleton] = useState(false);

    toast.configure();

    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            //set current company
            company_id = CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id
            LocationList(company_id)
        }
        else {
            //set current company
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id
            LocationList(company_id)
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    //================ This function is used to load location list =============================
    const LocationList = async (companyId) => {
        const result = await getWarehouseLocationList(`?company_id=${companyId}`);
        setSkeleton(true)
        setLocationList(result.data)
        warehouse_location_id = result.data[0].warehouse_location_id;
        setLocationType(result.data[0].location_name);
        shiftList(companyId, warehouse_location_id);

    }

    //=============== This function is to load all shifts with respect to company and warehouse location========
    const shiftList = async (companyId, warehouseLocationId) => {
        let result = await getShiftsByLocation(`?skip=0&take=10&company_id=${companyId}&warehouse_location_id=${warehouseLocationId}`);
        setAllShifts(result.data);

    }

    const _handleOnClick = (e) => {
        console.log('ee', e)
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setLocationType(str)
        }
        else {
            setLocationType(e[1].name)
        }
        warehouse_location_id = e[0].id;
        shiftList(company_id, warehouse_location_id);
    }

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }
    /* get all user shifts data for given comapny and warehouse location */
    const usershift_data = new CustomStore({
        key: 'user_shift_mapping_id',
        load: async function (loadOptions) {
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                    params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                }
            });
            params += `company_id=${company_id}&`
            //console.log("warehouse_location_id........"+warehouse_location_id);
            params += `warehouse_location_id=${warehouse_location_id}`
            //params = params.slice(0, -1);
            let response = await getAllUserShifts(params);
            console.log("employee shifts", response);
            return response;

        }

    });



    //====================== This function is used to save update data ======================
    const onSaving = React.useCallback((e) => {
        e.cancel = true;
        SaveBin(e.changes, e.component);

    }, []);

    const SaveBin = async (body, component) => {
        try {

            let data = body[0]

            if (body[0].type === 'update') {

                if ("shift_master_id" in data.data) {
                    let selectedShiftId = data.data.shift_master_id;
                    //get key of record that is going to be updated
                    let userShiftMappingId = data.key;
                    let shift_data = {
                        "user_shift_mapping_id": userShiftMappingId,
                        "shift_id": selectedShiftId,

                    }

                    const result = await updateUserShift(shift_data);
                    if (result.data['status'] === true) {
                        toast.success(<AlertMessage type='success' title='Update Shift'
                            message={result.data['message']} />, { autoClose: 4000 });
                    }
                    else {
                        toast.error(<AlertMessage type='error' title='Update Shift'
                            message={result.data['message']} />, { autoClose: false });
                    }
                    await component.refresh(true);
                    component.cancelEditData();
                    return result;

                }

            }

        }
        catch (error) {
            console.log(error)
        }
    }


    const buildingLocationRender = (cell) => {

        let building_list = cell.value;

        let displayBuildings = '';
        building_list.forEach(element => {
            displayBuildings += element + " ";
        });
        return displayBuildings;

    }

    //=========This code is used for set the action header in the list start===========
    const onCellPrepared = (e) => {
        if (e.rowType == 'header' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<b>Action</b>";
        }
        if (e.rowType == 'filter' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close dx-link-delete'></i></button>";
            e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
        }
    }

    const _handleOnClickTrip = () => {
        history.push('/operations/shifts')
    }
    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div>
                    <UncontrolledButtonDropdown>
                        <DropdownToggle color="link" className="pl-0 pb-0 btn-profile sidebar__link" >
                            <h4>Employee Shifts</h4>
                        </DropdownToggle>
                    </UncontrolledButtonDropdown>
                </div>
            </Navbar>
            {(skeleton === false) ?
                (
                    <EmployeeShiftSkeleton />

                ) : (
                    <>
                        <div className="container-fluid mt-0 mb-5">
                            <Container>
                                <Row>
                                    <Col lg={8} className="mt-3 mb-1">
                                        <p>You can assign shift to employees here</p>
                                    </Col>
                                </Row>

                                <Row className="mb-4">

                                    <Col>
                                        <div className='form-inline'>
                                            <span className="margin-right">Warehouse Location</span>

                                            <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }}>
                                                <DropdownToggle caret color="secondary" outline type="select" className="warehouse-location-drp-width">
                                                    {locationType}
                                                </DropdownToggle>
                                                <DropdownMenu persist >
                                                    {locationList && locationList.length > 0 ? (locationList.map((item, index) => (
                                                        <DropdownItem onClick={() => { _handleOnClick([{ id: item.warehouse_location_id }, { name: item.location_name }]) }}>{item.location_name}</DropdownItem>
                                                    ))) : (
                                                            ''
                                                        )}
                                                </DropdownMenu>
                                            </UncontrolledButtonDropdown>
                                        </div>
                                    </Col>
                                </Row>
                                <Card className="mb-3" className="margin-list">
                                    <CardBody>
                                        <h5 className='ml-3'>Manage Employee shifts</h5>
                                        <Row>
                                            <Col className='ml-5'>
                                                <div className="container-fluid margin-bottoms" >
                                                    <ButtonGroup className="float-right margin-bottoms" >
                                                        <Button outline className='ml-2' onClick={() => { _handleOnClickTrip() }} >
                                                            <i class="fa fa-cog" aria-hidden="true"></i>
                                                        </Button>
                                                    </ButtonGroup>
                                                </div>
                                            </Col>
                                        </Row>
                                        <div className="container-fluid">
                                            <DataGrid id="grid-container"
                                                showBorders={true}
                                                dataSource={usershift_data}
                                                ref={datagridRef}
                                                onCellPrepared={onCellPrepared}
                                                keyExpr="user_shift_mapping_id"
                                                remoteOperations={true}
                                                allowColumnReordering={true}
                                                columnHidingEnabled={true}
                                                onSaving={onSaving}
                                                rowAlternationEnabled={true}
                                                columnHidingEnabled={true}
                                                onKeyDown={(e) => {
                                                    var $event = e.jQueryEvent;
                                                    if ($event.ctrlKey && $event.keyCode === 13) {
                                                        $event.preventDefault();
                                                    }

                                                }}
                                                onToolbarPreparing={(e) => {
                                                    e.toolbarOptions.visible = false
                                                }}
                                            >
                                                <Editing
                                                    mode="row"
                                                    useIcons={true}
                                                    allowUpdating={true}
                                                    onKeyDown={false}
                                                >
                                                </Editing>

                                                <Paging defaultPageSize={10} enabled={true} />

                                                <Pager
                                                    showPageSizeSelector={true}
                                                    allowedPageSizes={[10, 15, 20]}
                                                    showInfo={true}
                                                    showNavigationButtons={true}
                                                />
                                                <FilterRow visible={true} />

                                                <Column dataField="user" caption="Employee full name" allowEditing={false}>
                                                </Column>

                                                <Column dataField="location_list"
                                                    caption="Building" cellRender={buildingLocationRender}
                                                    allowEditing={false} >
                                                </Column>


                                                <Column dataField="shift_master_id" caption="Shift">
                                                    <Lookup dataSource={allShifts} displayExpr="shift_name" valueExpr="shift_master_id" />
                                                </Column>
                                            </DataGrid>
                                        </div>
                                    </CardBody>
                                </Card>
                            </Container>
                        </div>
                    </>
                )
            }
        </>
    )

}

export default EmployeeShiftComponent;
