import React, { useState, useRef, useEffect } from 'react';
import { useSelector } from 'react-redux'
import { Configuration } from '../../commoncomponents/configurationfile';
import {
    Navbar,
    FormGroup,
    Container,
    Row, Col,
} from '../../../components';
import {
    getWarehouseLocationList,
    getBuildingDetailsList,
} from '../../../services/warehousemanagementservice';

import { getLayoutTypes } from '../../../services/layoutservices'

import {
    DropdownToggle,
    DropdownMenu, DropdownItem, UncontrolledButtonDropdown
} from '../../../components'
import Aisle from '../aisle/aisle'
import Zone from '../zone/zone'
import '../../../styles/common.scss';
import LayoutsSketeon from '../skeleton/layoutsskeleton';
import { useLocation } from 'react-router-dom';
const Layouts = () => {
    const location = useLocation()
    const [entityType, setEntityType] = useState([])
    const [layoutType, setLayoutType] = useState('Aisle')
    const [layoutTypeId, setLayoutTypeId] = useState(1)
    const [LayoutId, setLayoutId] = useState(0)
    const [companyId, setCompanyId] = useState(0)
    const [locations, setLocations] = useState([])
    const [buildings, setBuildings] = useState([])
    const [activelocationId, setActivelocationId] = useState(0)
    const [activeaddressId, setActiveaddressId] = useState(0)
    const [skeleton, setSkeleton] = useState(false)
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [locationType, setLocationType] = useState('Select Location')
    const [addressType, setAddressType] = useState('Select Address')
    const [isselect, setIsSelect] = useState(false)
    let editmode = 'row';

    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            WarehouseLocations(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
            setCompanyId(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
        }
        else {
            WarehouseLocations(CompanyListingStatus?.result?.response?.result[0].company_id)
            setCompanyId(CompanyListingStatus?.result?.response?.result[0].company_id)
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    //Load buildings
    const loadBuildings = async (locationId) => {
        let params = `?warehouse_location_id=${locationId}`
        let buildingResp = await getBuildingDetailsList(params)
        console.log('buildingResp', buildingResp)
        setSkeleton(true)
        setBuildings(buildingResp.data)
        if (location.state != null && isselect === false) {
            setAddressType(location.state.warehouse_address_name)
            setActiveaddressId(location.state.warehouse_address_id)
        } else {
            setAddressType(buildingResp.data[0].building_alias)
            setActiveaddressId(buildingResp.data[0].warehouse_address_id)
        }
    }
    //Load warehouse locations
    const WarehouseLocations = async (company_id) => {
        let params = `?company_id=${company_id}`
        let response = await getWarehouseLocationList(params)
        console.log('response.............', response)
        if (location.state != null) {
            setLocationType(location.state.warehouse_location_name)
            loadBuildings(location.state.warehouse_location_id)
            setActivelocationId(location.state.warehouse_location_id)
        } else {
            loadBuildings(response.data[0].warehouse_location_id)
            setLocationType(response.data[0].location_name)
            setActivelocationId(response.data[0].warehouse_location_id)
        }
        setLocations(response.data)
        return response.data
    }

    useEffect(() => {
        setIsSelect(true)
        setAddressType('')
    }, [activelocationId])
    const _handleOnClick = (e) => {
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setLocationType(str)
        }
        else {
            setLocationType(e[1].name)
        }
        setActivelocationId(e[0].id)
        loadBuildings(e[0].id);
    }
    const _handlebuildingOnClick = (e) => {
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setAddressType(str)
        }
        else {
            setAddressType(e[1].name)
        }
        setActiveaddressId(e[0].id);
    }
    useEffect(() => {
        loadentityType()
    }, []);

    const loadentityType = async () => {
        const result = await getLayoutTypes();
        setEntityType(result)
        if (location.state != null) {
            setLayoutType(location.state.layout_name)
            setLayoutTypeId(location.state.layout_id);
            console.log('location.state.warehouse_location_id', location.state.warehouse_location_id)
            console.log('location.state.warehouse_address_id', location.state.warehouse_address_id)
            setActivelocationId(location.state.warehouse_location_id);
            setActiveaddressId(location.state.warehouse_address_id);

        } else {
            setLayoutType(result[0].entity_type_name)
        }
    }
    console.log('Active location id', activelocationId)
    const _handleLayoutClick = (e) => {
        setLayoutType(e[1].name)
        setLayoutTypeId(e[0].id)
    }
    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div style={{ justifyContent: 'flex-start', display: 'inline-flex' }}>

                    <UncontrolledButtonDropdown>
                        <DropdownToggle color="link" className="btn-profile sidebar__link">
                            <h4>Layout - {layoutType}<i className="fa fa-angle-down ml-2"></i></h4>
                        </DropdownToggle>
                        <DropdownMenu persist >
                            {entityType && entityType.length > 0 ? (entityType.map((item, index) => (
                                <DropdownItem key={index} onClick={() => { _handleLayoutClick([{ id: item.entity_type_id }, { name: item.entity_type_name }]) }}>
                                    {item.entity_type_name}
                                </DropdownItem>
                            ))) : (
                                    ''
                                )}
                        </DropdownMenu>
                    </UncontrolledButtonDropdown>
                </div>
            </Navbar>
            <div>
                {(skeleton === false) ?
                    (
                        <LayoutsSketeon />
                    ) : (
                        <>
                            <Container>
                                <Container className="mb-5">
                                    <Row>
                                        <Col lg={12} className="warehouse-margin mt-3 mb-1">
                                            <p>Select warehouse location and building to manage stations within them</p>
                                        </Col>
                                    </Row>
                                    <Row className='mb-3'>
                                        <Col lg={4} className='mb-2'>
                                            <FormGroup>
                                                <label>Warehouse location</label>
                                                <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }} >
                                                    <DropdownToggle caret color="secondary" outline type="select" className='form-control ml-3 warehouse-location-drp-width'>
                                                        {locationType}
                                                    </DropdownToggle>
                                                    <DropdownMenu persist >
                                                        {locations && locations.length > 0 ? (locations.map((item, index) => (
                                                            <DropdownItem onClick={() => { _handleOnClick([{ id: item.warehouse_location_id }, { name: item.location_name }]) }}>{item.location_name}</DropdownItem>
                                                        ))) : (
                                                                ''
                                                            )}
                                                    </DropdownMenu>
                                                </UncontrolledButtonDropdown>
                                            </FormGroup>
                                        </Col>
                                        <Col lg={6}>
                                            <FormGroup className='bg-light'>
                                                <label>Building</label>
                                                <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }}>
                                                    <DropdownToggle caret color="secondary" outline type="select" className='form-control ml-3 warehouse-location-drp-width'>
                                                        {addressType}
                                                    </DropdownToggle>
                                                    <DropdownMenu persist >
                                                        {buildings && buildings.length > 0 ? (buildings.map((item, index) => (
                                                            <DropdownItem onClick={() => { _handlebuildingOnClick([{ id: item.warehouse_address_id }, { name: item.building_alias }]) }}>{item.building_alias}</DropdownItem>
                                                        ))) : (
                                                                ''
                                                            )}
                                                    </DropdownMenu>
                                                </UncontrolledButtonDropdown>
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    {
                                        layoutTypeId === Configuration.entityType.aisle
                                            ? <Aisle locationId={activelocationId} addressId={activeaddressId} companyId={companyId}
                                                warehouse_location_name={locationType} warehouse_address_name={addressType} /> :
                                            layoutTypeId === Configuration.entityType.zone
                                                ? <Zone locationId={activelocationId} addressId={activeaddressId} companyId={companyId}
                                                    warehouse_location_name={locationType} warehouse_address_name={addressType} /> : ''

                                    }
                                </Container>
                            </Container>
                        </>
                    )}
            </div>

        </>

    )
}


export default Layouts;
