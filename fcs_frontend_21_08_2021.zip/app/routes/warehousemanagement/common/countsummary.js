import React, { useState, useRef, useEffect } from 'react';
import { useSelector } from 'react-redux'
import { Configuration } from '../../commoncomponents/configurationfile';
import {
    Card, CardBody, Container, ButtonGroup, Button, DropdownToggle,
    UncontrolledButtonDropdown, DropdownMenu, DropdownItem, Row, Col,
    Navbar, ThemeConsumer, Nav, CardTitle
} from '../../../components';
import ContainerPreview from '../preview/containerpreview/containerpreview';
const CountSummary = (props) => {
    const [countsummarytype, setCountSummaryType] = useState(0)
    const [previewType, setPreviewType] = useState(0)
    const _handleRecords = (recordsType) => {
        setCountSummaryType(recordsType);
        setPreviewType(props.PreviewType)
        // datagridRef.current.instance.refresh();
    }
    return (
        <>
            <Row className="margin-top">
                <Col lg={3}>
                    <Card className="mb-3">
                        <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.ValidateRecords) }}>
                            <CardBody>
                                <CardTitle tag="h6" className="mb-4"> Validated Records </CardTitle>
                                <div className="mb-3">
                                    <h5>{props.valid_count}</h5>
                                </div>
                            </CardBody>
                        </a>
                    </Card>
                </Col>
                <Col lg={3}>
                    <Card className="mb-3">
                        <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.ErrorRecords) }}>
                            <CardBody>
                                <CardTitle tag="h6" className="mb-4"> Error Records </CardTitle>
                                <div className="mb-3">
                                    <h5>{props.invalid_count}</h5>
                                </div>
                            </CardBody>
                        </a>
                    </Card>
                </Col>
                <Col lg={3}>
                    <Card className="mb-3">

                        <CardBody>
                            <CardTitle tag="h6" className="mb-4"> Excluded Records </CardTitle>
                            <div className="mb-3">
                                <h5>0</h5>
                            </div>
                        </CardBody>

                    </Card>
                </Col>
                <Col lg={3}>
                    <Card className="mb-3">
                        <a className="cursor-pointers" onClick={() => { _handleRecords(Configuration.TotalRecords) }}>
                            <CardBody>
                                <CardTitle tag="h6" className="mb-4"> Total Records </CardTitle>
                                <div className="mb-3">
                                    <h5>{props.valid_count + props.invalid_count}</h5>
                                </div>
                            </CardBody>
                        </a>
                    </Card>
                </Col>
            </Row>
            {
                previewType == Configuration.ContainerPreview
                    ? <ContainerPreview countsummarytype={countsummarytype}></ContainerPreview>
                    : ''
            }
        </>
    )
}
export default CountSummary;