import React, { useState, useEffect } from 'react';
import {
    DropdownToggle, Button,
    UncontrolledButtonDropdown, DropdownMenu,
    DropdownItem, UncontrolledPopover,
    PopoverHeader, PopoverBody
} from '../../../components';
import { getImportSheet, UploadLayoutSheet, upload } from '../../../services/importservice';
import '../../../styles/common.scss';
import ProgressBarBox from '../../commoncomponents/progressbarbox';
import { Link, useHistory, useLocation } from 'react-router-dom';
import { Configuration } from '../../commoncomponents/configurationfile';
import { useSelector } from 'react-redux';
let container_type = 0;
let container_name = '';
let warehouse_location_id = 0;
let warehouse_address_id = 0;
let companyId = 0;
const LayoutImportDropdown = (props) => {
    console.log('props...........', props)
    let history = useHistory();
    const location = useLocation()
    container_type = props.containertype;
    container_name = props.containername;
    warehouse_location_id = props.warehouse_location_id
    warehouse_address_id = props.warehouse_address_id ? props.warehouse_address_id : 0;
    const [modal, setmodal] = useState(false);
    const [filename, setFileName] = useState('')
    const [progress, setProgress] = useState(0);
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            companyId = CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id
        }
        else {
            companyId = CompanyListingStatus?.result?.response?.result[0].company_id
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    const binDropdownData = [{ id: 1, name: "Download Template." }]
    const _handledropdownItem = async () => {
        let fileName = '';
        switch (container_type) {
            case Configuration.entityType.zone:
                fileName = 'layout-zone.xlsx'
                break;
            case Configuration.entityType.aisle:
                fileName = 'layout-aisle.xlsx'
                break;
            case Configuration.entityType.station:
                fileName = 'station.xlsx'
                break;
            case Configuration.entityType.location:
                fileName = 'location_storage_unit.xlsx'
                break;
            default:
                fileName = 'report.xlsx';
                break;
        }
        const result = await getImportSheet(container_type, companyId, warehouse_location_id, warehouse_address_id);
        console.log('result', result);
        const type = result.headers['content-type']
        const blob = new Blob([result.data], { type: type, encoding: 'UTF-8' })
        const link = document.createElement('a')
        link.href = window.URL.createObjectURL(blob)
        link.download = fileName
        link.click()
    }
    const toggledelModal = () => {
        setmodal(!modal);
    }
    const _handleChange = (event) => {
        setProgress(0);
        if (event.target.files && event.target.files[0]) {
            setmodal(true)
            let file = event.target.files[0];
            let form_data = new FormData();
            setFileName(file.name)
            form_data.append('filename', file.name);
            form_data.append('myfile', file);
            form_data.append('container_type', container_type);
            form_data.append('warehouse_location_id', props.warehouse_location_id);
            form_data.append('warehouse_address_id', props.warehouse_address_id);
            form_data.append('company_id', props.company_id);
            UploadLayoutSheet(form_data, (event) => {
                setProgress(Math.round((100 * event.loaded) / event.total));
            })
                .then((response) => {
                    // if (response.data['status'] == true && response.data['type'] == 'ZONE') {
                    if (response.data['status'] == true) {
                        localStorage.setItem("FileName", file.name)
                        console.log('hi shami')
                        if (container_type === Configuration.entityType.zone) {
                            history.push({
                                pathname: '/zonepreview',
                                state: {
                                    layouName: props.containername,
                                    layouId: props.containertype,
                                    warehouse_location_id: props.warehouse_location_id,
                                    warehouse_address_id: props.warehouse_address_id,
                                    warehouse_location_name: props.warehouse_location_name,
                                    warehouse_address_name: props.warehouse_address_name
                                }
                            });
                        }
                        else if (container_type === Configuration.entityType.aisle) {
                            history.push({
                                pathname: '/aislepreview',
                                state: {
                                    layouName: props.containername,
                                    layouId: props.containertype,
                                    warehouse_location_id: props.warehouse_location_id,
                                    warehouse_address_id: props.warehouse_address_id,
                                    warehouse_location_name: props.warehouse_location_name,
                                    warehouse_address_name: props.warehouse_address_name
                                }
                            });
                        }
                        else if (container_type === Configuration.entityType.location) {
                            history.push({
                                pathname: '/importlocationstorageunit',
                                state: {
                                    layouName: props.containername,
                                    layouId: props.containertype,
                                    warehouse_location_id: props.warehouse_location_id,
                                    warehouse_address_id: props.warehouse_address_id,
                                    warehouse_location_name: props.warehouse_location_name,
                                    warehouse_address_name: props.warehouse_address_name
                                }
                            });
                        }
                        else {
                            history.push({
                                pathname: '/stationpreview',
                                state: {
                                    layouName: props.containername,
                                    layouId: props.containertype,
                                    warehouse_location_id: props.warehouse_location_id,
                                    warehouse_address_id: props.warehouse_address_id,
                                    warehouse_location_name: props.warehouse_location_name,
                                    warehouse_address_name: props.warehouse_address_name
                                }
                            });
                        }
                    }
                })
                .catch((err) => {
                    setProgress(0);
                    console.log("Could not upload the file!:", err);
                });
        }
        console.log(event)
    }
    return (
        <>
            <Button outline>
                <div className="image-upload " >
                    <label htmlFor="file-input">
                        Import
                </label>
                    <input id="file-input" type="file" onChange={(e) => _handleChange(e)} accept=".xlsx,.xls" />
                </div>

            </Button>
            <UncontrolledButtonDropdown direction="down">
                <DropdownToggle color="secondary" outline caret />
                <DropdownMenu right>
                    {binDropdownData && binDropdownData.length > 0 ? (binDropdownData.map((item, index) => (
                        <DropdownItem onClick={() => _handledropdownItem(item.id)}>
                            {item.name}
                        </DropdownItem>
                    ))) : (
                            ''
                        )}
                </DropdownMenu>
            </UncontrolledButtonDropdown>
            <Button outline className='ml-2' id="UncontrolledPopoverTop">
                <i class="fa fa-info-circle" aria-hidden="true"></i>
            </Button>
            <UncontrolledPopover trigger="legacy" placement="top" target="UncontrolledPopoverTop">
                <PopoverHeader>
                    Import {container_name} <i className='fa fa-times-circle-o' aria-hidden="true"></i>
                </PopoverHeader>
                <PopoverBody>
                    <ul className="tooltip-padding">
                        <li>
                            Click Import to upload {container_name} Template.
                        </li>
                        <li>
                            Click <i class="fa fa-caret-down" aria-hidden="true"></i> to download import template.
                        </li>
                        <li>
                            maximum size for template file is 10 megabytes.
                    </li>

                    </ul>
                </PopoverBody>
            </UncontrolledPopover>
            <ProgressBarBox isOpen={modal} message={`Uploading file : ${filename}`}
                onClose={toggledelModal} title={`Import ${container_name}`} percentage={progress} />
        </>

    )

}
export default LayoutImportDropdown;