import React from 'react';
import {
    Modal,
    ModalHeader,
    ModalBody,
    ModalFooter,
    ThemeConsumer
} from '../../../components';

const Printselectsizemodal = (props) => {
    return (
        <Modal isOpen={props.isOpen} toggle={props.confirmToggle} className="modal-outline-warning modal-dialog-centered">
            <ModalHeader tag="h5">
                <span>
                    {props.title}</span>
            </ModalHeader>
            <ModalBody>
                <div style={{ marginTop: "10px" }} className="media-body">
                    <p> {props.message}</p>
                </div>
            </ModalBody>
            <ModalFooter>
                <button color="link" onClick={props.onClose} className="btn btn-default text-warning">
                    Cancel
                </button>

                <ThemeConsumer>
                    {
                        ({ color }) => (
                            <button className="btn btn-warning" onClick={props.onConfirm} color={color}>
                                {props.text}
                            </button>
                        )
                    }
                </ThemeConsumer>
            </ModalFooter>
        </Modal>
    )
}
Printselectsizemodal.defaultProps = {
    onConfirm: () => null,
    onClose: () => null
};
export default Printselectsizemodal;