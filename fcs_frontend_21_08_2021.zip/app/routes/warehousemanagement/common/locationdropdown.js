import {
    Navbar, Container, Col, DropdownToggle,
    DropdownMenu, DropdownItem, UncontrolledButtonDropdown
} from '../../../components';
import React, { useState, useEffect } from 'react';

import { useSelector } from 'react-redux';
import { getWarehouseLocationList } from '../../../services/warehousemanagementservice';
import { getEntityList } from '../../../services/binservice';

import BinList from '../bin/bin';
import BoxList from '../box/boxlist';
import CartList from '../cart/cartlist';
import PalleteList from '../pallete/pallete';
import ToteList from '../tote/totelist';
import { Configuration } from '../../commoncomponents/configurationfile';
import LocationDropdownSkeleton from '../skeleton/locationdropdownskeleton';
import { useLocation } from 'react-router-dom';
const LocationDropdown = () => {
    let warehouse_location_id = 0;
    const location = useLocation()
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [locationList, setLocationList] = useState([])
    const [locationType, setLocationType] = useState('Select Location')
    const [locationTypeId, setLocationTypeId] = useState(0)
    const [binType, setBinType] = useState('Bin');

    const [containerType, setContainerType] = useState(Configuration.entityType.bin);
    const [binTypeId, setBinTypeId] = useState(Configuration.entityType.bin)

    const [companyId, setcompanyId] = useState(0);
    const [entityType, setEntityType] = useState([])
    const [skeleton, setSkeleton] = useState(false)

    if (location.state != null) {
        useEffect(() => {
            setBinType(location.state.container_name)
            setContainerType(location.state.container_id);
        }, [])
    }
    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            LocationList(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
            setcompanyId(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id);
        }
        else {
            LocationList(CompanyListingStatus?.result?.response?.result[0].company_id)
            setcompanyId(CompanyListingStatus?.result?.response?.result[0].company_id)
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])
    //================ This function is used to load location list =============================
    const LocationList = async (company_id) => {
        const result = await getWarehouseLocationList(`?company_id=${company_id}`);
        setSkeleton(true)
        setLocationList(result.data)
        if (location.state != null) {
            setLocationTypeId(location.state.warehouse_location_id)
            warehouse_location_id = location.state.warehouse_location_id;
            setLocationType(location.state.warehouse_location_name)
        } else {
            setLocationTypeId(result.data[0].warehouse_location_id);
            warehouse_location_id = result.data[0].warehouse_location_id;
            setLocationType(result.data[0].location_name)
        }

    }
    //==================================== End ===================================================
    //==================================== This function is used to load function list ============
    useEffect(() => {
        loadentityType()
    }, []);
    const loadentityType = async () => {
        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
            setcompanyId(company_id)
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
            console.log('compid', company_id)
        }

        //let company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        const result = await getEntityList(`?company_id=${company_id}`);
        setEntityType(result.data.result)
    }
    //======================== End ==============================================
    const _handleContainerOnClick = (e) => {
        setBinType(e[1].name)
        setContainerType(e[0].id);
    }

    const _handleOnClick = (e) => {
        let str = '';
        if (e[1].name.length > 20) {
            str = e[1].name.substring(0, 25);
            setLocationType(str)
        }
        else {
            setLocationType(e[1].name)
        }

        setLocationTypeId(e[0].id)
        warehouse_location_id = e[0].id;
    }

    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow add-navbar-stylec'>
                <div style={{ justifyContent: 'flex-start', display: 'inline-flex' }}>

                    <UncontrolledButtonDropdown>
                        <DropdownToggle color="link" className="btn-profile sidebar__link">
                            <h4>Container - {binType}<i className="fa fa-angle-down ml-2"></i></h4>
                        </DropdownToggle>
                        <DropdownMenu persist >
                            {entityType && entityType.length > 0 ? (entityType.map((item, index) => (
                                <DropdownItem onClick={() => {
                                    _handleContainerOnClick([{ id: item.entity_type_id },
                                    { name: item.entity_type_name }])
                                }}

                                >
                                    {item.entity_type_name}</DropdownItem>

                            ))) : (
                                    ''
                                )}
                        </DropdownMenu>
                    </UncontrolledButtonDropdown>

                </div>
            </Navbar>
            {(skeleton === false) ?
                (
                    <LocationDropdownSkeleton />
                ) : (
                    <>
                        <Container className="margin-top">
                            <Col lg={12} >
                                <p>{`Select warehouse location to manage its ${containerType === Configuration.entityType.bin ? ' bin '
                                    : containerType === Configuration.entityType.box ? ' box '
                                        : containerType === Configuration.entityType.cart ? ' cart '
                                            : containerType === Configuration.entityType.pallete ? ' pallete '
                                                : containerType === Configuration.entityType.tote ? ' tote ' : ''} containers here.`}</p>
                                  Warehouse Location &nbsp;
                                <UncontrolledButtonDropdown style={{ marginLeft: 0 + "px" }}>
                                    <DropdownToggle caret color="secondary" outline type="select" className="warehouse-location-drp-width">
                                        {locationType}
                                    </DropdownToggle>
                                    <DropdownMenu persist >
                                        {locationList && locationList.length > 0 ? (locationList.map((item, index) => (
                                            <DropdownItem onClick={() => { _handleOnClick([{ id: item.warehouse_location_id }, { name: item.location_name }]) }}>{item.location_name}</DropdownItem>
                                        ))) : (
                                                ''
                                            )}
                                    </DropdownMenu>
                                </UncontrolledButtonDropdown>
                            </Col>

                            {containerType == Configuration.entityType.bin
                                ? <BinList locationId={locationTypeId} locationName={locationType} /> :
                                containerType == Configuration.entityType.box
                                    ? <BoxList locationId={locationTypeId} locationName={locationType} /> :
                                    containerType == Configuration.entityType.cart
                                        ? <CartList locationId={locationTypeId} locationName={locationType} /> :
                                        containerType == Configuration.entityType.pallete
                                            ? <PalleteList locationId={locationTypeId} locationName={locationType} /> :
                                            containerType == Configuration.entityType.tote
                                                ? <ToteList locationId={locationTypeId} locationName={locationType} /> : ''}
                        </Container>
                    </>
                )}
        </>
    )
}
export default LocationDropdown;
