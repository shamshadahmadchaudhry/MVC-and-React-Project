import {
    Navbar, Container, Col, DropdownToggle,
    DropdownMenu, DropdownItem, UncontrolledButtonDropdown
} from '../../../components';
import React, { useState, useEffect } from 'react';
import { getEntityList } from '../../../services/binservice';
import '../../../styles/common.scss';
import { useSelector } from 'react-redux';
import { useLocation } from "react-router-dom";
import ContainerConfigurations from '../containerconfiguration/containerconfigurations';
import { Configuration } from '../../commoncomponents/configurationfile';
const ContainerConfigurationheader = () => {
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [containerName, setContainerName] = useState('Bin');
    const [containerId, setContainerId] = useState(Configuration.entityType.bin);
    const [entityType, setEntityType] = useState([])

    const location = useLocation()
    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            loadentityType(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
        }
        else {
            loadentityType(CompanyListingStatus?.result?.response?.result[0].company_id)
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])
    const loadentityType = async (company_id) => {
        const result = await getEntityList(`?company_id=${company_id}`);
        setEntityType(result.data.result)
    }
    //======================== End ==============================================
    const _handleContainerOnClick = (e) => {
        setContainerName(e[1].name)
        setContainerId(e[0].id);
    }
    if (location.state != null) {
        useEffect(() => {
            setContainerName(location.state.container_name)
            setContainerId(location.state.container_id);
        }, [])
    }

    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div style={{ justifyContent: 'flex-start', display: 'inline-flex' }}>
                    <UncontrolledButtonDropdown style={{ marginLeft: 20 + "px" }}>
                        <DropdownToggle color="link" className="pl-0 pb-0 btn-profile sidebar__link" >
                            <h4>Container Configuration - {containerName}<i className="fa fa-angle-down ml-2"></i></h4>
                        </DropdownToggle>
                        <DropdownMenu persist className="dropdown-configuration-padding">
                            {entityType && entityType.length > 0 ? (entityType.map((item, index) => (
                                <DropdownItem onClick={() => {
                                    _handleContainerOnClick([{ id: item.entity_type_id }, { name: item.entity_type_name }])
                                }} key={index} >{item.entity_type_name}</DropdownItem>
                            ))) : (
                                    ''
                                )}
                        </DropdownMenu>
                    </UncontrolledButtonDropdown>

                </div>
            </Navbar>
            <Container className="margin-top">
                <ContainerConfigurations configurationType={{ containerId, containerName }} />
            </Container>
        </>
    )
}
export default ContainerConfigurationheader;
