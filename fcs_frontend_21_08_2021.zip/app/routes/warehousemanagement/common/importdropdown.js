import React, { useState, useEffect } from 'react';
import {
    DropdownToggle, Button,
    UncontrolledButtonDropdown, DropdownMenu,
    DropdownItem, UncontrolledPopover,
    PopoverHeader, PopoverBody,
    UncontrolledTooltip
} from '../../../components';
import { getImportSheet, UploadLayoutSheet } from '../../../services/importservice';
import '../../../styles/common.scss';
import { useSelector } from 'react-redux';
import ProgressBarBox from '../../commoncomponents/progressbarbox';
import { useHistory } from 'react-router-dom';
import { Configuration } from '../../commoncomponents/configurationfile';
import { toast } from 'react-toastify';
import AlertMessage from '../../commoncomponents/alertmessage';
let container_type = 0;
let container_name = '';
let warehouse_location_id = 0;
let warehouse_address_id = 0;
let companyId = 0;
const ImportDropdown = (props) => {
    toast.configure()
    let history = useHistory();
    container_type = props.containertype;
    container_name = props.containername;
    warehouse_location_id = props.locationid
    warehouse_address_id = props.warehouseAddessId ? props.warehouseAddessId : 0;
    const [modal, setmodal] = useState(false);
    const [filename, setFileName] = useState('')
    const [progress, setProgress] = useState(0);
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    //const [companyId, setCompanyId] = useState(0)
    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            companyId = CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id
        }
        else {
            companyId = CompanyListingStatus?.result?.response?.result[0].company_id
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])
    const binDropdownData = [{ id: 1, name: "Download Template." }]
    const _handledropdownItem = async () => {
        let fileName = '';
        switch (container_type) {
            case Configuration.entityType.bin:
                fileName = 'container-bin.xlsx'
                break;
            case Configuration.entityType.box:
                fileName = 'container-box.xlsx'
                break;
            case Configuration.entityType.cart:
                fileName = 'container-cart.xlsx'
                break;
            case Configuration.entityType.pallete:
                fileName = 'container-pallet.xlsx'
                break;
            case Configuration.entityType.tote:
                fileName = 'container-tote.xlsx'
                break;
            case Configuration.entityType.zone:
                fileName = 'layout-zone.xlsx'
                break;
            // case Configuration.entityType.location:
            //     fileName = 'location_storage_unit.xlsx'
            //     break;
            default:
                fileName = 'report.xlsx';
                break;
        }
        const result = await getImportSheet(container_type, companyId, warehouse_location_id, warehouse_address_id);
        const type = result.headers['content-type']
        const blob = new Blob([result.data], { type: type, encoding: 'UTF-8' })
        const link = document.createElement('a')
        link.href = window.URL.createObjectURL(blob)
        link.download = fileName
        link.click()
    }


    const _handleChange = async (event) => {
        setProgress(0);
        if (event.target.files && event.target.files[0]) {
            setmodal(true)
            try {
                let file = event.target.files[0];
                let form_data = new FormData();
                setFileName(file.name)
                form_data.append('filename', file.name);
                form_data.append('myfile', file);
                form_data.append('container_type', container_type);
                form_data.append('warehouse_location_id', warehouse_location_id);
                form_data.append('warehouse_address_id', warehouse_address_id);
                form_data.append('company_id', companyId)
                UploadLayoutSheet(form_data, (event) => {
                    setProgress(Math.round((100 * event.loaded) / event.total));
                })
                    .then((response) => {
                        console.log('response', response)
                        if (response.data['status'] == true) {
                            localStorage.setItem("ContainerFileName", file.name);
                            localStorage.setItem("ContainerType", container_type);
                            localStorage.setItem("ContainerName", container_name);
                            localStorage.setItem("warehouse_location_id", warehouse_location_id);

                            // if (container_type === Configuration.entityType.location) {
                            //     localStorage.setItem("FileName", file.name);
                            //     history.push('/importlocationstorageunit');
                            // } else {
                            history.push({
                                pathname: '/containerpreview',
                                state: {
                                    containerName: container_name,
                                    containerId: container_type,
                                    warehouseLocationId: warehouse_location_id,
                                    warehouseLocationName: props.locationName
                                }
                            });
                            // }
                        } else {
                            setProgress(0);
                            setmodal(false)
                            toast.error(<AlertMessage type="error" title="Bulk import failed" message={response.data.Message} />, { autoClose: false })
                        }
                    })
                    .catch((error) => {
                        setProgress(0);
                        console.log("Could not upload the file!", error);
                    });
            } catch (error) {
                console.log("Error happen in upload function", error);
            }
        }
    }
    const toggledelModal = () => {
        setmodal(!modal);
    }

    return (
        <>
            <Button outline>
                <div className="image-upload " >
                    <label htmlFor="file-input">
                        Import
                </label>
                    <input id="file-input" type="file" onChange={(e) => _handleChange(e)} accept=".xlsx" />
                </div>

            </Button>
            <UncontrolledButtonDropdown direction="down">
                <DropdownToggle color="secondary" outline caret />
                <DropdownMenu right>
                    {binDropdownData && binDropdownData.length > 0 ? (binDropdownData.map((item, index) => (
                        <DropdownItem onClick={() => _handledropdownItem(item.id)}>
                            {item.name}
                        </DropdownItem>
                    ))) : (
                            ''
                        )}
                </DropdownMenu>
            </UncontrolledButtonDropdown>
            <Button outline className='ml-2' id="UncontrolledPopoverTop">
                <i class="fa fa-info-circle" aria-hidden="true"></i>
            </Button>
            <UncontrolledPopover trigger="legacy" placement="top" target="UncontrolledPopoverTop">
                <PopoverHeader>
                    Import {container_name} <i className='fa fa-times-circle-o' aria-hidden="true"></i>
                </PopoverHeader>
                <PopoverBody>
                    <ul className="tooltip-padding">
                        <li>
                            Click Import to upload {container_name} Template.
                        </li>
                        <li>
                            Click <i class="fa fa-caret-down" aria-hidden="true"></i> to download import template.
                        </li>
                        <li>
                            maximum size for template file is 10 megabytes.
                    </li>

                    </ul>
                </PopoverBody>
            </UncontrolledPopover>
            <ProgressBarBox isOpen={modal} message={`Uploading file : ${filename}`}
                onClose={toggledelModal} title={`Import ${container_name}`} percentage={progress} />
        </>
    )

}
export default ImportDropdown;