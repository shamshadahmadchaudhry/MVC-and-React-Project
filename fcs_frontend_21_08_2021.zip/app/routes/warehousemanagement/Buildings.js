import React, { useState, useEffect, useRef } from 'react';
import { useSelector } from 'react-redux';
import DataGrid, {
  Column,
  Editing,
  Paging, Pager,
  FilterRow, RequiredRule,
  PatternRule
} from 'devextreme-react/data-grid';
import { toast } from 'react-toastify';
import { Configuration } from '../commoncomponents/configurationfile';
import ConfirmBox from '../commoncomponents/confirmbox';
import AddBuildingForm from './addbuildingform';
import {
  ThemeConsumer, Button, Modal, ModalHeader, ModalBody, ModalFooter
} from '../../components';
import AlertMessage from '../commoncomponents/alertmessage';
import {
  verifyAddress,
  getBuildingDetailsList,
  getWarehouseBuildingList,
  updateBuildingAddress,
  deleteBuildingAddress
} from '../../services/warehousemanagementservice';
import CustomStore from 'devextreme/data/custom_store';
import { getUnitofMeasures } from '../../services/companyprofileservice';


const Buildings = ({ data }) => {
  const Datagridref = useRef(null)
  let warehouseLocationId = data.warehouse_location_id;
  let zipcode = data.zip_code;
  let state = data.state;
  let city = data.city;
  toast.configure();
  const onCellPrepared = (e) => {
    if (e.rowType == 'header' && e.column.command == "edit") {
      e.cellElement.innerText = " Actions ";
    }
    if (e.rowType == 'filter' && e.column.command == "edit") {
      e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close dx-link-delete'></i></button>";
      e.cellElement.onclick = () => { Datagridref.current.instance.clearFilter() }
    }
  }
  const indicatorUrl = "https://js.devexpress.com/Content/data/loadingIcons/rolling.svg";
  const [whaddress, setwhaddress] = useState(0);
  const [isnewdata, setIsnewdata] = useState(false)
  const [modal, setModal] = useState(false);
  const [delmodal, setDelmodal] = useState(false);
  const [standadaddress, setStandaddress] = useState({});
  const [cap, setCap] = useState();
  const [alias, setAlias] = useState('');
  const [e, setE] = useState(true);
  const [add_1, setadd_1] = useState('');
  const [add_2, setadd_2] = useState('');
  const [standadd1, setStandadd1] = useState('');
  const [standadd2, setStandadd2] = useState('');
  const [unitOfMeasures, setUnitMeasures] = useState('');
  const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
  const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
  let capacity = '';
  let building_alias = '';
  let address_line_1 = '';
  let address_line_2 = '';
  let warehouseaddress = 0;

  const UnitMeasures = async () => {
    let company_id = 0;
    if (CompanyListingStatus?.result?.response?.result.length > 1)
      company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id
    else
      company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
    const result = await getUnitofMeasures(company_id, userData?.user_type_id);
    if (!result.data.error) {
      for (let i = 0; i < result.data.data.length; i++) {
        if (result.data.data[i].is_active == 1) {
          setUnitMeasures(result.data.data[i].cubic_unit);
          break;
        }
      }
    }
    console.log("Unit measure =>:", result);
  }

  const toggle = () => {
    setModal(!modal);
  }
  const toggledelModal = () => {
    setDelmodal(!delmodal);
  }

  useEffect(() => {
    UnitMeasures();
  }, [])

  const [buildingList, setBuildingList] = useState([]);
  const loadBuildingAddresses = async () => {
    let resp = await getWarehouseBuildingList(warehouseLocationId)
    setBuildingList(resp.data.data)
  }
  useEffect(() => {
    setIsnewdata(false)
  }, [isnewdata])

  const reload = (v) => {
    if (v === 2) {
      setIsnewdata(true)
      console.log(isnewdata)
    }
  }

  const x = (e) => {
    e.cancel = false;
  }

  const updateBuildingRecord = async () => {
    console.log(warehouseaddress)
    let updateresp = await updateBuildingAddress({
      warehouse_address_id: warehouseaddress,
      warehouse_location_id: warehouseLocationId,
      building_alias: building_alias,
      capacity: capacity,
      address_line_1: address_line_1,
      address_line_2: address_line_2,
    })
  }

  //oNLY RUNS WHEN ADDRESS HAS BEEN STANDARDIZED
  const saveBuildingAddress = async () => {
    let updateresp = await updateBuildingAddress({
      warehouse_address_id: whaddress,
      warehouse_location_id: warehouseLocationId,
      building_alias: alias,
      capacity: cap,
      address_line_1: standadaddress.Address1,
      address_line_2: standadaddress.Address2
    })
    toggle()
    setIsnewdata(true)
    //dataGrid.saveEditData();
    toast.success(<AlertMessage type='success' title='Building details updated'
      message='Updated Building details Successfully' />, { autoClose: 4000 });
    setE(false)
    setStandaddress('')
    Datagridref.current.instance.refresh();
  }

  const standardizeAddress = async (e) => {
    console.log(address_line_1)
    console.log(address_line_2)
    let response = await verifyAddress({
      Address1: address_line_1,
      Address2: address_line_2,
      zip_code: zipcode,
      state: state,
      city: city
    });
    console.log(response.data)
    if (response.data && response.data.length > 0) {
      let standardAdddress = response.data[0];
      setStandaddress(standardAdddress);
      setModal(true)
    }
    else {
      toast.error(<AlertMessage type='error' title='Error Standardizing Address'
        message='Invalid address' />, { autoClose: false });
    }
  }

  const deleteRow = async () => {
    let deleteresp = await deleteBuildingAddress(whaddress);
    setDelmodal(!delmodal)
    toast.success(<AlertMessage type='success' title='Building details deleted'
      message='Building details deleted Successfully' />, { autoClose: 4000 });
  }

  function isNotEmpty(value) {
    return value !== undefined && value !== null && value !== '';
  }

  const address_data = new CustomStore({
    key: 'warehouse_address_id',
    load: async (loadOptions) => {
      let count = 0;
      let params = '?';
      [
        'skip',
        'take',
        'requireTotalCount',
        'requireGroupCount',
        'sort',
        'filter',
        'totalSummary',
        'group',
        'groupSummary',
        'warehouse_location_id'
      ].forEach(function (i) {
        if (i in loadOptions && isNotEmpty(loadOptions[i])) {
          params += `${i}=${JSON.stringify(loadOptions[i])}&`;
        }
        if (!loadOptions.filter && !loadOptions.sort && count === 0 && !loadOptions.skip && !loadOptions.take) {
          params += `skip=0&take=5&requireTotalCount=true&totalSummary=[]&`;
        }
        if (loadOptions.filter && loadOptions['group'] !== null && count === 0) {
          params += `skip=0&take=5&`;
        }
        count++;
      });
      let warehouse_location_id = warehouseLocationId;
      params += `warehouse_location_id=${warehouse_location_id}&`
      params = params.slice(0, -1);
      return await getBuildingDetailsList(params)

    },
    update: async (key, values) => {
    }
  })

  return (
    <div>
      <div className='mt-2'>
        <h5 className='ml-1 mb-3'>Buildings</h5>
        <AddBuildingForm zipcode={zipcode} state={state} city={city} warehouseLocationId={warehouseLocationId} reload={reload} />
        <DataGrid
          id="gridContainer"
          dataSource={address_data}
          allowColumnReordering={true}
          ref={Datagridref}
          showBorders={true}
          rowAlternationEnabled={true}
          columnHidingEnabled={true}
          remoteOperations={true}
          onCellPrepared={onCellPrepared}
          onInitialized={(e) => {
            e.component.columnOption("command:edit", "width", 150)
          }}
          onRowUpdating={(e) => {
            e.cancel = true;
            if (e.newData.address_line_1) {
              address_line_1 = e.newData.address_line_1
              setadd_1(address_line_1)
            }
            else {
              address_line_1 = e.oldData.address_line_1;
              setadd_1(address_line_1)
            }
            if (e.newData.address_line_2) {
              address_line_2 = e.newData.address_line_2
              setadd_2(address_line_2)
            }
            else {
              address_line_2 = e.oldData.address_line_2
              setadd_2(address_line_2)
            }
            if (e.newData.building_alias) {
              building_alias = e.newData.building_alias
              setAlias(building_alias)
            }
            else {
              building_alias = e.oldData.building_alias;
              setAlias(building_alias)
            }
            if (e.newData.capacity) {
              capacity = e.newData.capacity
              setCap(capacity)
            }
            else {
              capacity = e.oldData.capacity
              setCap(capacity)
            }

            warehouseaddress = e.oldData.warehouse_address_id
            setwhaddress(warehouseaddress)
            e.cancel = true;
            if (e.newData.address_line_1 || e.newData.address_line_2) {
              standardizeAddress()
              if (standadaddress) {
                e.oldData.address_line_1 = standadaddress.Address1
                e.oldData.address_line_2 = standadaddress.Address2
              }
            }
            else {
              updateBuildingRecord()
              Datagridref.current.instance.refresh()
              toast.success(<AlertMessage type='success' title='Building details Updated'
                message='Building details updated successfully' />, { autoClose: 4000 });
            }
          }}
          onRowRemoving={async (e) => {
            e.cancel = true;
            setwhaddress(e.data.warehouse_address_id)
            setDelmodal(true)
          }}
        >
          <Paging enabled={true}
            defaultPageSize={5} />
          <Pager
            showPageSizeSelector={true}
            allowedPageSizes={[5, 10, 20]}
            showInfo={true} />
          <FilterRow visible={true} />
          <Editing
            mode="row"
            useIcons={true}
            allowUpdating={true}
            confirmDelete={false}
            allowDeleting={true}
          />
          <Column dataField="building_alias"
            caption="Building alias"
            allowSorting={true}>
            <RequiredRule />
            <PatternRule
              message={'Please enter valid building alias'}
              pattern={Configuration.alphanumericSpace}
            />
          </Column>
          <Column dataField="address_line_1"
            allowSorting={false}>
            <RequiredRule />
            <PatternRule
              message={'Please enter valid address line 1'}
              pattern={Configuration.alphanumComaSpace}
            />
          </Column>
          <Column dataField="address_line_2"
            allowSorting={false}>
            <RequiredRule />
            <PatternRule
              message={'Please enter valid address line 1'}
              pattern={Configuration.alphanumComaSpace}
            />
          </Column>
          <Column dataField="capacity"
            width={130} caption={`Capacity (${unitOfMeasures})`}
            allowSorting={false}>
            <RequiredRule />
            <PatternRule
              message={'IPlease enter valid capacity'}
              pattern={Configuration.decimal}
            />
          </Column>

        </DataGrid>
        <Modal isOpen={modal} toggle={toggle} className="modal-outline">
          <ModalHeader tag="h5">
            Standardized building address
                </ModalHeader>
          <ModalBody>
            <div style={{ marginTop: "10px" }} className="media-body">
              {standadaddress && <>
                <div className="text-center">
                  <p className="mb-0">{standadaddress.Address1} &nbsp; {standadaddress.Address2}</p>
                  <p>{standadaddress.city} &nbsp; {standadaddress.state} &nbsp; {standadaddress.zipcode} USA</p>
                </div>
              </>
              }
            </div>
          </ModalBody>
          <ModalFooter>
            <button type="button" onClick={toggle} color="link" className="btn btn-default text-warning">
              Cancel
                </button>
            <ThemeConsumer>
              {
                ({ color }) => (
                  <Button color={color} onClick={() => saveBuildingAddress()}>
                    Update
                  </Button>
                )
              }
            </ThemeConsumer>
          </ModalFooter>
        </Modal>
        <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this building detail`}
          onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete Building detail" />
      </div>
    </div>
  );
}

export default Buildings;