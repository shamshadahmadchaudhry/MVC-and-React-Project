import React, { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom';
import Toggle from 'react-toggle'
import { toast } from 'react-toastify';
import AlertMessage from '../commoncomponents/alertmessage';
import {
    Navbar,
    FormGroup,
    CustomInput,
    Container,
    Modal,
    ModalHeader,
    ModalBody,
    ModalFooter,
    ThemeConsumer,
    Row, Col
}
    from '../../components';
import { getNamingRules, updateNamingRules, updateentityStatus, getEntitySizes } from '../../services/warehousemanagementservice';
import { Configuration } from '../commoncomponents/configurationfile';
import { getContainerTypeList } from '../../services/binservice';
import CustomStore from 'devextreme/data/custom_store';
import NamingRulesSkeleton from './skeleton/namingrulesskeleton';
import { useSelector } from 'react-redux';
import DataGrid, { Column, Editing, Paging, Pager, RequiredRule, PatternRule, Lookup, FilterRow } from 'devextreme-react/data-grid';
import { updateIsSuffixSize } from '../../services/stationservices';

const NamingRules = () => {
    toast.configure();
    const Datagridref = useRef(null)
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [ischeckdisabled, setIscheckdisabled] = useState({
        check6: true,
        check7: true,
        check8: true,
        check9: true,
        check10: true,
    })
    const [istogglevisible, setIstogglevisible] = useState({
        toggle6: true,
        toggle7: true,
        toggle8: true,
        toggle9: true,
        toggle10: true,
    })
    const [ischecked, setIschecked] = useState({
        checked6: true,
        checked7: true,
        checked8: true,
        checked9: true,
        checked10: true,
    })
    const [editmode, setEditmode] = useState(false)
    const [key, setKey] = useState(0)
    const [preview, setPreview] = useState('')
    const [entityname, setEntityname] = useState('')
    const [containermodal, setContainermodal] = useState(false)
    const [containerPrefix, setContainerPrefix] = useState('');
    const [sizes, setSizes] = useState([]);
    const [containerid,setContainerid] = useState(0);

    let entity_rules_id = 0;
    let sequence = '';
    let prefix = '';
    let seedvalue = '';
    let increment = 0;
    let entity_sub_type = 0;

    const [screensize, setScreensize] = useState({
        matches: window.matchMedia("(min-width: 1200px)").matches
    });
    useEffect(() => {
        const handler = e => setScreensize({ matches: e.matches });
        window.matchMedia("(min-width: 1200px)").addListener(handler);
    }, [screensize.matches])
    const updateRules = async () => {
        let updateResp = await updateNamingRules({
            entity_rules_id: entity_rules_id,
            prefix: prefix,
            sequence: sequence,
            entity_subtype: entity_sub_type,
            seed_value: seedvalue,
            increment: increment
        })

        toast.success(<AlertMessage type='success' title='Naming Rules Updated'
            message='Successfully Updated Naming Rules' />, { autoClose: 4000 });
        setIscheckdisabled({ check6: true, check7: true, check8: true, check9: true, check10: true })
        setIstogglevisible({ toggle6: true, toggle7: true, toggle8: true, toggle9: true, toggle10: true })
        entity_rules_id = 0;
        prefix = '';
        sequence = '';
        entity_sub_type = '';
        seedvalue = '';
        increment = '';

    }

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }

    const namingRulesdata = new CustomStore({
        key: 'entity_rules_id',
        load: async (loadOptions) => {
            let company_id = 0
            if (CompanyListingStatus?.result?.response?.result.length > 1) {
                company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
            } else {
                company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
            }
            return await getNamingRules({ company_id: company_id })

        },
        update: async (key, values) => {
        }
    });

    const togglecontainerModal = () => {
        setSizes([])
        setContainermodal(!containermodal);
    }

    const handleTogglechange = async (c, e) => {
        let isEnable = 0;
        entity_rules_id = c.data.entity_rules_id
        // //If toggle button is enabled
        if (e.target.checked) {
            isEnable = 1
        }
        // //If toggle button is disabled
        else {
            isEnable = 0;
        }
        let updateEnableResp = await updateentityStatus({
            'entity_rules_id': entity_rules_id,
            'is_enable': isEnable
        })
        Datagridref.current.instance.refresh()
    }

    const ToggleBtn = (e) => {
        let initStatus = false;
        if (e.data.box_count != undefined) {
            let box_count = e.data.box_count
            if (box_count > 0) {
                initStatus = true
            }
            else {
                initStatus = false
            }
        }
        if (e.data.cart_count != undefined) {
            let cart_count = e.data.cart_count
            if (cart_count > 0) {
                initStatus = true
            }
            else {
                initStatus = false
            }
        }
        if (e.data.tote_count != undefined) {
            let tote_count = e.data.tote_count
            if (tote_count > 0) {
                initStatus = true
            }
            else {
                initStatus = false
            }
        }
        if (e.data.palette_count != undefined) {
            let palette_count = e.data.palette_count
            if (palette_count > 0) {
                initStatus = true
            }
            else {
                initStatus = false
            }
        }
        if (e.data.bin_count != undefined) {
            let bin_count = e.data.bin_count
            if (bin_count > 0) {
                initStatus = true
            }
            else {
                initStatus = false
            }
        }
        let isChecked = false;
        let g = e
        if (e.data.is_enable == 1) {
            isChecked = true
        }
        else {
            isChecked = false;
        }
        if (e.data.entity == 'Warehouse Container') {
            if (e.data.type_id === Configuration.entityType.bin && istogglevisible.toggle6) {
                return (
                    <>
                        <Toggle
                            id='status'
                            defaultChecked={isChecked}
                            onChange={(g) => handleTogglechange(e, g)} disabled={initStatus} />
                        <label htmlFor='status'></label>
                    </>
                )
            }
            else if (e.data.type_id === Configuration.entityType.box && istogglevisible.toggle7) {
                return (
                    <>
                        <Toggle
                            id='status'
                            defaultChecked={isChecked}
                            onChange={(g) => handleTogglechange(e, g)} disabled={initStatus} />
                        <label htmlFor='status'></label>
                    </>
                )
            }
            else if (e.data.type_id === Configuration.entityType.cart && istogglevisible.toggle8) {
                return (
                    <>
                        <Toggle
                            id='status'
                            defaultChecked={isChecked}
                            onChange={(g) => handleTogglechange(e, g)} disabled={initStatus} />
                        <label htmlFor='status'></label>
                    </>
                )
            }
            else if (e.data.type_id === Configuration.entityType.pallete && istogglevisible.toggle9) {
                return (
                    <>
                        <Toggle
                            id='status'
                            defaultChecked={isChecked}
                            onChange={(g) => handleTogglechange(e, g)} disabled={initStatus} />
                        <label htmlFor='status'></label>
                    </>
                )
            }
            else if (e.data.type_id === Configuration.entityType.tote && istogglevisible.toggle10) {
                return (
                    <>
                        <Toggle
                            id='status'
                            defaultChecked={isChecked}
                            onChange={(g) => handleTogglechange(e, g)} disabled={initStatus} />
                        <label htmlFor='status'></label>
                    </>
                )
            }
            else {
                //console.log('TRACTOY')
                return (<></>)
            }
        }
        else {
            return (<></>)
        }
    }

    const btnRender = (e) => {
        if (e.data.type_id === Configuration.entityType.bin && e.row.data.is_size_suffix === 1) {
            return (
                <div>
                    <button onClick={(g) => _handlepreviewClick(g, e)} className='btn btn-warning btn-sm'>preview</button>
                </div>
            )
        }
        else if (e.data.type_id === Configuration.entityType.box && e.row.data.is_size_suffix === 1) {
            return (
                <div>
                    <button onClick={(g) => _handlepreviewClick(g, e)} className='btn btn-warning btn-sm'>preview</button>
                </div>
            )
        }
        else if (e.data.type_id === Configuration.entityType.cart && e.row.data.is_size_suffix === 1) {
            return (
                <div>
                    <button onClick={(g) => _handlepreviewClick(g, e)} className='btn btn-warning btn-sm'>preview</button>
                </div>
            )
        }
        else if (e.data.type_id === Configuration.entityType.pallete && e.row.data.is_size_suffix === 1) {
            return (
                <div>
                    <button onClick={(g) => _handlepreviewClick(g, e)} className='btn btn-warning btn-sm'>preview</button>
                </div>
            )
        }
        else if (e.data.type_id === Configuration.entityType.tote && e.row.data.is_size_suffix === 1) {
            return (
                <div>
                    <button onClick={(g) => _handlepreviewClick(g, e)} className='btn btn-warning btn-sm'>preview</button>
                </div>
            )
        }
        else {
            return (
                <div>
                    <i>{e.row.data.preview}</i>
                </div>
            )
        }
    }

    const handleCheckchange = (g, e) => {
        //Checkbox is checked
        if (e.target.checked) {
            if (g.key === Configuration.entityType.bin) {
                setKey(g.key)
            }
            else if (g.key === Configuration.entityType.box) {
                setKey(g.key)
            }
            else if (g.key === Configuration.entityType.cart) {
                setKey(g.key)
            }
            else if (g.key === Configuration.entityType.pallete) {
                setKey(g.key)
            }
            else if (g.key === Configuration.entityType.tote) {
                setKey(g.key)
            }
            let request_body = {
                entity_rules_id: g.data.entity_rules_id,
                is_size_suffix: 1
            }
            const response = updateIsSuffixSize(request_body);
        }
        //Checkbox is unchecked
        else {
            let request_body = {
                entity_rules_id: g.data.entity_rules_id,
                is_size_suffix: 0
            }
            const response = updateIsSuffixSize(request_body);
        }
        Datagridref.current.instance.refresh();
        Datagridref.current.instance.editRow(g.rowIndex)

    }

    const _handlepreviewClick = async (g, e) => {
        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        }
        let container_type = 0
        if (e.data.entity_rules_id === Configuration.entityType.bin) {
            container_type = Configuration.entityType.bin
            setPreview(e.data.preview)
            setEntityname('Bin')
        }
        else if (e.data.entity_rules_id === Configuration.entityType.tote) {
            container_type = Configuration.entityType.tote
            setPreview(e.data.preview)
            setEntityname('Tote')
        }
        else if (e.data.entity_rules_id === Configuration.entityType.pallete) {
            container_type = Configuration.entityType.pallete
            setPreview(e.data.preview)
            setEntityname('Pallete')
        }
        else if (e.data.entity_rules_id === Configuration.entityType.cart) {
            container_type = Configuration.entityType.cart
            setPreview(e.data.preview)
            setEntityname('Cart')
        }
        else if (e.data.entity_rules_id === Configuration.entityType.box) {
            container_type = Configuration.entityType.box
            setPreview(e.data.preview)
            setEntityname('Box')
        }
        setContainerid(container_type)
        console.log('TYPE ID', container_type)
        console.log('container type', container_type)

        let entitydetails = await getContainerTypeList(container_type, company_id)
        console.log('Entity details', entitydetails)
        let prefix_name = container_type === Configuration.entityType.pallete ? 'P'
            : container_type === Configuration.entityType.bin ? "X" : container_type === Configuration.entityType.bin ? "B"
                : container_type === Configuration.entityType.cart ? "C" : container_type === Configuration.entityType.tote ? "T" : ''
        setContainerPrefix(prefix_name);
        setSizes(entitydetails.data.result)
        setContainermodal(true)
    }

    const CheckBox = (e) => {
        if (e.data.entity == 'Warehouse Container') {
            return (
                <>
                    <FormGroup className='text-center mt-3'>
                        <CustomInput type="checkbox" value=''
                            className='text-center'
                            checked={e.data.is_size_suffix === 1 ? true : false}
                            onChange={(g) => handleCheckchange(e, g)}
                            id={`chk-${e.data.type_id}`}
                            disabled={
                                e.data.type_id === Configuration.entityType.bin ? ischeckdisabled.check6 :
                                e.data.type_id === Configuration.entityType.box ? ischeckdisabled.check7 :
                                e.data.type_id === Configuration.entityType.cart ? ischeckdisabled.check8 :
                                e.data.type_id === Configuration.entityType.pallete ? ischeckdisabled.check9 :
                                e.data.type_id === Configuration.entityType.tote ? ischeckdisabled.check10 : ''
                            } />
                    </FormGroup>
                </>
            )
        }
        else {
            return (<></>)
        }
    }

    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div style={{ justifyContent: 'flex-start', display: 'inline-flex' }}>
                    <h4>Warehouse Naming Rules</h4>
                </div>
            </Navbar>
            {(CompanyListingStatus.isLoading === true) ?
                (
                    <NamingRulesSkeleton />
                ) : (
                    <>
                        <Container className="mb-5">
                            <Row>
                                <Col lg={12} className="warehouse-margin mt-3">
                                    <p>You can manage all warehouse entities here.</p>
                                </Col>
                            </Row>
                            <DataGrid
                                id="gridContainer"
                                dataSource={namingRulesdata}
                                keyExpr="entity_rules_id"
                                ref={Datagridref}
                                columnHidingEnabled={!screensize.matches ? true : false}
                                allowColumnReordering={true}
                                showBorders={true}
                                onEditorPreparing={(e)=>{
                                    setTimeout(() => {
                                        e.component.focus(e.editorElement) 
                                    }, 400);
                                    
                                }}
                                onEditingStart={(e) => {
                                    setEditmode(true)
                                    switch (e.data.type_id) {
                                        case Configuration.entityType.bin:
                                            setIscheckdisabled({ check6: false, check7: true, check8: true, check9: true, check10: true })
                                            setIstogglevisible({ toggle6: false, toggle7: true, toggle8: true, toggle9: true, toggle10: true })
                                            break;
                                        case Configuration.entityType.box:
                                            setIscheckdisabled({ check6: true, check7: false, check8: true, check9: true, check10: true })
                                            setIstogglevisible({ toggle6: true, toggle7: false, toggle8: true, toggle9: true, toggle10: true })
                                            break;
                                        case Configuration.entityType.cart:
                                            setIscheckdisabled({ check6: true, check7: true, check8: false, check9: true, check10: true })
                                            setIstogglevisible({ toggle6: true, toggle7: true, toggle8: false, toggle9: true, toggle10: true })
                                            break;
                                        case Configuration.entityType.pallete:
                                            setIscheckdisabled({ check6: true, check7: true, check8: true, check9: false, check10: true })
                                            setIstogglevisible({ toggle6: true, toggle7: true, toggle8: true, toggle9: false, toggle10: true })
                                            break;
                                        case Configuration.entityType.tote:
                                            setIscheckdisabled({ check6: true, check7: true, check8: true, check9: true, check10: false })
                                            setIstogglevisible({ toggle6: true, toggle7: true, toggle8: true, toggle9: true, toggle10: false })
                                            break;
                                    }

                                }}
                                onEditCanceled={() => {
                                    setEditmode(false)
                                    setKey(0)
                                    //set all checbox to disabled state
                                    setIscheckdisabled({ check6: true, check7: true, check8: true, check9: true, check10: true })
                                    setIstogglevisible({ toggle6: true, toggle7: true, toggle8: true, toggle9: true, toggle10: true })
                                }}
                                onCellPrepared={(e) => {
                                    if (e.rowType == 'header' && e.column.command == "edit") {
                                        e.cellElement.innerText = " Actions ";
                                    }
                                    if (e.rowType == 'header' && e.caption == 'Include Entity Subtype') {
                                        e.cellElement.innerHTML = '<p>Include <br> Entity Subtype</p>'
                                    }
                                    if (e.rowType == 'data' && e.column.name == 'include_sub_type') {
                                        if (e.data.entity == 'Warehouse Container') {
                                            e.cellElement.innerHTML = "<input type='checkbox' name='' id='' class='form-control p-4'  checked='true'/>"
                                        }
                                        else {
                                            e.cellElement.innerHTML = ''
                                        }
                                    }
                                    if (e.rowType == 'filter' && e.column.command == "edit") {
                                        e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close dx-link-delete'></i></button>";
                                        e.cellElement.onclick = () => { Datagridref.current.instance.clearFilter() }
                                    }
                                    if (e.rowType == 'data' && e.column.command == 'edit') {
                                        if (!e.data.is_enable) {
                                            e.cellElement.innerHTML = ''
                                        }

                                    }
                                }
                                }
                                onSaving={(e) => {
                                    setIstogglevisible({ toggle6: true, toggle7: true, toggle8: true, toggle9: true, toggle10: true })
                                    setIscheckdisabled({ check6: true, check7: true, check8: true, check9: true, check10: true })
                                }}
                                onRowUpdating={
                                    (e) => {
                                        if (e.newData.prefix) {
                                            prefix = e.newData.prefix;
                                        }
                                        else {
                                            prefix = e.oldData.prefix
                                        }
                                        if (e.newData.seed_value) {
                                            seedvalue = e.newData.seed_value
                                        }
                                        else {
                                            seedvalue = e.oldData.seed_value
                                        }
                                        if (e.newData.increment) {
                                            increment = e.newData.increment
                                        }
                                        else {
                                            increment = e.oldData.increment
                                        }
                                        entity_rules_id = e.oldData.entity_rules_id
                                        entity_sub_type = e.oldData.entity_subtype
                                        sequence = e.oldData.sequence
                                        updateRules()
                                    }
                                }
                            >

                                <Paging enabled={true}
                                    defaultPageSize={11} />
                                <Pager
                                    showPageSizeSelector={true}
                                    allowedPageSizes={[5, 10, 20]}
                                    showInfo={true} />
                                <Editing
                                    mode="row"
                                    allowUpdating={true} />
                                <FilterRow visible={true} />
                                <Column caption="" cellRender={ToggleBtn} allowEditing={false} />
                                <Column dataField="type" allowEditing={false} />
                                <Column dataField="entity" caption="Entity" width={180} allowEditing={false} />
                                <Column dataField="prefix">
                                </Column>
                                <Column dataField="sequence" allowEditing={false} />
                                <Column dataField="seed_value" caption='Seed'>
                                    <RequiredRule />
                                    <PatternRule
                                        message={'Please enter valid Seed value'}
                                        pattern={Configuration.alphanumeric}
                                    />
                                </Column>
                                <Column dataField="increment">
                                    <RequiredRule />
                                    <PatternRule
                                        message={'Please enter valid Increment'}
                                        pattern={Configuration.numeric}
                                    />
                                </Column>
                                <Column caption="Size suffix" cellRender={CheckBox} allowEditing={false} cssClass='text-center' />
                                <Column dataField="preview" cellRender={btnRender} allowEditing={false} />
                            </DataGrid>
                            <Modal isOpen={containermodal} toggle={togglecontainerModal} className="modal-outline-warning">
                                <ModalHeader tag="h5">
                                    <span className="text-dark">
                                        {/* <i className="fa fa-fw fa-remove"></i> */}{entityname} Naming Preview</span>
                                </ModalHeader>
                                <ModalBody>
                                    <div style={{ marginTop: "10px" }} className="media-body">
                                        <Link to={
                                            {
                                            pathname:'/warehouse/containerconfiguration',
                                            state:{
                                                    container_name:entityname,
                                                    container_id:containerid
                                                }
                                            }
                                            }>
                                            <button className='btn btn-sm pull-right btn-warning'><i className='fa fa-gear'></i> Configure</button>
                                        </Link>
                                        <div>
                                            <table className='table table-striped mt-2'>
                                                <thead>
                                                    <th>Size</th>
                                                    <th>Naming suffix</th>
                                                    <th>Preview</th>
                                                </thead>
                                                <tbody>

                                                    {(sizes && sizes.length > 0) ?
                                                        (sizes.map((item, index) => (
                                                            <tr>
                                                                <td key={index}>{item.size_name}</td>
                                                                <td key={index}>{item.suffix}</td>
                                                                <td key={index}>{containerPrefix}{1}{item.suffix}, {containerPrefix}{2}{item.suffix} </td>
                                                            </tr>
                                                        ))) : <tr>
                                                            <td colSpan='3'>{entityname} Size not configured,
                                                            <Link to={
                                                                {
                                                                pathname:'/warehouse/containerconfiguration',
                                                                state:{
                                                                        container_name:entityname,
                                                                        container_id:containerid
                                                                    }
                                                                }
                                                                }> Configure</Link> {entityname.toLowerCase} sizes
                                                             </td></tr>}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </ModalBody>
                                <ModalFooter>

                                    <ThemeConsumer>
                                        {
                                            ({ color }) => (
                                                <button className="btn btn-warning" onClick={togglecontainerModal}>
                                                    OK
                                                </button>
                                            )
                                        }
                                    </ThemeConsumer>
                                </ModalFooter>
                            </Modal>
                        </Container>
                    </>
                )}
        </>
    )
}

export default NamingRules;
