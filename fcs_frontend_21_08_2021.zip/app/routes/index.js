import React from "react";
import { Route, Switch, Redirect } from "react-router";
import { BrowserRouter, Route as R1 } from "react-router-dom";
import NavbarOnly from "../layout/Layouts/NavbarOnly";
import Login from "./accounts/login/login";
import { routes } from "../layout/Layouts/NavbarOnly/components/routes";
import { generateAppRoutes } from "./commoncomponents/utils";
import LayoutNavbar from "../layout/Layouts/NavbarOnly/components/LayoutNavbar";
import ForgotPassword from "./accounts/forgotpassword/";
import ResetPassword from "./accounts/resetpassword";
import ResetPasswordError from "./accounts/resetpassworderror";
import CompanyLayoutNavbar from "../layout/Layouts/NavbarOnly/components/companylayoutnavbar";
import CreateAccount from './accounts/createaccount/createaccount';
import TermsofUse from './accounts/createaccount/termsofuse';
import { useSelector } from 'react-redux';
const appRoutes = generateAppRoutes(routes);
import { check } from './commoncomponents/customhooks/Can';

 

import Error404 from './commoncomponents/notfound';

export const RoutedContent = () => {

    const PrivateRoute = ({ component: Component, ...rest }) => {
        return (<Route {...rest} render={props => (
            !localStorage.getItem("token") ?
                <Redirect to="/" />
                : <Component {...props} />
        )} />)
    };

 

    // const AppRoute = ({ route }) => {
    //     console.log("route", route);
    //     return (!localStorage.getItem("token") ? <Redirect to="/" /> : <Route path={route.path} render={
    //         (props) => {
    //             return (<LayoutNavbar key={route.path} route={route} {...props} />)
    //         }
    //     } />)
    // };

 

    // const AppRoute = ({ route }) => {
    //     console.log("route", route);
    //     return (<Route path={route.path} render={
    //         (props)=> {
    //             return (<div>{rou</div>)
    //         }
    //     } />)
    // };

 

    // const AppLayout = ({ component: Component}) => {
    //     return (!localStorage.getItem("token") ? <Redirect to="/" /> : <LayoutNavbar component={Component}  />)
    // };

 


    const UserData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data)

 

    const routeTest = async () => {
        {
            return appRoutes.map((route, index) => {
                return UserData && check(UserData, route.permission) && localStorage.getItem('token')
                    && <Route key={index} path={route.path} render={
                        (props) => {
                            return (<LayoutNavbar key={route.path} route={route} {...props} />)
                        }
                    } />
            })
        }
    }

 

    let isMenuRendered = true;
    // console.log('Approute',appRoutes)
    return (
        <BrowserRouter basename={process.env.PUBLIC_URL}>
            <Switch>
                <Redirect from='/' to='/account/login' exact />
                <Route path='/account/login' component={Login} />
                <Route path='/account/forgotPassword' component={ForgotPassword} />
                <Route path='/account/termsofuse' component={TermsofUse} />
                <Route path='/account/createaccount/:token/:email' component={CreateAccount} />
                <Route path='/resetpassword/:token/:key' component={ResetPassword} />
                <Route path='/account/resetpassworderror' component={ResetPasswordError} />
                <Route
                    path='/account/resetpassworderror'
                    component={ResetPasswordError}
                />
                <PrivateRoute path='/companylisting' component={CompanyLayoutNavbar} />
                {/* <Route path='/profile/profile' component={UserProfile} /> */}

 

                {
                    appRoutes.map((route, index) => {
                        console.log('Dynamic menu 1');
                        // if (index === appRoutes.length - 1) {
                        //     isMenuRendered = false;
                        //     console.log('All routes bind');
                        // }
                        return UserData && check(UserData, route.permission) && localStorage.getItem('token')
                            && <Route key={index} path={route.path} render={
                                (props) => {
                                    console.log('Props',props)
                                    console.log('Route path',route.path)
                                    return (<LayoutNavbar key={route.path} route={route} {...props} />)
                                }
                            } />
                        {/* {index === appRoutes.length - 1 && <Route key={'errorpage'} component={Error404} />} */ }

 

                    })}

                {!localStorage.getItem('token') && <Redirect to="/" />}

                {
                    console.log('static menu')}
                {/* {setTimeout(() => {
                    <Route component={Error404} />
                }, 3000)} */}
                {/* <Route path='/notfound' component={Error404} />
                <Redirect to='/notfound' /> */}
                {/* {isMenuRendered && <Route component={Error404} />} */}
                {appRoutes.map((route, index) => {
                    return UserData && check(UserData, route.permission) && localStorage.getItem('token')
                        && <Route path="*" component={Error404} />
                })}
            </Switch>
        </BrowserRouter>
    );
};
//const Example = () => (
//     <RouteNotFoundBoundary fallback={<div>Oh no!</div>}>
//         <Switch>
//             <Route path='/:pageId' component={Error404} />
//         </Switch>
//     </RouteNotFoundBoundary>
// )
export const RoutedNavbars = () => (
    <Switch>
        <Route component={NavbarOnly.Navbar} />
    </Switch>
);

