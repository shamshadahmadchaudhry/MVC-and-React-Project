import React from 'react';
import Skeleton from 'react-loading-skeleton';
import {
    Navbar,
    Container,
    Row, Col,
    Button,
    ButtonGroup,
    Card,
    CardBody,
} from '../../components';
import '../../styles/skeleton.scss';

const PackageSkelton = () => {
    return (
        <div>
            <Container className="mb-5">
                <Row>
                    <Col lg={12} className="warehouse-margin mt-3 mb-1">
                        <p><Skeleton width={200} /> </p>
                    </Col>
                </Row>

                <Card className="mb-3" className="margin-list">
                    <CardBody>
                        <h5 className='ml-3'><Skeleton width={100} /></h5>
                        <Row>
                            <Col className='ml-5'>
                                <div className="container-fluid margin-bottoms" >
                                    <ButtonGroup className="float-right margin-bottoms" >
                                        <Button outline onClick={() => _SingleRow()} className='ml-2'>
                                            <Skeleton width={20} />
                                        </Button>
                                    </ButtonGroup>
                                </div>
                            </Col>
                        </Row>
                        <div className="container-fluid">
                            <table className="table table-stripped">
                                <thead>
                                    <tr>
                                        <th>
                                            <Skeleton width={110} />
                                        </th>
                                        <th>
                                            <Skeleton width={50} />
                                        </th>
                                        <th>
                                            <Skeleton width={110} />
                                        </th>
                                        <th>
                                            <Skeleton width={100} />
                                        </th>
                                        <th>
                                            <Skeleton width={110} />
                                        </th>
                                        <th>
                                            <Skeleton width={110} />
                                        </th>
                                        <th>
                                            <Skeleton width={110} />
                                        </th>
                                        <th>
                                            <Skeleton width={100} />
                                        </th>
                                        <th>
                                            <Skeleton width={100} />
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td> <Skeleton width={110} /></td>
                                        <td> <Skeleton width={50} /></td>
                                        <td><Skeleton width={75} height={75} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td> <Skeleton width={110} /></td>
                                        <td> <Skeleton width={50} /></td>
                                        <td><Skeleton width={75} height={75} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>

                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td> <Skeleton width={110} /></td>
                                        <td> <Skeleton width={50} /></td>
                                        <td><Skeleton width={75} height={75} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>

                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td> <Skeleton width={110} /></td>
                                        <td> <Skeleton width={50} /></td>
                                        <td><Skeleton width={75} height={75} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td> <Skeleton width={110} /></td>
                                        <td> <Skeleton width={50} /></td>
                                        <td><Skeleton width={75} height={75} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>

                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td> <Skeleton width={110} /></td>
                                        <td> <Skeleton width={50} /></td>
                                        <td><Skeleton width={75} height={75} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>
                                        <td><Skeleton width={40} /></td>

                                        <td></td>
                                        <td></td>
                                    </tr>

                                </tbody>
                            </table>

                        </div>
                    </CardBody>
                </Card>
            </Container>
        </div>
    )
}

export default PackageSkelton