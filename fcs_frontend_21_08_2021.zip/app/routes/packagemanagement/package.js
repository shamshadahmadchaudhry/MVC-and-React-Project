import { DataGrid, FileUploader, RadioGroup } from 'devextreme-react';
import React, { useState, useEffect, useRef } from 'react';
import { toast } from 'react-toastify';
import {
    Navbar,
    Container,
    Row, Col,
    Button,
    ButtonGroup,
    Card,
    CardBody,
} from '../../components';
import { useSelector } from 'react-redux'
import CustomStore from 'devextreme/data/custom_store';
import ConfirmBox from '../commoncomponents/confirmbox';
import { addNewPackage, deletePackage, getPackagesList, printPackageQRCode, updatePackageDetails } from '../../services/packagemanagement';
import { Column, Editing, RequiredRule } from 'devextreme-react/data-grid';
import { getUnitofMeasures } from '../../services/companyprofileservice';
import AlertMessage from '../commoncomponents/alertmessage';
import { CONFIG } from '../../config';

import QRCode from 'qrcode.react';
import PackageSkelton from './packageskelton';

let companyId = 0;
const Package = () => {
    const [uploadedImage, setUploadedImage] = useState({});
    const [showHideQR, setShowHideQR] = useState(true);
    const [unitOfMeasures, setUnitMeasures] = useState('');
    toast.configure();
    const datagridRef = useRef(null);
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [rowEditing, setRowEditing] = useState(false);
    const [rowAdding, setRowAdding] = useState(false);
    const [packageId, setpackageId] = useState(0);
    const [isQrCode, setisQrCode] = useState(0);
    const [showHideTextbox, setShowHideTextbox] = useState(false);
    const [showHideQRCodeImage, setShowHideQRCodeImage] = useState(false);
    const [qrBarCodeValue, setQrBarCodeValue] = useState('');
    const [barCodeValue, setBarCodeValue] = useState('');
    const [iframeurl, setIframeurl] = useState('');
    const [imagePreview, setImagePreview] = useState('');
    const [delmodal, setDelmodal] = useState(false);

    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }

    useEffect(() => {
        UnitMeasures();
    }, [])

    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            companyId = CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id
        }
        else {
            companyId = CompanyListingStatus?.result?.response?.result[0].company_id
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    const UnitMeasures = async () => {
        let company_id = 0;
        if (CompanyListingStatus?.result?.response?.result.length > 1)
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id
        else
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
        const result = await getUnitofMeasures(company_id, userData?.user_type_id);
        if (!result.data.error) {
            for (let i = 0; i < result.data.data.length; i++) {
                if (result.data.data[i].is_active == 1) {
                    setUnitMeasures(result.data.data[i].small_unit);
                    break;
                }
            }
        }
    }

    const package_data = new CustomStore({
        key: 'package_id',
        load: async function (loadOptions) {
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                    params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                }
            });
            params += `company_id=${companyId}&`
            params = params.slice(0, -1);
            let response = await getPackagesList(params);
            return response.data.data;
        }
    });

    const _SingleRow = async () => {
        datagridRef.current.instance.addRow();
    }

    const deleteRow = async (package_id) => {
        const result = await deletePackage(packageId, userData.user_master_id);
        setDelmodal(!delmodal)

        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title='Delete Package'
                message={result.data['message']} />, { autoClose: 4000 });
            clearState();
        }
        else {
            toast.error(<AlertMessage type='error' title='Delete Package'
                message={result.data['message']} />, { autoClose: false });
        }
    }

    const onSaving = (e) => {
        SavePackage(e.changes, e.component);
        e.cancel = true;
    }

    const clearState = () => {
        setBarCodeValue('');
        setQrBarCodeValue('');
        setisQrCode('');
        setShowHideQR(true);
        setShowHideTextbox(false);
        setShowHideQRCodeImage(false);
        setImagePreview('');
    }

    const SavePackage = async (body, component) => {
        try {
            let data = body[0]
            if (body[0].type === 'insert') {
                let qr_value = data.data.package_name.replace(' ', '') + '_' + data.data.package_size.replace(' ', '')
                uploadedImage.append('package_name', data.data.package_name);
                uploadedImage.append('package_size', data.data.package_size);
                uploadedImage.append('height', data.data.height);
                uploadedImage.append('width', data.data.width);
                uploadedImage.append('length', data.data.length);
                uploadedImage.append('is_qr', isQrCode);
                uploadedImage.append('qr_bar_code_value', isQrCode === 1 ? qr_value : barCodeValue);
                uploadedImage.append('company_id', companyId);
                uploadedImage.append('standard_rate', data.data.standard_rate);
                uploadedImage.append('qr_binary_image', '');

                let result = await addNewPackage(uploadedImage);
                if (result.data.status) {
                    toast.success(<AlertMessage type="success" title="Add Package" message={result.data.message} />,
                        { autoClose: 4000 });
                    clearState();
                    await component.refresh(true);
                    component.cancelEditData();
                }

            } else if (body[0].type === 'update') {
                if (data?.data?.package_name)
                    uploadedImage.append('package_name', data.data.package_name);
                if (data?.data?.package_size)
                    uploadedImage.append('package_size', data.data.package_size);
                if (data?.data?.height)
                    uploadedImage.append('height', data.data.height);
                if (data?.data?.width)
                    uploadedImage.append('width', data.data.width);
                if (data?.data?.length)
                    uploadedImage.append('length', data.data.length);
                uploadedImage.append('is_qr', isQrCode);
                // uploadedImage.append('qr_bar_code_value', isQrCode === 1 ? qr_value : barCodeValue);
                uploadedImage.append('company_id', companyId);
                if (data?.data?.standard_rate)
                    uploadedImage.append('standard_rate', data.data.standard_rate);

                let result = await updatePackageDetails(uploadedImage);
                if (result.data.status) {
                    toast.success(<AlertMessage type="success" title="Add Package" message={result.data.message} />,
                        { autoClose: 4000 });
                    clearState();
                    await component.refresh(true);
                    component.cancelEditData();
                }

            } else if (body[0].type === 'remove') {
                setDelmodal(!delmodal);
                setpackageId(body[0].key);
            }
        } catch (error) {
            console.log(error)
        }
    }

    const onSelectedFilesChanged = async (e, package_id) => {
        console.log('Package Id', package_id)
        let file = e.value[0]
        let file_size = file.size;
        if (parseInt(file_size) <= 25000) {
            setImagePreview(URL.createObjectURL(e.value[0]));
            let form_data = new FormData();
            form_data.append('name', file.name);
            form_data.append('image', file);
            form_data.append('created_by', userData.user_master_id);
            form_data.append('package_id', package_id);
            setUploadedImage(form_data);
            // let response = await updatePackageImage(form_data)
            // if (response.data.status === true) {
            //     toast.success(<AlertMessage type='success' title='Package Image'
            //         message={response.data.message} />, { autoClose: false })
            // } else {
            //     toast.error(<AlertMessage type='error' title='Package Image'
            //         message={response.data.message} />, { autoClose: false })
            // }
            //dispatch(UpdateImageRequest({ form_data: form_data, user_master_id: userData.user_master_id }))
        } else {
            toast.error(<AlertMessage type='error' title='Package Image'
                message='File size should be 25kb/less than 25kb' />, { autoClose: false })
        }
    }

    const renderFileUploader = (cell) => {
        return (
            <>
                <img src={CONFIG.BASE_URL + cell.data.package_image} title="image_name" className="rounded card-img" style={{ width: "75px", height: "75px" }} />
            </>
        )
    }

    const editCellFileuploaderRender = (data) => {
        return (
            <>
                <FileUploader accept=".jpg, .jpeg, .png" uploadMode='instantly' id={`fileuploader${data.data.package_id}`}
                    onValueChanged={(e) => onSelectedFilesChanged(e, data.data.package_id)} dialogTrigger={`#dropzone-external${data.data.package_id}`} visible={false} />
                <i className="fa fa-arrow-circle-o-up text-primary" id={`dropzone-external${data.data.package_id}`}
                    title="Click here to upload .png/.jpg/.jpeg file." ></i>

                {
                    imagePreview && imagePreview !== '' && (
                        <img src={imagePreview} className="ml-2" style={{ width: "40px", height: "40px" }} alt="Preview" />
                    )
                }
            </>
        )
    }

    const printQrCode = async (packageId) => {
        const printdocument = await printPackageQRCode({ package_id: packageId });
        if (printdocument.data.status) {
            let path = printdocument.data.pdf_file_path
            let html_url = printdocument.data.html_url
            path = path.replace(/\\/g, "/");
            let indmedia = path.indexOf('media')
            let remPath = path.slice(indmedia)
            let fullPath = CONFIG.BASE_URL + '/' + remPath;
            let get_html_url = html_url + '?pdf_path=' + fullPath.substring(fullPath.indexOf('media'));
            setIframeurl(get_html_url, 'Print', 'left=200, top=200, width=950, height=500, toolbar=0, resizable=0');
            window.frames["labeliframe"].focus();
        }
    }

    const renderRadioButtons = (data) => {
        return (
            <>
                {data.data.is_qr !== 0 ? <>
                    <QRCode value={qrBarCodeValue} className="rounded card-img"
                        style={{ width: "40px", height: "40px" }} />
                    <button type="button" className="btn btn-sm bg-light mb-3 ml-1" onClick={() => printQrCode(data.data.package_id)}>
                        <i className="fa fa-print text-primary"></i></button></> :
                    <label>{data.data.qr_bar_code_value}</label>
                }
            </>
        )
    }

    const editCellRenderQrCode = (data) => {
        return (
            <>
                <div class={`form-group mt-3 ${showHideQR ? '' : 'hide-props'}`} >
                    <input type="radio" name="choice" onClick={(e) => onRadioClick(e, data)} value={1}
                        checked={isQrCode === 1 ? true : false} />
                    <i className="fa fa-qrcode ml-1"></i>
                    <input type="radio" name="choice" onClick={(e) => onRadioClick(e, data)} className="ml-2"
                        checked={isQrCode === 0 ? true : false} value={0} />
                    <i className="fa fa-barcode ml-1"></i>
                </div>
                <div class={`form-group mt-3 ${showHideQRCodeImage ? '' : 'hide-props'}`}>
                    <QRCode value={qrBarCodeValue} className="rounded card-img"
                        style={{ width: "30px", height: "30px" }} />
                    <button type="button" className="btn btn-sm bg-light mb-3 ml-1" onClick={changeState}>
                        <i className="fa fa-times text-danger text-center"></i></button>
                </div>
                <div class={`form-group mt-3 ${showHideTextbox ? '' : 'hide-props'}`}>
                    <input type="text" className="form-control form-control-sm" name="barCodeValue" value={barCodeValue}
                        onChange={(e) => onInputChange(e.target.value)} />
                    <button type="button" className="btn btn-sm bg-light ml-3 mt-1" onClick={changeStateForTextBox}>
                        <i className="fa fa-times text-danger text-center"></i></button>
                </div>

            </>
        )
    }

    const onInputChange = (v) => {
        setBarCodeValue(v);
    }

    const changeState = () => {
        setShowHideQR(true);
        setisQrCode('');
        setShowHideQRCodeImage(false);
    }

    const changeStateForTextBox = () => {
        setShowHideQR(true);
        setisQrCode('');
        setShowHideTextbox(false);
    }

    const onRadioClick = (e, cell) => {
        if (cell.data?.package_id) {
            if (e.target.value === "1") {
                if (cell.values[0] && cell.values[1]) {
                    setQrBarCodeValue(cell.values[0] + '-' + cell.values[1]);
                    setisQrCode(1);
                    setShowHideQR(true);
                    setShowHideTextbox(false);
                    setShowHideQRCodeImage(true);
                } else {
                    toast.error(<AlertMessage type="error" title="Generate QR Code" message="Please fill package name and size." />, { autoClose: false });
                }
            } else {
                setisQrCode(0);
                setShowHideTextbox(true);
                setShowHideQR(false);
                setShowHideQRCodeImage(false);
            }
            setpackageId(cell.data.package_id);
            //alert(e.target.value + '-' + cell.data.package_id)
        } else {
            if (e.target.value === "1") {
                if (cell.values[0] && cell.values[1]) {
                    setQrBarCodeValue(cell.values[0] + '-' + cell.values[1])
                    setisQrCode(1);
                    setShowHideTextbox(false);
                    setShowHideQR(false);
                    setShowHideQRCodeImage(true);
                } else {
                    clearState();
                    toast.error(<AlertMessage type="error" title="Generate QR Code" message="Please fill package name and size." />, { autoClose: false });
                }
            } else {
                setShowHideTextbox(true);
                setShowHideQR(false);
                setisQrCode(0);
                setShowHideQRCodeImage(false);
            }
            console.log(e.target.value)
        }
    }

    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <h4> Packages </h4>
            </Navbar>
            {/* <PackageSkelton /> */}
            <Container className="mb-5">
                <Row>
                    <Col lg={12} className="warehouse-margin mt-3 mb-1">
                        <p>You can define package types here. </p>
                    </Col>
                </Row>

                <Card className="mb-3" className="margin-list">
                    <CardBody>
                        <h5 className='ml-3'>Manage Packages</h5>
                        <Row>
                            <Col className='ml-5'>
                                <div className="container-fluid margin-bottoms" >
                                    <ButtonGroup className="float-right margin-bottoms" >
                                        <Button outline onClick={() => _SingleRow()} className='ml-2'>
                                            <i className="fa fa-fw fa-plus"></i>
                                        </Button>
                                    </ButtonGroup>
                                </div>
                            </Col>
                        </Row>
                        <div className="container-fluid">
                            <iframe name="labeliframe" id='labeliframe' title='labeliframe'
                                src={iframeurl}
                                className='hide-props'
                            ></iframe>
                            <DataGrid id="grid-container"
                                dataSource={package_data}
                                keyExpr="package_id"
                                ref={datagridRef}
                                showBorders={true}
                                onSaving={onSaving}
                                rowAlternationEnabled={true}
                                onToolbarPreparing={(e) => {
                                    e.toolbarOptions.visible = false
                                }}
                                onCellPrepared={(e) => {
                                    if (e.rowType == 'header' && e.column.command == "edit") {
                                        e.cellElement.innerHTML = "<b>Action</b>";
                                    }
                                    // if (e.rowType === 'data' && e.column.name === 'package_image') {
                                    //     if (!rowAdding && e.data?.package_id === undefined) {
                                    //         e.cellElement.innerHTML = '';
                                    //     }
                                    //     if ((!rowEditing && packageId === e.key)) {
                                    //         e.cellElement.innerHTML = '';
                                    //     }
                                    // }
                                }}
                                onInitNewRow={(e) => {
                                    setpackageId(0);
                                    setisQrCode('');
                                    setRowAdding(true);
                                }}
                                onEditingStart={(e) => {
                                    setisQrCode(e.data.is_qr)
                                    setpackageId(e.key);
                                    setRowEditing(true);
                                    console.log("editing start", e)
                                }}
                                onRowRemoving={(e) => {
                                    console.log('onrowremoving')
                                    e.cancel = true;
                                }}
                            >
                                <Editing
                                    mode='row'
                                    useIcons={true}
                                    allowAdding={true}
                                    allowUpdating={true}
                                    allowDeleting={true}
                                    confirmDelete={false}
                                ></Editing>
                                <Column dataField="package_name" caption="Package Name" allowSorting={true}>
                                    <RequiredRule />
                                </Column>
                                <Column dataField="package_size" caption="Size" allowSorting={true}>
                                    <RequiredRule />
                                </Column>
                                <Column dataField="package_image" caption="Image" allowSorting={false} alignment="center"
                                    cellRender={renderFileUploader} editCellRender={editCellFileuploaderRender} >
                                </Column>
                                <Column dataField="length" caption={`Lenght (${unitOfMeasures}.)`} allowSorting={false}>
                                    <RequiredRule />
                                </Column>
                                <Column dataField="width" caption={`Width (${unitOfMeasures}.)`} allowSorting={false}>
                                    <RequiredRule />
                                </Column>
                                <Column dataField="height" caption={`Height (${unitOfMeasures}.)`} allowSorting={false}>
                                    <RequiredRule />
                                </Column>
                                <Column dataField="standard_rate" caption="Standard Rate" allowSorting={true} >
                                    <RequiredRule />
                                </Column>
                                <Column dataField="qr_bar_code_value" caption="Bar code value" allowSorting={true}
                                    cellRender={renderRadioButtons} editCellRender={editCellRenderQrCode} >
                                </Column>
                            </DataGrid>
                            <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this package?`}
                                onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete Package" />
                        </div>
                    </CardBody>
                </Card>
            </Container>
        </>
    )
}

export default Package 