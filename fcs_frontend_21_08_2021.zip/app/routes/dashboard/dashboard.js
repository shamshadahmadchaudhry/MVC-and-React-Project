import React, {useEffect} from 'react';
import {
    Container
} from '../../components';
import { CompanyListingRequest, CompanyListingUpdateRequest } from '../../redux/actions';
import { useSelector, useDispatch } from "react-redux"

const Dashboard = () => {
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(CompanyListingRequest())
    }, [])
    return (
        <Container style={{ paddingLeft: "27%", paddingRight: "27%", paddingTop: "10%" }}>

        </Container>

    )
}
export default Dashboard;
