import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { LogoThemed } from './../../components/LogoThemed/LogoThemed';

const ResetPasswordErrorHeaderAuth = (props) => (
    <div className="mb-4">
        <div className="mb-4 text-center">
            <Link to="#" className="d-inline-block">
                {
                    props.icon ? (
                        <i className={`fa fa-${props.icon} fa-3x ${props.iconClassName}`}></i>
                    ) : (
                            <>
                                <LogoThemed checkBackground />
                                <br />
                                <i className="fa fa-close" style={{ fontSize: "50px", color: "red" }}></i>
                            </>
                        )
                }
            </Link>
        </div>
        <h5 className="text-center mb-4">
            {props.title}
        </h5>
        <p className="text-center">
            {props.text}
        </p>
    </div>
)
ResetPasswordErrorHeaderAuth.propTypes = {
    icon: PropTypes.node,
    iconClassName: PropTypes.node,
    title: PropTypes.node,
    text: PropTypes.node,
};
ResetPasswordErrorHeaderAuth.defaultProps = {
    title: "Waiting for Data...",
    text: " Enter the email you used to sign-in to the system.We will send you an email with the link to reset your password.",
    iconClassName: "text-theme"
};

export { ResetPasswordErrorHeaderAuth };
