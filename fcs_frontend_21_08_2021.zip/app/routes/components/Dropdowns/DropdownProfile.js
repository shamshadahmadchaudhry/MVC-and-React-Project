import React from 'react'; 
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

import { 
    DropdownMenu,
    DropdownItem
} from './../../../components';

const DropdownProfile = (props) => (
    <React.Fragment>
        <DropdownMenu right={ props.right } > 
            <DropdownItem tag={ Link } to="/apps/profile-details">
            <i className="fa fa-fw fa-user mr-2"></i>
                My Profile
            </DropdownItem>
            <DropdownItem tag={ Link } to="/apps/settings-edit">
            <i className="fa fa-fw fa-cog mr-2"></i>
                Change Password
            </DropdownItem>  
            <DropdownItem tag={ Link } to="/Account/login">
                <i className="fa fa-fw fa-sign-out mr-2"></i>
                Sign Out
            </DropdownItem>
        </DropdownMenu>
    </React.Fragment>
)
DropdownProfile.propTypes = {
    position: PropTypes.string,
    right: PropTypes.bool
};
DropdownProfile.defaultProps = {
    position: ""
};

export { DropdownProfile };
