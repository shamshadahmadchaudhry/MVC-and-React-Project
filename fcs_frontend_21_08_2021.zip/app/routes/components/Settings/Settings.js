import React from 'react'; 
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

import { 
    DropdownMenu,
    DropdownItem,
    NestedDropdown, 
    DropdownToggle
} from './../../../components';

const Settings = (props) => (
    <React.Fragment>
        <DropdownMenu right={ props.right } >  
            <DropdownItem tag={ Link } to="/apps/profile-details">
              Order Management
            </DropdownItem>
            <DropdownItem tag={ Link } to="/apps/settings-edit">
              User-Management Group Management
            </DropdownItem>   
                <NestedDropdown.Submenu title=" Trip Management">
                    <DropdownItem tag={ Link } to="/apps/projects/list">Projects List</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/projects/grid">Projects Grid</DropdownItem>
                </NestedDropdown.Submenu> 
            <DropdownItem tag={ Link } to="/apps/billing-edit">
               Product Management
            </DropdownItem> 
            <DropdownItem tag={ Link } to="/apps/billing-edit">
               Bin Management
            </DropdownItem> 
            <DropdownItem tag={ Link } to="/apps/billing-edit">
               Tote Management
            </DropdownItem> 
            <DropdownItem tag={ Link } to="/apps/billing-edit">
               Rack Management
            </DropdownItem> 
            <DropdownItem tag={ Link } to="/apps/billing-edit">
               Zone Management
            </DropdownItem> 
            <DropdownItem tag={ Link } to="/apps/billing-edit">
               Box Management
            </DropdownItem> 
            <DropdownItem tag={ Link } to="/apps/billing-edit">
               User Management
            </DropdownItem> 
            <DropdownItem tag={ Link } to="/apps/billing-edit">
               User Security Management
            </DropdownItem> 
            <DropdownItem tag={ Link } to="/apps/billing-edit">
               Merchant Management
            </DropdownItem> 
            <DropdownItem tag={ Link } to="/apps/billing-edit">
               Inbound Shipment
            </DropdownItem>
            <DropdownItem tag={ Link } to="/apps/billing-edit">
                Automation Rule
            </DropdownItem>
        </DropdownMenu>
        <NestedDropdown nav inNavbar>
            <DropdownToggle nav>
                Apps
                <i className="fa fa-angle-down fa-fw ml-1"></i>
            </DropdownToggle>
            <DropdownMenu>
                <NestedDropdown.Submenu title="Projects">
                    <DropdownItem tag={ Link } to="/apps/projects/list">Projects List</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/projects/grid">Projects Grid</DropdownItem>
                </NestedDropdown.Submenu>
                <NestedDropdown.Submenu title="Tasks">
                    <DropdownItem tag={ Link } to="/apps/tasks/list">Tasks List</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/tasks/grid">Tasks Grid</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/tasks/kanban">Tasks Kanban</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/tasks/details">Task Details</DropdownItem>
                </NestedDropdown.Submenu>
                <NestedDropdown.Submenu title="Files">
                    <DropdownItem tag={ Link } to="/apps/files/list">Files List</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/files/grid">Files Grid</DropdownItem>
                </NestedDropdown.Submenu>
                <NestedDropdown.Submenu title="Search Results">
                    <DropdownItem tag={ Link } to="/apps/search-results">Search Results</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/images-results">Images Results</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/videos-results">Videos Results</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/users-results">Users Results</DropdownItem>
                </NestedDropdown.Submenu>
                <NestedDropdown.Submenu title="Users">
                    <DropdownItem tag={ Link } to="/apps/users/list">Users List</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/users/grid">Users Grid</DropdownItem>
                </NestedDropdown.Submenu>
                <NestedDropdown.Submenu title="Gallery">
                    <DropdownItem tag={ Link } to="/apps/gallery-grid">Gallery Grid</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/gallery-table">Gallery Table</DropdownItem>
                </NestedDropdown.Submenu>
                <NestedDropdown.Submenu title="Mailbox">
                    <DropdownItem tag={ Link } to="/apps/inbox">Inbox</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/new-email">New Email</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/email-details">Email Details</DropdownItem>
                </NestedDropdown.Submenu>
                <NestedDropdown.Submenu title="Profile">
                    <DropdownItem tag={ Link } to="/apps/profile-details">Profile Details</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/profile-edit">Profile Edit</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/account-edit">Account Edit</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/billing-edit">Billing Edit</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/settings-edit">Settings Edit</DropdownItem>
                    <DropdownItem tag={ Link } to="/apps/sessions-edit">Sessions Edit</DropdownItem>
                </NestedDropdown.Submenu>
                <DropdownItem tag={ Link } to="/apps/clients">Clients</DropdownItem>
                <DropdownItem tag={ Link } to="/apps/chat">Chat</DropdownItem>
            </DropdownMenu>
        </NestedDropdown>
    </React.Fragment>
)
Settings.propTypes = {
    position: PropTypes.string,
    right: PropTypes.bool
};
Settings.defaultProps = {
    position: ""
};

export { Settings };
 