import React from 'react';
import PropTypes from 'prop-types';

const FooterText = (props) => (
	<React.Fragment>
		<span>&#169;</span> { props.year} All rights reserved.
	</React.Fragment>
)
FooterText.propTypes = {
	year: PropTypes.node,
	name: PropTypes.node,
	desc: PropTypes.node,
};
FooterText.defaultProps = {
	year: "2020",
	name: "Shujabits Infotech Pvt. Ltd.",
};

export { FooterText };
