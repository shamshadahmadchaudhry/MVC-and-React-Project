import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom';
import { Formik, Form, ErrorMessage, Field } from 'formik';
import { FormGroup, InputGroupAddon, CustomInput, InputGroup, Label, EmptyLayout, ThemeConsumer, Button } from '../../../components';

import { HeaderAuth } from "../../components/Pages/HeaderAuth";
import { FooterAuth } from "../../components/Pages/FooterAuth";
import * as yup from 'yup';

import { Configuration } from '../../commoncomponents/configurationfile';
import FormikTextInput from '../../commoncomponents/formiktextinput';
import AlertMessage from '../../commoncomponents/alertmessage';

import ReCAPTCHA from "react-google-recaptcha";
import { toast, ToastContainer } from 'react-toastify';
import { LoginClean, LoginRequest, CompanyListingRequest } from '../../../redux/actions/index'
import LoginSkeleton from '../../skeletenview/loginskeleton';
const publicIp = require("react-public-ip");



const Login = (props) => {
    const dispatch = useDispatch()
    const LoginStatus = useSelector(state => state.LoginStatus)
    const [hidePass, setHidePass] = useState(true);
    const [captchaSiteKey, setCaptchaSiteKey] = useState('6LePVNoZAAAAAP9Qh8zqGbue_saydOtDy6xgeJmq');
    const [isCaptchaEnable, setIsCaptchEnabled] = useState(false);
    const [isCaptchaLogin, setIsCaptchLogin] = useState(false);
    const showHidePass = () => { setHidePass(!hidePass); }
    const isLogged = useSelector(state => state.LoginStatus && state.LoginStatus.loggedIn)
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus)
    const [rememberMe, setRememberMe] = useState(false)
    useEffect(() => {
        LoginClean()
    }, [])

    useEffect(() => {
        dispatch(CompanyListingRequest())
    }, [isLogged])

    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            if (localStorage.getItem("callBackUrl") != '' && localStorage.getItem("callBackUrl") != null
                && localStorage.getItem("callBackUrl") != '/account/login' &&
                localStorage.getItem("callBackUrl") != '/account/forgotpassword') {
                window.location = localStorage.getItem("callBackUrl")
            } else {
                window.location = '/companylisting'
            }
        } else if (CompanyListingStatus?.result?.response?.result.length == 1) {
            if (localStorage.getItem("callBackUrl") != '' && localStorage.getItem("callBackUrl") != null
                && localStorage.getItem("callBackUrl") != '/'
                && localStorage.getItem("callBackUrl") != '/account/login' &&
                localStorage.getItem("callBackUrl") != '/account/forgotpassword') {
                window.location = localStorage.getItem("callBackUrl")
            } else {
                window.location = '/Dashboard'
            }
        }
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    useEffect(() => {
        setIsCaptchEnabled(LoginStatus?.result?.failed_attempts > LoginStatus?.result?.max_failed_attempt)
    }, [LoginStatus?.result?.error])

    useEffect(() => {
        if (LoginStatus?.result?.failed_attempts >= LoginStatus?.result?.max_failed_attempt)

            setIsCaptchLogin(true);
        else
            setIsCaptchLogin(false);
        console.log(LoginStatus)
    }, [LoginStatus?.result?.failed_attempts >= LoginStatus?.result?.max_failed_attempt])


    useEffect(() => {
        if (LoginStatus.isError && LoginStatus?.result?.error) {
            LoginClean()
            setIsCaptchEnabled(true);
            toast.error(<AlertMessage type='error' title='Sign-in Failed.'
                message={Configuration.loginFailed} />, { deautoCloselay: false })

        } else if (LoginStatus.isSuccess) {
            LoginClean()
            toast.success(<AlertMessage type='success'
                title='Sign-in success'
                message='You have logged in successfully' />, { autoClose: 4000 })
        }
    }, [LoginStatus?.isError && LoginStatus?.result?.error])


    useEffect(() => {
        if (LoginStatus.loggedIn) {
            props.history.push('/companylisting');
        } else {
            props.history.push('/account/login');
        }
    }, [])

    const onChange = (value) => {
        if (value) {
            setIsCaptchLogin(false)
            //dispatch(LoginCaptcha())
            submitForm();
        }
    }

    const getClientMachineDetails = async () => {
        const clientMachineDetails = {
            ip_address: await publicIp.v4() || "",
            // mac_address: await publicIp.v6() || ""
        }
        return clientMachineDetails;
    }

    // Show red border if password invalid for passwword field
    let invalidPassword = {
        borderRadius: '3px',
        border: '1px solid',
        borderColor: '#ED1C24'
    };

    return (

        <EmptyLayout>
            <EmptyLayout.Section center>

                {/* Toster Message */}

                <>
                    <ToastContainer
                        draggable={false}
                        hideProgressBar={false}
                    />

                    { /* START Header */}
                    <HeaderAuth title="Sign-in to the application" text="Enter your e-mail and password to sign-in to the application" />
                    { /* END Header */}
                    { /* START Form */}
                    <Formik
                        initialValues={{ email: '', password: '', rememberPassword: false }}
                        validationSchema={yup.object().shape({
                            email: yup.string().required(`${Configuration.required} e-mail`)
                                .matches(Configuration.emailpattern, Configuration.invalidemail),
                            //password: yup.string().required(`${Configuration.required} password.`)

                            password: yup.string().nullable().required(`${Configuration.required} password.`)
                                .matches(
                                    Configuration.password,
                                    `${Configuration.passwordmessage}`
                                ),
                        })
                        }
                        onSubmit={async (values) => {
                            let machinedeatails = await getClientMachineDetails()
                            values.isCaptchaEnabled = isCaptchaEnable;
                            values.rememberPassword = rememberMe;
                            dispatch(LoginRequest({ ...values, ...machinedeatails }))
                        }}
                    >
                        {({ errors, touched }) => (
                            <Form>
                                <FormGroup>
                                    <Label for="emailAdress">E-mail</Label>
                                    <FormikTextInput type="email"
                                        placeholder="Enter e-mail"
                                        name="email"
                                        isError={touched.email && errors.email} />
                                </FormGroup>
                                <FormGroup>
                                    <Label for="password">Password</Label>
                                    <InputGroup style={touched.password && errors.password && invalidPassword} >
                                        <Field type={hidePass ? "password" : "text"}
                                            name="password"
                                            className='bg-white form-control'
                                            placeholder="Enter password" />
                                        <InputGroupAddon addonType="append" onClick={showHidePass} >
                                            <i className={hidePass ? 'fa fa-eye' : 'fa fa-eye-slash'}></i>
                                        </InputGroupAddon>
                                    </InputGroup>
                                    {touched.password && errors.password &&
                                        <ErrorMessage name="password" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                <FormGroup>
                                    <CustomInput type="checkbox" value={rememberMe} onChange={(e) => setRememberMe(!rememberMe)} id="rememberPassword" name="rememberPassword" label="Remember Me" inline />
                                </FormGroup>
                                <FormGroup >
                                    {
                                        // failedCount >= Configuration.reCaptchaCount &&
                                        LoginStatus?.result?.failed_attempts >= LoginStatus?.result?.max_failed_attempt &&
                                        isCaptchaEnable &&
                                        <ReCAPTCHA
                                            sitekey={captchaSiteKey}
                                            //onChange={e => onChange(e, submitForm)}
                                            onChange={onChange}
                                        />
                                    }

                                </FormGroup>
                                <FormGroup>
                                    <ThemeConsumer>
                                        {
                                            ({ color }) => (
                                                <Button className="align-self-center btn-block"
                                                    style={{ backgroundColor: Configuration.BackgroundColor, color: Configuration.Color, borderColor: Configuration.BorderColor }}
                                                    disabled={LoginStatus.isLoading || isCaptchaLogin} >
                                                    Sign-In {LoginStatus.isLoading && (
                                                        <i
                                                            className="fa fa-spinner fa-spin"
                                                            style={{ marginRight: "5px" }}
                                                        />
                                                    )}
                                                </Button>
                                            )
                                        }
                                    </ThemeConsumer>
                                </FormGroup>
                            </Form>
                        )}
                    </Formik>
                    { /* END Form */}
                    { /* START Bottom Links */}
                    <div className="d-flex mb-5">

                        <Link to="/account/forgotpassword" className="text-decoration-none">
                            Forgot Password
                </Link>
                    </div>
                    { /* END Bottom Links */}
                    { /* START Footer */}
                    <FooterAuth />
                </>


                { /* END Footer */}
            </EmptyLayout.Section>
        </EmptyLayout >

    )

}

export default Login;
