import ForgotPassword from "./forgotpassword";

export default ForgotPassword;
