import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom';
import {
    FormGroup,
    Label,
    EmptyLayout,
    ThemeConsumer,
    Button

} from '../../../components';
import { HeaderAuth } from "../../components/Pages/HeaderAuth";
import { FooterAuth } from "../../components/Pages/FooterAuth";
import { ToastContainer, toast } from 'react-toastify';
import { Formik, Form, } from 'formik';
import * as yup from 'yup';
import { Configuration } from '../../commoncomponents/configurationfile';
import FormikTextInput from '../../commoncomponents/formiktextinput';
import ReCAPTCHA from "react-google-recaptcha";
import AlertMessage from '../../commoncomponents/alertmessage';
import { ForgetPasswordRequest } from '../../../redux/actions/index';
import '../../../styles/common.scss';

const ForgotPassword = () => {
    const dispatch = useDispatch()
    const ForgetPasswordStatus = useSelector(state => state.ForgetPasswordStatus)
    const [loader, setLoader] = useState(false);
    const [captchaSiteKey, setCaptchaSiteKey] = useState('6LePVNoZAAAAAP9Qh8zqGbue_saydOtDy6xgeJmq');
    // ============ This code is used for the count check =============
    const onChange = (value) => {
        setLoader(false);
    }
    useEffect(() => {
        if (ForgetPasswordStatus?.resetCount > 5) {
            setLoader(true)
        }
    }, [ForgetPasswordStatus?.resetCount])

    useEffect(() => {
        if (ForgetPasswordStatus.isSuccess && ForgetPasswordStatus?.data?.response?.data?.code === 200) {
            //setIsSuccessToast(!isSuccessToast)
            toast.success(<AlertMessage type='success'
                title='Mail sent'
                message={ForgetPasswordStatus?.data?.response?.data?.data} />, { autoClose: 4000 })
            ForgetPasswordStatus.isSuccess = false
            ForgetPasswordStatus.resetCount = 0
        }

        if (ForgetPasswordStatus.isSuccess && ForgetPasswordStatus?.data?.response?.data?.error) {
            //setIsSuccessToast(false)
            console.log('Invalid Details', ForgetPasswordStatus?.data?.error)
            toast.error(<AlertMessage type='error'
                title='Invalid details.'
                message={ForgetPasswordStatus?.data?.response?.data?.Message} />, { autoClose: false })
        }

    }, [ForgetPasswordStatus.isSuccess])

    return (

        <EmptyLayout>
            <EmptyLayout.Section center>
                { /* START Header */}
                <HeaderAuth title="Forgot password" />
                <p className="text-center">
                    Enter the email you used to sign-in to the system.
                    </p>
                <p className="text-center forgot-password-margin-top" >
                    We will send you an email with the link to reset your password.
        </p>
                { /* END Header */}
                { /* START Form */}
                {/*==== This code is used for the form validation and submitting the data =====*/}
                <Formik
                    initialValues={{ email: '', rememberPassword: false }}
                    validationSchema={yup.object().shape({
                        email: yup.string().required(`${Configuration.required} e-mail`).matches(Configuration.emailpattern, Configuration.invalidemail),
                    })
                    }
                    onSubmit={(values) => {
                        // values.newPassword = "new123"
                        dispatch(ForgetPasswordRequest(values))
                        console.log('SMTP Failed 2=>:', ForgetPasswordStatus?.result);
                    }
                    }
                >
                    {({ errors, touched }) => (
                        <Form className="mb-3">
                            <FormGroup>
                                <Label for="emailAdress">
                                    E-mail
                        </Label>
                                <FormikTextInput type="email"
                                    placeholder="Enter e-mail"
                                    name="email"
                                    isError={touched.email && errors.email} />
                            </FormGroup>
                            <FormGroup >
                                {
                                    ForgetPasswordStatus?.resetCount >= 5 &&
                                    <ReCAPTCHA
                                        sitekey={captchaSiteKey}
                                        onChange={onChange}
                                    />
                                }

                            </FormGroup>

                            <ThemeConsumer>
                                {
                                    ({ color }) => (
                                        <Button type="submit" className="align-self-center btn-block" disabled={loader}
                                            style={{ backgroundColor: Configuration.BackgroundColor, color: Configuration.Color, borderColor: Configuration.BorderColor }}
                                        >
                                            Reset Password<span> </span>
                                            {ForgetPasswordStatus.isLoading && (
                                                <i
                                                    className="fa fa-spinner fa-spin"
                                                    style={{ marginRight: "5px" }}
                                                />
                                            )}</Button>
                                    )
                                }
                            </ThemeConsumer>
                        </Form>
                    )}
                </Formik>
                { /* END Form */}
                { /* START Bottom Links */}
                <div className="d-flex mb-5">
                    <Link to="/Account/login" className="text-decoration-none">
                        Sign-in
                    </Link>
                </div>
                { /* END Bottom Links */}
                { /* START Footer */}
                <FooterAuth />
                { /* END Footer */}
            </EmptyLayout.Section>
            <ToastContainer
                position={'top-right'}
                draggable={false}
                hideProgressBar={true}
            />
        </EmptyLayout>
    )
}

export default ForgotPassword;
