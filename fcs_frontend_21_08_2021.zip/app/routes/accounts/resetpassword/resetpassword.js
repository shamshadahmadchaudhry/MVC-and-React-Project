import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import {
    FormGroup,
    InputGroupAddon,
    InputGroup,
    Label,
    EmptyLayout,
} from '../../../components';
import { HeaderAuth } from "../../components/Pages/HeaderAuth";
import { FooterAuth } from "../../components/Pages/FooterAuth";
import HostUrl from '../../commoncomponents/fulfyldwmsurls.json';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import { Formik, Form, ErrorMessage, Field } from 'formik';
import * as yup from 'yup';
import { Configuration } from '../../commoncomponents/configurationfile';
import { useHistory } from 'react-router-dom';
import ResetPasswordMessage from './restpasswordmessage';
import AlertMessage from '../../commoncomponents/alertmessage';
import { ResetPasswordClean, ResetPasswordRequest } from '../../../redux/actions';
import { checkLinkValidation } from '../../../services/profileservice';

const ResetPassword = (props) => {
    const dispatch = useDispatch()
    const history = useHistory();
    const ResetPasswordStatus = useSelector(state => state.ResetPasswordStatus)
    const [hidePass, setHidePass] = useState(true);
    const [hideConfirmPass, setHideConfirmPass] = useState(true);
    const [loader, setLoader] = useState(false);
    const showHidePass = () => { setHidePass(!hidePass); }
    const showHideConfirmPass = () => { setHideConfirmPass(!hideConfirmPass); }

    const handleReset = (values) => {
        console.log('Data: ', values);
        let payload = {
            token: props.match.params.token,
            unique_id: props.match.params.key,
            password: values.password
        }
        dispatch(ResetPasswordRequest(payload))
    }
    useEffect(() => {
        ResetPasswordStatus?.data?.error && history.push("/account/login")
    }, [ResetPasswordStatus])

    useEffect(() => {
        if (window?.location?.pathname) {
            async function getDataFunction() {
                const queryString = window.location.pathname.substring(1).split('/');
                const result = await checkLinkValidation({ unique_id: queryString[2], user_token: queryString[1] })
                // If User link expired redirect on resetpassworderror page
                if (result?.data?.error) {
                    console.log('Query String:', result);
                    history.push("/account/resetpassworderror")
                }
            }
            getDataFunction()
        }

    }, [])

    if (ResetPasswordStatus.isSuccess && ResetPasswordStatus?.data?.response?.error === false) {
        toast.success(<AlertMessage type='success'
            title='Password Updated'
            message={ResetPasswordStatus?.data?.response?.message} />)
        history.push("/")
    } else if (ResetPasswordStatus?.data?.response?.error === true) {
        // history.push("/account/resetpassworderror")
    }

    // Show red border if password invalid for passwword field
    let invalidPassword = {
        borderRadius: '3px',
        border: '1px solid',
        borderColor: '#ED1C24'
    };

    return (

        <EmptyLayout>
            <EmptyLayout.Section center>
                { /* START Header */}
                <HeaderAuth
                    title="Reset Password"
                    text="Set a new password to regain access to the application"
                />
                { /* END Header */}
                { /* START Form */
                }
                {/*==== This code is used for the form validation and submitting the data =====*/}
                <Formik
                    initialValues={{ password: '', confirmpassword: '', rememberPassword: false }}
                    validationSchema={yup.object().shape({
                        password: yup.string().required(`${Configuration.required} password.`)
                            .matches(Configuration.password, `${Configuration.passwordmessage}`),
                        confirmpassword: yup.string().when("password", {
                            is: val => (val && val.length > 0 ? true : false),
                            then: yup.string().oneOf(
                                [yup.ref("password")],
                                "Both password fields need to be the same"
                            )
                        }).required('Confirm password is required')
                    })
                    }
                    onSubmit={(values) => {
                        handleReset(values)
                        //dispatch(ResetPasswordRequest(values))
                    }}

                >
                    {({ errors, touched }) => (
                        <Form className="mb-3">
                            <FormGroup>
                                <Label for="newPassword">
                                    New Password
                        </Label>
                                <InputGroup style={touched.password && errors.password && invalidPassword}>
                                    <Field type={hidePass ? "password" : "text"}
                                        name="password"
                                        className={`bg-white form-control`}
                                        placeholder="Enter password" />
                                    <InputGroupAddon addonType="append" onClick={showHidePass}>
                                        <i className={hidePass ? 'fa fa-eye' : 'fa fa-eye-slash'}></i>
                                    </InputGroupAddon>
                                </InputGroup>
                                {touched.password && errors.password &&
                                    <ErrorMessage name="password" component="span" className="text-danger"></ErrorMessage>
                                }
                            </FormGroup>
                            <ResetPasswordMessage />
                            <FormGroup>
                                <Label for="confirmPassword">
                                    Confirm new Password
                        </Label>
                                <InputGroup style={touched.confirmpassword && errors.confirmpassword && invalidPassword}>
                                    <Field type={hideConfirmPass ? "password" : "text"}
                                        name="confirmpassword"
                                        className={`bg-white form-control`}
                                        placeholder="Re-enter new password" />
                                    <InputGroupAddon addonType="append" onClick={showHideConfirmPass}>
                                        <i className={hideConfirmPass ? 'fa fa-eye' : 'fa fa-eye-slash'}></i>
                                    </InputGroupAddon>
                                </InputGroup>
                                {touched.confirmpassword && errors.confirmpassword &&
                                    <ErrorMessage name="confirmpassword" component="span" className="text-danger"></ErrorMessage>
                                }
                            </FormGroup>
                            <div className="d-flex">
                                <button type="submit" className="btn btn-warning btn-block" disabled={loader}
                                    style={{ backgroundColor: Configuration.BackgroundColor, color: Configuration.Color, borderColor: Configuration.BorderColor }}
                                >
                                    Reset Password<span> </span>
                                    {loader && (
                                        <i
                                            className="fa fa-spinner fa-spin"
                                            style={{ marginRight: "5px" }}
                                        />
                                    )}</button>
                            </div>
                        </Form>
                    )}
                </Formik>
                { /* END Form */}
                { /* START Footer */}
                <FooterAuth />
                { /* END Footer */}
            </EmptyLayout.Section>
            <ToastContainer
                position={'top-right'}
                autoClose={ResetPasswordStatus.isSuccess && ResetPasswordStatus?.data?.response?.error ? false : 4000}
                draggable={false}
                hideProgressBar={true}
            />
        </EmptyLayout>
    )
}

export default ResetPassword;
