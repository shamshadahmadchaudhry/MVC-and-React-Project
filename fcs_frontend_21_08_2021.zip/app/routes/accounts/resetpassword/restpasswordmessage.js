import React from 'react';
import {
    FormText
} from '../../../components';

const ResetPasswordMessage = () => {

    return (
        <>
            <FormText color="muted">
                <span>Enter a strong password that has</span>
                <ul>
                    <li>length of 8 to 32 characters</li>
                    <li>atleast one number</li>
                    <li>atleast one uppercase character</li>
                    <li>atleast one lowercase character</li>
                    <li>atleast one special character</li>
                </ul>
            </FormText>
        </>
    )

}
export default ResetPasswordMessage;