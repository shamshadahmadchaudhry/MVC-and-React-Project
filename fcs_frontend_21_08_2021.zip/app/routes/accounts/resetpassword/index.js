import ResetPassword from './resetpassword';

export default ResetPassword;