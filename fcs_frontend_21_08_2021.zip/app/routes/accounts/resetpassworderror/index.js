import ResetPasswordError from './resetpassworderror';

export default ResetPasswordError;