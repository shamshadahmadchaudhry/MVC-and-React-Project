import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
    EmptyLayout,
} from '../../../components';
import { ResetPasswordErrorHeaderAuth } from "../../components/Pages/ResetPasswordErrorHeaderAuth";
import { FooterAuth } from "../../components/Pages/FooterAuth";

const ResetPasswordError = () => {
    return (

        <EmptyLayout>

            <EmptyLayout.Section center>
                { /* START Header */}


                <ResetPasswordErrorHeaderAuth

                    title="The password reset link has expired."
                    text="Oops! Something went wrong!"

                />

                <div className="mb-5" style={{ textAlign: "center" }}>
                    <Link to="/Account/ForgotPassword" className="text-decoration-none">
                        <i className="fa fa-angle-left"></i> Go to Forgot password
                    </Link>
                </div>
                { /* END Bottom Links */}
                { /* START Footer */}
                <FooterAuth />
                { /* END Footer */}
            </EmptyLayout.Section>
        </EmptyLayout>
    )
}

export default ResetPasswordError;
