import React, {useEffect, useState} from 'react';
import {
    FormGroup,
    InputGroupAddon,
    InputGroup,
    Label,
    EmptyLayout,
    ThemeConsumer,
    Button,
    CustomInput
} from '../../../components';
import {Redirect} from 'react-router-dom';
import { HeaderAuth } from "../../components/Pages/HeaderAuth"; 
import { FooterAuth } from "../../components/Pages/FooterAuth";
import { CONFIG } from "../../../config";
import { Configuration } from '../../commoncomponents/configurationfile';
import '../../../styles/common.scss'; 
import { Formik, Form, Field, ErrorMessage, useFormikContext } from 'formik';
import * as yup from 'yup';
import ResetPasswordMessage from '../../../routes/accounts/resetpassword/restpasswordmessage'; 
import {userAccountDetails_Service, userAccountUpdate_Service} from '../../../services/accountservice';
import { ToastContainer, toast } from 'react-toastify';
import AlertMessage from '../../commoncomponents/alertmessage';
import {useDispatch} from 'react-redux';

const CreaateAccount = (props) => {
    //If user is logged in, redirect to dashboard
    if(localStorage.getItem('token')){
        window.location='/dashboard'
    }
    const dispatch = useDispatch()
    let emailid = props.match.params.email;
    let token = props.match.params.token
    const [hidePass, setHidePass] = useState(true);
    const [hideConfirmPass, setHideConfirmPass] = useState(true);
    const [accountData, setaccountData] = useState({first_name:'',last_name:'',phone_number:'',
                                                    new_password:'',confirm_new_password:''})  
    const [image, setImage] = useState('')
    const [email, setEmail] = useState('')
    const [imagename, setImageName] = useState('')
    const [imagevalue, setImageValue] = useState('')
    const [loader, setLoader] = useState(false);
    const [changeimage, setchangeImage] =useState('')
    const [agreed,setAgreed] = useState(false); 
    const [done,setDone] = useState(false);
    
    const showHidePass = () => { setHidePass(!hidePass); }
    const showHideConfirmPass = () => { setHideConfirmPass(!hideConfirmPass); }
    useEffect(()=>{
        loadaccountDetails()
    },[])

const loadaccountDetails = async () =>{
    debugger;
    const result = await userAccountDetails_Service(emailid)
    let data = result.data.result;
    setImage(data.profile_img_path)
    setEmail(data.email) 
    setaccountData({first_name:data.first_name,last_name:data.last_name,
    phone_number:data.phone_number,new_password:'',confirm_new_password:''});
    setchangeImage('')
}

const RedirectHome = () =>{
    return(<Redirect to='/acount/login'/>)
}
useEffect(()=>{
    RedirectHome();
},[done])
    const handleChange = (e) => {
        let file_size = e.target.files[0].size;
        if (parseInt(file_size) <= 25000) {
            const image = e.target.files[0]; 
            setImageName(image.name);
            setImageValue(image); 
            const url = URL.createObjectURL(e.target.files[0]);
            setchangeImage(url)
        } else {
            toast.error(<AlertMessage type='error' title='Profile Validation'
                message='File size should be 25kb/less than 25kb' />, { autoClose: false })
        }
    }
    //
   const  _handleagreed = (e)=>{
        var checked = e.target.checked;
        setAgreed(checked);
      }
    const CreateAccount = async (values) =>{
        setLoader(true)
        if(values.new_password === values.confirm_new_password){
            if(agreed){
            // let form_data = new FormData();
            // form_data.append('email', email);
            // form_data.append('name', imagename);
            // form_data.append('image', imagevalue);
            // form_data.append('first_name', values.first_name);
            // form_data.append('last_name', values.last_name);
            // form_data.append('phone_number', values.phone_number);
            // form_data.append('new_password', values.new_password);
            // form_data.append('confirm_new_password', values.confirm_new_password);
            let details = {
                'first_name':values.first_name,
                'last_name':values.last_name,
                'phone_number':values.phone_number,
                'email':email,
                'password':values.new_password,
                'is_active':1
            }
            const result = await userAccountUpdate_Service(details)
            toast.success(<AlertMessage type='success' title='Account created'
                message='You will be redirected to login shortly' />, { autoClose: false })
                setTimeout(() => {
                    setLoader(false);
                }, 4000);
                loadaccountDetails();
                setDone(true)
                setTimeout(() => {
                    window.location = '/account/login'
                }, 5000);
                
        }
        else{
            toast.warning(<AlertMessage type='warning' title='Create Account Failed'
            message={'You must agree with the terms and condition to create an account.'} />, { autoClose: 4000 })
        setTimeout(() => {
            setLoader(false);
        }, 2000);
        }
        }else{
            toast.error(<AlertMessage type='warning' title='Create Account Failed'
            message={'Confirm password does not match with new password. Enter confirm password same as new password.'} />, { autoClose: 4000 })
        setTimeout(() => {
            setLoader(false);
        }, 2000); 
        }
       
    }
    //If user is logged in, redirect to dashboard
    return (
        <EmptyLayout>
            <EmptyLayout.Section center>
                <HeaderAuth className="maargin-top"
                    title="Create Account"
                    text="Let's get started with the set-up of you user profile "
                />
                <div className="create-account-align-img">
                    {changeimage === ''?(
                    <img className="img-profile"
                    src={
                    image === null
                    || image === ''
                    || image === undefined
                    ? CONFIG.BASE_URL + Configuration.blankImagePath + ''
                    : CONFIG.BASE_URL + image + '?' + Date.now()
                    } />
                    ):(
                    <img className="img-profile"
                    src={
                    changeimage
                    } />

                    )}
                       
                           
                    
                </div>
                <div className="image-upload create-account-align-img" >
                    <label htmlFor="file-input">
                        <a className="create-account-align-img"> Upload picture
               
                        </a>
                        </label>
                        <input id="file-input" type="file" onChange={handleChange}/>
                   
                </div>
                <div className="create-account-align-img">
                {email === null
                || email === ''
                || email === undefined
                ? 'someone@example.com'
                :email}
                </div>
                <Formik
                initialValues={accountData}
                validationSchema={yup.object().shape({
                    first_name: yup.string().nullable().required(`${Configuration.required} first name`),
                    last_name: yup.string().nullable().required(`${Configuration.required} last name`),
                    phone_number: yup.string().nullable().required(`${Configuration.required} contact number`),
                    new_password: yup.string().nullable().required(`${Configuration.required} new password`).matches(
                        Configuration.password,
                        `${Configuration.passwordmessage}`
                    ),
                    confirm_new_password: yup.string().nullable().required(`${Configuration.required} confirm new password`).matches(
                        Configuration.password,
                        `${Configuration.passwordmessage}`
                    ),
                    
                })
                }
                onSubmit={CreateAccount}
                enableReinitialize={true}
            >
                {({ errors, touched, values }) => (
                    <Form>
                        <FormGroup>
                    <Label for="firstname">
                        First Name <span className="text-danger">*</span>
                    </Label>
                    <Field type="text"
                        placeholder="Enter first name"
                        name="first_name"
                        value={values.first_name}
                        className={`${touched.first_name && errors.first_name && 'is-invalid'} bg-white form-control`} />
                    {touched.first_name && errors.first_name &&
                        <ErrorMessage name="first_name" component="span" className="text-danger"></ErrorMessage>
                    }

                </FormGroup>
                <FormGroup>
                    <Label for="lastname">
                        Last Name <span className="text-danger">*</span>
                    </Label>
                    <Field type="text"
                        placeholder="Enter last name"
                        name="last_name"
                        value={values.last_name}
                        className={`${touched.last_name && errors.last_name && 'is-invalid'} bg-white form-control`} />
                    {touched.last_name && errors.last_name &&
                        <ErrorMessage name="last_name" component="span" className="text-danger"></ErrorMessage>
                    }

                </FormGroup>
                <FormGroup>
                    <Label for="contactnumber">
                        Contact Number <span className="text-danger">*</span>
                    </Label>
                    <Field type="text"
                        placeholder="Enter contact number"
                        name="phone_number"
                        value={values.phone_number}
                        className={`${touched.phone_number && errors.phone_number && 'is-invalid'} bg-white form-control`} />
                    {touched.phone_number && errors.phone_number &&
                        <ErrorMessage name="phone_number" component="span" className="text-danger"></ErrorMessage>
                    }

                </FormGroup>
                <FormGroup>
                                    <Label for="newpassword">
                                        New Password <span className="text-danger">*</span>
                                    </Label>
                                    <InputGroup>
                                        <Field type={hidePass ? "password" : "text"}
                                            name="new_password"
                                            className={`${touched.new_password && errors.new_password && 'is-invalid'} bg-white form-control`}
                                            placeholder="Enter new password" />
                                        <InputGroupAddon addonType="append" onClick={showHidePass}>
                                            <i className={hidePass ? 'fa fa-eye' : 'fa fa-eye-slash'}></i>
                                        </InputGroupAddon>
                                    </InputGroup>
                                    {touched.new_password && errors.new_password &&
                                        <ErrorMessage name="new_password" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                <ResetPasswordMessage />
                                <FormGroup>
                                <Label for="confirmnewpassword">
                                        Confirm New Password <span className="text-danger">*</span>
                                    </Label>
                                    <InputGroup>
                                        <Field type={hideConfirmPass ? "password" : "text"}
                                            name="confirm_new_password"
                                            className={`${touched.confirm_new_password && errors.confirm_new_password && 'is-invalid'} bg-white form-control`}
                                            placeholder="Enter new password" />
                                        <InputGroupAddon addonType="append" onClick={showHideConfirmPass}>
                                            <i className={hideConfirmPass ? 'fa fa-eye' : 'fa fa-eye-slash'}></i>
                                        </InputGroupAddon>
                                    </InputGroup>
                                    {touched.confirm_new_password && errors.confirm_new_password &&
                                        <ErrorMessage name="confirm_new_password" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                <FormGroup>
                                            
                                            <input type="checkbox" name="agree_terms" className="form-control-label" onChange={_handleagreed}/>
                                            <label className="ml-2">I accept the <a href={'/account/termsofuse'} target={'_blank'} >terms of use</a>
                                            </label>
                                        </FormGroup>
                                <ThemeConsumer>
                                                {
                                                    ({ color }) => (
                                                        
                                                          <Button   className="align-self-center btn-block" disabled={!agreed || loader}
                                                          style={{ backgroundColor: Configuration.BackgroundColor, color: Configuration.Color, borderColor: Configuration.BorderColor }}
                                                          >
                                                          Create Account<span> </span>
                                                          {loader && (
                                                              <i
                                                                  className="fa fa-spinner fa-spin"
                                                                  style={{ marginRight: "5px" }}
                                                              />
                                                          )}</Button>
                                                    )
                                                }
                                            </ThemeConsumer>
                            </Form>
                )}
                </Formik>
                <FooterAuth className="margin-top" />
            </EmptyLayout.Section>
            <ToastContainer
                position={'top-right'}
                draggable={false}
                hideProgressBar={true}
            />
        </EmptyLayout>
    )
    }
export default CreaateAccount;