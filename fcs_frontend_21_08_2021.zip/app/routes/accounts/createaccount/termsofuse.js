import React from 'react';
import {
    Avatar,
    AvatarAddOn,
    DropdownToggle,
    Navbar,
    Nav,
    UncontrolledDropdown,
    NavItem,
    Card,
    CardBody,
    Container,
    UncontrolledCollapse
} from '../../../components';
import { Link } from 'react-router-dom';
import { Logo } from '../../../routes/components/LogoThemed/Logo';

const TermsofUse = () => {
    return (
        <>
            <React.Fragment>
                <Navbar expand="lg" themed>
                    <Link to="/" className="navbar-brand mr-0 mr-sm-3">
                        <Logo className="mb-1" checkBackground />
                    </Link>



                </Navbar>
            </React.Fragment>
            <Container className="margin-top">
                <Card>
                    <CardBody>
                        <br />
                        <br />
                        <h3>1. Terms</h3>
                        <br />
                        <br />
                        <br />
                        <br />
                        <h3>2. Conditions</h3>
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                    </CardBody>
                </Card>
            </Container>
        </>
    )
}

export default TermsofUse;