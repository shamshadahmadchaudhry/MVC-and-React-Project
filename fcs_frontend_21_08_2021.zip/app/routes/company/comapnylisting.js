import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from "react-redux"
import {
    Container,
    CardBody,
    Card,
    ThemeConsumer,
    Button
} from '../../components';
import { useHistory } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import AlertMessage from '../commoncomponents/alertmessage';
import { CompanyListingUpdateRequest } from '../../redux/actions';
import CompanySkeleton from '../skeletenview/companylistingskeleton';
import { Configuration } from '../commoncomponents/configurationfile'

const CompanyListing = () => {
    const dispatch = useDispatch()
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus)
    const [newData, setData] = useState([])
    const [value, setValue] = useState(0)
    const [defaultCompany, setDefaultCompany] = useState({})
    const history = useHistory();


    useEffect(() => {
        setData(CompanyListingStatus?.result?.response?.result)
        setDefaultCompany(CompanyListingStatus?.result?.response?.result.filter(val => val.is_default))
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    useEffect(() => {
        newData.length == 1 && history.push("/dashboard")
    }, [])
    const onInputChange = data => {
        // setData(arrayList);`
        setValue(data.company_id);
        dispatch(CompanyListingUpdateRequest({ company_id: data.company_id }))
    };


    useEffect(() => {
        if (CompanyListingStatus.isError) {
            localStorage.setItem('callBackUrl', '')
            history.push("/accounts/login");
        }
        else {
            history.push("/companylisting");
        }

    }, [CompanyListingStatus?.isError == true])

    const _handleClick = () => {
        // After company selection proccess ahead
        if (value === 0 && defaultCompany && defaultCompany.length == 0) {
            toast.error(<AlertMessage type='error' title='Company' message={'Please select a company to proceed.'} />, { autoClose: false })
        }
        localStorage.setItem("CompanyLogo", "")
        history.push('/Dashboard')
    }
    return (
        <>
            {(CompanyListingStatus.isLoading === true) ?
                (
                    <CompanySkeleton />
                ) :
                (
                    <Container style={{ paddingLeft: "27%", paddingRight: "27%", paddingTop: "10%" }}>
                        {newData?.map((data, index) => {
                            return (
                                <Card key={index}>
                                    <CardBody>
                                        <div>
                                            <input type="radio" id={`rdCompanyid${data.company_id}`}
                                                value={data.company_id}
                                                checked={value ? parseInt(value) === data.company_id : data.is_default}
                                                name={data.company_dba_name}
                                                onChange={() => onInputChange(data)} />
                                            <label style={{ paddingLeft: "2%" }} htmlFor={`rdCompanyid ${data.company_id}`} >{data.company_dba_name}</label>
                                        </div>
                                    </CardBody>
                                </Card>
                            )
                        })
                        }
                        <div className="d-flex" style={{ float: "right", marginTop: "2%" }}>
                            <ThemeConsumer>
                                {
                                    ({ color }) => (
                                        <Button
                                            style={{ backgroundColor: Configuration.BackgroundColor, color: Configuration.Color, borderColor: Configuration.BorderColor }}
                                            onClick={_handleClick} disabled={value === 0 && defaultCompany?.length == 0}>
                                            Proceed
                                        </Button>
                                    )
                                }
                            </ThemeConsumer>
                        </div>
                        <ToastContainer
                            position={'top-right'}
                            draggable={false}
                            hideProgressBar={true}
                        />
                    </Container>
                )
            }
        </>

    )
}
export { CompanyListing };
