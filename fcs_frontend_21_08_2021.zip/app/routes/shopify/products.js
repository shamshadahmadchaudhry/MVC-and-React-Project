{/* Import all the necessary package */ }
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import axios from 'axios';
import { Card, CardBody, Container } from '../../components';
import { HeaderMain } from '../components/HeaderMain';
import Headers from '../commoncomponents/TableHeader';
import { Link } from 'react-router-dom';
const host = "http://127.0.0.1:8000/";
const productLink = { 'link': 'admin/api/2020-07/products.json?status=active', 'flag': 'products' }



const Products = () => {
    const dispatch = useDispatch()
    const [productCount, setProductCount] = useState([]);
    const [productDetailList, setProductDetailList] = useState([]);
    const [productSingleList, setProductSingleList] = useState([]);
    {/* This method is used for retrive all the products on the page load*/ }
    useEffect(() => {
        loadProducts(productLink);
    }, []);
    {/* This method is used for retrive all the products on click function*/ }
    function handleGetProductList(e) {
        loadProducts(e)
    }
    {/* This method is used for call the product api*/ }
    const loadProducts = async (productLink) => {
        const result = await axios.post(host + 'api/product', productLink);
        setProductDetailList(result.data.data);
        setProductCount(result.data.data.length);
        var productSingleList = result.data.data.filter(function (Product) {
            return Product.id == '5836474941608';
        });
        setProductSingleList(productSingleList)

    }
    return (
        <React.Fragment>
            {/* Card  Start */}
            <Container style={{ marginTop: "8px" }}>
                <Card className="mb-3">
                    <CardBody>
                        <table className="table table-bordered table-hover" >
                            <thead>
                                <Headers headers={["Handle", "ID", "Product Type", "PublishedAt", "TemplateSuffix", "Title", "UpdatedAt", "Variants", "Vendor"]} />
                            </thead>
                            <tbody>
                                {
                                    productDetailList.map((Product, index) => (
                                        <tr>
                                            <td>{Product.handle}</td>
                                            <td>{Product.id}</td>
                                            <td>{Product.product_type}</td>
                                            <td>{Product.published_at}</td>
                                            <td>{Product.template_suffix}</td>
                                            <td>{Product.title}</td>
                                            <td>{Product.updated_at}</td>
                                            <td><Link style={{ color: "#77b5fe" }} to={"/Product/ProductVarient"}>varient</Link></td>
                                            <td>{Product.vendor}</td>
                                        </tr>
                                    ))
                                }
                            </tbody>
                        </table>
                    </CardBody>
                </Card>
            </Container>
        </React.Fragment>
    )
}

export default Products;