import Axios from 'axios';
import React, { useEffect, useState } from 'react';
//import { Col, Container, Row, Badge } from 'reactstrap';

import {
    Badge,
    Container,
    Row,
    Col
} from './../../components';
import {
    buildCustomTextFilter,
} from '../../components/Tables/ExtendedTable/filters';

import { HeaderMain } from '../components/HeaderMain'
import AdvancedTableA from '../../components/Tables/ExtendedTable/components/AdvancedTableA';
import { CONFIG } from '../../config';
import ConfirmBox from '../commoncomponents/confirmbox';

const UserList = () => {
    const [userList, setuserList] = useState([]);
    const [modal, setmodal] = useState(false);

    const confirmToggle = () => {
        setmodal(!modal);
    }

    const onConfirm = () => {
        alert('User details removed successfully')
        setmodal(!modal);
    }

    useEffect(() => {
        Axios.get(`${CONFIG.BASE_URL}/api/login`).then(result => {
            setuserList(result.data.data);
        })
    }, []);

    let firstNameFilter = () => {

    }

    const sortCaret = (order) => {
        if (!order)
            return <i className="fa fa-fw fa-sort text-muted"></i>;
        if (order)
            return <i className={`fa fa-fw text-muted fa-sort-${order}`}></i>
    };

    const header = [{ text: 'Id', dataField: 'user_master_id', sort: true, sortCaret },
    {
        text: 'First Name',
        dataField: 'first_name',
        sort: true, sortCaret,
        formatter: (cell) => (
            <span className="text-inverse">
                { cell}
            </span>
        ),
        ...buildCustomTextFilter({
            placeholder: 'Enter first name...',
            getFilter: filter => { firstNameFilter = filter; }
        })
    }
        ,
    {
        text: 'Last Name', dataField: 'last_name', sort: true, sortCaret,
        formatter: (cell) => (
            <span className="text-inverse">
                { cell}
            </span>
        ),
        ...buildCustomTextFilter({
            placeholder: 'Enter last name...',
            getFilter: filter => { firstNameFilter = filter; }
        })
    },
    { text: 'E-mail', dataField: 'email', sort: true, sortCaret },
    { text: 'Phone', dataField: 'phone_number' },
    {
        text: 'Status', dataField: 'is_active', formatter: (cell) => {
            const color = cell === 1 ? 'success' : 'danger';
            return (
                <Badge color={color}>
                    { cell === 1 ? 'Active' : 'In-Active'}
                </Badge>
            );
        }
    },
    { text: 'Img', dataField: 'profile_img_path' },
    {
        text: 'Action', dataField: '', formatter: (userid, cell) => {
            return (
                <div>
                    <a href="#" onClick={() => handleUpdateUser(cell.user_master_id)}>
                        <i className="fa fa-pencil-square" ></i>
                    </a>&nbsp;
                    {/* <a href="#" onClick={() => handleDeleteUser(cell.user_master_id)}>
                        <i className="fa fa-trash" ></i>
                    </a> */}
                    <a href="#" onClick={confirmToggle}>
                        <i className="fa fa-trash" ></i>
                    </a>
                </div>
            )
        }
    }
    ]

    const handleDeleteUser = (userId) => {
        alert(userId);
    }

    const handleUpdateUser = (userId) => {
        alert(userId);
    }

    return (
        <Container>
            <HeaderMain
                title="Custome Tables"
                className="mb-5 mt-4"
            />
            <Row className="mb-5">
                <Col>
                    <AdvancedTableA headers={header} rowData={userList} />
                </Col>
            </Row>
            {/* <Row className="mb-5">
                <Col>
                    <AdvancedTableB headers={header} rowData={userList} childData={userList} />
                </Col>
            </Row> */}
            {/* <CustomTable defaultSort="first_name|asc" headers={header} rowData={userList}></CustomTable> */}
            <ConfirmBox isOpen={modal} message="Are you sure want to remove this user from system?"
                onClose={confirmToggle} onConfirm={onConfirm} title="Remove User" />
        </Container >

    )
}

export default UserList;