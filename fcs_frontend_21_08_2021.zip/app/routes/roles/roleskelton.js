import Skeleton from 'react-loading-skeleton';
import React from 'react';
import {
    Row,
    Col,
    Container
} from '../../components';
import '../../styles/skeleton.scss';

import { HeaderDemo } from "../components/HeaderDemo";

const RoleSkeleton = (props) => {
    return (
        <Container>
            <HeaderDemo className="mt-2"
                subTitle="On this screen, you can manage the roles in the application, one interface per tab" />
            <Row className="margin-top-textbox">
                <Col lg={12}>
                    <ul className="nav nav-tabs">
                        <li><a className={`nav-item nav-link active`}> <Skeleton width={150} /></a></li>
                        <li><a className={`nav-item nav-link`}> <Skeleton width={150} /></a></li>
                        <li><a className={`nav-item nav-link`}> <Skeleton width={150} /></a></li>
                    </ul>
                    <div className="margin-top-textbox"></div>
                    <div style={{ border: "1px solid #3333" }} className="tab" id="divProductOwner">
                        <div style={{ margin: "0.7%" }}>
                            <h6><Skeleton width={150} /></h6>
                            <p><Skeleton width={300} /></p>
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th>
                                            <Skeleton width={50} /><br />
                                            <Skeleton width={80} /><br />
                                            <Skeleton width={100} /><br />
                                        </th>
                                        <th>
                                            <Skeleton width={150} /><br />
                                            <Skeleton width={80} /><br />
                                            <Skeleton width={20} /> <Skeleton width={20} /><br />
                                        </th>
                                        <th>
                                            <Skeleton width={150} /><br />
                                            <Skeleton width={80} /><br />
                                            <Skeleton width={20} /> <Skeleton width={20} /><br />
                                        </th>
                                        <th>
                                            <Skeleton width={150} /><br />
                                            <Skeleton width={80} /><br />
                                            <Skeleton width={20} /> <Skeleton width={20} /><br />
                                        </th>
                                        <th>
                                            <Skeleton width={150} /><br />
                                            <Skeleton width={80} /><br />
                                            <Skeleton width={20} /> <Skeleton width={20} /><br />
                                        </th>
                                        <th>
                                            <Skeleton width={160} height={30} /><br />
                                            <Skeleton width={80} height={30} /><br />
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><Skeleton width={150} /></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                        <td></td>
                                        <td></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                    </tr>
                                    <tr>
                                        <td><Skeleton width={150} /></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                        <td></td>
                                        <td></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                    </tr>
                                    <tr>
                                        <td><Skeleton width={150} /></td>
                                        <td></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                        <td></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                    </tr>
                                    <tr>
                                        <td><Skeleton width={150} /></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                    </tr>
                                    <tr>
                                        <td><Skeleton width={150} /></td>
                                        <td></td>
                                        <td></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                        <td></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                    </tr>
                                    <tr>
                                        <td><Skeleton width={150} /></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td><Skeleton width={30} height={25} /></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </Col>
            </Row>
        </Container>
    )
}
export default RoleSkeleton;