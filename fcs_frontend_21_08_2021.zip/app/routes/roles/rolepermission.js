import React, { useEffect } from 'react'
import { CustomInput } from './../../components';

const RolePermission = (props) => {
    return (
        <>
            {
                props.roleData && props.roleData.length > 0 && (props.roleData.map((role, roleIndex) => (

                    <td key={role.role_id}>
                        {
                            //console.log("ss", role.permissionData.find(item => item.permission_id === permission.permission_master_id))
                            role.is_edit ? <CustomInput
                                type="checkbox"
                                id={role.permissionData && role.permissionData.find(item => item.permission_id === props.permission.permission_master_id).permission_name}
                                onChange={() => updatePermissionStatus(props.permission.permission_master_id,
                                    role.permissionData.find(item => item.permission_id === props.permission.permission_master_id).is_selected,
                                    props.permission.parent_permission_id, role.role_id)}
                                checked={role.permissionData.find(item => item.permission_id === props.permission.permission_master_id).is_selected}
                            />
                                : role.permissionData && role.permissionData.find(item => item.permission_id === props.permission.permission_master_id).is_selected
                                    ? <><span className="fa fa-check"></span> </> : <span>&nbsp;</span>
                        }

                    </td>
                )))
            }
        </>
    )
}

export default RolePermission
