import React, { useState, useEffect } from 'react';
import {
    Container,
    Row,
    Col,
    Navbar
} from './../../components';
import { HeaderDemo } from "../components/HeaderDemo";
import ProductOwnerRole from './productownerrole';
import { ToastContainer } from 'react-toastify';
import RoleSkeleton from './roleskelton';
import { getRoles } from './../../services/rolespermissionService';
import { Configuration } from '../commoncomponents/configurationfile';

const ApplicationRolesManagement = () => {
    const [activeTab, setActiveTab] = useState('productowner');
    const [userType, setUserType] = useState(1);
    const [loadSkelton, setloadSkelton] = useState(true)
    const [skeltonLoaded, setSkeltonLoaded] = useState(0);
    const [userRoleData, setRoleData] = useState([]);

    // Toggle tabs function
    const loadTab = (tabName, userTypeId) => {
        setActiveTab(tabName);
        setUserType(userTypeId);
        setSkeltonLoaded(1);
    }

    useEffect(() => {
        console.log('Props user Type', userType)
        // Load role master data 
        async function selectRoles() {
            const responseData = await getRoles(userType)
            setRoleData(responseData.data.result);
            setloadSkelton(false);
        }
        selectRoles();
    }, [])

    return (
        <>
            {
                loadSkelton ? <RoleSkeleton />
                    :
                    <div>
                        <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                            <div class="btn-group title-text-style">

                                <h4>Application Roles</h4>
                            </div>

                        </Navbar>

                        <Container>
                            <HeaderDemo className="mt-3"
                                subTitle="On this screen, you can manage the roles in the application, one interface per tab" />
                            { /* START Tab Section */}
                            <Row>
                                <Col lg={12}>

                                    {/* <Card className="mb-3">
                            <CardBody> */}
                                    <ul className="nav nav-tabs">
                                        <li><a className={`${activeTab === 'productowner' ? 'active' : ''} nav-item nav-link`}
                                            onClick={() => loadTab('productowner', Configuration.userType.productOwner)} style={{ cursor: "pointer" }}>Product Owner</a></li>
                                        <li><a className={`${activeTab === '3plcompany' ? 'active' : ''} nav-item nav-link`}
                                            onClick={() => loadTab('3plcompany', Configuration.userType.threePlCompany)} style={{ cursor: "pointer" }}>3PL Company</a></li>
                                        <li><a className={`${activeTab === 'merchant' ? 'active' : ''} nav-item nav-link`}
                                            onClick={() => loadTab('merchant', Configuration.userType.merchant)} style={{ cursor: "pointer" }} >Merchant</a></li>
                                    </ul>

                                    {/* Start Product Owner Tab Content Section  */}
                                    <div className="tab" id="divProductOwner" style={{ display: `${activeTab === 'productowner' ? 'block' : 'none'}`, border: "1px solid #3333", overflowX: 'auto' }}>
                                        {activeTab === 'productowner' && <ProductOwnerRole skeltonLoaded={skeltonLoaded} userType={userType} />}
                                    </div>
                                    {/* End Product Owner Tab Content Section  */}

                                    {/* Start Product Owner Tab Content Section  */}
                                    <div className="tab" id="div3PLCompany" style={{ display: `${activeTab === '3plcompany' ? 'block' : 'none'}`, border: "1px solid #3333" }}>
                                        {activeTab === '3plcompany' && <ProductOwnerRole skeltonLoaded={skeltonLoaded} userType={userType} />}
                                    </div>
                                    {/* End Product Owner Tab Content Section  */}

                                    {/* Start Product Owner Tab Content Section  */}
                                    <div className="tab" id="divMerchant" style={{ display: `${activeTab === 'merchant' ? 'block' : 'none'}`, border: "1px solid #3333" }}>
                                        {activeTab === 'merchant' && <ProductOwnerRole skeltonLoaded={skeltonLoaded} userType={userType} />}
                                    </div>
                                    {/* End Product Owner Tab Content Section  */}

                                </Col>
                            </Row>
                            { /* END Tab Section */}
                            <ToastContainer
                                position={'top-right'}
                                draggable={false}
                                hideProgressBar={true}
                            />
                        </Container>
                    </div>
            }
        </>
    )
}

export default ApplicationRolesManagement
