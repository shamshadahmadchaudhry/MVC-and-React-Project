import React, { useState } from 'react'
import { removeRole, updateRole } from '../../services/rolespermissionService';
import AlertMessage from '../commoncomponents/alertmessage';
import { toast } from 'react-toastify';
import {
    Modal,
    ModalHeader,
    ModalBody,
    ModalFooter,
    Button
} from './../../components';
import { Configuration } from '../commoncomponents/configurationfile';
const RolesHeader = (props) => {
    const [confirmModal, setconfirmModal] = useState(false)
    const [role_name, setroleName] = useState(props.rowitem.role_name);
    const [invalidInput, setInvalidInput] = useState(false);
    const [roleId, setRoleId] = useState(0);

    // Set role_name state
    const OnInputChange = (e) => {
        setroleName(e.target.value.replace(Configuration.SpecialCharecter, ''));
    }

    // Toggle confirm box modal
    const confirmToggle = (role_id) => {
        setRoleId(role_id);
        setconfirmModal(!confirmModal);
    }

    // Validate edit textbox for required field
    const validate = () => {
        if (role_name === '' || role_name === undefined)
            setInvalidInput(true);
        else
            setInvalidInput(false);
    }

    // Remove roles from system    
    const handleDelete = async () => {
        if (roleId > 0) {
            let respData = await removeRole(roleId);
            if (respData.data.error) {
                toast.error(<AlertMessage type='error'
                    title='Failed.'
                    message={respData.data.Message} />, { autoClose: false })
            } else {
                toast.success(<AlertMessage type='success'
                    title='Success'
                    message={respData.data.Message} />, { autoClose: 4000 })
            }
            props.updateRoleList();
        }
        setconfirmModal(!confirmModal)
    }

    // Update existing role details
    const updateExistingRole = async (roleId) => {
        if (role_name === '' || role_name === undefined
            || !role_name.match(Configuration.alphanumericSpace)
            || role_name.match(Configuration.digits))
            setInvalidInput(true);
        else {
            let permissionData = props.rowitem.permissionData;
            let values = {
                description: role_name, role_name: role_name, role_id: roleId,
                permissionData: permissionData, user_type_id: props.userType
            };
            let response = await updateRole(values);
            if (response.data.error) {
                toast.error(<AlertMessage type='error'
                    title='Invalid details.'
                    message={response.data.Message} />, { autoClose: false })
            } else {
                toast.success(<AlertMessage type='success'
                    title='Success.'
                    message={response.data.Message} />, { autoClose: 4000 })
                window.location.reload;
            }
            props.editRoleDetails(roleId, true)
            setInvalidInput(false);
        }

    }

    return (
        <>
            {/* Create Header with roles data */}
            {
                props.rowitem.is_edit ?
                    <>
                        <input style={{ style: "100%", width: "150px" }}
                            type="text"
                            name="role_name"
                            onBlur={validate}
                            value={role_name}
                            onChange={(e) => OnInputChange(e)}
                            className={`${invalidInput ? 'is-invalid' : ''} form-control bg-white`} />
                        <span style={{ fontSize: "10px" }}>{props.rowitem.user_count} users</span><br />
                        <a style={{ cursor: "pointer" }}><span className="fa fa-fw fa-save" title="Update"
                            onClick={() => updateExistingRole(props.rowitem.role_id)} ></span> </a> &nbsp; &nbsp;
                        <a style={{ cursor: "pointer" }} title="Cancel" onClick={() => props.updateRoleList(props.rowitem.role_id, true)} ><span className="fa fa-fw fa-remove"></span></a>
                    </>
                    : <>
                        <span className={props.rowitem.css_class_name} style={{ whiteSpace: "nowrap", fontSize: "11px !important" }}>{props.rowitem.role_name}</span><br />
                        <span style={{ fontSize: "10px" }}>{props.rowitem.user_count} users</span><br />
                        {
                            props.rowitem.user_count > 0
                                ? <><a className="navbar-brand" title="Edit" style={{ cursor: "pointer" }} onClick={() => props.editRoleDetails(props.rowitem.role_id, false)} >
                                    <span className="fa fa-fw fa-pencil-square-o"></span>&nbsp;&nbsp;</a></>
                                : <> <a className="navbar-brand" style={{ cursor: "pointer" }} title="Edit" onClick={() => props.editRoleDetails(props.rowitem.role_id, false)} >
                                    <span className="fa fa-fw fa-pencil-square-o"></span>&nbsp;&nbsp;</a>
                                    <a className="navbar-brand" style={{ cursor: "pointer" }} title="Remove" onClick={() => confirmToggle(props.rowitem.role_id)} ><span className="fa fa-fw fa-trash"></span></a>
                                </>
                        }
                    </>
            }

            {/* Start confirm Box */}
            <Modal isOpen={confirmModal} toggle={confirmToggle} className="modal-outline-warning">
                <ModalHeader tag="h6">
                    <span className="text-warning">
                        <i className="fa fa-fw fa-2x fa-exclamation"></i>
                                                Warning : Product Owner Role
                                            </span>
                </ModalHeader>
                <ModalBody>
                    <div style={{ marginTop: "10px" }} className="media-body">
                        <p> Are sure you want to remove this role?</p>
                    </div>
                </ModalBody>
                <ModalFooter>
                    <button onClick={confirmToggle} className="btn btn-default" > No </button>
                    <Button color="warning" onClick={handleDelete}>Yes</Button>
                </ModalFooter>
            </Modal>
        </>
    )
}

export default RolesHeader
