/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react';
import {
    CustomInput, ThemeConsumer, Button
} from './../../components';
import { Configuration } from '../commoncomponents/configurationfile';
import RolesHeader from './rolesheader';
import { addNewRole, getRoles, getMasterPermission } from './../../services/rolespermissionService';
import AlertMessage from '../commoncomponents/alertmessage';
import { toast } from 'react-toastify';
import { useLoading, Oval } from '@agney/react-loading';

const ProductOwnerRole = (props) => {
    const [permissionData, setPermissionData] = useState([]);
    const [roleData, setRoleData] = useState([]);
    const [new_role, setNewRole] = useState("");
    const [invalidInput, setInvalidInput] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        // Load role master data 
        async function selectRoles() {
            const responseData = await getRoles(props.userType)
            setRoleData(responseData.data.result);
        }
        selectRoles();
        // Load permission master data
        async function selectPermissions() {
            props.skeltonLoaded != 0 ? setIsLoading(true) : setIsLoading(false);
            const responseData = await getMasterPermission(props.userType);
            setPermissionData(responseData.data.result);
            setIsLoading(false);
        }
        selectPermissions();
    }, [props.userType])

    // Set edit mode after role edit action
    const editRoleDetails = (roleid, isCancel) => {
        let newState = roleData.map(item => {
            if (item.role_id === roleid) {
                item.is_edit = isCancel ? false : true;
                return item;
            } else {
                item.is_edit = false;
                return item;
            }
        })
        setRoleData(newState)
    }

    // Set new role state
    const onChangeInput = (e) => {
        setNewRole(e.target.value.replace(Configuration.SpecialCharecter, ''));
    }

    // Validate required field for role text box
    const validate = () => {
        if (new_role === '' || new_role === undefined || !new_role.match(Configuration.alphanumericSpace) || new_role.match(Configuration.digits))
            setInvalidInput(true);
        else
            setInvalidInput(false);
    }

    // Add new role for product owner
    const saveNewRole = async () => {
        if (new_role === '' || new_role === undefined || !new_role.match(Configuration.alphanumericSpace) || new_role.match(Configuration.digits))
            setInvalidInput(true);
        else {
            let body = { role_name: new_role, description: new_role, user_type_id: props.userType, created_date: new Date() }
            const respData = await addNewRole(body);
            if (respData.data.error) {
                toast.error(<AlertMessage type='error'
                    title='Failed.'
                    message={respData.data.Message} />, { autoClose: false })
            } else {
                toast.success(<AlertMessage type='success'
                    title='Success'
                    message={respData.data.Message} />, { autoClose: 4000 })
            }
            setNewRole("");
        }
        updateRoleList();
    }

    // Check for parent checkbox select deselect after child selection
    const checkIsAllChildSelected = (permissionId, parentPermissionId, roleId, status) => {
        let permissionData = roleData.find(item => item.role_id === roleId).permissionData;
        let childArray = permissionData.filter(item => item.parent_permission_id === parentPermissionId);
        let selectedCount = childArray.filter(c => c.is_selected === 1).length;

        if (parentPermissionId === 0) {
            let newRoleData = roleData.map(role => {
                if (role.role_id === roleId) {
                    role.permissionData.map(permission => {
                        if (permission.permission_id === permissionId || permission.parent_permission_id === permissionId) {
                            permission.is_selected = status
                            return permission;
                        }
                    })
                    return role;
                } else {
                    return role;
                }
            });
            setRoleData(newRoleData);
        } else {
            if (childArray.length === selectedCount || (parentPermissionId === 0 && status === 1)) {
                let newRoleData = roleData.map(role => {
                    if (role.role_id === roleId) {
                        role.permissionData.map(permission => {
                            if (permission.permission_id === permissionId || permission.permission_id === parentPermissionId) {
                                permission.is_selected = status
                                return permission;
                            }
                        })
                        return role;
                    } else {
                        return role;
                    }
                });
                setRoleData(newRoleData);
                //return true;
            } else {
                let newRoleData = roleData.map(role => {
                    if (role.role_id === roleId) {
                        role.permissionData.map(permission => {
                            if (permission.permission_id === permissionId) {
                                permission.is_selected = status
                                return permission;
                            } else if (permission.permission_id === parentPermissionId) {
                                permission.is_selected = 0;
                                return permission;
                            }
                        })
                        return role;
                    } else {
                        return role;
                    }
                });
                setRoleData(newRoleData);
            }
        }
    }

    // Set selected permission status for selected role
    const setCheckboxStatus = (permissionId, roleId, currentStatus) => {
        let status;
        roleData.find(item => item.role_id === roleId)
            .permissionData.map(prmsn => {
                if (prmsn.permission_id === permissionId) {
                    prmsn.is_selected = currentStatus === 1 ? 0 : 1;
                    status = prmsn.is_selected;
                }
            });
        return status;
    }

    // Update permission for particular role
    const updatePermissionStatus = async (permissionId, isSelected, parentPermissionId, role_id) => {
        let status = setCheckboxStatus(permissionId, role_id, isSelected)
        let isAllChildSelected = checkIsAllChildSelected(permissionId, parentPermissionId, role_id, status);
        let body = {
            role_id: role_id,
            permission_id: permissionId,
            is_selected: status,
            is_all_child_selected: isAllChildSelected,
            parent_permission_id: parentPermissionId,
            user_type_id: props.userType
        }
    }

    // After save, update or delete refresh the role and permission details
    const updateRoleList = () => {
        async function selectRoles() {
            const responseData = await getRoles(props.userType);
            setRoleData(responseData.data.result);
        }
        selectRoles();
    }

    // Return parent child permission mapping tree
    const returnPermissionTree = (permissionList) => {
        permissionList.forEach(eachPermission => {
            let filter = permissionList.filter(function (pemission) {
                return pemission.parent_permission_id === eachPermission.permission_master_id;
            });
            eachPermission.childPermission = [];
            eachPermission.childPermission = filter;
        });
        //console.log('permision respose=>', permissionList.filter(item => item.parent_permission_id === 0 || item.parent_permission_id === null))
        return permissionList.filter(item => item.parent_permission_id === 0 || item.parent_permission_id === null);
    }

    const { containerProps, indicatorEl } = useLoading({
        loading: true,
        indicator: <Oval width="50" />,
    });

    return (
        <div style={{ margin: "0.7%" }} >
            {
                // Conditional rendering for Tab header
                props.userType === Configuration.userType.productOwner ? <><h6>Product Owner Roles</h6>
                    <p>Manage the roles for the product owner interface.</p></>
                    : props.userType === Configuration.userType.threePlCompany ? <><h6>3PL Company Roles</h6>
                        <p>Manage the roles for the 3PL Company interface.</p></>
                        : props.userType === Configuration.userType.merchant ? <><h6>Merchant Roles</h6>
                            <p>Manage the roles for the merchant interface.</p></>
                            : ""
            }
            {
                isLoading ?
                    <div style={{ textAlign: "center" }} {...containerProps}>
                        {indicatorEl} {/* renders only while loading */}
                    </div>
                    :

                    <table className="table mb-5">
                        <thead>
                            <tr>
                                <th style={{ verticalAlign: "middle" }}>
                                    <div>Roles</div>
                                    <div style={{ marginTop: "2%" }}>Actions</div>
                                    <div>Permissions</div>
                                </th>
                                {
                                    roleData && roleData.length > 0 && roleData.map((item, index) => (
                                        <th style={{ whiteSpace: "nowrap" }} key={index}>
                                            <RolesHeader updateRoleList={updateRoleList} userType={props.userType} editRoleDetails={editRoleDetails} rowitem={item} />
                                        </th>
                                    ))
                                }
                                <th style={{ verticalAlign: "middle" }}>
                                    <input type="text" placeholder="Role Name" style={{ width: "65%" }}
                                        name="new_role"
                                        value={new_role}
                                        onBlur={validate}
                                        onChange={(e) => onChangeInput(e)}
                                        className={`${invalidInput ? 'is-invalid' : ''} form-control bg-white`} />
                                    <ThemeConsumer>
                                        {
                                            ({ color }) => (
                                                <Button style={{ marginTop: "3%" }} color={color} className="align-self-center" onClick={saveNewRole}
                                                    className="btn-sm">
                                                    Add Role &nbsp;<i className="fa fa-plus"></i>
                                                </Button>
                                            )
                                        }
                                    </ThemeConsumer>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {

                                permissionData.map((permission, index) => (
                                    <tr key={permission.permission_master_id} className={permission.parent_permission_id === 0 ? 'table-secondary' : ''}>
                                        <td style={{ whiteSpace: "nowrap" }}>{permission.permission_name}</td>

                                        {/* <RolePermission updatePermissionStatus={updatePermissionStatus} roleData={roleData} parmission={permission} /> */}

                                        {
                                            roleData && roleData.length > 0 && (roleData.map((role, roleIndex) => (

                                                <td key={role.role_id}>
                                                    {
                                                        role.is_edit ? <CustomInput
                                                            type="checkbox"
                                                            id={role.permissionData && role.permissionData.find(item => item.permission_id === permission.permission_master_id).permission_name}
                                                            onChange={() => updatePermissionStatus(permission.permission_master_id,
                                                                role.permissionData.find(item => item.permission_id === permission.permission_master_id).is_selected,
                                                                permission.parent_permission_id, role.role_id)}
                                                            checked={role.permissionData.find(item => item.permission_id === permission.permission_master_id).is_selected}
                                                        />
                                                            : role.permissionData && role.permissionData.find(item => item.permission_id === permission.permission_master_id).is_selected
                                                                ? <><span className="fa fa-check"></span> </> : <span>&nbsp;</span>
                                                    }

                                                </td>
                                            )))
                                        }
                                        <td></td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </table>
            }
        </div >
    )
}

export default ProductOwnerRole