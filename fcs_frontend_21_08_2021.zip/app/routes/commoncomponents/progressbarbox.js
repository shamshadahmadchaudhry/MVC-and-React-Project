import React from 'react';
import {
    Modal,
    ModalHeader,
    ModalBody,
    ModalFooter,
    ThemeConsumer,
    Progress
} from './../../components'

const ProgressBarBox = (props) => {
    return (
        <Modal isOpen={props.isOpen} toggle={props.confirmToggle} >
            <ModalHeader tag="h5">
                <span >
                    {props.title}</span>
            </ModalHeader>
            <ModalBody>
                <div style={{ marginTop: "10px" }} className="media-body">
                    <p> {props.message}</p>
                </div>
                <Progress value={props.percentage} striped>{props.percentage}%</Progress>
            </ModalBody>
            <ModalFooter>
                <button color="link" onClick={props.onClose} className="btn btn-default text-warning">
                    Cancel
                </button>

            </ModalFooter>
        </Modal>
    )
}

ProgressBarBox.defaultProps = {
    onConfirm: () => null,
    onClose: () => null
};

export default ProgressBarBox