import React, { useState } from 'react';

const CustomTextInput = ({ type, textValue, handleChange, isRequired, name, placeholder, icons }) => {
    const [errorMessage, SetErrorMessage] = useState('');
    const [requiredMessage, SetRequiredMessage] = useState('');
    const textChange = (e) => {
        handleChange(e.target.value);

        if (type === 'email') {
            const regExpEmail = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
            if (e.target.value.length > 0 && !e.target.value.match(regExpEmail)) {
                SetErrorMessage('Please Enter Valid Email Id')
            } else {
                SetErrorMessage('')
            }
        }
    }

    const handleBlur = (e) => {
        if (isRequired && e.target.value.length === 0) {
            SetErrorMessage(`Please enter ${e.target.name}`);
        }
    }
    return (
        <>
            <input name={name} type={type} value={textValue} onChange={textChange} required={isRequired}
                className={`${errorMessage.length > 0 && 'is-invalid'} bg-white form-control`}
                onBlur={handleBlur} placeholder={placeholder} />
            { errorMessage.length > 0 && <div className='text-danger'>{errorMessage}</div>}
        </>
    )
}

CustomTextInput.defaultProps = {
    isRequired: false,
}

export default CustomTextInput