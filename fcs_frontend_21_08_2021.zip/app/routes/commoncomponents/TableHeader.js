import React from "react"

export default function Headers(props){
    let th = props.headers.map(data=>{
        return <th>{data}</th>
    })
    return (
        <tr>
            {th}
        </tr>
    )
}