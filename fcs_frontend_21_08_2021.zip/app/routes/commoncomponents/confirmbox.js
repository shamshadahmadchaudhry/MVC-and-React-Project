import React from 'react';
import {
    Modal,
    ModalHeader,
    ModalBody,
    ModalFooter,
    ThemeConsumer
} from './../../components'

const ConfirmBox = (props) => {
    return (
        <Modal isOpen={props.isOpen} toggle={props.confirmToggle} className="modal-outline-warning">
            <ModalHeader tag="h5">
                <span className="text-danger">
                    {/* <i className="fa fa-fw fa-remove"></i> */}{props.title}</span>
            </ModalHeader>
            <ModalBody>
                <div style={{ marginTop: "10px" }} className="media-body">
                    <p> {props.message}</p>
                </div>
            </ModalBody>
            <ModalFooter>
                <button color="link" onClick={props.onClose} className="btn btn-default text-warning">
                    Cancel
                </button>

                <ThemeConsumer>
                    {
                        ({ color }) => (
                            <button className="btn btn-danger" onClick={props.onConfirm}>
                                {props.text}
                            </button>
                        )
                    }
                </ThemeConsumer>

                {/* <button onClick={confirmToggle} className="btn btn-default" > No </button>
                <Button color="warning" onClick={handleDelete}>Yes</Button> */}
            </ModalFooter>
        </Modal>
    )
}

ConfirmBox.defaultProps = {
    onConfirm: () => null,
    onClose: () => null
};

export default ConfirmBox