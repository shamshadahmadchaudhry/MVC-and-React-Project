import React from 'react'
import { useSelector } from 'react-redux';
import { check } from './Can';


export const usePermission = (actionName) => {
    const [isAuthorized, setAuthorized] = React.useState(null);
    const UserData = useSelector(state => state.userData);
    React.useEffect(() => {
        const fetchData = async () => {
            try {
                setAuthorized(check(UserData.data.response.data, actionName));
            } catch (error) { }
        };
        fetchData();
    }, []);
    return { isAuthorized };
};

// export const checkPermission = (permission) => {
//     const ProfileStatus = useSelector(state => state.ProfileStatus);
//     let isPermitted = check(ProfileStatus.data.response, permission);
//     return isPermitted
// }