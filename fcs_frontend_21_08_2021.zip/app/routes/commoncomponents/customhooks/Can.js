import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import rules from "../../../config/rbac-rules";

export const check = (userData, action) => {
    //const ProfileStatus = useSelector(state => state.ProfileStatus);
    //const [userData1, setUserData] = useState(ProfileStatus?.data.response)
    const permissions = userData.permission;
    //const staticPermissions = permissions.static;

    if (permissions && permissions.find(p => p.permission === action && p.is_selected === 1)) {
        //console.log('Permission ->', userData1)
        // static rule not provided for action
        return true;
    }

    return false;
};

const Can = (data, action) =>
    check(data, action)
        ? props.yes()
        : props.no();



Can.defaultProps = {
    yes: () => null,
    no: () => null
};

export default Can;