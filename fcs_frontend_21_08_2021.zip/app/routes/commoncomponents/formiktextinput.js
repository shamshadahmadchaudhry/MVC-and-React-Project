import React, { useState } from 'react';
import { ErrorMessage, Field } from 'formik';

const FormikTextInput = ({ type, name, placeholder, isError }) => {
    return (
        <>
            <Field type={type} name={name} placeholder={placeholder}
                className={`${isError && 'is-invalid'} bg-white form-control`} />
            { isError &&
                <ErrorMessage name={name} component="span" className="text-danger"></ErrorMessage>
            }
        </>
    )
}

// FormikTextInput.PropTypes = {
//     type: PropTypes.string.isRequired
// }

export default FormikTextInput