import React from 'react';
import { useFormikContext } from 'formik';
import { Prompt } from 'react-router';

export const PromptIfDirty = () => {
    const formik = useFormikContext();
    // Generic code to display the popup message if users wants to move to other page without saving the filled data in form.
    return (
        <Prompt
            when={formik.dirty && formik.submitCount === 0}
            message="Are you sure you want to leave? You have with unsaved changes."
        />
    );
};

export const PromptIfDirtyWarehouse = () => {
    const location = localStorage.getItem('locationDetails');
    const building = localStorage.getItem('buildings');
    // Generic code to display the popup message if users wants to move to other page without saving the filled data in form.
    return (
        <Prompt
            when={location || building}
            message="Are you sure you want to leave? You have with unsaved changes."
        />
    );
};