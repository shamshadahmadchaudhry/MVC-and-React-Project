import React from 'react';
import { Media, Button } from '../../components';

const AlertMessage = ({ type, message, title }) => {
    return (
        <Media>
            <Media middle left className="mr-3">
                {   // Alert Icons 
                    type === 'error' ? <i className="fa fa-fw fa-2x fa-close"></i>
                        : type === 'success' ? <i className="fa fa-fw fa-2x fa-check"></i>
                            : type === 'info' ? <i className="fa fa-fw fa-2x fa-info"></i>
                                : type === 'warning' ? <i className="fa fa-fw fa-2x fa-exclamation"></i>
                                    : <i className="fa fa-fw fa-2x fa-question"></i>
                }
            </Media>
            <Media body>
                <Media heading tag="h6">
                    {title}
                </Media>
                <p>
                    {message}
                </p>
                {
                    type === 'error' ?

                        <div className="d-flex mt-2">
                            <Button color="danger">
                                Ok
                    </Button>
                        </div>
                        : type === 'success' ? <div className="d-flex mt-2">
                            <Button color="success">
                                Ok
                </Button>
                        </div>
                            : type === 'info' ? <div className="d-flex mt-2">
                                <Button color="info" >
                                    Ok
                </Button>
                            </div>
                                : type === 'warning' ? <div className="d-flex mt-2">
                                    <Button color="warning">
                                        Ok
                    </Button>
                                </div>
                                    : ''
                }

            </Media>
        </Media>
    )
}

export default AlertMessage