/* eslint-disable react/prop-types */
import React, { useEffect } from 'react';
import BootstrapTable from 'react-bootstrap-table-next';

const CustomTable = (props) => {

    useEffect(() => {
        console.log(props);
        console.log("Header->", props.headers);
        console.log("Row Data->", props.rowData);
    }, [])

    // const defaultSorted = [{
    //     dataField: props.defaultSort.split('|')[0],
    //     order: props.defaultSort.split('|')[1]
    // }];

    return (
        <table className="table table-striped">
            <thead>
                <tr>
                    {
                        props.headers && props.headers.map((header, index) => (
                            <th>
                                {header.text}
                            </th>
                        ))
                    }
                </tr>
            </thead>
            <tbody>
                {
                    props?.rowData && props.rowData.map((row, index) => (
                        <tr>
                            {props.headers.map((column, count) => (
                                <td>
                                    {
                                        column?.formatter ? (column.formatter) : row[column.dataField]
                                    }
                                </td>
                            ))
                            }
                        </tr>
                    ))
                }
            </tbody>
            {
                props?.footer && (<tfoot></tfoot>)
            }

        </table>
        // <BootstrapTable
        //     keyField="user_master_id"
        //     data={props.rowData}
        //     columns={props.headers}
        //     bootstrap4
        //     defaultSorted={defaultSorted} />
    )
}

export default CustomTable;