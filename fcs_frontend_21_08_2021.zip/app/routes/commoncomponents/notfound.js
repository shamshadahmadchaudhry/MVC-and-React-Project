import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { EmptyLayout } from '../../components';

import { FooterAuth } from "../components/Pages/FooterAuth";
import { ResetPasswordErrorHeaderAuth } from '../components/Pages/ResetPasswordErrorHeaderAuth';


const Error404 = () => {
    return (
        <EmptyLayout>

            <EmptyLayout.Section center>
                { /* START Header */}


                <ResetPasswordErrorHeaderAuth

                    title="Access Denied."
                    text="Oops! Something went wrong!"

                />

                <div className="mb-5" style={{ textAlign: "center" }}>
                    <Link to="/Dashboard" className="text-decoration-none">
                        <i className="fa fa-angle-left"></i> Go back to home
                </Link>
                </div>
                { /* END Bottom Links */}
                { /* START Footer */}
                <FooterAuth />
                { /* END Footer */}
            </EmptyLayout.Section>
        </EmptyLayout>

    )
}

export default Error404;
