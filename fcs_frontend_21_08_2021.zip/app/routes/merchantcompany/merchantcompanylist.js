import React from 'react'
import { Configuration } from '../commoncomponents/configurationfile'
// import CompaniesList from '../threeplcompany/companieslist'
import CompanyList from '../threeplcompany/companylist/companylist'
const MerchantCompanyList = () => {
    return (
        <CompanyList userType={Configuration.userType.merchant} />
    )
}

export default MerchantCompanyList