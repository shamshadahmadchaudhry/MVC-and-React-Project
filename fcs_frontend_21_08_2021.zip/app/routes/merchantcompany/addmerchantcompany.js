import React from 'react';

import { Configuration } from '../commoncomponents/configurationfile';

import CompanyManagement from '../threeplcompany/companymanagement';



const AddMerchantCompany = (props) => {
    return (
        <CompanyManagement userType={Configuration.userType.merchant} />
    )
}

export default AddMerchantCompany;