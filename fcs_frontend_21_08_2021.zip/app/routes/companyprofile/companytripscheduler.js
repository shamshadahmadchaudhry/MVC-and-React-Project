import React, { useEffect, useState } from 'react';
import {
    Card,
    CardBody,
    CardTitle,
    Container,
    FormGroup,
    Col,
    Label
} from '../../components';
import { useSelector, useDispatch } from 'react-redux';
import Toggle from 'react-toggle';
import { tripSchedulingPermission } from '../../services/tripmanagement';
import { toast } from 'react-toastify';
import AlertMessage from '../commoncomponents/alertmessage';
import { UserDataRequest } from '../../redux/actions';

function CompanyTripScheduler() {
    toast.configure();
    const dispatch = useDispatch();
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [isChecked, setisChecked] = useState(false);
    const [role_permission_id, setRolePermissinId] = useState(0);

    useEffect(() => {
        let permissionList = userData.permission;
        if (permissionList) {
            let permission = permissionList?.find(item => item.permission === 'p-trip-scheduler-on');
            setRolePermissinId(permission.role_permission_id);
            if (permission.is_selected) {
                setisChecked(true);
            } else {
                setisChecked(false);
            }
        }
    }, [])

    const handleTogglechange = async (e) => {
        let is_selected = 0;
        if (e.target.checked) {
            is_selected = 1;
            setisChecked(true);
        } else {
            is_selected = 0
            setisChecked(false);
        }
        let body = {
            role_permission_id: role_permission_id,
            is_selected: is_selected
        }

        const result = await tripSchedulingPermission(body);
        if (result.data.status) {
            dispatch(UserDataRequest());
            toast.success(<AlertMessage type="success" title="Success Trip Scheduling"
                message="You have changes trip scheduling permission successfully." />, { autoClose: 4000 });
        } else {
            toast.error(<AlertMessage type="error" title="Success Trip Scheduling"
                message={result.data.message} />, { autoClose: 4000 });
        }
    }

    return (
        <>
            <Card className="mb-3 margin-top">
                <CardBody>
                    <div className="d-flex mb-4">
                        <CardTitle tag="h6">
                            Warehouse Settings
                           </CardTitle>
                    </div>
                    <Container>
                        <FormGroup row>
                            <Col sm={4}>
                                <Label for="lastName" className="text-right"> Trip Scheduling </Label>
                            </Col>
                            <Col sm={8} className="float-right">
                                <Toggle
                                    id='status'
                                    checked={isChecked}
                                    onChange={(e) => handleTogglechange(e)} />
                                <label htmlFor='status'></label>
                            </Col>
                        </FormGroup>
                    </Container>
                </CardBody>
            </Card>
        </>
    )
}

export default CompanyTripScheduler
