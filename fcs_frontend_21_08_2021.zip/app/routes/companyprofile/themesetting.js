import React, { useState, useEffect } from 'react';
import {
    Card,
    CardBody,
    CardTitle,
    FormGroup,
    Label,
    Col,
    Button,
    ThemeConsumer,
    Container,
    Row
} from '../../components';
import ColorBox from 'devextreme-react/color-box';
import { CompanyProfileTheme, addCompanyTheme, UserCompanyProfile } from '../../services/companyprofileservice';
import { useSelector, useDispatch } from 'react-redux';
import { CONFIG } from "../../config";
import { Configuration } from '../commoncomponents/configurationfile';
import '../../styles/common.scss';
import { toast } from 'react-toastify';
import AlertMessage from '../commoncomponents/alertmessage';
import { useHistory } from 'react-router-dom';
import { CompanyListingRequest } from '../../redux/actions/index'
let companyId = 0;
const CompanyThemeSetting = () => {
    const dispatch = useDispatch();
    let history = useHistory();
    toast.configure();
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [secondarycolorvalue, setSecondaryColorValue] = useState('')
    const [primarycolorvalue, setPrimaryColorValue] = useState('')
    const [companylogo, setCompanyLogo] = useState('')
    const [imagePreview, setImagePreview] = useState('')
    const [imagename, setImageName] = useState('')
    const [image, setImage] = useState('')
    const [loader, setLoader] = useState(false);
    const [btndisable, setBtnDisable] = useState("none")
    const [btneditdisable, setBtnEditDisable] = useState("")
    const [disable, setDisable] = useState(true)
    const handleSecondaryColorChange = (e) => {
        setSecondaryColorValue(e.value)
    }
    const handlePrimaryColorChange = (e) => {
        setPrimaryColorValue(e.value)
    }
    let company_id = CompanyListingStatus?.result?.response?.result[0].company_id
    // companyId = CompanyListingStatus?.result?.response?.result[0].company_id
    // useEffect(() => {
    //     company_id = CompanyListingStatus?.result?.response?.result[0].company_id
    //     setCompanyId(company_id)
    //     CompanyProfile(company_id)
    // }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])
    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            CompanyProfile(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
            companyId = CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id
        }
        else {
            CompanyProfile(CompanyListingStatus?.result?.response?.result[0].company_id)
            companyId = CompanyListingStatus?.result?.response?.result[0].company_id
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    const CompanyProfile = async (company_id) => {
        console.log('themesetting-companyid', company_id)
        const result = await CompanyProfileTheme(company_id, userData?.user_type_id);
        console.log('result.data.data[0].primary_color_theme', result.data)
        setPrimaryColorValue(result.data.data[0].primary_color_theme)
        setSecondaryColorValue(result.data.data[0].secondary_color_theme)
        setImagePreview('')
        setCompanyLogo(result.data.data[0].company_logo)
    }
    const handleChange = (event) => {
        if (event.target.files && event.target.files[0]) {
            let reader = new FileReader();
            let file = event.target.files[0];
            setImageName(file.name)
            setImage(file)
            reader.onloadend = () => {
                setImagePreview(reader.result)
            };
            reader.readAsDataURL(file);
        } else {
            setImageName('')
            setImage('')
        }
    }
    const _handleSave = async () => {
        setLoader(true)
        let form_data = new FormData();
        form_data.append('companyname', imagename);
        form_data.append('image', image);
        form_data.append('primary_color_theme', primarycolorvalue);
        form_data.append('secondary_color_theme', secondarycolorvalue);
        form_data.append('created_by', userData.user_master_id);
        form_data.append('company', companyId);
        form_data.append('user_type_id', userData?.user_type_id);
        const result = await addCompanyTheme(form_data);
        if (result.data['status'] === true) {
            console.log('result', result.data.Message)
            toast.success(<AlertMessage type='success' title='Update Theme Setting'
                message={result.data['Message']} />, { autoClose: 4000 });
            setLoader(false)
            setBtnDisable('none')
            setBtnEditDisable('block')
            setDisable(true)
            dispatch(CompanyListingRequest())
        }
        else {
            toast.error(<AlertMessage type='error' title='Update Theme Setting'
                message={result.data['Message']} />, { autoClose: false });
            setLoader(false)
            setBtnDisable('none')
            setBtnEditDisable('block')
            setDisable(true)
        }
    }
    const _handleEdit = () => {
        setBtnDisable('block')
        setBtnEditDisable('none')
        setDisable(false)
    }
    const _handleCancel = () => {
        setBtnDisable('none')
        setBtnEditDisable('block')
        setDisable(true)
    }
    return (
        <React.Fragment>

            <Card>
                <CardBody>
                    <div className="d-flex">
                        <CardTitle tag="h6">
                            Theme Settings
                           </CardTitle>
                    </div>
                </CardBody>
                <Container>
                    <Container>

                        <FormGroup>
                            <Row>
                                <Col sm={5}>
                                    <Label className="text-right">
                                        Company logo
                                    </Label>
                                </Col>
                                <Col sm={7}>
                                    <div className="image-upload " disabled={disable}>
                                        <label htmlFor="file-input">

                                            <img className="img-profile-logo logo-size"
                                                src={imagePreview === ''
                                                    ? companylogo === null
                                                        || companylogo === ''
                                                        || companylogo === undefined
                                                        ? CONFIG.BASE_URL + Configuration.blankLogoPath + ''
                                                        : CONFIG.BASE_URL + companylogo + '?' + Date.now()
                                                    : imagePreview
                                                }
                                            />

                                        </label>
                                        <input id="file-input" disabled={disable} type="file" onChange={(e) => handleChange(e)} />
                                    </div>

                                </Col>
                            </Row>
                        </FormGroup>
                        <FormGroup>
                            <Row>
                                <Col sm={5}>
                                    <Label className="text-right">
                                        Primary color theme
                                    </Label>
                                </Col>
                                <Col sm={7}>
                                    <ColorBox
                                        disabled={disable}
                                        value={primarycolorvalue}
                                        applyValueMode="instantly"
                                        onValueChanged={(e) => handlePrimaryColorChange(e)}
                                    />
                                </Col>
                            </Row>
                        </FormGroup>
                        <FormGroup>
                            <Row>
                                <Col sm={5}>
                                    <Label className="text-right">
                                        Secondary color theme
                                    </Label>
                                </Col>
                                <Col sm={7}>

                                    <ColorBox
                                        disabled={disable}
                                        value={secondarycolorvalue}
                                        applyValueMode="instantly"
                                        onValueChanged={handleSecondaryColorChange}
                                    />


                                </Col>
                            </Row>
                        </FormGroup>

                        <div className="text-right company-profile-margin" >
                            <ThemeConsumer>{
                                ({ color }) => (
                                    <>
                                        <span style={{ display: btndisable }}>
                                            <span className="save-padding-add3plcompany">
                                                <Button outline color="secondary-custom" onClick={() => _handleCancel()}> Cancel </Button>
                                            </span>
                                            <Button color={color} disabled={loader} onClick={() => _handleSave()}>
                                                <span className="fa fa-floppy-o"></span>  Update <span> </span>
                                                {loader && (
                                                    <i
                                                        className="fa fa-spinner fa-spin"
                                                        style={{ marginRight: "5px" }}
                                                    />
                                                )}
                                            </Button>
                                        </span>
                                        <span style={{ display: btneditdisable }}>
                                            <Button color={color} onClick={() => _handleEdit()}>  <span className="fa fa-pencil" ></span>  Edit </Button>
                                        </span>
                                    </>
                                )

                            }
                            </ThemeConsumer>
                        </div>

                    </Container>
                </Container>
            </Card>
        </React.Fragment>
    )
}
export default CompanyThemeSetting;