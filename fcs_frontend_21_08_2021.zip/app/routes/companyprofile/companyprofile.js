import {
    Navbar, Container, Row, Col, DropdownToggle,
    DropdownMenu, DropdownItem, UncontrolledButtonDropdown
} from '../../components';
import React, { useState, useEffect } from 'react';
import { Configuration } from '../commoncomponents/configurationfile';
import CompanyInformation from './companyinformation'
import ThemeSetting from './themesetting'
import OtherSetting from './othersetting'
import CompanyTripScheduler from './companytripscheduler';

const CompanyProfile = (props) => {
    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div style={{ justifyContent: 'flex-start', display: 'inline-flex' }}>
                    <h4>Company Profile</h4>
                </div>
            </Navbar>
            <Container className="margin-top">
                you can manage your company information here.
                {props.userType === Configuration.userType.threePlCompany

                    ? <Row className="mb-3" className="margin-top">
                        <Col lg={6}>
                            <CompanyInformation />
                        </Col>
                        <Col lg={6}>
                            <ThemeSetting />
                        </Col>
                        <Col lg={6}>
                            <CompanyTripScheduler />
                        </Col>
                        <Col lg={6}>
                            <OtherSetting />
                        </Col>
                    </Row>
                    : <Row className="mb-3" className="margin-top">
                        <Col lg={6}>
                            <CompanyInformation userType={props.userType} />
                        </Col>

                    </Row>
                }
            </Container>
        </>
    )
}
export default CompanyProfile;
