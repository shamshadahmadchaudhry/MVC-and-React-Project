import React, { useState, useEffect } from 'react';
import {
    Card,
    CardBody,
    CardTitle,
    Container,
    FormGroup,
    Col,
    Label,
    Row,
    Button, ThemeConsumer
} from '../../components';
import { getUnitofMeasures } from '../../services/companyprofileservice';
import { UpdateUnitofMeasures } from '../../services/companyprofileservice';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import AlertMessage from '../commoncomponents/alertmessage';
let companyId = 0;
const OtherSetting = () => {
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [otherdata, setOtherData] = useState([])
    const [ischeckedtrue, setIsCheckedTrue] = useState(true)
    const [ischeckedfalse, setIsCheckedFalse] = useState(false)
    const [unitofmeasures, setUnitofMeasures] = useState('')
    const [loader, setLoader] = useState(false);
    const [btndisable, setBtnDisable] = useState("none")
    const [btneditdisable, setBtnEditDisable] = useState("")
    const [disable, setDisable] = useState(true)
    toast.configure();
    //companyId = CompanyListingStatus?.result?.response?.result[0].company_id
    // useEffect(() => {
    //     let company_id = CompanyListingStatus?.result?.response?.result[0].company_id
    //     companyId = company_id
    //     UnitMeasures(company_id)
    // }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])
    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            UnitMeasures(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
            companyId = CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id
        }
        else {
            UnitMeasures(CompanyListingStatus?.result?.response?.result[0].company_id)
            companyId = CompanyListingStatus?.result?.response?.result[0].company_id
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])
    const UnitMeasures = async (company_id) => {
        console.log('othersetting-companyid', company_id)
        const result = await getUnitofMeasures(company_id, userData?.user_type_id);
        setOtherData(result.data.data)
        console.log('result', result.data.data)
    }
    const _handleChecledFalse = (e) => {
        setIsCheckedFalse(true)
        setIsCheckedTrue(false)
        setUnitofMeasures(e)
        console.log(e)
    }
    const _handleChecledTrue = (e) => {
        setIsCheckedFalse(false)
        setIsCheckedTrue(true)
        setUnitofMeasures(e)
        console.log(e)
    }
    const _handleSave = async () => {
        setLoader(true)
        let body = {
            'company_id': companyId,
            'unitofmeasures': unitofmeasures
        }
        console.log(unitofmeasures)
        const result = await UpdateUnitofMeasures(body);
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title='Update UnitofMeasures'
                message={result.data['Message']} />, { autoClose: 4000 });
            setLoader(false)
        }
        else {
            toast.error(<AlertMessage type='error' title='Update UnitofMeasures'
                message={result.data['Message']} />, { autoClose: false });
            setLoader(false)
        }
        setBtnDisable('none')
        setBtnEditDisable('block')
        setDisable(true)
    }
    const _handleEdit = () => {
        setBtnDisable('block')
        setBtnEditDisable('none')
        setDisable(false)
    }
    const _handleCancel = () => {
        setBtnDisable('none')
        setBtnEditDisable('block')
        setDisable(true)
    }
    return (
        <React.Fragment>

            <Card className="mb-3 margin-top">
                <CardBody>
                    <div className="d-flex mb-4">
                        <CardTitle tag="h6">
                            Other Settings
                           </CardTitle>
                    </div>
                    <Container>
                        <FormGroup row>
                            <Col sm={4}>
                                <Label for="lastName" className="text-right">
                                    Unit of measure
                                    </Label>
                            </Col>
                            <Col sm={8}>
                                <div>
                                    <Row>
                                        {otherdata.map((item, index) => (
                                            (item.is_active === 1) ? (
                                                <Col sm={6}>
                                                    <input type="radio"
                                                        disabled={disable}
                                                        value={item.unitmeasures}
                                                        name={item.unitmeasures}
                                                        checked={ischeckedtrue}
                                                        onChange={() => _handleChecledTrue(item.unitmeasures)}
                                                    />
                                                    <label style={{ paddingLeft: "2%" }} >{item.unitmeasures}</label>
                                                </Col>
                                            ) :
                                                (
                                                    <Col sm={6}>
                                                        <input type="radio"
                                                            disabled={disable}
                                                            value={item.unitmeasures}
                                                            checked={ischeckedfalse}
                                                            name={item.unitmeasures}
                                                            onChange={() => _handleChecledFalse(item.unitmeasures)}
                                                        />
                                                        <label style={{ paddingLeft: "2%" }} >{item.unitmeasures}</label>
                                                    </Col>
                                                )

                                        ))}


                                    </Row>
                                </div>
                            </Col>
                        </FormGroup>
                        <div className="text-right company-profile-margin">
                            <ThemeConsumer>{
                                ({ color }) => (
                                    <>
                                        <span style={{ display: btndisable }}>
                                            <span className="save-padding-add3plcompany">
                                                <Button outline color="secondary-custom" onClick={() => _handleCancel()}> Cancel </Button>
                                            </span>
                                            <Button color={color} disabled={loader} onClick={() => _handleSave()}>
                                                <span className="fa fa-floppy-o"></span>  Update <span> </span>
                                                {loader && (
                                                    <i
                                                        className="fa fa-spinner fa-spin"
                                                        style={{ marginRight: "5px" }}
                                                    />
                                                )}
                                            </Button>
                                        </span>
                                        <span style={{ display: btneditdisable }}>
                                            <Button color={color} onClick={() => _handleEdit()}>  <span className="fa fa-pencil" ></span>  Edit </Button>
                                        </span>
                                    </>
                                )

                            }
                            </ThemeConsumer>
                        </div>
                    </Container>
                </CardBody>
            </Card>
        </React.Fragment>
    )
}
export default OtherSetting;