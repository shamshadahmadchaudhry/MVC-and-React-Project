import React from 'react';

import CompanyProfile from './companyprofile';
import { useSelector } from 'react-redux';

const CompanyThemeSetting = () => {
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    return (
        <CompanyProfile userType={userData?.user_type_id} />
    )
}
export default CompanyThemeSetting;