import React, { useState, useEffect } from 'react';
import Container from 'reactstrap/lib/Container';
import {
    Card,
    CardBody,
    CardTitle,
    FormGroup,
    Label,
    Col
} from '../../components';
import { Configuration } from '../commoncomponents/configurationfile';
import { CompanyProfileTheme } from '../../services/companyprofileservice';
import { useSelector } from 'react-redux';
let companyId = 0;
const CompanyInformation = (props) => {
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [companyprofile, setCompanyProfile] = useState([])
    const [companyaddress, setCompanyAddress] = useState('')
    //companyId = CompanyListingStatus?.result?.response?.result[0].company_id
    // useEffect(() => {
    //     let company_id = CompanyListingStatus?.result?.response?.result[0].company_id
    //     companyId = company_id
    //     CompanyProfile(company_id)
    // }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])
    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            CompanyProfile(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].company_id)
        }
        else
            CompanyProfile(CompanyListingStatus?.result?.response?.result[0].company_id)

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])
    const CompanyProfile = async (company_id) => {
        const result = await CompanyProfileTheme(company_id, userData?.user_type_id);
        console.log("Compant result=>:",result);
        setCompanyProfile(result.data.data[0])
        setCompanyAddress(result.data.data[0].company_address.address_line_1)
    }
    return (
        <React.Fragment>

            <Card>
                <CardBody>
                    <div className="d-flex mb-4">
                        <CardTitle tag="h6">
                            Company Information
                           </CardTitle>
                    </div>
                    <Container>
                        {props.userType === Configuration.userType.merchant
                            ? < div >
                                <FormGroup row>
                                    <Col sm={5}>
                                        <Label for="lastName" className="text-right">
                                            Company DBA name
                                    </Label>
                                    </Col>
                                    <Col sm={7}>
                                        {companyprofile.company_DBA_name}

                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Col sm={5}>
                                        <Label for="lastName" className="text-right">
                                            Company legal name
                                    </Label>
                                    </Col>
                                    <Col sm={7}>
                                        {companyprofile.company_legal_name}

                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Col sm={5}>
                                        <Label for="lastName" className="text-right">
                                            Company address
                                    </Label>
                                    </Col>
                                    <Col sm={7}>
                                        {companyaddress}

                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Col sm={5}>
                                        <Label for="lastName" className="text-right">
                                            Product category
                                    </Label>
                                    </Col>
                                    <Col sm={7}>
                                        {companyprofile.product_category_name}

                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Col sm={5}>
                                        <Label for="lastName" className="text-right">
                                            Desired sales channel
                                    </Label>
                                    </Col>
                                    <Col sm={7}>
                                        {companyprofile.sales_channel_name}

                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Col sm={5}>
                                        <Label for="lastName" className="text-right">
                                            Number of SKU in hand
                                    </Label>
                                    </Col>
                                    <Col sm={7}>
                                        {companyprofile.sku_count}
                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Col sm={5}>
                                        <Label for="lastName" className="text-right">
                                            Monthly order volume
                                    </Label>
                                    </Col>
                                    <Col sm={7}>
                                        {companyprofile.monthly_order_volume}
                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Col sm={5}>
                                        <Label for="lastName" className="text-right">
                                            Quantity per order
                                    </Label>
                                    </Col>
                                    <Col sm={7}>
                                        {companyprofile.monthly_order_volume}
                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Col sm={5}>
                                        <Label for="lastName" className="text-right">
                                            Number of pallets per order
                                    </Label>
                                    </Col>
                                    <Col sm={7}>
                                        {companyprofile.qty_per_order}

                                    </Col>
                                </FormGroup>
                            </div>
                            : < div >
                                <FormGroup row>
                                    <Col sm={5}>
                                        <Label for="lastName" className="text-right">
                                            Company DBA name
                                    </Label>
                                    </Col>
                                    <Col sm={7}>
                                        {companyprofile.company_DBA_name}

                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Col sm={5}>
                                        <Label for="lastName" className="text-right">
                                            Company legal name
                                    </Label>
                                    </Col>
                                    <Col sm={7}>
                                        {companyprofile.company_legal_name}

                                    </Col>
                                </FormGroup>
                                <FormGroup row>
                                    <Col sm={5}>
                                        <Label for="lastName" className="text-right">
                                            Company address
                                    </Label>
                                    </Col>
                                    <Col sm={7}>
                                        {companyaddress}
                                    </Col>
                                </FormGroup>
                            </div>
                        }

                    </Container>
                </CardBody>
            </Card>
        </React.Fragment >
    )
}
export default CompanyInformation;