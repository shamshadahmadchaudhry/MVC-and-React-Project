import React, { useState, useEffect } from 'react';
import {
    Container, Row, Col, ThemeConsumer, Button, Navbar, Nav
    , Card, CardBody, CardTitle, FormGroup, Label
} from '../../components';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as yup from 'yup';
import { Configuration } from '../commoncomponents/configurationfile';
import {
    threeplCompanyAdd_Service, threeplCompanyEdit_Service,
    threeplCompanyUpdate_Service
} from '../../services/threeplcompanyservice'
import AlertMessage from '../commoncomponents/alertmessage';
import { ToastContainer, toast } from 'react-toastify';
import queryString from 'query-string';
import { useHistory } from "react-router-dom";
import '../../styles/common.scss';
import CompanyUsers from '../productowner/companyusers';
import { productCategoryList, salesChannelList, saveMerchantAdditionalInfo, updateMerchantAdditionalInfo } from '../../services/merchantservices';
import { useSelector } from "react-redux";

const CompanyManagement = (props) => {
    let history = useHistory();
    const parsed = queryString.parse(location.search);
    const [companyId, setCompanyId] = useState(parsed['company_id']);
    const [productCategory, setproductCategory] = useState([]);
    const [salesChannel, setsalesChannel] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus)
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [companyData, setCompanyData] = useState({
        company_dba_name: '', company_name: '', address_line_1: '', address_line_2: ''
        , zip_code: '', city: '', state: '1', country: '1', website_url: '', sku_count: '', product_category_id: '',
        monthly_order_volume: '', sales_channel_id: '', qty_per_order: '', pallets_per_order_count: '',
        user_type_id: props.userType, created_by: userData.user_master_id, created_date: new Date()
    })

    async function loadData() {
        let category = await productCategoryList();
        let channels = await salesChannelList();
        setproductCategory(category.data.result);
        setsalesChannel(channels.data.result);
    }

    useEffect(() => {
        if (props.userType === Configuration.userType.merchant) {
            loadData();
        }
    }, [])

    const [buttonName, setButtonName] = useState('Save');

    useEffect(() => {
        if (!companyId) {
            setButtonName('Save')
        } else {
            setButtonName('Update')
            loadThreePLCompanyDetails(companyId)
        }
    }, [companyId])

    const loadThreePLCompanyDetails = async (companyId) => {
        const result = await threeplCompanyEdit_Service(companyId)
        console.log('RESULT', result)
        setCompanyData(result.data['data'][0])
    }

    const _handleClick = () => {
        if (props.userType === Configuration.userType.threePlCompany)
            history.push('3PLCompany/3PLCompany');
        else
            history.push('MerchantCompany/MerchantCompany');
        //empty users variable in local Storage
        localStorage.setItem('users', JSON.stringify(""))
    }

    const AddThreePLCompany = async (values) => {
        let parentCompanyId = CompanyListingStatus?.result?.response?.result[0].company_id

        setIsLoading(true);
        let localUser = JSON.parse(localStorage.getItem('users'));

        let body = {
            company_id: companyId,
            company_dba_name: values.company_dba_name,
            company_legal_name: values.company_name,
            tax_no: 'TAX',
            address_line_1: values.address_line_1,
            address_line_2: values.address_line_2,
            city: values.city,
            country: values.country,
            state: values.state,
            zip_code: values.zip_code,
            is_active: 1,
            user_type_id: props.userType,
            users: localUser,
            created_by: userData.user_master_id,
            parent_company_id: parentCompanyId
        }

        let additional_info = {
            merchant_info_id: values.merchant_info_id, "company_id": companyId, "product_category_id": values.product_category_id,
            "sales_channel_id": values.sales_channel_id, "website_url": values.website_url, created_by: userData.user_master_id,
            "sku_count": values.sku_count, "monthly_order_volume": values.monthly_order_volume,
            "qty_per_order": values.qty_per_order, "pallets_per_order_count": values.pallets_per_order_count
        }

        if (!companyId) {
            if (localStorage.getItem('users')) {
                if (localUser.length > 0) {
                    const response = await threeplCompanyAdd_Service(body);
                    if (response.data.status === true) {
                        if (props.userType === Configuration.userType.threePlCompany) {
                            setIsLoading(false);
                            localStorage.removeItem('users');
                            if (response.data.message) {
                                toast.error(<AlertMessage type='error'
                                    title='Failed.'
                                    message={response.data.message} />, { autoClose: false });
                            } else {
                                history.push('3PLCompany/3PLCompany');
                            }
                        }
                        else {
                            // If merchant company  added successfully then add merchant company additional information.
                            additional_info.company_id = response.data.result.company_id;
                            const resp = await saveMerchantAdditionalInfo(additional_info);
                            if (resp.data.status === true) {
                                if (response.data.message) {
                                    toast.error(<AlertMessage type='error'
                                        title='Failed.'
                                        message={response.data.message} />, { autoClose: false });
                                } else {
                                    history.push('MerchantCompany/MerchantCompany');
                                }
                                localStorage.removeItem('users');
                            }
                            else {
                                toast.error(<AlertMessage type='error'
                                    title='Failed.'
                                    message={resp.data.message} />, { autoClose: false })
                                setIsLoading(false);
                            }
                        }
                    } else {
                        toast.error(<AlertMessage type='error'
                            title='Failed.'
                            message={response.data.result} />, { autoClose: false })
                        setIsLoading(false);
                    }
                } else {
                    toast.error(<AlertMessage type='error'
                        title='Failed.'
                        message='Please add atleast one user.' />, { autoClose: false });
                    setIsLoading(false);
                }
            } else {
                toast.error(<AlertMessage type='error'
                    title='Failed.'
                    message='Please add atleast one user.' />, { autoClose: false });
                setIsLoading(false);
            }
        } else {
            const result = await threeplCompanyUpdate_Service(body);
            if (result.data.status === true) {
                if (props.userType === Configuration.userType.merchant) {
                    // If merchant company  added successfully then add merchant company additional information.
                    const resp = await updateMerchantAdditionalInfo(additional_info);
                    if (resp.data.status === true) {
                        localStorage.removeItem('users');
                        history.push('MerchantCompany/MerchantCompany');
                    }
                    setIsLoading(false);
                } else {
                    history.push('3PLCompany/3PLCompany');
                }
            } else {
                toast.error(<AlertMessage type='error'
                    title='Failed.'
                    message={result.data['message']} />, { autoClose: false });

                setIsLoading(false);

            }
        }
        return false;
    }

    let validationShape = {
        company_dba_name: yup.string().nullable().required(`${Configuration.required} company dba name`)
            .matches(Configuration.alphanumericSpacemandatory, "Only Alphanumeric characters are accepted"),
        company_name: yup.string().nullable().required(`${Configuration.required} company legal name`)
            .matches(Configuration.alphanumericSpacemandatory, "Only Alphanumeric characters are accepted"),
        // tax_no: yup.string().nullable().required(`${Configuration.required} tax id`)
        //     .matches(Configuration.alphanumeric, "Only Alphanumeric Characters are accepted"),
        address_line_1: yup.string().nullable().required(`${Configuration.required} address line 1`)
            .matches(Configuration.alphanumComaDashSpace, "Only Alphanumeric Characters are accepted"),
        address_line_2: yup.string().nullable().required(`${Configuration.required} address line 2`)
            .matches(Configuration.alphanumComaDashSpace, "Only Alphanumeric Characters are accepted"),
        zip_code: yup.string().nullable().required(`${Configuration.required} zip code`)
            .matches(Configuration.digits, "Invalid input, Only digits allowed"),
        city: yup.string().nullable().required(`${Configuration.required} city`)
            .matches(Configuration.alphabat, "Only Alphabets are allowed"),
        state: yup.string().nullable().required(`${Configuration.required} state`),
        country: yup.string().nullable().required(`${Configuration.required} country`),
    }

    if (props.userType === Configuration.userType.merchant) {
        validationShape = {
            company_dba_name: yup.string().nullable().required(`${Configuration.required} company dba name`)
                .matches(Configuration.alphanumericSpacemandatory, "Only Alphanumeric characters are accepted"),
            company_name: yup.string().nullable().required(`${Configuration.required} company legal name`)
                .matches(Configuration.alphanumericSpacemandatory, "Only Alphanumeric characters are accepted"),
            // tax_no: yup.string().nullable().required(`${Configuration.required} tax id`)
            //     .matches(Configuration.alphanumeric, "Only Alphanumeric Characters are accepted"),
            address_line_1: yup.string().nullable().required(`${Configuration.required} address line 1`)
                .matches(Configuration.alphanumComaSpace, "Only Alphanumeric Characters are accepted"),
            address_line_2: yup.string().nullable().required(`${Configuration.required} address line 2`)
                .matches(Configuration.alphanumComaSpace, "Only Alphanumeric Characters are accepted"),
            zip_code: yup.string().nullable().required(`${Configuration.required} zip code`)
                .matches(Configuration.digits, "Invalid input, Only digits allowed"),
            city: yup.string().nullable().required(`${Configuration.required} city`)
                .matches(Configuration.alphabat, "Only Alphabets are allowed"),
            state: yup.string().nullable().required(`${Configuration.required} state`),
            country: yup.string().nullable().required(`${Configuration.required} country`),
            website_url: yup.string().nullable().required(`${Configuration.required} website url`).
                matches(Configuration.websiteUrl, "Invalid website url"),
            sku_count: yup.string().nullable().required(`${Configuration.required} number of SKUs in hand`)
                .matches(Configuration.numeric, "Invalid input"),
            product_category_id: yup.string().nullable().required(`Please select product category`),
            monthly_order_volume: yup.string().nullable().required(`${Configuration.required} monthly order volume`)
                .matches(Configuration.digits, "Please input valid monthly order volume"),
            sales_channel_id: yup.string().nullable().required(`Please select desired sales channel.`),
            qty_per_order: yup.string().nullable().required(`${Configuration.required} quantity per order.`)
                .matches(Configuration.digits, "Please input valid quantity"),
            pallets_per_order_count: yup.string().nullable().required(`${Configuration.required} number of pallates per order.`)
                .matches(Configuration.digits, "Please input valid number of pallets")
        }
    }

    return (
        <>
            <Formik
                initialValues={companyData}
                validationSchema={yup.object().shape(validationShape)}
                onSubmit={AddThreePLCompany}
                enableReinitialize={true}
            >
                {({ errors, touched, values }) => (
                    <Form>
                        <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                            <div class="btn-group title-text-style">
                                <h4>Add {props.userType === Configuration.userType.threePlCompany ? ' 3PL ' : ' Merchant '} Companies</h4>
                            </div>
                            <ThemeConsumer>
                                {({ color }) => (
                                    <div>
                                        <Nav className='d-md-block'>
                                            <span className="save-padding-add3plcompany">
                                                <Button outline color="secondary" onClick={() => _handleClick()}> Cancel </Button>
                                            </span>
                                            <Button type="submit" disabled={isLoading} color={color} >
                                                <i className="fa fa-floppy-o" aria-hidden="true"></i>  {buttonName}
                                                {isLoading && (
                                                    <i
                                                        className="fa fa-spinner fa-spin ml-1"
                                                    />)}
                                            </Button>
                                        </Nav>
                                    </div>
                                )}
                            </ThemeConsumer>
                        </Navbar>
                        <Container className="margin-top">
                            <Row>
                                <Col lg={12}>
                                    <Col lg={12}>
                                        <p>Add new {props.userType === Configuration.userType.threePlCompany ? '3PL' : 'merchant'} company by adding company and atleast one user under the company</p>
                                    </Col>
                                </Col>
                            </Row>
                            <Row >
                                <Col>
                                    <Card>
                                        <CardBody>
                                            <div className="d-flex mb-4">
                                                <CardTitle tag="h6">
                                                    {props.userType === Configuration.userType.threePlCompany ? '3PL' : 'Merchant'} Company Information
                               </CardTitle>
                                                <span className="ml-auto align-self-start small">
                                                    Fields mark as <span className="text-danger">*</span> is required.
                                </span>
                                            </div>

                                            <Row >
                                                <Col lg={6}>
                                                    <FormGroup>
                                                        <Label for="companydbaname">
                                                            Company DBA name <span className="text-danger">*</span>
                                                        </Label>
                                                        <Field type="text"
                                                            placeholder="Enter Company DBA name"
                                                            name="company_dba_name"
                                                            value={values.company_dba_name}
                                                            className={`${touched.company_dba_name && errors.company_dba_name && 'is-invalid'} bg-white form-control`} />
                                                        {touched.company_dba_name && errors.company_dba_name &&
                                                            <ErrorMessage name="company_dba_name" component="span" className="text-danger"></ErrorMessage>
                                                        }

                                                    </FormGroup>
                                                </Col>
                                                <Col lg={6}>
                                                    <FormGroup>
                                                        <Label for="state">
                                                            Country <span className="text-danger">*</span>
                                                        </Label>
                                                        <Field disabled={true} as="select" className="form-control" name="country" maxLength="100" id="country"
                                                            className={`${touched.country && errors.country && 'is-invalid'} bg-white form-control`} >
                                                            <option value="1">US</option>
                                                            <option value="0">Select State</option>
                                                            <option value="1">India</option>
                                                            <option value="3">America</option>
                                                        </Field >
                                                        <ErrorMessage name="country" component="span" className="text-danger" />

                                                    </FormGroup>

                                                </Col>
                                            </Row>
                                            <Row >
                                                <Col lg={6}>
                                                    <FormGroup>
                                                        <Label for="companylegalname">
                                                            Company legal name <span className="text-danger">*</span>
                                                        </Label>
                                                        <Field type="text"
                                                            placeholder="Enter Company legal name"
                                                            name="company_name"
                                                            value={values.company_name}
                                                            className={`${touched.company_name && errors.company_name && 'is-invalid'} bg-white form-control`} />
                                                        {touched.company_name && errors.company_name &&
                                                            <ErrorMessage name="company_name" component="span" className="text-danger"></ErrorMessage>
                                                        }
                                                    </FormGroup>
                                                </Col>
                                                <Col lg={6}>
                                                    <FormGroup>
                                                        <Label for="addressline1">
                                                            Address line 1 <span className="text-danger">*</span>
                                                        </Label>
                                                        <Field type="text"
                                                            placeholder="Enter Address line 1"
                                                            name="address_line_1"
                                                            value={values.address_line_1}
                                                            className={`${touched.address_line_1 && errors.address_line_1 && 'is-invalid'} bg-white form-control`} />
                                                        {touched.address_line_1 && errors.address_line_1 &&
                                                            <ErrorMessage name="address_line_1" component="span" className="text-danger"></ErrorMessage>
                                                        }
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                            <Row >
                                                {/*<Col lg={6}>
                                                    <FormGroup>
                                                        <Label for="taxid">
                                                            Tax id <span className="text-danger">*</span>
                                                        </Label>
                                                        <Field type="text"
                                                            placeholder="Enter tax id"
                                                            name="tax_no"
                                                            value={values.tax_no}
                                                            className={`${touched.tax_no && errors.tax_no && 'is-invalid'} bg-white form-control`} />
                                                        {touched.tax_no && errors.tax_no &&
                                                            <ErrorMessage name="tax_no" component="span" className="text-danger"></ErrorMessage>
                                                        }
                                                    </FormGroup> 
                                                </Col>*/}
                                                <Col lg={6}>

                                                </Col>
                                                <Col lg={6}>
                                                    <FormGroup>
                                                        <Label for="addressline2">
                                                            Address line 2 <span className="text-danger">*</span>
                                                        </Label>
                                                        <Field type="text"
                                                            placeholder="Enter Address line 2"
                                                            name="address_line_2"
                                                            value={values.address_line_2}
                                                            className={`${touched.address_line_2 && errors.address_line_2 && 'is-invalid'} bg-white form-control`} />
                                                        {touched.address_line_2 && errors.address_line_2 &&
                                                            <ErrorMessage name="address_line_2" component="span" className="text-danger"></ErrorMessage>
                                                        }
                                                    </FormGroup>
                                                    <Row>
                                                        <Col lg={4}>
                                                            <FormGroup>
                                                                <Label for="zipcode">
                                                                    ZIP Code <span className="text-danger">*</span>
                                                                </Label>
                                                                <Field type="text"
                                                                    placeholder="Enter ZIP code"
                                                                    name="zip_code"
                                                                    value={values.zip_code}
                                                                    className={`${touched.zip_code && errors.zip_code && 'is-invalid'} bg-white form-control`} />
                                                                {touched.zip_code && errors.zip_code &&
                                                                    <ErrorMessage name="zip_code" component="span" className="text-danger"></ErrorMessage>
                                                                }
                                                            </FormGroup>
                                                        </Col>
                                                        <Col lg={4}>
                                                            <FormGroup>
                                                                <Label for="state">
                                                                    State <span className="text-danger">*</span>
                                                                </Label>
                                                                <Field disabled={true} as="select" className="form-control" name="state" maxLength="100" id="state"
                                                                    className={`${touched.state && errors.state && 'is-invalid'} bg-white form-control`} >
                                                                    <option value="1">Alabama</option>
                                                                    <option value="1">Maharashtra</option>
                                                                    <option value="2">UP</option>
                                                                    <option value="3">Delhi</option>
                                                                </Field >
                                                                <ErrorMessage name="state" component="span" className="text-danger" />
                                                            </FormGroup>
                                                        </Col>
                                                        <Col lg={4}>
                                                            <FormGroup>
                                                                <Label for="city">
                                                                    City <span className="text-danger">*</span>
                                                                </Label>
                                                                <Field type="text"
                                                                    placeholder="Enter city"
                                                                    name="city"
                                                                    value={values.city}
                                                                    className={`${touched.city && errors.city && 'is-invalid'} bg-white form-control`} />
                                                                {touched.city && errors.city &&
                                                                    <ErrorMessage name="city" component="span" className="text-danger"></ErrorMessage>
                                                                }
                                                            </FormGroup>
                                                        </Col>
                                                    </Row>
                                                </Col>
                                            </Row>
                                        </CardBody>
                                    </Card>
                                </Col>
                            </Row>
                        </Container>
                        {
                            props.userType === Configuration.userType.merchant ? <Container className="margin-top">
                                <Row >
                                    <Col>
                                        <Card>
                                            <CardBody>
                                                <div className="d-flex mb-4">
                                                    <CardTitle tag="h6"> Additional Information </CardTitle>
                                                    <span className="ml-auto align-self-start small">
                                                        Fields mark as <span className="text-danger">*</span> is required. </span>
                                                </div>
                                                <Row >
                                                    <Col lg={6}>
                                                        <FormGroup>
                                                            <Label for="website_url">
                                                                Website url <span className="text-danger">*</span>
                                                            </Label>
                                                            <Field type="text"
                                                                placeholder="Enter website url"
                                                                name="website_url"
                                                                value={values.website_url}
                                                                className={`${touched.website_url && errors.website_url && 'is-invalid'} bg-white form-control`} />
                                                            {touched.website_url && errors.website_url &&
                                                                <ErrorMessage name="website_url" component="span" className="text-danger"></ErrorMessage>
                                                            }

                                                        </FormGroup>
                                                    </Col>
                                                    <Col lg={6}>
                                                        <FormGroup>
                                                            <Label for="sku_count">
                                                                Number of SKUs in hand <span className="text-danger">*</span>
                                                            </Label>
                                                            <Field type="text"
                                                                placeholder="Enter number of SKUs in hand"
                                                                name="sku_count"
                                                                value={values.sku_count}
                                                                className={`${touched.sku_count && errors.sku_count && 'is-invalid'} bg-white form-control`} />
                                                            {touched.sku_count && errors.sku_count &&
                                                                <ErrorMessage name="sku_count" component="span" className="text-danger"></ErrorMessage>
                                                            }

                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                                <Row >
                                                    <Col lg={6}>
                                                        <FormGroup>
                                                            <Label for="state">
                                                                Product Category <span className="text-danger">*</span>
                                                            </Label>
                                                            <Field as="select" className="form-control" name="product_category_id" maxLength="100" id="product_category_id"
                                                                className={`${touched.product_category_id && errors.product_category_id && 'is-invalid'} bg-white form-control`} >
                                                                <option value="">Select product category</option>
                                                                {
                                                                    productCategory.length > 0 && (productCategory.map((cat, index) => (
                                                                        <option key={cat.product_category_name} value={cat.product_category_id}>{cat.product_category_name}</option>
                                                                    )))
                                                                }

                                                            </Field >
                                                            <ErrorMessage name="product_category_id" component="span" className="text-danger" />

                                                        </FormGroup>
                                                    </Col>
                                                    <Col lg={6}>
                                                        <FormGroup>
                                                            <Label for="website_url">
                                                                Monthly order volume <span className="text-danger">*</span>
                                                            </Label>
                                                            <Field type="text"
                                                                placeholder="Enter monthly order volume"
                                                                name="monthly_order_volume"
                                                                value={values.monthly_order_volume}
                                                                className={`${touched.monthly_order_volume && errors.monthly_order_volume && 'is-invalid'} bg-white form-control`} />
                                                            {touched.monthly_order_volume && errors.monthly_order_volume &&
                                                                <ErrorMessage name="monthly_order_volume" component="span" className="text-danger"></ErrorMessage>
                                                            }

                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                                <Row>
                                                    <Col lg={6}>
                                                        <FormGroup>
                                                            <Label for="state">
                                                                Desired sales channel <span className="text-danger">*</span>
                                                            </Label>
                                                            <Field as="select" className="form-control" name="sales_channel_id" maxLength="100" id="country"
                                                                className={`${touched.sales_channel_id && errors.sales_channel_id && 'is-invalid'} bg-white form-control`} >
                                                                <option value="">Select desired sales channel</option>
                                                                {
                                                                    salesChannel.length > 0 && (salesChannel.map((sales, index) => (
                                                                        <option key={sales.sales_channel_name} value={sales.sales_channel_id}>{sales.sales_channel_name}</option>
                                                                    )))
                                                                }
                                                            </Field >
                                                            <ErrorMessage name="sales_channel_id" component="span" className="text-danger" />

                                                        </FormGroup>
                                                    </Col>
                                                    <Col lg={6}>
                                                        <FormGroup>
                                                            <Label for="qty_per_order">
                                                                Quantity per order <span className="text-danger">*</span>
                                                            </Label>
                                                            <Field type="text"
                                                                placeholder="Enter quantity per order"
                                                                name="qty_per_order"
                                                                value={values.qty_per_order}
                                                                className={`${touched.qty_per_order && errors.qty_per_order && 'is-invalid'} bg-white form-control`} />
                                                            {touched.qty_per_order && errors.qty_per_order &&
                                                                <ErrorMessage name="qty_per_order" component="span" className="text-danger"></ErrorMessage>
                                                            }

                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                                <Row>
                                                    <Col lg={6}>

                                                    </Col>
                                                    <Col lg={6}>
                                                        <FormGroup>
                                                            <Label for="pallets_per_order_count">
                                                                Number of pallates per order <span className="text-danger">*</span>
                                                            </Label>
                                                            <Field type="text"
                                                                placeholder="Enter number of pallates per order"
                                                                name="pallets_per_order_count"
                                                                value={values.pallets_per_order_count}
                                                                className={`${touched.pallets_per_order_count && errors.pallets_per_order_count && 'is-invalid'} bg-white form-control`} />
                                                            {touched.pallets_per_order_count && errors.pallets_per_order_count &&
                                                                <ErrorMessage name="pallets_per_order_count" component="span" className="text-danger"></ErrorMessage>
                                                            }
                                                        </FormGroup>
                                                    </Col>
                                                </Row>
                                            </CardBody>
                                        </Card>
                                    </Col>
                                </Row>
                            </Container> : ''
                        }
                    </Form>
                )}
            </Formik>


            {buttonName === 'Save' && (
                <Container className="margin-top">
                    <Row >
                        <Col>
                            <Card>
                                <CardBody>
                                    <div className="d-flex mb-0 pb-0">
                                        <CardTitle tag="h6">
                                            Company Users
                               </CardTitle>
                                        {/* <span className="ml-auto align-self-start small">
                                        Fields mark as <span className="text-danger">*</span> is required.
                                </span> */}
                                    </div>

                                    <Row >
                                        <CompanyUsers companyId={0} userType={props.userType} />
                                    </Row>
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                </Container>)
            }

            <ToastContainer
                position={'top-right'}
                draggable={false}
                hideProgressBar={true}
            />
        </>

    )
}

export default CompanyManagement;