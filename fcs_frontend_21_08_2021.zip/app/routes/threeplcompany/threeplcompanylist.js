
import React from 'react';
import { Configuration } from '../commoncomponents/configurationfile';

import CompaniesList from './companieslist';

const ThreePlCompanyList = (props) => {
    return (
        <CompaniesList userType={Configuration.userType.threePlCompany} />
    )
}

export default ThreePlCompanyList;