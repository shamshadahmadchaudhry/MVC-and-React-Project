import React from 'react';
import BootstrapTable from 'react-bootstrap-table-next';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import paginationFactory from 'react-bootstrap-table2-paginator';
import filterFactory from 'react-bootstrap-table2-filter';
import { Container } from '../../components';
import { CustomPaginationPanel } from './components/CustomPaginationPanel';
import { CustomSizePerPageButton } from './components/CustomSizePerPageButton';
import { CustomPaginationTotal } from './components/CustomPaginationTotal';
import CompanyUsersListing from '../productowner/companyuserslisting';


const ThreePLCompany = (props) => {
    const customTotal = (from, to, size) => (
        <span className="react-bootstrap-table-pagination-total">
            Showing { from} to { to} of { size} Results
        </span>
    );

    const pagination = (length, pageSize) => {
        let pazination = [];
        let pageCount = length / pageSize;

        for (let i = 0; i < length; i++) {
            pazination({ text: 1 })
        }
    }

    const options = {
        paginationSize: 5,
        pageStartIndex: 0,
        //alwaysShowAllBtns: true, // Always show next and previous button
        // withFirstAndLast: false, // Hide the going to First and Last page button
        // hideSizePerPage: true, // Hide the sizePerPage dropdown always
        // hidePageListOnlyOnePage: true, // Hide the pagination list when only one page
        firstPageText: 'First',
        prePageText: 'Back',
        nextPageText: 'Next',
        lastPageText: 'Last',
        nextPageTitle: 'First page',
        prePageTitle: 'Pre page',
        firstPageTitle: 'Next page',
        lastPageTitle: 'Last page',
        showTotal: true,
        paginationTotalRenderer: customTotal,
        disablePageTitle: true,
        sizePerPageList: [{
            text: '5', value: 5
        }, {
            text: '10', value: 10
        }, {
            text: 'All', value: props.rowData.length
        }] // A numeric array is also available. the purpose of above example is custom the text
    };

    const paginationDef = paginationFactory({
        paginationSize: 10,
        showTotal: true,
        pageListRenderer: (props) => (
            <CustomPaginationPanel {...props} size="sm" className="ml-md-auto mt-2 mt-md-0" />
        ),
        sizePerPageRenderer: (props) => (
            <CustomSizePerPageButton {...props} />
        ),
        paginationTotalRenderer: (from, to, size) => (
            <CustomPaginationTotal {...{ from, to, size }} />
        )
    });

    const expandRow = {
        renderer: row => (
            <CompanyUsersListing userType={props.userType} key={row.company_dba_name} companyId={row.company_id} />
        ),
        showExpandColumn: true,
        expandByColumnOnly: true,

        expandHeaderColumnRenderer: ({ isAnyExpands }) => isAnyExpands ? (
            <i className="fa fa-angle-down fa-fw fa-lg text-muted"></i>
        ) : (
                <i className="fa fa-angle-right fa-fw fa-lg text-muted"></i>
            ),
        expandColumnRenderer: ({ expanded }) =>
            expanded ? (
                <i className="fa fa-angle-down fa-fw fa-lg text-muted"></i>
            ) : (
                    <i className="fa fa-angle-right fa-fw fa-lg text-muted"></i>
                )
    }

    return (
        <ToolkitProvider
            keyField="company_id"
            columns={props.headers}
            data={props.rowData}
            search
            exportCSV
        >
            {
                props => (
                    <React.Fragment>
                        <Container >
                            <BootstrapTable hover
                                classes="table-responsive"
                                pagination={paginationDef}
                                filter={filterFactory()}
                                expandRow={expandRow}
                                bordered={false}
                                responsive
                                {...props.baseProps}
                            />
                        </Container>
                    </React.Fragment>
                )
            }
        </ToolkitProvider>
    )
}

export default ThreePLCompany