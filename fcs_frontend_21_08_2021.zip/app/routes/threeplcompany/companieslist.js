
import React, { useEffect, useState } from 'react';
import {
    Container, Row, Col, ThemeConsumer, Button, Navbar, Nav,
    UncontrolledModal,
    ModalFooter,
    ModalBody,
    ModalHeader,
    UncontrolledTooltip
} from '../../components';
import {
    buildCustomTextFilter,
} from '../../components/Tables/ExtendedTable/filters';
import ThreePLCompany from './threeplcompany';
import { threeplCompanyList_Service, threeplCompanyDelete_Service } from '../../services/threeplcompanyservice'
import { Link } from "react-router-dom";
import AlertMessage from '../commoncomponents/alertmessage';
import { ToastContainer, toast } from 'react-toastify';
import { useHistory } from "react-router-dom";
import { Configuration } from '../commoncomponents/configurationfile';

let companydbanameFilter;
let companynameFilter;

const CompaniesList = (props) => {
    let history = useHistory();
    const [threeplCompanyList, setthreeplCompanyList] = useState([])

    useEffect(() => {
        async function loadthreeplCompanyList() {
            const result = await threeplCompanyList_Service(props.userType);
            let responseData = result.data.data
            setthreeplCompanyList(responseData.sort((a, b) => b.company_id - a.company_id));
        }
        loadthreeplCompanyList();
    }, []);

    const loadthreeplCompany = async () => {
        const result = await threeplCompanyList_Service(props.userType);
        let responseData = result.data.data
        setthreeplCompanyList(responseData.sort((a, b) => b.company_id - a.company_id));
    }

    const sortCaret = (order) => {
        if (!order)
            return <i className="fa fa-fw fa-sort text-muted"></i>;
        if (order)
            return <i className={`fa fa-fw text-muted fa-sort-${order}`}></i>
    };

    const header = [{
        dataField: 'company_dba_name',
        text: 'Company DBA Name',
        sort: true,
        sortCaret,
        formatter: (cell) => (
            <span className="text-inverse">
                { cell}
            </span>
        ),
        ...buildCustomTextFilter({
            placeholder: 'Enter company DBA name...',
            getFilter: filter => { companydbanameFilter = filter; }
        }),

    },
    {
        dataField: 'company_legal_name',
        text: 'Company legal Name',
        sort: true,
        sortCaret,
        formatter: (cell) => (
            <span className="text-inverse">
                { cell}
            </span>
        ),
        ...buildCustomTextFilter({
            placeholder: 'Enter company legal name...',
            getFilter: filter => { companynameFilter = filter; }
        })
    },
    {
        text: 'Action', dataField: '',
        formatter: (cell, row) => {
            return (
                <>
                    <a id='UncontrolledTooltipEditCompany'  title='Edit Company' style={{ cursor: "pointer" }} className="navbar-brand mr-0 mr-sm-3" onClick={() => _handleEdit(row.company_id)} >
                        <i className="fa fa-edit ml-1" ></i></a>
                        {/* <UncontrolledTooltip placement="top" target="UncontrolledTooltipEditCompany">
                            Edit Company
                        </UncontrolledTooltip> */}
                    <a style={{ cursor: "pointer" }} title='Delete company' className="navbar-brand mr-0 mr-sm-3" id={"modalDefault" + row.company_id}  >
                        <i className="fa fa-trash ml-1"></i></a>
                    {/* <UncontrolledTooltip placement="top" ClassName='bg-light'>
                        Delete Company
                    </UncontrolledTooltip> */}
                    < UncontrolledModal target={"modalDefault" + row.company_id} className="modal-outline-warning" >
                        <ModalHeader tag="h6">
                            <span className="text-warning">
                                <i className="fa fa-fw fa-2x fa-exclamation"></i>
                                    Warning : Remove Company
                                </span>
                        </ModalHeader>
                        <ModalBody>
                            <div style={{ marginTop: "10px" }} className="media-body">
                                <p> Are sure you want to remove this company?</p>
                            </div>
                        </ModalBody>
                        <ModalFooter>
                            <UncontrolledModal.Close color="link" className="text-warning">
                                Close
                                </UncontrolledModal.Close>
                            <ThemeConsumer>
                                {
                                    ({ color }) => (
                                        <UncontrolledModal.Close color="link" className="text-warning">
                                            <Button color={color} onClick={() => _handleDelete(row.company_id)} >
                                                Yes
                                        </Button>
                                        </UncontrolledModal.Close>
                                    )
                                }
                            </ThemeConsumer>

                        </ModalFooter>
                    </UncontrolledModal >
                </>
            )
        },
        headerFormatter: column => (
            <React.Fragment>
                <span className="text-nowrap">{column.text}</span>
                <a
                    href="javascript:;"
                    className="d-block small text-decoration-none text-nowrap"
                    onClick={handleResetFilters}
                >
                    Reset Filters <i className="fa fa-times fa-fw dx-link-delete"></i>
                </a>
            </React.Fragment>
        )
    }
    ]


    const handleResetFilters = () => {
        companydbanameFilter('')
        companynameFilter('')
    }

    const _handleDelete = async (company_id) => {
        const result = await threeplCompanyDelete_Service(company_id)
        if (result.data['status'] === true) {
            loadthreeplCompany();
            toast.success(<AlertMessage type='success'
                title='Success'
                message={result.data['data']} />, { autoClose: 4000 })
        } else {
            toast.error(<AlertMessage type='error'
                title='Failed.'
                message={result.data['data']} />, { autoClose: false })
        }
    }

    const _handleEdit = (company_id) => {
        if (props.userType === Configuration.userType.threePlCompany)
            history.push('/addthreeplcomapny?company_id=' + company_id);
        else
            history.push('/addmerchantcomapny?company_id=' + company_id);
    }

    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div class="btn-group title-text-style">
                    <h4>{props.userType === Configuration.userType.threePlCompany ? '3PL Company Management' : 'Merchant Companies'}</h4>
                </div>
                <ThemeConsumer>
                    {({ color }) => (
                        <div>
                            <Nav className='d-md-block'>
                                <Button color={color} >
                                    {props.userType === Configuration.userType.threePlCompany
                                        ? <Link to='/addthreeplcomapny' className="a-color">
                                            <i className="fa fa-fw fa-plus"></i>{props.userType === Configuration.userType.threePlCompany ? 'Add 3PL Company' : 'Add Merchant Company'}
                                        </Link>
                                        : <Link to='/addmerchantcomapny' className="a-color">
                                            <i className="fa fa-fw fa-plus"></i>{props.userType === Configuration.userType.threePlCompany ? 'Add 3PL Company' : 'Add Merchant Company'}
                                        </Link>
                                    }

                                </Button>
                            </Nav>
                        </div>
                    )}
                </ThemeConsumer>
            </Navbar>
            <Container className="margin-top">
                <Row >
                    <Col>
                        <ThreePLCompany headers={header} userType={props.userType} rowData={threeplCompanyList} />
                    </Col>
                </Row>
            </Container>
            <ToastContainer
                position={'top-right'}
                draggable={false}
                hideProgressBar={true}
            />
        </>
    )
}

export default CompaniesList