import React from 'react';
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider from 'react-bootstrap-table2-toolkit';
import _ from 'lodash';
import faker from 'faker/locale/en_US';

import {
    Row,
    Col,
    Container
} from '../../../components';
import { CustomPaginationPanel } from './CustomPaginationPanel';
import { CustomSizePerPageButton } from './CustomSizePerPageButton';
import { CustomPaginationTotal } from './CustomPaginationTotal';
import {
    buildCustomTextFilter
} from './../filters';

const INITIAL_PRODUCTS_COUNT = 500;

const ProductQuality = {
    Good: 'product-quality__good',
    Bad: 'product-quality__bad',
    Unknown: 'product-quality__unknown'
};

const sortCaret = (order) => {
    if (!order)
        return <i className="fa fa-fw fa-sort text-muted"></i>;
    if (order)
        return <i className={`fa fa-fw text-muted fa-sort-${order}`}></i>
}

const threeplCompanyList = () => {
    const [threeplCompanyList, setthreeplCompanyList] = useState([])
    useEffect(() => {
        loadthreeplCompanyList();
    }, []);
    const loadthreeplCompanyList = async () => {
        Axios.get(`${CONFIG.BASE_URL}/api/companydata`).then(result => {
            setthreeplCompanyList(result.data.data);
            console.log('shamshad ahmad dataa', result)
        })
    }
}

const generateRow = (index) => ({
    id: index,
    companydbaname: faker.commerce.productName(),
    companylegalname: faker.commerce.productName(),
    taxid: Math.round(Math.random() * 6),
    inStockDate: faker.date.past()
});

export class AdvancedTableA extends React.Component {
    constructor() {
        super();

        this.state = {
            products: _.times(INITIAL_PRODUCTS_COUNT, generateRow),
            selected: []
        };

        this.headerCheckboxRef = React.createRef();
    }

    handleSelect(row, isSelected) {
        if (isSelected) {
            this.setState({ selected: [...this.state.selected, row.id] })
        } else {
            this.setState({
                selected: this.state.selected.filter(itemId => itemId !== row.id)
            })
        }
    }

    handleSelectAll(isSelected, rows) {
        if (isSelected) {
            this.setState({ selected: _.map(rows, 'id') })
        } else {
            this.setState({ selected: [] });
        }
    }

    handleAddRow() {
        const currentSize = this.state.products.length;

        this.setState({
            products: [
                generateRow(currentSize + 1),
                ...this.state.products,
            ]
        });
    }

    handleDeleteRow() {
        this.setState({
            products: _.filter(this.state.products, product =>
                !_.includes(this.state.selected, product.id))
        })
    }

    handleResetFilters() {
        this.companydbanameFilter('');
        this.companylegalnameFilter('');
        this.taxidFilter('');
    }

    createColumnDefinitions() {
        return [{
            dataField: 'id',
            text: 'Company Id',
            headerFormatter: column => (
                <React.Fragment>
                    <span className="text-nowrap">{column.text}</span>
                    <a
                        href="javascript:;"
                        className="d-block small text-decoration-none text-nowrap"
                        onClick={this.handleResetFilters.bind(this)}
                    >
                        Reset Filters <i className="fa fa-times fa-fw dx-link-delete"></i>
                    </a>
                </React.Fragment>
            )
        }, {
            dataField: 'company_name',
            text: 'Company DBA Name',
            sort: true,
            sortCaret,
            formatter: (cell) => (
                <span className="text-inverse">
                    { cell}
                </span>
            ),
            ...buildCustomTextFilter({
                placeholder: 'Enter company DBA name...',
                getFilter: filter => { this.companydbanameFilter = filter; }
            }),

        },
        {
            dataField: 'companylegalname',
            text: 'Company legal Name',
            sort: true,
            sortCaret,
            formatter: (cell) => (
                <span className="text-inverse">
                    { cell}
                </span>
            ),
            ...buildCustomTextFilter({
                placeholder: 'Enter company legal name...',
                getFilter: filter => { this.companylegalnameFilter = filter; }
            })
        },
        {
            dataField: 'taxid',
            text: 'Tax id',
            sort: true,
            sortCaret,
            formatter: (cell) => (
                <span className="text-inverse">
                    { cell}
                </span>
            ),
            ...buildCustomTextFilter({
                placeholder: 'Enter tax id...',
                getFilter: filter => { this.taxidFilter = filter; }
            })
        },
        {
            text: 'Action', dataField: 'id',
            formatter: (id) => {
                return (
                    <>
                        <a style={{ cursor: "pointer" }} className="navbar-brand mr-0 mr-sm-3"  >
                            <i className="fa fa-pencil-square ml-1" ></i></a>
                        <a style={{ cursor: "pointer" }} className="navbar-brand mr-0 mr-sm-3"  >
                            <i className="fa fa-trash ml-1"></i></a>
                    </>
                )
            }
        }
        ];
    }
    render() {
        const columnDefs = this.createColumnDefinitions();
        const paginationDef = paginationFactory({
            paginationSize: 5,
            showTotal: true,
            pageListRenderer: (props) => (
                <CustomPaginationPanel {...props} size="sm" className="ml-md-auto mt-2 mt-md-0" />
            ),
            sizePerPageRenderer: (props) => (
                <CustomSizePerPageButton {...props} />
            ),
            paginationTotalRenderer: (from, to, size) => (
                <CustomPaginationTotal {...{ from, to, size }} />
            )
        });


        const expandRow = {
            renderer: row => (
                <Row>
                    <Col md={6}>
                        <dl className="row">
                            <dt className="col-sm-6 text-right">Last Login</dt>


                            <dt className="col-sm-6 text-right">IP Address</dt>


                            <dt className="col-sm-6 text-right">Browser</dt>

                        </dl>
                    </Col>
                    <Col md={6}>
                        <dl className="row">
                            <dt className="col-sm-6 text-right">Operating System</dt>


                            <dt className="col-sm-6 text-right">Selected Plan</dt>


                            <dt className="col-sm-6 text-right">Plan Expiriation</dt>

                        </dl>
                    </Col>
                </Row>
            ),
            showExpandColumn: true,
            expandHeaderColumnRenderer: ({ isAnyExpands }) => isAnyExpands ? (
                <i className="fa fa-angle-down fa-fw fa-lg text-muted"></i>
            ) : (
                    <i className="fa fa-angle-right fa-fw fa-lg text-muted"></i>
                ),
            expandColumnRenderer: ({ expanded }) =>
                expanded ? (
                    <i className="fa fa-angle-down fa-fw fa-lg text-muted"></i>
                ) : (
                        <i className="fa fa-angle-right fa-fw fa-lg text-muted"></i>
                    )
        }

        return (

            <ToolkitProvider
                keyField="id"
                data={this.state.products}
                columns={columnDefs}
                search
                exportCSV
            >
                {
                    props => (
                        <React.Fragment>
                            <Container >
                                <BootstrapTable hover
                                    classes="table-responsive"
                                    pagination={paginationDef}
                                    filter={filterFactory()}
                                    expandRow={expandRow}
                                    bordered={false}
                                    responsive
                                    {...props.baseProps}
                                />
                            </Container>
                        </React.Fragment>
                    )
                }
            </ToolkitProvider>
        );
    }
}