import React from 'react';
import TagBox from 'devextreme-react/tag-box';

const TagBoxList = (props) => {
    // console.log('props.data.column.lookup.dataSource', props.data.column.lookup.dataSource)
    // console.log('props.data.value', props.data.value)
    const onValueChanged = (e) => {
        props.data.setValue(e.value);
    }

    const onSelectionChanged = () => {
        props.data.component.updateDimensions();
    }
    // let arr = [17, 18]
    return (
        <TagBox
            dataSource={props.data.column.lookup.dataSource}
            //defaultValue={arr}
            valueExpr="role_master_id"
            displayExpr="Roles"
            showSelectionControls={true}
            maxDisplayedTags={5}
            showMultiTagOnly={false}
            applyValueMode="useButtons"
            searchEnabled={true}
            onValueChanged={onValueChanged}
            onSelectionChanged={onSelectionChanged}
        />
    )

}
export default TagBoxList;