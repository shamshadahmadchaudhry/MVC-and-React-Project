import React, { useState, useRef, useEffect } from 'react';
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    Button,
    RequiredRule,
    PatternRule
} from 'devextreme-react/data-grid';
import TagBox from 'devextreme-react/tag-box';
import CustomStore from 'devextreme/data/custom_store';
import { Container } from '../../../components';
import { toast } from 'react-toastify';
import AlertMessage from '../../commoncomponents/alertmessage';
import { useSelector, useDispatch } from 'react-redux';
import { getUserListByCompanyId, getUserCompanyList, getUserRole } from '../../../services/threeplcompanyservice';
import { Configuration } from '../../commoncomponents/configurationfile';
import {
    CompanyUsersUpdateRequest, ResendIvMailRequest, CancelIvMailRequest, CreateCompanyUserRequest
} from '../../../redux/actions/index';
import ThreeplCompanyAddress from '../../3plcompanymanagement/threeplcompanyaddress';
import CompanyUserListSkeleton from '../../warehousemanagement/skeleton/companyuserslistingskeleton';
const CompanyUserList = ({ data }) => {
    const dispatch = useDispatch()
    toast.configure();
    const companyId = data.data.company_id
    const userType = Configuration.userType.threePlCompany
    const datagridRef = useRef(null)
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const CreateCompanyUserStatus = useSelector(state => state.CreateCompanyUserStatus);
    const [userlist, setUserList] = useState([])
    const [isuseractive, setIsuseractive] = useState(false)
    const [rolesdata, setRoles] = useState([])
    const [editactive, setEditactive] = useState(false)
    const [userId, setUserId] = useState(0)
    const [rolesIds, setRoleIds] = useState(0)
    const [updatedetails, setUpdatedetails] = useState({});
    const [skeleton, setSkeleton] = useState(false);
    let first_name = '';
    let last_name = '';
    let email = '';
    let phone_number = '';
    let role_ids = '';
    const [screensize, setScreensize] = useState({
        matches: window.matchMedia("(min-width: 1200px)").matches
    });
    useEffect(() => {
        const handler = e => setScreensize({ matches: e.matches });
        window.matchMedia("(min-width: 1200px)").addListener(handler);
    }, [screensize.matches])

    useEffect(() => {
        loadCompanyUserList()
        loadUserRole(userType)
    }, [userType])


    const loadCompanyUserList = async () => {
        const result = await getUserListByCompanyId(companyId, userType);
        setSkeleton(true)
        setUserList(result.data)
    }

    const loadUserRole = async (userType) => {
        const result = await getUserRole(userType);
        setRoles(result.data)
    }

    //Load user data

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }

    const users_data = new CustomStore({
        key: 'user_master_id',
        load: async (loadOptions) => {
            let count = 0;
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                    params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                }
                if (!loadOptions.filter && !loadOptions.sort && count === 0 && !loadOptions.skip && !loadOptions.take) {
                    params += `skip=0&take=5&requireTotalCount=true&totalSummary=[]&`;
                }
                if (loadOptions.filter && loadOptions['group'] !== null && count === 0) {
                    params += `skip=0&take=5&`;
                }
                count++;
            });
            params += `company_id=${companyId}&`
            params += `user_type_id=${userType}&`
            params = params.slice(0, -1);
            return await getUserCompanyList(params)

        },
        insert: async (user_details) => {
            dispatch(CreateCompanyUserRequest({ ...user_details, password: 'default1234', status: 2, user_type: userType, company_id: companyId, role_ids: user_details.roles.toString() }));
            if (CreateCompanyUserStatus.isSuccess) {
                toast.success(<AlertMessage type='success' title='User Invited'
                    message='User has been Invited' />, { autoClose: 4000 });
            }
        },
        update: async (key, values) => {
            role_ids += ','
            let user_details = { user_master_id: key, first_name: first_name, last_name: last_name, email: email, phone_number: phone_number, roles: role_ids, is_active: 2, company_id: companyId, user_type_id: userType }
            dispatch(CompanyUsersUpdateRequest(user_details))
            toast.success(<AlertMessage type='success' title='Record Updated'
                message='User record has been updated' />, { autoClose: 4000 });
        }
    })


    const onCellPrepared = (e) => {
        if (e.rowType == 'header' && e.column.command == "edit") {
            e.cellElement.innerHTML = "Action";
        }
        if (e.rowType == 'filter' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close text-danger'></i></button>";
            e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
        }
        if (e.rowType === 'data' && e.column.name === 'roles') {
            let a = e.data.roles
            let cellEls = []
            let els = ''
            if (userId != e.row.data.user_master_id) {
                if (a != undefined) {
                    let arr = a.replace(',', " ").split(" ")
                    let role = ''
                    e.cellElement.innerHTML = null
                    for (let i = 0; i < rolesdata.length; i++) {
                        for (let j = 0; j < arr.length; j++) {
                            if (arr[j] == rolesdata[i].role_master_id) {
                                els = "<pre class='ml-1 mt-4 " + rolesdata[i].css_class_name + "'> " + rolesdata[i].Roles + "</pre>";
                                cellEls.push(els)
                            }
                        }

                    }
                    for (let t = 0; t < cellEls.length; t++) {
                        e.cellElement.innerHTML += cellEls[t]
                    }
                }
            }
        }
        if (e.rowType === 'data' && e.column.name === 'status') {
            if (e.data.is_active == Configuration.invitationStatus.active) {
                e.cellElement.innerHTML = 'Active'
            } else if (e.data.is_active == Configuration.invitationStatus.canceled) {
                e.cellElement.innerHTML = 'Invitation Cancelled'
            }
            else if (e.data.is_active == Configuration.invitationStatus.inactive) {
                e.cellElement.innerHTML = 'Inactive'
            }
            else if (e.data.is_active == Configuration.invitationStatus.invited) {
                e.cellElement.innerHTML = 'Invited'
            }
        }

    }
    const onEditorPreparing = (e) => {

        e.editorElement.innerText = ''
        e.value = rolesIds == 0 ? '' : rolesIds.toString().split`,`.map(x => +x);
        if (e.parentType === "dataRow" && e.dataField === "roles") {
            e.editorName = "dxTagBox";
            e.editorOptions.dataSource = rolesdata;
            e.editorOptions.showSelectionControls = true;
            e.editorOptions.displayExpr = "Roles";
            e.editorOptions.valueExpr = "role_master_id";
            e.editorOptions.maxDisplayedTags = 10;
            e.editorOptions.showClearButton = true,
                e.editorOptions.value = e.value || [];
            e.editorOptions.onValueChanged = function (args) {
                e.setValue(args.value);
            }
        }
        if (e.parentType == 'dataRow' && e.dataField == 'phone_number') {
            e.editorOptions.maxLength = 11;
        }
        if (e.parentType == 'dataRow' && e.dataField == 'first_name') {
            setTimeout(() => {
                e.component.focus(e.editorElement)
            }, 400);
        }
    }

    return (
        <>
            {(skeleton === false) ?
                (
                    <CompanyUserListSkeleton />

                ) : (
                    <>
                        <Container className="margin-top">
                            <>
                                <div className="container-fluid">
                                    {userType !== Configuration.userType.productOwner && <ThreeplCompanyAddress company_id={companyId} userType={userType} />}
                                    {/* <h6 className='m-3'>Manage Company Users</h6>
                    {userType !== Configuration.userType.userManagement && <ThreeplCompanyAddress company_id={company_id} userType={props.userType} />} */}
                                    <DataGrid id="grid-container"
                                        showBorders={true}
                                        dataSource={users_data}
                                        ref={datagridRef}
                                        keyExpr="user_master_id"
                                        onCellPrepared={onCellPrepared}
                                        columnHidingEnabled={!screensize.matches ? true : false}
                                        onEditorPreparing={onEditorPreparing}
                                        columnAutoWidth={true}
                                        remoteOperations={true}
                                        onRowInserting={(e) => {
                                            setIsuseractive(false)
                                        }}
                                        onEditingStart={(e) => {
                                            console.log('edit', e.data.is_active)
                                            setRoleIds(e.data.roles)
                                            setUserId(e.data.user_master_id)
                                            setEditactive(true)
                                            if (e.data.is_active === 1) {
                                                setIsuseractive(true)
                                            }
                                            else {
                                                setIsuseractive(false)
                                            }
                                        }}
                                        onInitNewRow={(e) => {
                                            datagridRef.current.instance.cancelEditData()
                                        }}
                                        onEditCanceled={(e) => {
                                            setRoleIds(0)
                                            setUserId(0)
                                            setEditactive(false)
                                            datagridRef.current.instance.refresh()
                                        }}
                                        onRowUpdating={(e) => {
                                            if (e.newData.first_name) {
                                                first_name = e.newData.first_name
                                            }
                                            else {
                                                first_name = e.oldData.first_name
                                            }
                                            if (e.newData.last_name) {
                                                last_name = e.newData.last_name
                                            }
                                            else {
                                                last_name = e.oldData.last_name
                                            }
                                            if (e.newData.email) {
                                                email = e.newData.email
                                            }
                                            else {
                                                email = e.oldData.email
                                            }
                                            if (e.newData.phone) {
                                                phone_number = e.newData.phone_number
                                            }
                                            else {
                                                phone_number = e.oldData.phone_number
                                            }
                                            if (e.newData.roles) {
                                                role_ids = e.newData.roles
                                            }
                                            else {
                                                role_ids = e.oldData.roles
                                            }
                                            setUserId(0)
                                            setEditactive(false)
                                            datagridRef.current.instance.refresh()

                                        }}
                                    >
                                        <Editing
                                            mode="row"
                                            useIcons={true}
                                            allowUpdating={true}
                                            allowAdding={true}
                                            confirmDelete={false}
                                        />
                                        <Paging defaultPageSize={10} />
                                        <Pager
                                            showPageSizeSelector={true}
                                            allowedPageSizes={[5, 10, 20]}
                                            showInfo={true} />
                                        <FilterRow visible={true} />

                                        <Column dataField="first_name" caption="First Name" allowEditing={true}>
                                            <RequiredRule />
                                            <PatternRule
                                                message={'Please Input valid first name'}
                                                pattern={Configuration.alphanumericSpace}
                                            />
                                        </Column>
                                        <Column dataField="last_name" caption="Last Name" allowEditing={true}>
                                            <RequiredRule />
                                            <PatternRule
                                                message={'Please input valid last name'}
                                                pattern={Configuration.alphanumericSpace}
                                            />
                                        </Column>
                                        <Column dataField="email" caption="Email" allowEditing={isuseractive ? false : true} allowAdding={true}>
                                            <RequiredRule />
                                            <PatternRule
                                                message={'Please input valid email'}
                                                pattern={Configuration.emailpattern}
                                            />
                                        </Column>
                                        <Column dataField="phone_number" caption="Phone" allowEditing={true}>
                                            <RequiredRule />
                                            <PatternRule
                                                message={'Your phone number must contain only numbers'}
                                                pattern={Configuration.phoneRegExp}
                                            />
                                        </Column>
                                        <Column dataField="roles" caption="Roles" cssClass='min_width_role' allowFiltering={false} allowSorting={false}>
                                            <RequiredRule />
                                        </Column>
                                        <Column dataField="status" caption="Status" allowFiltering={false} allowSorting={false} allowEditing={false} width={100} />

                                        <Column type="buttons" width={120}>
                                            <Button name="edit" />
                                        </Column>
                                        <Column cellRender={(e) => {
                                            if (e.data.is_active != 1) {
                                                return (
                                                    <>
                                                        <span className="fa fa-envelope ml-1"
                                                            onClick={() => {
                                                                // console.log(e.data.user_master_id)
                                                                dispatch(CancelIvMailRequest({ user_master_id: e.data.user_master_id, company_id: companyId }))
                                                                toast.success(<AlertMessage type='success' title='Invitation canceled'
                                                                    message={'Invitation  has been canceled'} />, { autoClose: 4000 })
                                                                datagridRef.current.instance.refresh();
                                                            }}><sup class="fa fa-close fa-xs text-danger small"></sup></span>
                                                        <span className="fa fa-envelope ml-1" onClick={() => {
                                                            dispatch(ResendIvMailRequest({ user_master_id: e.data.user_master_id, company_id: companyId }));
                                                            datagridRef.current.instance.refresh();
                                                            toast.success(<AlertMessage type='success' title='Invitation sent'
                                                                message={'Invitation mail has been sent successfully.'} />, { autoClose: 4000 })
                                                        }}><sup class="fa fa-arrow-right fa-xs text-success small"></sup></span>
                                                    </>
                                                )
                                            }
                                        }}>
                                        </Column>
                                    </DataGrid>
                                </div>
                            </>
                        </Container>
                    </>
                )}
        </>
    )
}

export default CompanyUserList;