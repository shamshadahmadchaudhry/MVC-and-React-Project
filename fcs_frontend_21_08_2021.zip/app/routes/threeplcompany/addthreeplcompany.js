import React, { useState, useEffect } from 'react';
import { Configuration } from '../commoncomponents/configurationfile';
import CompanyManagement from './companymanagement';

const AddThreePlCompanys = () => {
    //empty users variable in local Storage
    localStorage.setItem('users', JSON.stringify(""))
    return (
        <CompanyManagement userType={Configuration.userType.threePlCompany} />
    )
}

export default AddThreePlCompanys;