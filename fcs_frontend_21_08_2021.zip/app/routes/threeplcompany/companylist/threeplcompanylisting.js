import React from 'react';
import { Configuration } from '../../commoncomponents/configurationfile';

import CompanyList from './companylist';

const ThreePlCompanyLististing = () => {
    return (
        <CompanyList userType={Configuration.userType.productOwner} />
    )
}
export default ThreePlCompanyLististing;