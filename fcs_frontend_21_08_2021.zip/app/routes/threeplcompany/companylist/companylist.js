import React, { useEffect, useRef, useState } from 'react'
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    MasterDetail,
    RequiredRule,
    PatternRule
} from 'devextreme-react/data-grid';
import {
    Card, CardBody, Container, ThemeConsumer, Navbar, Nav, Button
} from '../../../components';
import { Link, useHistory } from "react-router-dom";
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import '../../../styles/common.scss';
import AlertMessage from '../../commoncomponents/alertmessage';
import CustomStore from 'devextreme/data/custom_store';
import { getThreePLCompanyList, threeplCompanyDelete_Service } from '../../../services/threeplcompanyservice'
import ConfirmBox from '../../commoncomponents/confirmbox';
import { Configuration } from '../../commoncomponents/configurationfile';
import CompanyUserList from '../companyuserlist/companyuserlist';
import MerchantCompanyUserList from '../../merchantcompany/merchantcompanyusers'
import CompanyListSkeleton from '../../warehousemanagement/skeleton/companylistskeleton';
const CompanyList = (props) => {
    const datagridRef = useRef(null)
    const history = useHistory();
    const userType = props.userType;
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [delmodal, setDelmodal] = useState(false);
    const [delcompanyid, SetCompanyId] = useState(0);
    const [threeplCompanyList, setthreeplCompanyList] = useState([])
    const [skeleton, setSkeleton] = useState(false);
    toast.configure();

    // useEffect(() => {
    //     loadthreeplCompany()
    // }, [])
    // const loadthreeplCompany = async () => {
    //     const result = await threeplCompanyList_Service(Configuration.userType.productOwner);
    //     let responseData = result.data.data
    //     console.log('result.data.data', result.data.data)
    //     setthreeplCompanyList(responseData);
    // }
    setTimeout(() => {
        setSkeleton(true)
    }, 1000)
    let newCompanyId = CompanyListingStatus?.result?.response?.result[0].parent_company_id
    let company_id = CompanyListingStatus?.result?.response?.result[0].company_id
    console.log('TREYSS', newCompanyId)

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }

    const company_data = new CustomStore({
        key: 'company_id',
        load: async function (loadOptions) {
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                    params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                }
            });
            params += `user_type_id=${userType}&`
            params += `new_company_id=${newCompanyId}&`
            params += `company_id=${company_id}&`
            params = params.slice(0, -1);
            let response = await getThreePLCompanyList(params);
            return response;

        },
        remove(e) {
            SetCompanyId(e)
            setDelmodal(true)
            e.cancel
        }
    });
    //============================================== End ===================================================== 
    //========= This code is used for show the action header label and show the filter button ===========
    const onCellPrepared = (e) => {
        if (e.rowType == 'header' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<b>Action</b>";
        }
        if (e.rowType == 'filter' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close text-danger'></i></button>";
            e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
        }
    }
    //========= End =========== 

    //===================== This modal is used for the delete ============================
    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }
    //===================== End ===========================================================
    //========================= This funccction is used for the delete particular row ===========
    const deleteRow = async () => {
        const result = await threeplCompanyDelete_Service(delcompanyid)
        console.log('del rez', result)
        setDelmodal(!delmodal)
        if (result.data['status'] === true) {
            toast.success(<AlertMessage type='success' title='Delete Company'
                message={result.data['data']} />, { autoClose: 4000 });
        }
        else {
            toast.error(<AlertMessage type='error' title='Delete Company'
                message={result.data['data']} />, { autoClose: false });
        }
    }
    //======================== End =====================================================
    return (
        <>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <h4>{props.userType === Configuration.userType.productOwner ? '3PL Company Management' : 'Merchant Companies'}</h4>
                <ThemeConsumer>
                    {({ color }) => (
                        <div>
                            <Nav className='d-md-block'>
                                <Button color={color} >
                                    {props.userType === Configuration.userType.productOwner
                                        ? <Link to='/addthreeplcomapny' className="a-color">
                                            <i className="fa fa-fw fa-plus"></i>{props.userType === Configuration.userType.productOwner ? 'Add 3PL Company' : 'Add Merchant Company'}
                                        </Link>
                                        : <Link to='/addmerchantcomapny' className="a-color">
                                            <i className="fa fa-fw fa-plus"></i>{props.userType === Configuration.userType.productOwner ? 'Add 3PL Company' : 'Add Merchant Company'}
                                        </Link>
                                    }

                                </Button>
                            </Nav>
                        </div>
                    )}
                </ThemeConsumer>
            </Navbar>
            {(skeleton === false) ?
                (
                    <CompanyListSkeleton />

                ) : (
                    <>
                        <div className="container margin-top">
                            {props.userType === Configuration.userType.threePlCompany
                                ? <p>You can manage all your 3pl companies from here.</p>
                                : <p>You can manage all your merchant companies from here.</p>
                            }
                            <Card className="mb-3" className="margin-top">
                                <CardBody>
                                    {/* Start DataGrid */}
                                    <div className="container-fluid">
                                        <DataGrid id="grid-container"
                                            showBorders={true}
                                            dataSource={company_data}
                                            ref={datagridRef}
                                            keyExpr="company_id"
                                            columnHidingEnabled={true}
                                            onCellPrepared={onCellPrepared}
                                            remoteOperations={true}
                                            allowColumnReordering={true}
                                            rowAlternationEnabled={true}
                                            onEditingStart={(e) => {
                                                console.log('Comp id', e.data.company_id)
                                                if (props.userType === Configuration.userType.productOwner)
                                                    history.push('/addthreeplcomapny?company_id=' + e.data.company_id);
                                                else
                                                    history.push('/addmerchantcomapny?company_id=' + e.data.company_id);
                                                e.cancel = true;
                                            }}
                                        >
                                            <Editing
                                                mode="row"
                                                useIcons={true}
                                                allowDeleting={true}
                                                allowUpdating={true}
                                                confirmDelete={false}
                                            >
                                            </Editing>
                                            <Paging defaultPageSize={10} />
                                            <Pager
                                                showPageSizeSelector={true}
                                                allowedPageSizes={[5, 10, 15]}
                                                showInfo={true} />
                                            <FilterRow visible={true} />
                                            <Column dataField="company_dba_name" caption="Company DBA Name">
                                                <RequiredRule />
                                                <PatternRule
                                                    message={'Please Input valid Company DBA Name'}
                                                    pattern={Configuration.alphanumericSpace}
                                                />
                                            </Column>
                                            <Column dataField="company_name" caption="Company legal Name">
                                            </Column>
                                            <MasterDetail
                                                enabled={true}
                                                component={userType == Configuration.userType.productOwner ? CompanyUserList : MerchantCompanyUserList} />
                                        </DataGrid>
                                    </div>
                                    {/* End DataGrid */}
                                    <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this company ?`}
                                        onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete Company" />
                                </CardBody>
                            </Card>
                        </div>
                    </>
                )}

        </>
    )

}

export default CompanyList
