import Skeleton from 'react-loading-skeleton';
import React from 'react';
import {
    Row,
    Col,
    Media,
    Card,
    CardBody,
    Container
} from '../../components';
import '../../styles/skeleton.scss';
const CompanyListingSkeleton = (props) => {
    return (
        <>
            <Container className="companylisting-container">
                {/* This code is used for the company one */}
                <Card >
                    <CardBody>
                        <Row>
                            <Col lg={1}>
                                <Skeleton circle={true} height={20} width={20} />
                            </Col>
                            <Col lg={11} className="margin-top-companylisting">
                                <Skeleton />
                            </Col>
                        </Row>
                    </CardBody>
                </Card>
                {/* This code is used for the company two */}
                <Card >
                    <CardBody>
                        <Row>
                            <Col lg={1}>
                                <Skeleton circle={true} height={20} width={20} />
                            </Col>
                            <Col lg={11} className="margin-top-companylisting">
                                <Skeleton />
                            </Col>
                        </Row>
                    </CardBody>
                </Card>
                {/* This code is used for the company three */}
                <Card >
                    <CardBody>
                        <Row>
                            <Col lg={1}>
                                <Skeleton circle={true} height={20} width={20} />
                            </Col>
                            <Col lg={11} className="margin-top-companylisting">
                                <Skeleton />
                            </Col>
                        </Row>
                    </CardBody>
                </Card>
                {/* This code is used for the proceed button */}
                <div className="margin-top-textbox"></div>
                <div className="text-right">
                    <Skeleton width={100} height={40} />
                </div>
            </Container>

        </>
    )
}
export default CompanyListingSkeleton;