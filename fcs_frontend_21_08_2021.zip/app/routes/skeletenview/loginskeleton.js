import Skeleton from 'react-loading-skeleton';
import React from 'react';
import {
    Row,
    Col,
    Media,
    EmptyLayout
} from '../../components';
import '../../styles/skeleton.scss';
const LoginSkeleton = (props) => {
    return (
        <>      <EmptyLayout>
            <EmptyLayout.Section center>
                <Row  >
                    <Col lg={12} >
                        <Media body>
                            {/* This code is used for the logo */}
                            <Skeleton width={100} height={40} className="margin-left-logo" />
                            <div className="margin-top-textbox"></div>
                            <div style={{ paddingLeft: "50px" }}>
                                {/* This code is used for the sign in application label */}
                                <Skeleton width={300} />
                            </div>
                            <div className="margin-top-textbox"></div>
                            <div>
                                {/* This code is used for the sign in page */}
                                <Skeleton width={400} />
                            </div>
                            <div className="margin-top-textbox"></div>
                            {/* This code is used for the email label */}
                            <Skeleton width={100} />
                            <div className="margin-top-label"></div>
                            {/* This code is used for the email textbox */}
                            <Skeleton height={40} />
                            <div className="margin-top-textbox"></div>
                            {/* This code is used for the password label */}
                            <Skeleton width={100} />
                            <div className="margin-top-label"></div>
                            {/* This code is used for the password textbox */}
                            <Skeleton height={40} />
                            <div className="margin-top-textbox"></div>
                            {/* This code is used for the remember me password label */}
                            <Skeleton width={150} />
                            <div className="margin-top-textbox"></div>
                            {/* This code is used for the sign in button */}
                            <Skeleton height={40} />
                            <div className="margin-top-textbox"></div>
                            {/* This code is used for the forgot password link button */}
                            <Skeleton width={100} />
                            <div className="margin-top-textbox"></div>
                            {/* This code is used for the footer */}
                            <Skeleton width={200} className="margin-left-footer" />
                        </Media>
                    </Col>
                </Row>
            </EmptyLayout.Section>
        </EmptyLayout>
        </>
    )
}
export default LoginSkeleton;