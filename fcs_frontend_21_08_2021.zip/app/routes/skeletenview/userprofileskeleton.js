import Skeleton from 'react-loading-skeleton';
import React from 'react';
import {
    Row,
    Col,
    Media,
    Card,
    CardBody,
} from '../../components';
import '../../styles/skeleton.scss';
const UserProfileSkeleton = () => {
    return (
        <Row className="margin-top-textbox">

            <Col lg={1}>
                {/* This code is used for the user image */}
                <Skeleton circle={true} height={60} width={60} />
            </Col>
            <Col lg={6} className="padding-userprofile">
                <Media body>
                    {/* This code is used for the user name */}
                    <Skeleton width={150} />
                    <div></div>
                    {/* This code is used for the remove image button */}
                    <Skeleton width={150} />
                </Media>
            </Col>
            <Col lg={6}>
                <div className="margin-top-textbox"></div>
                <Card>
                    <CardBody>
                        <Row>
                            <Col lg={6}>
                                {/* This code is used for the edit profile */}
                                <Skeleton width={150} />
                            </Col>
                            <Col lg={6} className="text-right">
                                {/* This code is used for the mark as a required field */}
                                <Skeleton width={150} />
                            </Col>
                        </Row>
                        <div className="margin-top-textbox"></div>
                        {/* This code is used for the first name label */}
                        <Skeleton width={100} />
                        <div className="margin-top-label"></div>
                        {/* This code is used for the first name textbox */}
                        <Skeleton height={40} />
                        <div className="margin-top-textbox"></div>
                        {/* This code is used for the last name label */}
                        <Skeleton width={100} />
                        <div className="margin-top-label"></div>
                        {/* This code is used for the last name textbox */}
                        <Skeleton height={40} />
                        <div className="margin-top-textbox"></div>
                        {/* This code is used for the conatcat number label */}
                        <Skeleton width={100} />
                        <div className="margin-top-label"></div>
                        {/* This code is used for the contact number textbox */}
                        <Skeleton height={40} />
                        <div className="margin-top-textbox"></div>
                        <div className="text-right">
                            {/* This code is used for the update profile button */}
                            <Skeleton width={100} height={40} />
                        </div>
                    </CardBody>
                </Card>

            </Col>
            <Col lg={6}>
                <div className="margin-top-textbox"></div>
                <Card>
                    <CardBody>
                        <Row>
                            <Col lg={6}>
                                {/* This code is used for the change password */}
                                <Skeleton width={150} />
                            </Col>
                            <Col lg={6} className="text-right">
                                {/* This code is used for the mark as a required field */}
                                <Skeleton width={150} />
                            </Col>
                        </Row>
                        <div className="margin-top-textbox"></div>
                        {/* This code is used for the password label */}
                        <Skeleton width={100} />
                        <div className="margin-top-label"></div>
                        {/* This code is used for the password textbox */}
                        <Skeleton height={40} />
                        <div className="margin-top-textbox"></div>
                        {/* This code is used for the new password label */}
                        <Skeleton width={100} />
                        <div className="margin-top-label"></div>
                        {/* This code is used for the new password textbox */}
                        <Skeleton height={40} />
                        <div className="margin-top-textbox"></div>
                        {/* This code is used for the pasword validation message */}
                        <Skeleton width={200} />
                        <div className="margin-top-label"></div>
                        <Row>
                            <Col lg={5} className="padding-left-changepassword">
                                <Skeleton count={5} />
                            </Col>
                            <Col lg={6}></Col>
                        </Row>
                        {/* =end */}
                        <div className="margin-top-label"></div>
                        {/* This code is used for the confirm new password label */}
                        <Skeleton width={100} />
                        <div className="margin-top-label"></div>
                        {/* This code is used for the confirm new password textbox */}
                        <Skeleton height={40} />
                        <div className="margin-top-textbox"></div>
                        <div className="text-right">
                            {/* This code is used for the update password button */}
                            <Skeleton width={100} height={40} />
                        </div>
                    </CardBody>
                </Card>
            </Col>
        </Row>
    )
}
export default UserProfileSkeleton;