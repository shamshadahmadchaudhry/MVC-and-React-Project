import { Field, Formik, Form } from 'formik'
import React from 'react'
import { Container, Button } from '../../components';
import DatePicker from 'react-datepicker';
import ThreePLCompany from './addthreeplcompany';

export default class ThreePlCompanyListing extends React.Component {

    render = () => (
        <React.Fragment>
            <Container fluid={true}>
                <div className="row mb-2">
                    <div className="col-lg-9">
                        <h3 className="float-left" >3PL Company Managements</h3>
                    </div>
                    <div className="col-lg-3">
                        <ThreePLCompany target="add3plcompany" size="lg"></ThreePLCompany>
                        <Button id="add3plcompany" color="secondary float-right" outline size="lg">
                            Add 3PL fCompany  <i className="fa fa-plus ml-1"></i>
                        </Button>
                    </div>
                </div>
            </Container>
            <div className="card">
                <div className="card-footer">
                    <Formik
                        initialValues={{ companyName: '', fromdate: '', todate: '', fullName: '', email: '' }}
                    >
                        {({ setFieldValue, values }) => (
                            <Form>
                                <div className="form-row">
                                    <div className="form-group col-md-2">
                                        <label htmlFor="companyName">Company Name</label>
                                        <Field as="select" className="form-control" name="companyName" id="companyName">
                                            <option value="">--Select--</option>
                                            <option value="1">Suja BITS</option>
                                        </Field>
                                    </div>
                                    <div className="form-group col-md-4">
                                        <label htmlFor="invitedFromDate">Invited Date</label>
                                        <div className="col-lg-12 form-group row">
                                            <div className="col-6">
                                                <DatePicker as="text" name="fromdate" value={values['fromdate']}
                                                    selected={values.fromdate} className="form-control datetimepicker-input"
                                                    onChange={e => setFieldValue('fromdate', e)}
                                                    placeholderText="From" />
                                            </div>
                                            <div className="col-6">
                                                <DatePicker name="todate" value={values['todate']}
                                                    selected={values.todate} className="form-control"
                                                    onChange={e => setFieldValue('todate', e)}
                                                    placeholderText="To"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-lg-2 col-md-2 col-sm-2 form-group"><label htmlFor="fullName">Full Name</label>
                                        <input type="text" className="form-control" name="fullName" id="fullName" />
                                    </div>
                                    <div className="col-lg-4 col-md-4 col-sm-4 form-group"><label htmlFor="email">E-mail</label>
                                        <div className="col-lg-12 form-group row">
                                            <div className="col-lg-6 col-xs-12 col-sm-12">
                                                <input type="email" className="form-control" name="email" id="email" />
                                            </div>
                                            <div className="col-lg-6 col-xs-12 col-sm-12">
                                                <button type="reset" className="btn btn-secondary" style={{ margin: "1%" }} >CLEAR</button>
                                                <button className="btn btn-dark" type="button">FILTER</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </Form>
                        )}
                    </Formik>
                </div>
                <div className="card-body">
                    <table className="table table-bordered table-hover">
                        <thead className="thead-primary">
                            <tr>
                                <th>Company Name</th>
                                <th>Full Name</th>
                                <th>E-mail</th>
                                <th>Phone Number</th>
                                <th>Invited Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr style={{ textAlign: "center" }} className="odd">
                                <td colSpan="7"> No 3PL company</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </React.Fragment>
    )
} 
