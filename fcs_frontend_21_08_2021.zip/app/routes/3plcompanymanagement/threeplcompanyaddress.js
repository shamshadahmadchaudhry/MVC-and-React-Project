import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from "react-redux"
import {
    Row,
    Col
} from '../../components';
import { CompanyAddressRequest } from '../../redux/actions/index'
import { Configuration } from '../commoncomponents/configurationfile';


const ThreeplCompanyAddress = ({ company_id, userType }) => {
    const CompanyAddressStatus = useSelector(state => state.CompanyAddressStatus);
    const dispatch = useDispatch()
    const [additionalInfo, setadditionalInfo] = useState({});
    const [address, setAddress] = useState({
        address_line_1: '',
        address_line_2: ''
    });
    useEffect(() => {
        dispatch(CompanyAddressRequest({ company_id }))
    }, [])

    useEffect(() => {
        if (CompanyAddressStatus.isSuccess) {
            setAddress(CompanyAddressStatus?.result?.response?.address);
            setadditionalInfo(CompanyAddressStatus?.result?.response?.additional_info)
        }
    }, [CompanyAddressStatus?.isSuccess, CompanyAddressStatus?.result])
    return (
        <React.Fragment>
            <div className="ml-2 mt-0">
                <> <Row>
                    <Col>
                        <p><strong>Address:</strong> <span className='text-dark mb-3'>{address.address_line_1}, {address.address_line_2}, {address.city} - {address.zip_code}</span></p>
                    </Col>
                </Row></>
                {additionalInfo && userType === Configuration.userType.merchant && (
                    <>
                        <Row className='mt-3 mr-2 pr-3'>
                            <Col lg={6}><strong>Website url:</strong>  <span className='text-dark'>{additionalInfo.website_url}</span></Col>
                            <Col lg={3}><strong>Product category: </strong>  <span className='text-dark'>{additionalInfo.product_category_name}</span></Col>
                            <Col lg={3}><strong>Desired sales channel: </strong>  <span className='text-dark'>{additionalInfo.sales_channel_name}</span></Col>
                        </Row>
                        <Row className='mt-2 mr-2 pr-3'>
                            <Col lg={3}><strong>Number of SKUs at Hand:</strong>   <span className='text-dark'>{additionalInfo.sku_count}</span></Col>
                            <Col lg={3}><strong>Monthly order volume:</strong>   <span className='text-dark'>{additionalInfo.monthly_order_volume}</span></Col>
                            <Col lg={3}><strong>Quantity per order:</strong>   <span className='text-dark'>{additionalInfo.qty_per_order}</span></Col>
                            <Col lg={3}><strong>Number of pallets per order:</strong>  <span className='text-dark'>{additionalInfo.pallets_per_order_count}</span></Col>
                        </Row><hr />
                    </>
                )}

                <p className='mb-3'>Manage users under the {userType === Configuration.userType.merchant ? 'merchant' : '3PL'} company</p>
            </div>
        </React.Fragment>
    )
}

export default ThreeplCompanyAddress;