import React from 'react';
import { Field, Form, Formik, ErrorMessage } from 'formik';
import * as yup from 'yup';
import { 
    UncontrolledModal,
    ModalHeader,
    ModalBody,
    ModalFooter
} from '../../components';

const ThreePLCompany = () => {
    return (
        <UncontrolledModal target="add3plcompany" size="lg">
            <ModalHeader tag="h5">
                Add 3PL Company
            </ModalHeader>
            <ModalBody>
                <Formik
                    initialValues={{ companyName: '', companyFullname: '', phoneNumber: '', firstName: '', lastName: '', taxId: '', email: '' }}
                    validationSchema={
                        yup.object().shape({
                            companyName: yup.string().required('Please enter company name.'),
                            firstName: yup.string().required('Please enter first name.'),
                            lastName: yup.string().required('Please enter last name.'),
                            email: yup.string().required('Please enter e-mail Id').matches(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/, 'Please enter valid e-mail Id'),
                            taxId: yup.string().required('Please enter Tax Id.')
                        })
                    }
                    onSubmit={(values, { setSubmitting }) => { 
                        setTimeout(() => {
                            alert(JSON.stringify(values, null, 2));
                            setSubmitting(false);
                        }, 400);
                    }}
                >
                    {() => (
                        <Form>
                            <div className="row">
                                <div className="col-lg-4 form-group"><label className="float-right" htmlFor="companyName">Company Name <span className="text-danger">*</span></label></div>
                                <div className="col-lg-8 form-group">
                                    <Field className="form-control" name="companyName" id="companyName"></Field>
                                    <ErrorMessage name="companyName" component="span" className="text-danger"></ErrorMessage>
                                </div>
                                <div className="col-lg-4 form-group"><label className="float-right" htmlFor="companyFullname">Company Full Name</label></div>
                                <div className="col-lg-8 form-group">
                                    <Field className="form-control" name="companyFullname" id="companyFullname"></Field>
                                </div>
                                <div className="col-lg-4 form-group"><label className="float-right" htmlFor="firstName">Full Name<span className="text-danger">*</span></label></div>
                                <div className="col-lg-8 form-group">
                                    <div className="row">
                                        <div className="col-lg-6 form-group">
                                            <Field className="form-control" name="firstName" id="firstName" placeholder="First Name" ></Field>
                                            <ErrorMessage name="firstName" className="text-danger" component="span"></ErrorMessage>
                                        </div>
                                        <div className="col-lg-6 form-group">
                                            <Field className="form-control" name="lastName" placeholder="Last Name" ></Field>
                                            <ErrorMessage name="lastName" className="text-danger" component="span"></ErrorMessage>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-4 form-group"><label className="float-right" htmlFor="email">E-Mail<span className="text-danger">*</span></label></div>
                                <div className="col-lg-8">
                                    <Field className="form-control" name="email" id="email" ></Field>
                                    <ErrorMessage name="email" className="text-danger" component="span"></ErrorMessage>
                                </div>
                                <div className="col-lg-4 form-group"><label className="float-right" htmlFor="phoneNumber">Phone Number</label></div>
                                <div className="col-lg-8">
                                    <Field className="form-control" name="phoneNumber" id="phoneNumber" ></Field>
                                </div>
                                <div className="col-lg-4 form-group"><label className="float-right" htmlFor="taxId">Tax ID<span className="text-danger">*</span></label></div>
                                <div className="col-lg-8">
                                    <Field className="form-control" name="taxId" id="taxId" ></Field>
                                    <ErrorMessage name="taxId" className="text-danger" component="span"></ErrorMessage>
                                </div>
                            </div>
                            <ModalFooter>
                                <UncontrolledModal.Close color="link" className="btn btn-secondary" size="lg"> CANCEL </UncontrolledModal.Close>
                                <button type="submit" className="btn btn-dark btn-lg float-right">ADD</button>
                            </ModalFooter>
                        </Form>
                    )}
                </Formik>
            </ModalBody>
        </UncontrolledModal>
    );
};

export default ThreePLCompany