import React, { useState, useEffect } from 'react';
import {
    Card,
    CardBody,
    CardTitle,
    InputGroupAddon,
    InputGroup,
    Label,
    FormGroup,
    ThemeConsumer,
    Button
} from '../../components';
import { toast } from 'react-toastify';
import { Formik, Form, ErrorMessage, Field } from 'formik';
import * as yup from 'yup';
import { Configuration } from '../commoncomponents/configurationfile';
import AlertMessage from '../commoncomponents/alertmessage';
import ResetPasswordMessage from '../accounts/resetpassword/restpasswordmessage';
import { useDispatch, useSelector } from 'react-redux';
import { ChangePasswordRequest } from '../../redux/actions';
const ChangePassword = (props) => {
    const [hidePass, setHidePass] = useState(true);
    const [hideNewPass, setHideNewPass] = useState(true);
    const [hideConfirmPass, setHideConfirmPass] = useState(true);
    const [loader, setLoader] = useState(false);
    const showHidePass = () => { setHidePass(!hidePass); }
    const showHideNewPass = () => { setHideNewPass(!hideNewPass); }
    const showHideConfirmPass = () => { setHideConfirmPass(!hideConfirmPass); }
    const ChangePasswordStatus = useSelector(state => state.ChangePasswordStatus)
    const dispatch = useDispatch()

    useEffect(() => {
        if (ChangePasswordStatus?.isSuccess) {
            if (ChangePasswordStatus?.data?.response.error) {
                toast.error(<AlertMessage type='error'
                    title='Password Update Failed'
                    message={ChangePasswordStatus?.data?.response?.Message} />, { autoClose: false })
            } else {
                toast.success(<AlertMessage type='success'
                    title='Password Updated'
                    message='Your new password updated successfully' />, { autoClose: 4000 });
            }
        } else if (ChangePasswordStatus?.isError) {
            toast.error(<AlertMessage type='error'
                title='Password Update Failed'
                message='Some internal error occurred.' />, { autoClose: false })
        }
    }, [ChangePasswordStatus?.isSuccess])

    const validateConfirmPassword = (pass, value) => {
        let error = "";
        if (pass && value) {
            if (pass !== value) {
                error = "Password do not match";
            }
        }
        return error;
    };

    // Show red border if password invalid for passwword field
    let invalidPassword = {
        borderRadius: '3px',
        border: '1px solid',
        borderColor: '#ED1C24'
    };

    return (
        <React.Fragment>
            <Card>
                <CardBody>
                    <div className="d-flex mb-4">
                        <CardTitle tag="h6">
                            Change Password
                               </CardTitle>
                        <span className="ml-auto align-self-start small">
                            Fields mark as <span className="text-danger">*</span> is required.
                                </span>
                    </div>
                    {/* =================== This code is used for the validation and also change the password on click ================== */}
                    <Formik
                        initialValues={{ password: '', newpassword: '', confirmpassword: '', rememberPassword: false }}
                        validationSchema={yup.object().shape({
                            password: yup.string().nullable().required(`${Configuration.required} password.`)
                                .matches(
                                    Configuration.password,
                                    `${Configuration.passwordmessage}`
                                ),
                            newpassword: yup.string().nullable().required(`${Configuration.required} new password.`).matches(
                                Configuration.password,
                                `${Configuration.passwordmessage}`
                            ),
                            confirmpassword: yup.string().nullable().required(`Please re-enter new password.`).matches(
                                Configuration.password,
                                `${Configuration.passwordmessage}`
                            )
                        })
                        }

                        onSubmit={(values, { resetForm }) => {
                            // setLoader(true);
                            if (values.password === values.confirmpassword) {
                                toast.error(<AlertMessage type='error' title='Change Password'
                                    message={'Old pasword and new password should not be the same.'} />, { autoClose: false })
                                setTimeout(() => {
                                    setLoader(false);
                                }, 2000);
                            } else {
                                if (values.newpassword === values.confirmpassword) {
                                    dispatch(ChangePasswordRequest({ 'id': props.userData.user_master_id, 'old_password': values.password, 'password': values.newpassword }));
                                    resetForm();
                                } else {
                                    toast.error(<AlertMessage type='success' title='Change Password Failed'
                                        message={'Confirm password does not match with new password. Enter confirm password same as new password.'} />, { autoClose: 4000 })
                                    setTimeout(() => {
                                        setLoader(false);
                                    }, 2000);
                                }

                            }
                        }
                        }

                    >
                        {({ errors, touched, values }) => (
                            <Form className="mb-3">
                                <FormGroup>
                                    <Label for="password">
                                        Password <span className="text-danger">*</span>
                                    </Label>
                                    <InputGroup style={touched.password && errors.password && invalidPassword} >
                                        <Field type={hidePass ? "password" : "text"}
                                            id="password"
                                            name="password"
                                            className={`bg-white form-control`}
                                            placeholder="Enter password" />
                                        <InputGroupAddon addonType="append" onClick={showHidePass}>
                                            <i className={hidePass ? 'fa fa-eye' : 'fa fa-eye-slash'}></i>
                                        </InputGroupAddon>
                                    </InputGroup>
                                    {touched.password && errors.password &&
                                        <ErrorMessage name="password" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                <FormGroup>
                                    <Label for="newPassword">
                                        New password <span className="text-danger">*</span>
                                    </Label>
                                    <InputGroup style={touched.newpassword && errors.newpassword && invalidPassword}>
                                        <Field type={hideNewPass ? "password" : "text"}
                                            name="newpassword"
                                            className={`bg-white form-control`}
                                            placeholder="Enter new password" />
                                        <InputGroupAddon addonType="append" onClick={showHideNewPass}>
                                            <i className={hideNewPass ? 'fa fa-eye' : 'fa fa-eye-slash'}></i>
                                        </InputGroupAddon>
                                    </InputGroup>
                                    {touched.newpassword && errors.newpassword &&
                                        <ErrorMessage name="newpassword" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                <ResetPasswordMessage />
                                <FormGroup>
                                    <Label for="confirmPassword">
                                        Confirm new password <span className="text-danger">*</span>
                                    </Label>
                                    <InputGroup style={touched.confirmpassword && errors.confirmpassword && invalidPassword}>
                                        <Field type={hideConfirmPass ? "password" : "text"}
                                            validate={value => validateConfirmPassword(values.newpassword, value)}
                                            name="confirmpassword"
                                            className={`bg-white form-control`}
                                            placeholder="Re-enter new password" />
                                        <InputGroupAddon addonType="append" onClick={showHideConfirmPass}>
                                            <i className={hideConfirmPass ? 'fa fa-eye' : 'fa fa-eye-slash'}></i>
                                        </InputGroupAddon>
                                    </InputGroup>
                                    {touched.confirmpassword && errors.confirmpassword &&
                                        <ErrorMessage name="confirmpassword" component="span" className="text-danger"></ErrorMessage>
                                    }
                                    {errors.confirmPassword && (<div>{errors.confirmPassword}</div>)}
                                </FormGroup>
                                <div className="text-right">
                                    <ThemeConsumer>
                                        {
                                            ({ color }) => (
                                                <Button color={color} disabled={loader}>
                                                    Update Password<span> </span>
                                                    {loader && (
                                                        <i
                                                            className="fa fa-spinner fa-spin"
                                                            style={{ marginRight: "5px" }}
                                                        />
                                                    )}</Button>
                                            )
                                        }
                                    </ThemeConsumer>
                                </div>
                            </Form>
                        )}
                    </Formik>
                    { /* END Form */}
                </CardBody>
            </Card>
        </React.Fragment>
    )
}
export default ChangePassword;




