import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import {
    Card,
    CardBody,
    CardTitle,
    Label,
    FormGroup,
    ThemeConsumer,
    Button,
    Navbar,
} from '../../components';
import { Formik, Form, Field, ErrorMessage, useFormikContext } from 'formik';
import * as yup from 'yup';
import { Configuration } from '../commoncomponents/configurationfile';
import { toast } from 'react-toastify';
import AlertMessage from '../commoncomponents/alertmessage';
import { UpdateProfileRequest } from '../../redux/actions/index'
import { PromptIfDirty } from '../commoncomponents/userpromt';
import { usePermission } from '../commoncomponents/customhooks/usePermission'



const Profile = (props) => {
    const dispatch = useDispatch();
    const [userData, setUserData] = useState(props.userData);
    const [loader, setLoader] = useState(false);
    const ProfileStatus = useSelector(state => state.ProfileStatus)
    const { isAuthorized } = usePermission('p-manage-profile');

    useEffect(() => {
        setUserData(props.userData);
    }, [props.userData]);

    // Update profile details
    const updateUserProfile = (values) => {
        console.log(values.first_name)
        delete values.profile_img_path;
        dispatch(UpdateProfileRequest(values));

        if (ProfileStatus?.isSuccess) {
            toast.success(<AlertMessage type='success'
                title='Profile Updated'
                message='Your profile updated successfully' />, { autoClose: 4000 })
        }
    }

    return (
        <React.Fragment>

            <Card>
                <CardBody>
                    
                    <div className="d-flex mb-4">
                        <CardTitle tag="h6">
                            {isAuthorized ? 'Edit ' : 'View '} Profile
                               </CardTitle>
                        <span className="ml-auto align-self-start small">
                            Fields mark as <span className="text-danger">*</span> is required.
                                </span>
                    </div>
                    {/* This code is used for the validation and also update the user details.*/}
                    {userData && <Formik
                        initialValues={userData}
                        validationSchema={yup.object().shape({
                            first_name: yup.string().nullable().required(`${Configuration.required} firstname`)
                                .matches(Configuration.nameRegex, 'Please enter valid first name'),
                            last_name: yup.string().nullable().required(`${Configuration.required} lastname`)
                                .matches(Configuration.nameRegex, 'Please enter valid last name'),
                            phone_number: yup.string().nullable().required(`${Configuration.required} phone number`)
                                .matches(Configuration.phoneRegExp, 'Please enter valid phone number.')
                                .min(10, 'Phone number minimum contains 10 character')
                        })
                        }
                        onSubmit={updateUserProfile}
                        enableReinitialize={true}
                    >
                        {({ errors, touched, values }) => (
                            <Form>
                                <PromptIfDirty />
                                { /* START Input */}
                                <FormGroup>
                                    <Label for="firstName">
                                        First name <span className="text-danger">*</span>
                                    </Label>
                                    <Field type="text"
                                        placeholder="Enter first name"
                                        name="first_name"
                                        value={values.first_name}
                                        disabled={!isAuthorized}
                                        className={`${touched.first_name && errors.first_name && 'is-invalid'} ${!isAuthorized ? '' : 'bg-white'} form-control`} />
                                    {touched.first_name && errors.first_name &&
                                        <ErrorMessage name="first_name" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                { /* END Input */}
                                { /* START Input */}
                                <FormGroup>
                                    <Label for="lastName">
                                        Last name <span className="text-danger">*</span>
                                    </Label>
                                    <Field type="text"
                                        placeholder="Enter last name"
                                        name="last_name"
                                        disabled={!isAuthorized}
                                        value={values.last_name}
                                        className={`${touched.last_name && errors.last_name && 'is-invalid'} ${!isAuthorized ? '' : 'bg-white'} form-control`} />
                                    {touched.last_name && errors.last_name &&
                                        <ErrorMessage name="last_name" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                { /* END Input */}
                                { /* START Input */}
                                <FormGroup>
                                    <Label for="phone_number">
                                        Phone number <span className="text-danger">*</span>
                                    </Label>
                                    <Field type="text"
                                        placeholder="Enter phone number"
                                        name="phone_number"
                                        maxLength={10}
                                        disabled={!isAuthorized}
                                        value={values.phone_number}
                                        className={`${touched.phone_number && errors.phone_number && 'is-invalid'} ${!isAuthorized ? '' : 'bg-white'} form-control`} />
                                    {touched.phone_number && errors.phone_number &&
                                        <ErrorMessage name="phone_number" component="span" className="text-danger"></ErrorMessage>
                                    }
                                </FormGroup>
                                {isAuthorized &&
                                    <div className="text-right">
                                        <ThemeConsumer>{
                                            ({ color }) => (
                                                <Button color={color} disabled={loader}>
                                                    Update Profile<span> </span>
                                                    {loader && (
                                                        <i
                                                            className="fa fa-spinner fa-spin"
                                                            style={{ marginRight: "5px" }}
                                                        />
                                                    )}</Button>
                                            )

                                        }
                                        </ThemeConsumer>
                                    </div>
                                }

                                { /* END Input */}
                            </Form>
                        )}
                    </Formik>}

                    { /* END Form */}

                </CardBody>
            </Card >
        </React.Fragment >
    )
}
export default Profile;