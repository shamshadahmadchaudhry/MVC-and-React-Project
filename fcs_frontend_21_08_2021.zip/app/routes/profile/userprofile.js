import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import {
    Container,
    Row,
    Col,
    UncontrolledModal,
    ModalFooter,
    Button,
    ModalBody,
    ModalHeader,
    ThemeConsumer,
    Media,
    FormText,
    Navbar
} from '../../components';
import ChangePassword from './changepassword';
import Profile from './profile';
import { ToastContainer, toast } from 'react-toastify';
import AlertMessage from '../commoncomponents/alertmessage';
import { ProfileRequest, UpdateImageRequest } from '../../redux/actions/index';
import { CONFIG } from "../../config";
import { Configuration } from '../commoncomponents/configurationfile';
import UserProfileSkeleton from '../skeletenview/userprofileskeleton';
import Can from '../commoncomponents/customhooks/Can';
import '../../styles/common.scss';

const UserProfile = (props) => {
    const dispatch = useDispatch()
    const ProfileStatus = useSelector(state => state.ProfileStatus)
    const [loader, setLoader] = useState(false);
    const [userData, setUserData] = useState(ProfileStatus?.data || false);
    const [users, setUser] = useState({ firstname: '', lastname: '' });

    useEffect(() => {
        ProfileStatus?.data?.response && setUserData(ProfileStatus?.data?.response)
        console.log(ProfileStatus)
    }, [ProfileStatus]);

    useEffect(() => {
        dispatch(ProfileRequest())
    }, [])

    //=================== This method is used for update the user profile on picture change ==================
    const handleChange = (e) => {
        let file_size = e.target.files[0].size;
        if (parseInt(file_size) <= 25000) {
            const image = e.target.files[0];
            let form_data = new FormData();
            form_data.append('name', image.name);
            form_data.append('image', image);
            console.log("form data->", form_data);
            dispatch(UpdateImageRequest({ form_data: form_data, user_master_id: userData.user_master_id }))
        } else {
            toast.error(<AlertMessage type='error' title='Profile Validation'
                message='File size should be 25kb/less than 25kb' />, { autoClose: false })
        }
    }

    const closeConfirmBox = () => {
        setLoader(false)
    }
    //=================== This method is used for remove user profile on click ==================
    const handleClick = async () => {
        setLoader(true);
        let form_data = new FormData();
        dispatch(UpdateImageRequest({ form_data: form_data, user_master_id: userData.user_master_id }))
        setLoader(false);
    }

    const setUserName = (user) => {
        setUser({ firstname: user.firstname, lastname: user.lastname })
    }

    return (

        <React.Fragment>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div class="btn-group title-text-style">
                    <h4>Profile</h4>
                </div>

            </Navbar>
            <Container>
                <div>
                </div>
                {(ProfileStatus.isLoading === true) ?
                    (
                        <UserProfileSkeleton />
                    ) : (
                        <>
                            { /* START Content */}
                            <Row style={{ marginTop: "15px" }}>

                                <Col lg={1} className="mb-3">

                                    <div className="image-upload ">
                                        <label htmlFor="file-input">

                                            <img className="img-profile"
                                                src={userData.profile_img_src === null
                                                    || userData.profile_img_src === ''
                                                    || userData.profile_img_src === undefined
                                                    ? CONFIG.BASE_URL + Configuration.blankImagePath + ''
                                                    : CONFIG.BASE_URL + userData?.profile_img_src + '?' + Date.now()} />

                                        </label>
                                        <input id="file-input" type="file" onChange={handleChange} />
                                    </div>

                                </Col>
                                <Col lg={6} className="user-padding mb-3">
                                    <Media body>
                                        <h4 className="mb-1 mt-0 captalize" >
                                            {userData.first_name} {userData.last_name}
                                        </h4>
                                        {(userData.profile_img_src === null || userData.profile_img_src === '' || userData.profile_img_src === undefined) ? (
                                            <FormText color="muted">Maximum dimension 60px X 60px/file size 25kb</FormText>
                                        ) :
                                            (
                                                <>
                                                    <span className="span-profile" href='#' id="modalDefault304" disabled={loader}> Remove picture
                                        <span> </span>
                                                        {loader && (
                                                            <i
                                                                className="fa fa-spinner fa-spin"
                                                                style={{ marginRight: "5px" }}
                                                            />
                                                        )}
                                                    </span>
                                                    <UncontrolledModal target="modalDefault304" className="modal-outline-warning">
                                                        <ModalHeader tag="h6">
                                                            <span className="text-warning">
                                                                <i className="fa fa-fw fa-2x fa-exclamation"></i>
                                                    Warning : Profile Picture
                                                </span>
                                                        </ModalHeader>
                                                        <ModalBody>
                                                            <div style={{ marginTop: "10px" }} className="media-body">
                                                                <p> Are sure you want to remove profile picture?</p>
                                                            </div>
                                                        </ModalBody>
                                                        <ModalFooter>
                                                            <UncontrolledModal.Close color="link" onClick={closeConfirmBox} className="text-warning">
                                                                Close
                                                </UncontrolledModal.Close>
                                                            <ThemeConsumer>
                                                                {
                                                                    ({ color }) => (
                                                                        <Button color={color} onClick={handleClick}>
                                                                            Yes
                                                                        </Button>
                                                                    )
                                                                }
                                                            </ThemeConsumer>

                                                        </ModalFooter>
                                                    </UncontrolledModal>
                                                </>
                                            )}
                                    </Media>
                                </Col>
                                <Col lg={6}>
                                    <Profile setUserName={setUserName} userData={userData} />
                                </Col>
                                <Col lg={6}>
                                    <ChangePassword userData={userData} />
                                </Col>
                            </Row>
                            { /* END Content */}
                        </>
                    )}



            </Container>
            <ToastContainer
                position={'top-right'}
                draggable={false}
                hideProgressBar={true}
            />
        </React.Fragment>

    )
}
export default UserProfile;