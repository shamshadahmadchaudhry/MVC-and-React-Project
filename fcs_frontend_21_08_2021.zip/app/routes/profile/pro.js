import React from 'react';

const pro = () => {
    return(
        <div>
            <h1>
                asdfghjk
            </h1>
        </div>
    )
}
export default pro;