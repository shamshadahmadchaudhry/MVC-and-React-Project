import React, { useState, useEffect } from 'react';
import CompanyUsers from './companyuserslisting';
import { useSelector } from "react-redux";
import { Configuration } from '../commoncomponents/configurationfile';
import {
    Container,
    Button,
    Row,
    Col,
    Navbar
} from '../../components';

const UserList = (props) => {
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [companyId, setCompanyId] = useState(0);
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    useEffect(() => {
        setCompanyId(CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id);
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])
    return (
        <div>
            <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <div class="btn-group title-text-style">
                    
                    <h4>Company User</h4>
                </div>
                
            </Navbar>
            <Container>
                <Row className='mt-3 ml-1 mb-3'>
                    <Col>
                        <span>Manage users within your company from this screen.</span>&nbsp;<br />
                    </Col>
                </Row>
            </Container>
            <CompanyUsers listingType="user-management" userType={userData.user_type_id} companyId={companyId} />
        </div>
    )
}

export default UserList
