import React, { useState, useRef, useEffect } from 'react';
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    Button,
    RequiredRule,
    PatternRule
} from 'devextreme-react/data-grid';
import { Container } from '../../components';
import { toast } from 'react-toastify';
import AlertMessage from '../commoncomponents/alertmessage';
import { useSelector } from 'react-redux';
import { getUserRole } from '../../services/threeplcompanyservice';
import { Configuration } from '../commoncomponents/configurationfile';
import ConfirmBox from '../commoncomponents/confirmbox';

const CompanyUsers = ({ userType }) => {
    toast.configure();
    const companyId = 0
    const datagridRef = useRef(null)
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const [userlist, setUserList] = useState([])
    const [rolesdata, setRoles] = useState([])
    const [editmode, setEditmode] = useState('row')
    const [editactive, setEditactive] = useState(false)
    const [userId, setUserId] = useState(0)
    const [rolesIds, setRoleIds] = useState(0)
    const [updatedetails, setUpdatedetails] = useState({});
    const [allusers, setAllusers] = useState(JSON.parse(localStorage.getItem('users')) || []);
    const [isuseractive, setIsuseractive] = useState(false)
    const [delmodal, setDelmodal] = useState(false)
    const [delkey, setDelkey] = useState(0);
    let first_name = '';
    let last_name = '';
    let email = '';
    let phone_number = '';
    let role_ids = '';

    useEffect(() => {
        loadUserRole(userType)
    }, [userType])


    useEffect(() => {
        localStorage.setItem('users', JSON.stringify(allusers))
    }, [allusers]);

    const [screensize, setScreensize] = useState({
        matches: window.matchMedia("(min-width: 1200px)").matches
    });
    useEffect(() => {
        const handler = e => setScreensize({ matches: e.matches });
        window.matchMedia("(min-width: 1200px)").addListener(handler);
    }, [screensize.matches])


    const loadUserRole = async (userType) => {
        const result = await getUserRole(userType);
        console.log('Roleszzz', result)
        setRoles(result.data)
    }
    const toggledelModal = () => {
        setDelmodal(!delmodal);
    }
    const deleteRow = () => {
        let usersLeft = allusers.filter((user) => {
            return user.id !== delkey;
        })
        console.log('USERS LEFT', usersLeft)
        setAllusers(usersLeft)
        setDelmodal(!delmodal)
        toast.success(<AlertMessage type='success' title='User Deleted'
            message='User has been deleted Successfully' />, { autoClose: 4000 });
    }

    const users_data = allusers;

    const SaveUser = async (body, component) => {
        let numrows = 1;
        let email_exist = false;
        if (body[0].type === 'insert') {
            //Check if user already exist
            allusers.map(user => {
                if (user.email === body[0].data.email) {
                    email_exist = true
                }
            })
            if (!email_exist) {
                for (let i = 0; i < numrows; i++) {
                    allusers.push({
                        id: body[i].data.__KEY__, first_name: body[i].data.first_name,
                        last_name: body[i].data.last_name,
                        email: body[i].data.email,
                        password: Configuration.userdefaultPassword,
                        status: Configuration.invitationStatus.pending,
                        user_type: userType,
                        phone_number: body[i].data.phone_number,
                        roles: body[i].data.roles
                    })
                }
                localStorage.setItem('users', JSON.stringify(allusers));
                setAllusers(JSON.parse(localStorage.getItem('users')) || []);
                toast.success(<AlertMessage type='success' title='User Saved'
                    message='User has been Saved Successfully' />, { autoClose: 4000 });
                datagridRef.current.instance.cancelEditData();
                setEditmode('row');
                setRoleIds(0)
                setUserId(0)
                setEditactive(false)
                datagridRef.current.instance.refresh()
            }
            else {
                toast.error(<AlertMessage type='error' title='User Already Exist'
                    message='This email is already registered' />, { autoClose: 4000 });
            }

        }
        else if (body[0].type === 'update') {
            let first_name = '';
            let last_name = '';
            let email = '';
            let phone_number = '';
            let roles = '';
            if ('first_name' in body[0].data) {
                first_name = body[0].data.first_name
            }
            if ('last_name' in body[0].data) {
                last_name = body[0].data.last_name
            }
            if ('email' in body[0].data) {
                email = body[0].data.email
            }
            if ('phone_number' in body[0].data) {
                phone_number = body[0].data.phone_number
            }
            if ('roles' in body[0].data) {
                roles = body[0].data.roles
            }
            let updateduser = allusers.map(user => {
                if (user.id === body[0].key.id) {
                    console.log('match', user)
                    if (first_name.length > 0) {
                        user.first_name = first_name;
                    }
                    if (last_name.length > 0) {
                        user.last_name = last_name;
                    }
                    if (email.length > 0) {
                        user.email = email;
                    }
                    if (phone_number.length > 0) {
                        user.phone_number = phone_number;
                    }
                    if (roles.length > 0) {
                        user.roles = roles;
                    }
                }
                return user;
            })
            setAllusers(updateduser)
            toast.success(<AlertMessage type='success' title='User Updated'
                message='User record has been Updated Successfully' />, { autoClose: 4000 });
            setRoleIds(0)
            setUserId(0)
            setEditactive(false)
            datagridRef.current.instance.refresh()
        }
        else {
            setDelkey(body[0].key)
            setDelmodal(true)
        }
    }


    const onCellPrepared = (e) => {
        if (e.rowType == 'header' && e.column.command == "edit") {
            e.cellElement.innerHTML = "Action";
        }
        if (e.rowType == 'filter' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close text-danger'></i></button>";
            e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
        }
        if (e.rowType === 'data' && e.column.name === 'roles') {
            let a = e.data.roles
            let cellEls = []
            let els = ''
            if (userId != e.row.data.id) {
                if (a != undefined) {
                    let arr = a;
                    let role = ''
                    e.cellElement.innerHTML = null
                    for (let i = 0; i < rolesdata.length; i++) {
                        for (let j = 0; j < arr.length; j++) {
                            if (arr[j] == rolesdata[i].role_master_id) {
                                els = "<pre class='ml-1 mt-4 " + rolesdata[i].css_class_name + "'> " + rolesdata[i].Roles + "</pre>";
                                cellEls.push(els)
                            }
                        }

                    }
                    for (let t = 0; t < cellEls.length; t++) {
                        e.cellElement.innerHTML += cellEls[t]
                        console.log(cellEls[t])
                    }
                    
                }
                for(let t=0;t<cellEls.length;t++){
                    e.cellElement.innerHTML += cellEls[t]
                }
            }
        }
        if (e.rowType === 'data' && e.column.name === 'status') {
            if (e.data.status == Configuration.invitationStatus.pending) {
                e.cellElement.innerHTML = 'Pending Invitation'
            }
        }

    }
    const onEditorPreparing = (e) => {
        e.editorElement.innerText = ''
        e.value = rolesIds == 0 ? '' : rolesIds.toString().split`,`.map(x => +x);
        if (e.parentType === "dataRow" && e.dataField === "roles") {
            e.editorName = "dxTagBox"
            e.editorOptions.dataSource = rolesdata;
            e.editorOptions.showSelectionControls = true;
            e.editorOptions.displayExpr = "Roles";
            e.editorOptions.valueExpr = "role_master_id";
            e.editorOptions.showClearButton = true
            e.editorOptions.value = e.value || []
            e.editorOptions.onValueChanged = function (args) {
                e.setValue(args.value);
            }
        }
        if (e.parentType == 'dataRow' && e.dataField == 'phone_number') {
            e.editorOptions.maxLength = 14;
            console.log('Edit opt', e.editorOptions);
        }
        //   if (e.parentType == 'header' && e.column.name == 'email') {  
        //     e.column.width='300px'
        //     console.log('Edit opt',e.editorOptions);  
        // }
        if (e.parentType == 'dataRow' && e.dataField == 'first_name') {
            setTimeout(() => {
                e.component.focus(e.editorElement)
            }, 400);
        }
    }

    return (
        <>
            <Container className="margin-top">
                <>
                    <div className="container-fluid">
                        <DataGrid id="grid-container"
                            showBorders={true}
                            dataSource={allusers}
                            ref={datagridRef}
                            onCellPrepared={onCellPrepared}
                            columnHidingEnabled={!screensize.matches ? true : false}
                            onEditorPreparing={onEditorPreparing}
                            columnAutoWidth={true}
                            remoteOperations={true}
                            onRowInserting={(e) => {
                                setIsuseractive(false)
                            }}
                            onEditingStart={(e) => {
                                setRoleIds(e.data.roles)
                                setUserId(e.data.id)
                                setEditactive(true)
                                if (e.data.status === 1) {
                                    setIsuseractive(true)
                                }
                                else {
                                    setIsuseractive(false)
                                }
                            }}
                            onInitNewRow={(e) => {
                                setIsuseractive(false)
                                datagridRef.current.instance.cancelEditData()
                            }}
                            onEditCanceled={(e) => {
                                setRoleIds(0)
                                setUserId(0)
                                setEditactive(false)
                                datagridRef.current.instance.refresh()
                            }}
                            onSaving={(e) => {
                                e.cancel = true;
                                SaveUser(e.changes, e.component)
                            }}
                            onRowUpdating={(e) => {
                                if (e.newData.first_name) {
                                    first_name = e.newData.first_name
                                }
                                else {
                                    first_name = e.oldData.first_name
                                }
                                if (e.newData.last_name) {
                                    last_name = e.newData.last_name
                                }
                                else {
                                    last_name = e.oldData.last_name
                                }
                                if (e.newData.email) {
                                    email = e.newData.email
                                }
                                else {
                                    email = e.oldData.email
                                }
                                if (e.newData.phone_number) {
                                    phone_number = e.newData.phone_number
                                }
                                else {
                                    phone_number = e.oldData.phone_number
                                }
                                if (e.newData.roles) {
                                    role_ids = e.newData.roles
                                }
                                else {
                                    role_ids = e.oldData.roles
                                }
                                setUserId(0)
                                setEditactive(false)
                                datagridRef.current.instance.refresh()
                            }}
                        >
                            <Editing
                                mode={editmode}
                                useIcons={true}
                                allowUpdating={true}
                                allowDeleting={true}
                                allowAdding={true}
                                confirmDelete={false}
                            />
                            <Paging defaultPageSize={10} />
                            <Pager
                                showPageSizeSelector={true}
                                allowedPageSizes={[5, 10, 20]}
                                showInfo={true} />
                            <FilterRow visible={true} />

                            <Column dataField="first_name" caption="First Name" allowEditing={true}>
                                <RequiredRule />
                                <PatternRule
                                    message={'Please Input valid first name'}
                                    pattern={Configuration.alphanumericSpace}
                                />
                            </Column>
                            <Column dataField="last_name" caption="Last Name" allowEditing={true}>
                                <RequiredRule />
                                <PatternRule
                                    message={'Please input valid last name'}
                                    pattern={Configuration.alphanumericSpace}
                                />
                            </Column>
                            <Column dataField="email" caption="Email" cssClass='min_width_role' allowEditing={isuseractive ? false : true} allowAdding={true}>
                                <RequiredRule />
                                <PatternRule
                                    message={'Please input valid email'}
                                    pattern={Configuration.emailpattern}
                                />
                            </Column>
                            <Column dataField="phone_number" caption="Phone" allowEditing={true}>
                                <RequiredRule />
                                <PatternRule
                                    message={'Your phone number must contain only numbers'}
                                    pattern={Configuration.phoneRegExp}
                                />
                            </Column>
                            <Column dataField="roles" caption="Roles" allowFiltering={false} cssClass='min_width_role' allowSorting={false}>
                                <RequiredRule />
                            </Column>
                            <Column dataField="status" caption="Status" allowFiltering={false} allowSorting={false} allowEditing={false} />

                            <Column type="buttons" width={120}>
                                <Button name="edit" />
                                <Button name="delete" />
                            </Column>
                        </DataGrid>
                        <ConfirmBox isOpen={delmodal} message={`Are you sure you want to delete this user`}
                            onClose={toggledelModal} onConfirm={deleteRow} text="Delete" title="Delete User" />
                    </div>
                </>
            </Container>
        </>
    )
}

export default CompanyUsers;