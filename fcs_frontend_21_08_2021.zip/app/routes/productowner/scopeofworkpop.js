import React from 'react';
import {
    Modal,
    ModalHeader,
    ModalBody,
    ModalFooter,
    ThemeConsumer
} from '../../components';

const Scopeofworkpop = (props) => {
    return (
        <Modal isOpen={props.isOpen} toggle={props.confirmToggle} className="modal-outline-warning">
            <ModalHeader tag="h5">
                <span>
                    {props.title}</span>
            </ModalHeader>
            <ModalBody>
                <div style={{ marginTop: "10px" }} className="media-body">
                    <p> {props.message}</p>
                </div>
            </ModalBody>
            <ModalFooter>
                <button color="link" onClick={props.onClose} className="btn btn-default text-warning">
                    Cancel
                </button>

                <ThemeConsumer>
                    {
                        ({ color }) => (
                            <button className="btn btn-warning" onClick={props.onConfirm}>
                                {props.text}
                            </button>
                        )
                    }
                </ThemeConsumer>

                {/* <button onClick={confirmToggle} className="btn btn-default" > No </button>
                <Button color="warning" onClick={handleDelete}>Yes</Button> */}
            </ModalFooter>
        </Modal>
    )
}
Scopeofworkpop.defaultProps = {
    onConfirm: () => null,
    onClose: () => null
};
export default Scopeofworkpop;