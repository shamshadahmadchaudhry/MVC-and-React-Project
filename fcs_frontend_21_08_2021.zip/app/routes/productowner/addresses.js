import React,{useEffect,useState,useRef} from 'react'
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    Button,
    RequiredRule,
    PatternRule,
    Selection,
    Scrolling

} from 'devextreme-react/data-grid';
import 
{ 
    getWarehouseBuildingList,
    updateBuildingAddress,
    deleteBuildingAddress 
} from '../../services/warehousemanagementservice';
import {Switch} from 'devextreme-react'
const Addresses = ({data,userscope,selectedBuildings}) => {
    console.log('Active scope',userscope)
    const [addressList,setAddressList] = useState([])
    const [toggleactive,setToggleactive] = useState(false)
    const [defaultbuilding,setDefaultbuilding] = useState(0)
    const [selectedkeys,setSelectedkeys] = useState([])
    const [isparentchecked,setIsparentchecked] = useState(false)
    const datagridRef = useRef(null)
    useEffect(()=>{
        address_data()
        if(data.component.getSelectedRowKeys().includes(data.data.warehouse_location_id)){
            //setIsparentchecked(true)
            datagridRef.current.instance.selectAll()
        }
        // else{
        //     setIsparentchecked(false)
        // }
    },[])

    const address_data = async() =>{
        let addressList = await getWarehouseBuildingList(data.data.warehouse_location_id);
        // console.log('ADDRESS LIST',addressList);
        setAddressList(addressList.data.data)
        return addressList;
    }
    const handleTogglechange = (c,e) =>{
        let keyarr = c.component.getSelectedRowsData()
        if(keyarr != undefined){
        for(let q=0;q<keyarr.length;q++){
            console.log('keyarr',keyarr[q].is_default)
            if((keyarr[q].warehouse_address_id === c.key.warehouse_address_id) && (e.value)){
                keyarr[q].is_default = 1;
            }
            else{
                keyarr[q].is_default = 0;
            }
        }
        selectedBuildings(keyarr)
        }
        
        if(e.value){
           setDefaultbuilding(c.key.warehouse_address_id)
        }
        else{
            setDefaultbuilding(0)
        }
    }
    
    return (
        <div>
            <DataGrid
            dataSource={addressList}
            ref={datagridRef}
            columnAutoWidth={true}
            showColumnHeaders={false}
            onSelectionChanged={(e)=>{
                setSelectedkeys(e.selectedRowKeys)
                let keyarr = e.selectedRowKeys
                // for(let q=0;q<keyarr.length;q++){
                //     if(keyarr[q].warehouse_address_id === defaultbuilding){
                //         keyarr[q].is_default = 1;
                //     }
                //     else{
                //         keyarr[q].is_default = 0;
                //     }
                // }
                selectedBuildings(e.selectedRowKeys)
            }}
            onCellPrepared={(e)=>{
                if (e.rowType == 'data' && e.column.dataField == "warehouse_address_id") {
                    e.cellElement.innerHTML = "<input type='checkbox' className='form-control'/>";
                }
            }}
            >
                
                 <Selection mode="multiple"
                 showCheckBoxesMode='always'/>
                <Scrolling mode="infinite" />
                <Paging enabled={true} pageSize={10} />
                <Column caption='' dataField='building_alias'/>
                <Column dataField='status' cellRender={(e)=>{
                    // console.log('Toggle active',toggleactive)
                    // console.log('defaultbuilding',defaultbuilding)
                    // console.log('eee',e.key.warehouse_address_id)
                        return (
                            <>
                            <Switch
                                value={e.key.warehouse_address_id == defaultbuilding ? true:false}
                                onValueChanged={(g) => handleTogglechange(e,g)}
                            />
                            </>
                        )
                }}/>
            </DataGrid>
        </div>
    )
}

export default Addresses