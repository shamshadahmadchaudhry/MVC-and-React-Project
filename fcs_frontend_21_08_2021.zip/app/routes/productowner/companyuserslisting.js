import React, { useState, useRef, useEffect } from 'react';
import DataGrid,
{
    Column,
    Editing,
    Pager,
    Paging,
    FilterRow,
    Button,
    RequiredRule,
    PatternRule,
    MasterDetail,
    Selection,
    Scrolling

} from 'devextreme-react/data-grid';
import Toggle from 'react-toggle'
import { CheckBox } from 'devextreme-react/check-box';
import CustomStore from 'devextreme/data/custom_store';

import DropDownBox from 'devextreme-react/drop-down-box';

import { Container } from '../../components';
import { toast } from 'react-toastify';
import AlertMessage from '../commoncomponents/alertmessage';
import { useSelector, useDispatch } from 'react-redux';
import { getUserListByCompanyId, getUserCompanyList, getUserRole } from '../../services/threeplcompanyservice';
import { getWarehouseBuildingList, getWarehouseLocationList, updateScopework } from '../../services/warehousemanagementservice';
import { Configuration } from '../commoncomponents/configurationfile';
import {
    CompanyUsersUpdateRequest, ResendIvMailRequest, CancelIvMailRequest, CreateCompanyUserRequest, CompanyUsersRequest
} from '../../redux/actions/index';
import Addresses from './addresses'
import ThreeplCompanyAddress from '../3plcompanymanagement/threeplcompanyaddress';
import { address } from 'faker';
import Scopeofworkpop from './scopeofworkpop'


let global_user_id = 0

const CompanyUsersListing = ({ userType, companyId }) => {

    const dispatch = useDispatch()
    toast.configure();
    // const companyId = companyId
    // const userType = userType
    const datagridRef = useRef(null)
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data);
    const CreateCompanyUserStatus = useSelector(state => state.CreateCompanyUserStatus);
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [userlist, setUserList] = useState([])
    const [rolesdata, setRoles] = useState([])
    const [editactive, setEditactive] = useState(false)
    const [userId, setUserId] = useState(0)
    const [rolesIds, setRoleIds] = useState(0)
    const [updatedetails, setUpdatedetails] = useState({});
    const [isuseractive, setIsuseractive] = useState(false)
    const [locationlist, setLocationlist] = useState([])
    const [checkedStatus, setCheckedStatus] = useState(false)
    const [addresses, setAddresses] = useState([])
    const [selectedLocations, setSelectedLocations] = useState([])
    const [activescope, setActivescope] = useState([])
    const [addingRow, setAddingRow] = useState(false)
    const [addressList, setAddressList] = useState([])
    const [toggleactive, setToggleactive] = useState(false)
    const [defaultbuilding, setDefaultbuilding] = useState(0)
    const [buildings, setBuildings] = useState([])
    const [scopeofwork, setScopeofwork] = useState([])
    const [userscopeworkprop, setUserscopeworkprop] = useState([]);
    const [addmodal, setAddmodal] = useState(false)
    const [addBtn, setAddBtn] = useState(true)
    let sellocat = []
    let address_arr = []
    let first_name = '';
    let last_name = '';
    let email = '';
    let phone_number = '';
    let role_ids = '';
    let scope = [];
    let scope_work = [];
    const [screensize, setScreensize] = useState({
        matches: window.matchMedia("(min-width: 1200px)").matches
    });

    useEffect(() => {
        const handler = e => setScreensize({ matches: e.matches });
        window.matchMedia("(min-width: 1200px)").addListener(handler);
    }, [screensize.matches])

    useEffect(() => {
        location_data()
        loadCompanyUserList()
        loadUserRole(userType)
    }, [])


    //location data
    const location_data = async () => {
        let company_id = 0
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            company_id = CompanyListingStatus?.result?.response?.result?.find(val => val.is_default).company_id;
            setcompanyId(company_id)
        } else {
            company_id = CompanyListingStatus?.result?.response?.result[0].company_id;
            // setcompanyId(company_id)
            console.log('compid', company_id)
        }
        console.log('COMPANY ID', company_id)
        let locationlist = await getWarehouseLocationList(`?company_id=${company_id}`)
        setLocationlist(locationlist.data)
        console.log('LOCATION LISTS', locationlist.data)
        //Load Buildings of locations to array
        for (let b = 0; b < locationlist.data.length; b++) {
            console.log('locationlist.data[b].warehouse_location_id', locationlist.data[b].warehouse_location_id)
            let addressList = await getWarehouseBuildingList(locationlist.data[b].warehouse_location_id);
            address_arr.push(addressList.data.data)
        }
        console.log('Address Array', address_arr)
        setAddresses(address_arr)
        return locationlist.data
    }

    const loadCompanyUserList = async () => {
        const result = await getUserListByCompanyId(companyId, userType);
        setUserList(result.data)
    }

    const loadUserRole = async (userType) => {
        const result = await getUserRole(userType);
        setRoles(result.data)
    }

    //Load user data

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== '';
    }

    const users_data = new CustomStore({
        key: 'user_master_id',
        load: async (loadOptions) => {
            let count = 0;
            let params = '?';
            [
                'skip',
                'take',
                'requireTotalCount',
                'requireGroupCount',
                'sort',
                'filter',
                'totalSummary',
                'group',
                'groupSummary'
            ].forEach(function (i) {
                if (i in loadOptions && isNotEmpty(loadOptions[i])) {
                    params += `${i}=${JSON.stringify(loadOptions[i])}&`;
                }
                if (!loadOptions.filter && !loadOptions.sort && count === 0 && !loadOptions.skip && !loadOptions.take) {
                    params += `skip=0&take=5&requireTotalCount=true&totalSummary=[]&`;
                }
                if (loadOptions.filter && loadOptions['group'] !== null && count === 0) {
                    params += `skip=0&take=5&`;
                }
                count++;
            });
            params += `company_id=${companyId}&`
            params += `user_type_id=${userType}&`
            params = params.slice(0, -1);
            const companyUsers = await getUserCompanyList(params)
            return companyUsers;

        },
        insert: async (user_details) => {
            // if(scopeofwork.length != 0){
            console.log('SCOPEEEEETYY', scopeofwork)
            //   console.log('Selected Locations: ',selectedLocations)
            //   console.log('Selected Addresses: ')
            //"scope": [{ "location_id":"1","address_id":"2","is_default":1 },{ "location_id":"1","address_id":"2","is_default":0 }],
            dispatch(CreateCompanyUserRequest({
                ...user_details, password: 'default1234', status: 2,
                user_type: userType, company_id: companyId, role_ids: user_details.roles.toString(),
                scope: []
            }));
            if (CreateCompanyUserStatus.isSuccess) {
                toast.success(<AlertMessage type='success' title='User Invited'
                    message='User has been Invited' />, { autoClose: 4000 });
                scope = []
                setAddingRow(false)
            }
            console.log('ALTER', user_details)
            // }
        },
        update: async (key, values) => {
            console.log('SCOPE OF WORK LOGGED', scopeofwork)
            role_ids += ','
            let user_details = {
                user_master_id: key, first_name: first_name, last_name: last_name, email: email, phone_number: phone_number, roles: role_ids, is_active: 2, company_id: companyId, user_type_id: userType,
                scope: [{ 'location_id': 1, 'address_id': 2, 'is_default': 0 }, { 'location_id': 2, 'address_id': 1, 'is_default': 1 }]
            }

            // alert(JSON.stringify(user_details))
            console.log('USER DETAILS', JSON.stringify(user_details))
            //    dispatch(CompanyUsersUpdateRequest(user_details))
            //    toast.success(<AlertMessage type='success' title='Record Updated'
            //    message='User record has been updated' />, { autoClose: 4000 });
        }
    })


    const onCellPrepared = async (e) => {
        if (e.rowType == 'header' && e.column.command == "edit") {
            e.cellElement.innerHTML = "Action";
        }

        if (e.rowType == 'filter' && e.column.command == "edit") {
            e.cellElement.innerHTML = "<button class='btn btn-sm btn-outline-secondary mb-1'>Reset Filters <i class='fa fa-close text-danger'></i></button>";
            e.cellElement.onclick = () => { datagridRef.current.instance.clearFilter() }
        }
        if (e.rowType === 'data' && e.column.name === 'roles') {
            let a = e.data.roles
            let cellEls = []
            let els = ''
            if (userId != e.row.data.user_master_id) {
                if (a != undefined) {
                    let arr = a.replace(',', " ").split(" ")
                    let role = ''
                    e.cellElement.innerHTML = null
                    for (let i = 0; i < rolesdata.length; i++) {
                        for (let j = 0; j < arr.length; j++) {
                            if (arr[j] == rolesdata[i].role_master_id) {
                                els = "<pre class='ml-1 mt-4 " + rolesdata[i].css_class_name + "'> " + rolesdata[i].Roles + "</pre>";
                                cellEls.push(els)
                            }
                        }

                    }
                    for (let t = 0; t < cellEls.length; t++) {
                        e.cellElement.innerHTML += cellEls[t]
                    }
                }
            }
        }
        //Scope of work
        // if (e.rowType === 'data' && e.column.name === 'scope_of_work') {
        //     let scopearr = e.data.scope_of_work
        //     let locations = locationlist
        //     let location_address_arr = []
        //     if ((userId != e.row.data.user_master_id)) {
        //         if (scopearr != undefined) {
        //             e.cellElement.innerHTML = null
        //             for (let k = 0; k < scopearr.length; k++) {
        //                 if (!location_address_arr.includes('loc-' + scopearr[k].warehouse_location)) {
        //                     location_address_arr.push('loc-' + scopearr[k].warehouse_location)
        //                 }

        //                 for (let t = 0; t < addresses.length; t++) {
        //                     for (let x = 0; x < addresses[t].length; x++) {
        //                         if (addresses[t][x].warehouse_address_id === scopearr[k].address_id) {
        //                             location_address_arr.push(addresses[t][x].building_alias)
        //                         }
        //                     }
        //                 }
        //             }
        //         }
        //     }
        //     console.log('TEST ',location_address_arr)
        //     if(location_address_arr.length === 0){
        //         e.cellElement.innerHTML = "<button class='btn btn-sm'>Map location</button>"
        //     }
        //     for (let u = 0; u < location_address_arr.length; u++) {
        //         if (location_address_arr[u].substring(0, 4) == 'loc-') {
        //             if (u != 0) {
        //                 e.cellElement.innerHTML += "<br/><span class='badge badge-success'> " + location_address_arr[u].substring(4) + "</span>";
        //             }
        //             else {
        //                 e.cellElement.innerHTML += "<span class='badge badge-success'> " + location_address_arr[u].substring(4) + "</span>";
        //             }
        //         }
        //         else {
        //             e.cellElement.innerHTML += "<span class='badge badge-primary ml-1 '> " + location_address_arr[u] + "</span>";
        //         }

        //     }
        // }

        if (e.rowType === 'data' && e.column.name === 'status') {
            if (e.data.is_active == Configuration.invitationStatus.active) {
                e.cellElement.innerHTML = 'Active'
            } else if (e.data.is_active == Configuration.invitationStatus.canceled) {
                e.cellElement.innerHTML = 'Invitation Cancelled'
            }
            else if (e.data.is_active == Configuration.invitationStatus.inactive) {
                e.cellElement.innerHTML = 'Inactive'
            }
            else if (e.data.is_active == Configuration.invitationStatus.invited) {
                e.cellElement.innerHTML = 'Invited'
            }
        }

    }


    const getLocationsaddress = (lockeys) => {
        let location_address_arr = [];
        let location_address_obj = {}
        // console.log('LOCATION KEYS',lockeys)
        //location keys
        let location_keys = lockeys //        [1,2]  Address list = [[{'location_id':1,'address_id':1}],[{'location_id':2},{'location_id':2,'address_id':3}]]
        //console.log('ADDRESSSS', addresses)
        // Fetch address for each key
        for (let i = 0; i < location_keys.length; i++) {
            for (let k = 0; k < addresses.length; k++) {
                console.log('addresses [k]', addresses[k])
                if (addresses[k]) {
                    for (let o = 0; o < addresses[k].length; o++) {
                        console.log('addresses K[0]', addresses[k][o])
                        if (addresses[k][o].warehouse_location_id === location_keys[i]) {
                            console.log('lOcation id ', addresses[k][o].warehouse_location_id)
                            console.log('Address Id', addresses[k][o].warehouse_address_id)
                            addresses[k][o].location_id = addresses[k][o].warehouse_location_id
                            addresses[k][o].address_id = addresses[k][o].warehouse_address_id
                            addresses[k][o].is_default = 0
                            location_address_arr.push(addresses[k][o])
                            //console.log('Addresses for location',addresses[k][o].warehouse_address_id)

                        }
                    }
                }
            }

        }
        setScopeofwork(location_address_arr)
        console.log('The scope of work when select location checkbox ', location_address_arr)
    }

    //selectedBuildings
    const selectedBuildings = (keyarr) => {
        let scope_output = []
        //"scope": [{ "location_id":"1","address_id":"2" },{ "location_id":"1","address_id":"2" }],
        console.log('SELECTED ADDRESS KEY', keyarr)
        console.log('SELECTED LOCATIONS', locationlist)
        // scope = []
        let locaddobj = {}
        for (let i = 0; i < locationlist.length; i++) {
            //console.log('LOCATION ID',locationlist[i].warehouse_location_id)
            for (let k = 0; k < keyarr.length; k++) {
                if (keyarr[k].warehouse_location_id == locationlist[i].warehouse_location_id) {
                    locaddobj.location_id = locationlist[i].warehouse_location_id
                    locaddobj.address_id = keyarr[k].warehouse_address_id
                    locaddobj.is_default = keyarr[k].is_default
                    // console.log('ADDRESSES UNDER ID',keyarr[k].warehouse_address_id)
                    // if (!scope.some(scop => (scop.location_id === locationlist[i].warehouse_location_id && scop.address_id === keyarr[k].warehouse_address_id && scop.is_default === keyarr[k].is_default))) {
                    //console.log('keyarr[k].is_default',keyarr[k].is_default)
                    scope.push(locaddobj)
                    // }
                }

            }
            console.log('SCOPE INNER CHECK', scope)
        }
        console.log('SCOPE OUTPT', scope_output)
    }




    //Toggle add modal
    const togglepopup = () => {

        setAddmodal(!addmodal)
    }

    //Save Edited Scope
    const saveScopeofwork = async () => {
        // console.log('ADDING ROW',scopeofwork)
        // console.log()

        if (!addingRow) {
            let updateResp = await updateScopework({ scope: scopeofwork, company_id: companyId, user_master_id: global_user_id, created_by: global_user_id })
            console.log('Update Response', updateResp)
            if (updateResp.data.status) {
                toast.success(<AlertMessage type='success' title='Updated Scope of work'
                    message={'Scope of work has been updated'} />, { autoClose: 4000 })
                setActivescope([])
                setUserscopeworkprop([])
                setScopeofwork([]);
                setSelectedLocations([])
                setAddmodal(false)
            }
            else {
                toast.error(<AlertMessage type='error' title='Error Updating scope of work'
                    message={'An error occured during update, please try again later'} />, { autoClose: 4000 })
            }
        }
        else {
            //Update state and display success Message
            toast.success(<AlertMessage type='success' title='Scope of work Added'
                message={'Scope of work has been added'} />, { autoClose: 4000 })
        }
    }

    useEffect(() => {
        setUserscopeworkprop(userscopeworkprop)
    }, [userscopeworkprop])
    const popupBtnRender = (e) => {
        let scopework = e.data.data.scope_of_work;
        let scopearr = scopework
        let location_address_arr = []
        if ((userId === e.data.data.user_master_id)) {
            if (scopearr != undefined) {
                for (let k = 0; k < scopearr.length; k++) {
                    if (!location_address_arr.includes('loc-' + scopearr[k].warehouse_location)) {
                        location_address_arr.push('loc-' + scopearr[k].warehouse_location)
                    }
                    for (let t = 0; t < addresses.length; t++) {
                        if (addresses[t]) {
                            for (let x = 0; x < addresses[t].length; x++) {
                                if (addresses[t][x].warehouse_address_id === scopearr[k].address_id) {
                                    location_address_arr.push(addresses[t][x].building_alias)
                                }
                            }
                        }
                    }
                }
            }
        }
        //setUserscopework(location_address_arr)
        console.log('WORK', location_address_arr)
        // for (let u = 0; u < location_address_arr.length; u++) {
        //     if (location_address_arr[u].substring(0, 4) == 'loc-') {
        //         if (u != 0) {
        //             e.cellElement.innerHTML += "<br/><span class='badge badge-success'> " + location_address_arr[u].substring(4) + "</span>";
        //         }
        //         else {
        //             e.cellElement.innerHTML += "<span class='badge badge-success'> " + location_address_arr[u].substring(4) + "</span>";
        //         }
        //     }
        //     else {
        //         e.cellElement.innerHTML += "<span class='badge badge-primary ml-1 '> " + location_address_arr[u] + "</span>";
        //     }

        // }
        if (userId != 0) {
            return (
                <div className='ml-2'>
                    {location_address_arr.map((scopeofwork, index) => {
                        return (
                            <span key={index}>
                                {((scopeofwork.substring(0, 4)) === 'loc-' && (index === 0)) ? (
                                    <span className='badge badge-success'>{scopeofwork.substring(4)}</span>
                                ) :
                                    ((scopeofwork.substring(0, 4)) === 'loc-' && (index > 0)) ? (
                                        <span><br /><span className='badge badge-success'>{scopeofwork.substring(4)}</span></span>
                                    ) : (
                                            <span className='badge badge-primary ml-1'>{scopeofwork}</span>
                                        )
                                }
                            </span>
                        )
                    })}
                    {/* <button>Hello <sup><button><i className='fa fa-plus'></i></button></sup></button> */}
                </div>
            )
        }
        else {
            return (
                <div className='ml-3'>
                    <div>
                        <span className='btn btn-default btn-sm'>Map location</span>
                    </div>
                    {/* <button onClick={()=>{setAddmodal(true)}} className='btn btn-sm btn-success' disabled={true}><i className='fa fa-plus'></i></button> */}
                </div>
            )
        }
    }
    //Drop down menu
    const dropdownRender = (e) => {
        console.log('Active vals = ', activescope)
        console.log('SCOPE OF WORK', e.data.row.data.scope_of_work);
        return (
            <DropDownBox
                value={selectedLocations}
                valueExpr="warehouse_location_id"
                deferRendering={false}
                displayExpr="location_name"
                placeholder="Select scope of work"
                dataSource={locationlist}
                selectedRowKeys={
                    userId == 0 ?
                        selectedLocations : activescope
                }
                onValueChanged={(e) => {
                    console.log('e')
                }}
                contentRender={
                    (e) => {
                        return (
                            <DataGrid
                                dataSource={locationlist}
                                keyExpr='warehouse_location_id'
                                columnAutoWidth={true}
                                showColumnHeaders={false}
                                showScrollbar={true}
                                displayExpr="location_name"
                                selectedRowKeys={
                                    userId == 0 ?
                                        selectedLocations : activescope
                                }
                                onSelectionChanged={(e) => {
                                    getLocationsaddress(e.selectedRowKeys)
                                    setSelectedLocations(e.selectedRowKeys)
                                    setActivescope(e.selectedRowKeys)
                                }}
                                onCellPrepared={(e) => {
                                }}>
                                <Selection mode="multiple"
                                    showCheckBoxesMode='always' />
                                <Scrolling mode="infinite" />
                                <Paging enabled={true} pageSize={10} />
                                <Column dataField='location_name' />
                                <MasterDetail
                                    enabled={true}
                                    render={props => {
                                        return (
                                            <Addresses data={props} selectedBuildings={selectedBuildings} />
                                        )
                                    }}
                                // component={Addresses}
                                />
                            </DataGrid>
                        )
                    }
                }
            />
        )
    }

    const onEditorPreparing = (e) => {
        e.editorElement.innerText = ''
        e.value = rolesIds == 0 ? '' : rolesIds.toString().split`,`.map(x => +x);
        if (e.parentType === "dataRow" && e.dataField === "roles") {
            e.editorName = "dxTagBox"
            e.editorOptions.dataSource = rolesdata;
            e.editorOptions.showSelectionControls = true;
            e.editorOptions.displayExpr = "Roles";
            e.editorOptions.valueExpr = "role_master_id";
            e.editorOptions.maxDisplayedTags = 10;
            e.editorOptions.showClearButton = true,
                e.editorOptions.value = e.value || [];
            e.editorOptions.onValueChanged = function (args) {
                e.setValue(args.value);
            }
        }
        if (e.parentType == 'dataRow' && e.dataField == 'phone_number') {
            e.editorOptions.maxLength = 11;
        }
        if (e.parentType == 'dataRow' && e.dataField == 'first_name') {
            setTimeout(() => {
                e.component.focus(e.editorElement)
            }, 400);
        }

    }

    return (
        <>
            <Container className="margin-top">
                <>
                    <div className="container-fluid mb-4">

                        <DataGrid id="grid-container"
                            showBorders={true}
                            dataSource={users_data}
                            ref={datagridRef}
                            keyExpr="user_master_id"
                            onCellPrepared={onCellPrepared}
                            onEditorPreparing={onEditorPreparing}
                            columnHidingEnabled={!screensize.matches ? true : false}
                            columnAutoWidth={true}
                            remoteOperations={true}

                            onInitNewRow={(e) => {
                                setUserId(0)
                                setAddingRow(true)
                                setActivescope([])
                                setSelectedLocations([])
                                setIsuseractive(false)
                                datagridRef.current.instance.cancelEditData()
                            }}
                            onEditingStart={(e) => {
                                let location_keys = []
                                for (let k = 0; k < e.data.scope_of_work.length; k++) {
                                    if (!(location_keys.includes(e.data.scope_of_work[k].warehouse_location_id))) {
                                        location_keys.push(e.data.scope_of_work[k].warehouse_location_id)
                                    }

                                }
                                setSelectedLocations(location_keys)
                                setActivescope(location_keys)
                                setRoleIds(e.data.roles)
                                setUserId(e.data.user_master_id)
                                setEditactive(true)
                                setUserscopeworkprop(e.data.scope_of_work)
                                if (e.data.is_active === 1) {
                                    setIsuseractive(true)
                                }
                                else {
                                    setIsuseractive(false)
                                }
                            }}
                            onSaving={(e) => {
                                setRoleIds(0)
                                setUserId(0)
                                setEditactive(false)
                                setAddingRow(false)
                                datagridRef.current.instance.refresh()
                            }}
                            onEditCanceled={(e) => {
                                setAddingRow(false)
                                setRoleIds(0)
                                setUserId(0)
                                setEditactive(false)
                                datagridRef.current.instance.refresh()
                            }}
                            onRowUpdating={(e) => {
                                if (e.newData.first_name) {
                                    first_name = e.newData.first_name
                                }
                                else {
                                    first_name = e.oldData.first_name
                                }
                                if (e.newData.last_name) {
                                    last_name = e.newData.last_name
                                }
                                else {
                                    last_name = e.oldData.last_name
                                }
                                if (e.newData.email) {
                                    email = e.newData.email
                                }
                                else {
                                    email = e.oldData.email
                                }
                                if (e.newData.phone) {
                                    phone_number = e.newData.phone_number
                                }
                                else {
                                    phone_number = e.oldData.phone_number
                                }
                                if (e.newData.roles) {
                                    role_ids = e.newData.roles
                                }
                                else {
                                    role_ids = e.oldData.roles
                                }
                                setUserId(0)
                                setEditactive(false)
                                datagridRef.current.instance.refresh()

                            }}
                        >
                            <Editing
                                mode="row"
                                useIcons={true}
                                allowUpdating={true}
                                allowAdding={true}
                            />
                            <Paging defaultPageSize={10} />
                            <Pager
                                showPageSizeSelector={true}
                                allowedPageSizes={[5, 10, 20]}
                                showInfo={true} />
                            <FilterRow visible={true} />

                            <Column dataField="first_name" caption="First Name" allowEditing={true}>
                                <RequiredRule />
                                <PatternRule
                                    message={'Please Input valid first name'}
                                    pattern={Configuration.alphanumericSpace}
                                />
                            </Column>
                            <Column dataField="last_name" caption="Last Name" allowEditing={true}>
                                <RequiredRule />
                                <PatternRule
                                    message={'Please input valid last name'}
                                    pattern={Configuration.alphanumericSpace}
                                />
                            </Column>
                            <Column dataField="email" caption="Email" allowEditing={isuseractive ? false : true} allowAdding={true}>
                                <RequiredRule />
                                <PatternRule
                                    message={'Please input valid email'}
                                    pattern={Configuration.emailpattern}
                                />
                            </Column>
                            <Column dataField="phone_number" caption="Phone" width={120} allowEditing={true}>
                                <RequiredRule />
                                <PatternRule
                                    message={'Please input valid Phone number'}
                                    pattern={Configuration.numeric}
                                />
                            </Column>
                            <Column dataField="roles" caption="Roles" cssClass='min_width_role' allowFiltering={false} allowSorting={false}>
                                <RequiredRule />
                            </Column>
                            <Column dataField="scope_of_work"
                                width={360}
                                cellRender={(e) => {
                                    if (e.data.scope_of_work.length === 0) {
                                        return (
                                            <div>
                                                <button onClick={

                                                    () => {
                                                        //console.log('e.data.user_master_id',e.data.user_master_id)
                                                        // setUserId(e.data.user_master_id);
                                                        global_user_id = e.data.user_master_id;
                                                        setActivescope([]);
                                                        setScopeofwork([]);
                                                        setAddmodal(true)
                                                    }
                                                } className='btn btn default'>Map Location</button>
                                            </div>
                                        )
                                    }
                                    else {
                                        console.log('SCPE', e.data.scope_of_work)
                                        let scopework = e.data.scope_of_work;
                                        let scopearr = scopework
                                        let location_address_arr = []
                                        // if ((userId === e.data.user_master_id)) {
                                        if (scopearr != undefined) {
                                            for (let k = 0; k < scopearr.length; k++) {
                                                if (!location_address_arr.includes('loc-' + scopearr[k].warehouse_location)) {
                                                    location_address_arr.push('loc-' + scopearr[k].warehouse_location)
                                                }
                                                for (let t = 0; t < addresses.length; t++) {
                                                    if (addresses[t]) {
                                                        for (let x = 0; x < addresses[t].length; x++) {
                                                            if (addresses[t][x].warehouse_address_id === scopearr[k].address_id) {
                                                                location_address_arr.push(addresses[t][x].building_alias)
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        // }

                                        let location_keys = []
                                        for (let k = 0; k < e.data.scope_of_work.length; k++) {
                                            if (!(location_keys.includes(e.data.scope_of_work[k].warehouse_location_id))) {
                                                location_keys.push(e.data.scope_of_work[k].warehouse_location_id)
                                            }
                                            console.log('LOCATION KEYSFin', location_keys)
                                        }

                                        //Map and display

                                        return (
                                            <div className='ml-2'>
                                                {location_address_arr.length > 0 ? (
                                                    <button className='btn btn-sm btn-warning bg-light b-0 m-1 pull-right'
                                                        onClick={
                                                            () => {
                                                                global_user_id = e.data.user_master_id;
                                                                setScopeofwork(e.data.scope_of_work)
                                                                setSelectedLocations(location_keys)
                                                                console.log('e.data.scopeofwork', e.data.scope_of_work)
                                                                setAddmodal(true)
                                                            }} title='Edit Scope of work'>
                                                        <i className='dx-icon-edit text-warning'></i></button>
                                                ) : ''}
                                                {location_address_arr.map((scopeofwork, index) => {
                                                    return (
                                                        <span key={index}>
                                                            {((scopeofwork.substring(0, 4)) === 'loc-' && (index === 0)) ? (
                                                                <span className='badge badge-success'>{scopeofwork.substring(4)}</span>
                                                            ) :
                                                                ((scopeofwork.substring(0, 4)) === 'loc-' && (index > 0)) ? (
                                                                    <span><br /><span className='badge badge-success'>{scopeofwork.substring(4)}</span></span>
                                                                ) : (
                                                                        <span className='badge badge-primary ml-1'>{scopeofwork}</span>
                                                                    )
                                                            }
                                                        </span>
                                                    )
                                                })}
                                            </div>
                                        )
                                    }
                                }}
                                // editCellComponent={dropdownRender} 
                                editCellComponent={popupBtnRender}
                                // allowEditing={addingRow ? false}
                                allowFiltering={false} allowSorting={false}>
                            </Column>
                            <Column dataField="status" caption="Status" allowFiltering={false} allowSorting={false} allowEditing={false} width={100}>

                            </Column>
                            <Column type="buttons" width={60}>
                                <Button name="edit" />
                            </Column>
                            <Column width={120} cellRender={(e) => {
                                if (e.data.is_active != 1) {
                                    return (
                                        <>
                                            <span className="fa fa-envelope ml-1"
                                                onClick={() => {
                                                    dispatch(CancelIvMailRequest({ user_master_id: e.data.user_master_id, company_id: companyId }))
                                                    toast.success(<AlertMessage type='success' title='Invitation canceled'
                                                        message={'Invitation  has been canceled'} />, { autoClose: 4000 })
                                                    datagridRef.current.instance.refresh();
                                                }}><sup class="fa fa-close fa-xs text-danger small"></sup></span>
                                            <span className="fa fa-envelope ml-1" onClick={() => {
                                                dispatch(ResendIvMailRequest({ user_master_id: e.data.user_master_id, company_id: companyId }));
                                                datagridRef.current.instance.refresh();
                                                toast.success(<AlertMessage type='success' title='Invitation sent'
                                                    message={'Invitation mail has been sent successfully.'} />, { autoClose: 4000 })
                                            }}><sup class="fa fa-arrow-right fa-xs text-success small"></sup></span>
                                        </>
                                    )
                                }
                            }}>
                            </Column>
                        </DataGrid>

                        <Scopeofworkpop isOpen={addmodal}
                            message={
                                <div>
                                    <DataGrid
                                        dataSource={locationlist}
                                        keyExpr='warehouse_location_id'
                                        columnAutoWidth={true}
                                        showColumnHeaders={false}
                                        showScrollbar={true}
                                        displayExpr="location_name"
                                        selectedRowKeys={
                                            userId == 0 ?
                                                selectedLocations : activescope
                                        }
                                        onSelectionChanged={(e) => {
                                            getLocationsaddress(e.selectedRowKeys)
                                            setSelectedLocations(e.selectedRowKeys)
                                            setActivescope(e.selectedRowKeys)
                                        }}
                                        onCellPrepared={(e) => {
                                        }}>
                                        <Selection mode="multiple"
                                            showCheckBoxesMode='always' />
                                        <Scrolling mode="infinite" />
                                        <Paging enabled={true} pageSize={10} />
                                        <Column dataField='location_name' />
                                        <MasterDetail
                                            enabled={true}
                                            autoExpandAll={true}
                                            render={props => {

                                                return (
                                                    <Addresses data={props} userscope={userscopeworkprop} selectedBuildings={selectedBuildings} />
                                                )
                                            }}
                                        />
                                    </DataGrid>
                                </div>
                            }
                            onClose={togglepopup} onConfirm={saveScopeofwork} text={'Save'}
                            title={'Add scope of work'} />
                    </div>
                </>
            </Container>
        </>
    )
}


export default CompanyUsersListing;