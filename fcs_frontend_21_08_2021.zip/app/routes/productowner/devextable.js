// import React, { useState, useRef, useEffect } from 'react';
// import DataGrid,
// {
//     Column,
//     Editing,
//     Pager,
//     Paging,
//     FilterRow,
//     Button,
//     RequiredRule,
//     PatternRule,
//     MasterDetail,
//     Selection,
//     Scrolling

// } from 'devextreme-react/data-grid';
// import Toggle from 'react-toggle'
// import { CheckBox } from 'devextreme-react/check-box';
// import CustomStore from 'devextreme/data/custom_store';
// import DropDownBox from 'devextreme-react/drop-down-box';


// import { getWarehouseBuildingList,getWarehouseLocationList } from '../../services/warehousemanagementservice';
// const Devextable = () => {
//     const [locationlist,setLocationlist] = useState([])
//     const [rowkeys,setRowkeys] = useState(0)
//     const [selectedRkeys, setSelectedRkeys] = useState(0)

//     useEffect(()=>{
//         load_data()
//     },[])
//     const load_data = async ()=>{
//         let locationlist = await getWarehouseLocationList(`?company_id=${2}`)
//         setLocationlist(locationlist.data)
//     }
//     const table_data = [
//         {'id':1,'first_name':'Habib','last_name':'Nuhu'},
//         {'id':2,'first_name':'Hemant','last_name':'Upasani'},
//         {'id':3,'first_name':'Jitendra','last_name':'Dubey'},
//         {'id':4,'first_name':'Ankita','last_name':'Shukla'},
//     ]




//     //DROPDOWN BOX
//     const dropdownRender = (e) => {
//        // console.log('SCOPE OF WORK', e.data.row.data.scope_of_work);
//         return (
//             <DropDownBox
//                 value={[1]}
//                 valueExpr="warehouse_location_id"
//                 deferRendering={false}
//                 displayExpr="location_name"
//                 placeholder="Select scope of work"
//                 dataSource={locationlist}
//                 // selectedRowKeys={
//                 //     userId == 0 ?
//                 //         selectedLocations : activescope
//                 // }
//                 // onValueChanged={(e) => {
//                 //     console.log('e')
//                 // }}
//                 contentRender={
//                     (e) => {
//                         return (
//                             <DataGrid
//                                 dataSource={locationlist}
//                                 keyExpr='warehouse_location_id'
//                                 columnAutoWidth={true}
//                                 showColumnHeaders={false}
//                                 showScrollbar={true}
//                                 displayExpr="location_name"
//                                 // selectedRowKeys={
//                                 //     userId == 0 ?
//                                 //         selectedLocations : activescope
//                                 // }
//                                 onSelectionChanged={(e) => {
//                                     console.log('selectedRowKeys', e.selectedRowKeys)
//                                     setSelectedRkeys(e.selectedRowKeys)
//                                     // getLocationsaddress(e.selectedRowKeys)
//                                     // setSelectedLocations(e.selectedRowKeys)
//                                     // setActivescope(e.selectedRowKeys)
//                                 }}
//                                 onCellPrepared={(e) => {
//                                 }}>
//                                 <Selection mode="multiple"
//                                     showCheckBoxesMode='always' />
//                                 <Scrolling mode="infinite" />
//                                 <Paging enabled={true} pageSize={10} />
//                                 <Column dataField='location_name' />
//                                 <MasterDetail
//                                     enabled={true}
//                                     render={props => {
//                                         return (
//                                             <Addresses data={props} selectedBuildings={selectedBuildings} />
//                                         )
//                                     }}
//                                 // component={Addresses}
//                                 />
//                             </DataGrid>
//                         )
//                     }
//                 }
//             />
//         )
//     }

//     return (
//         <div className='container'>
//             <div className='card mt-4'>
//                 <DataGrid
//                 keyExpr='id'
//                 rowAlternationEnabled={true}
//                 dataSource={table_data}
//                 onSelectionChanged={(e)=>{
//                     console.log('Stte set')
//                     setRowkeys(e.selectedRowKeys)
//                 }}>
//                 <Column dataField='first_name'/>
//                 <Column dataField='last_name'/>
//                 <Column caption='scope' cellRender={dropdownRender}/>
//                 <Selection mode="multiple" 
//                 showCheckBoxesMode='always' />
//                 <Editing allowAdding={true}
//                 allowUpdating={true}
//                 allowDeleting={true}/>
//                 </DataGrid>
//             </div>
//         </div>
//     )
// }

// export default Devextable;

import React, { useState,useEffect } from "react";
import DataGrid, {
  Paging,
  HeaderFilter,
  SearchPanel,
  Editing,
  Column,
  Selection,
  Scrolling,
  Lookup,
  RequiredRule
} from "devextreme-react/data-grid";
import DropDownBox from "devextreme-react/drop-down-box";
import { getWarehouseBuildingList,getWarehouseLocationList } from '../../services/warehousemanagementservice';



const Devextable = () => {
    // const url = "https://js.devexpress.com/Demos/Mvc/api/CustomEditors";
    const [locationlist,setLocationlist] = useState([])
    const [rowkeys,setRowkeys] = useState(0)
    const [selectedRkeys, setSelectedRkeys] = useState(0)

    useEffect(()=>{
        load_data()
    },[])

    const load_data = async ()=>{
        let locationlist = await getWarehouseLocationList(`?company_id=${2}`)
        setLocationlist(locationlist.data)

    }
    const [selectedLocations, setSelectedLocations] = useState([]);


    const gridData = [
      { id: 1, first_name: "John", email: "jamie@yopmail.com" },
      { id: 2, first_name: "John", email: "jamie@yopmail.com" },
      { id: 3, first_name: "John", email: "jamie@yopmail.com" }
    ];
    
    const ddBoxData = [
      { location_id: 1, location_name: "Location 1" },
      { location_id: 2, location_name: "Location 2" }
    ];

    return (
      <div>
        <DataGrid
          dataSource={locationlist}
          keyExpr="warehouse_location_id"
          columnHidingEnabled={true}
          columnAutoWidth={true}
          remoteOperations={true}
          showBorders={true}
        >
          <Paging enabled={true} defaultPageSize={15} />
          <HeaderFilter visible={true} />
          <SearchPanel visible={true} />
          <Editing mode="row" allowUpdating={true} allowAdding={true} />
          <Column dataField="location_name" allowEditing={true}/>
          <Column
            caption="Scope of work"
            width="400px"
            cellRender={() => {
              return (
                <DropDownBox
                  value={selectedLocations}
                  valueExpr="location_id"
                  deferRendering={false}
                  displayExpr="location_name"
                  placeholder="Select scope of work"
                  showClearButton={true}
                  dataSource={ddBoxData}
                  onValueChanged={() => {}}
                  contentRender={(e) => {
                    return (
                      <DataGrid
                        dataSource={ddBoxData}
                        keyExpr="location_id"
                        columnAutoWidth={true}
                        showColumnHeaders={false}
                        selectedRowKeys={selectedLocations}
                        onSelectionChanged={(e) => {
                          console.log("eee", e);
                          setSelectedLocations(e.selectedRowKeys);
                        }}
                        onCellPrepared={(e) => {}}
                      >
                        <Selection mode="multiple" showCheckBoxesMode="always" />
                        <Scrolling mode="infinite" />
                        <Paging enabled={true} pageSize={10} />
                        <Column dataField="location_name" />
                      </DataGrid>
                    );
                  }}
                />
              );
            }}
          ></Column>
        </DataGrid>
      </div>
    );
  };

export default Devextable;
