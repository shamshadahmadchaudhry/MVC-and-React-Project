import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch, shallowEqual } from "react-redux"
import BootstrapTable from 'react-bootstrap-table-next';
import cellEditFactory from 'react-bootstrap-table2-editor';
import paginationFactory from 'react-bootstrap-table2-paginator';
import { Multiselect } from 'multiselect-react-dropdown';
import { toast } from 'react-toastify';
import { Container, Button, Card, CardBody } from '../../components';
import AlertMessage from '../commoncomponents/alertmessage';
import {
  CompanyUsersUpdateRequest, ResendIvMailRequest, CancelIvMailRequest, CreateCompanyUserRequest, CompanyUsersRequest
} from '../../redux/actions/index';

import { CustomPaginationPanel } from '../threeplcompany/components/CustomPaginationPanel';
import { CustomSizePerPageButton } from '../threeplcompany/components/CustomSizePerPageButton';
import { CustomPaginationTotal } from '../threeplcompany/components/CustomPaginationTotal';

import { getAllUserListByCompanyId } from '../../services/threeplcompanyservice';

import ThreeplCompanyAddress from '../3plcompanymanagement/threeplcompanyaddress';
import { Configuration } from '../commoncomponents/configurationfile';
import { RolesRequest } from '../../redux/actions/index';

//Imported for loader
import { useLoading, Oval } from '@agney/react-loading';
import userRoles from '../../redux/reducers/userRoles';

const CompanyUsers = (props) => {

  const dispatch = useDispatch()
  const CompanyUsersStatus = useSelector(state => state.CompanyUsersStatus);
  const CreateCompanyUserStatus = useSelector(state => state.CreateCompanyUserStatus);
  const CancelIvMailStatus = useSelector(state => state.CancelIvMailStatus);
  const ResendIvMailStatus = useSelector(state => state.ResendIvMailStatus);
  //const UserRolesStatus = useSelector(state => state.UserRolesStatus);
  const RolesStatus = useSelector(state => state.RolesStatus)
  const multiselectRef = React.createRef();
  let users = []
  let selroles = []
  let company_id = props.companyId;
  const [seloption, setSeloption] = useState('');
  const [editmode, setEditmode] = useState(false);
  const [editid, setEditid] = useState(0);
  const [t, setT] = useState([])
  const [newdata, setNewdata] = useState(false);
  const [formIsValid, setformIsValid] = useState(false);
  const [newuser, setNewuser] = useState({
    first_name: '',
    last_name: '',
    email: '',
    password: 'default1234',
    phone_number: '',
    roles: seloption,
    status: 2,
  });

  const [error, setError] = useState({
    email_err: '',
    first_name_err: '',
    last_name_err: '',
    phone_err: ''
  });

  const [options, setOptions] = useState([]);
  const [userroles, setUserroles] = useState([]);

  //set loader
  const { containerProps, indicatorEl } = useLoading({
    indicator: <Oval width="50" />,
  });
  //configure toast
  toast.configure();

  if (CompanyUsersStatus.isSuccess) {
    let data = CompanyUsersStatus.result.response;
    users = data;
  }

  useEffect(() => {
    dispatch(CompanyUsersRequest({ company_id: company_id }));
  }, [CreateCompanyUserStatus?.isSuccess])


  useEffect(() => {
    dispatch(CompanyUsersRequest({ company_id: company_id }));
  }, [ResendIvMailStatus.isSuccess]);

  useEffect(() => {
    dispatch(CompanyUsersRequest({ company_id: company_id }));
  }, [CancelIvMailStatus.isSuccess]);

  const loadCompanyUserList = async () => {
    const result = await getAllUserListByCompanyId(company_id);
    data = result.data;
  }

  useEffect(() => {
    dispatch(CompanyUsersRequest({ company_id: company_id }));
  }, [company_id]);

  useEffect(() => {
    dispatch(RolesRequest({ user_type_id: props.userType }));
  }, [props.userType]);

  //GET ALL ROLES FOR COMPANY ID BASED ON USER TYPE
  useEffect(() => {
    if (RolesStatus.isSuccess) {
      setOptions(RolesStatus?.result?.response);
    }
  }, [RolesStatus?.isSuccess, RolesStatus?.result])

  //Update users Record
  const updateUser = details => {
    debugger;
    console.log("gggggg", details);
    dispatch(CompanyUsersUpdateRequest(details));
    toast.success(<AlertMessage type='success' title='Record Updated'
      message={'User record has been Updated'} />, { autoClose: false })
    setEditmode(false);
  }
  const resetValues = () => {
    multiselectRef.current.resetSelectedValues();
  }
  //Add new user 
  const inviteUser = () => {
    newuser.roles = seloption
    if (newuser.first_name === '' || newuser.last_name === '' || newuser.email === '' || newuser.phone_number === '') {
      toast.error(<AlertMessage type='error' title='Invalid input' message={'Please Fill in required Fields'} />, { autoClose: false })
    }
    else {
      if (newuser.phone_number.match(Configuration.phoneRegExp)
        && (newuser.first_name.match(Configuration.alphabat))
        && newuser.last_name.match(Configuration.alphabat)
        && newuser.email.match(Configuration.emailpattern)) {
        dispatch(CreateCompanyUserRequest({ ...newuser, company_id: company_id, role_ids: seloption.slice(0, -1) }));
        //display success
        toast.success(<AlertMessage type='success' title='User Invited' message={'User has been Invited, Check email for invitation'} />, { autoClose: false })
        //set all fields to empty
        setNewuser({
          first_name: '',
          last_name: '',
          password: 'default1234',
          email: '',
          phone_number: '',
          roles: '',
          status: 0
        });
        resetValues();
        setNewdata(true);
      } else {
        toast.error(<AlertMessage type='error' title='Invalid input'
          message={'Please provide valid input'} />, { autoClose: false })
      }
    }
  }

  //Resend email
  const resendEmail = (details) => {
    dispatch(ResendIvMailRequest(details));
    toast.success(<AlertMessage type='success' title='Invitation sent'
      message={'Invitation mail has been sent successfully.'} />, { autoClose: 4000 })
  }
  const handleChange = (e) => {
    setNewuser({ ...newuser, [e.target.name]: e.target.value });
  }

  const handleSeloptChange = (selectedItem) => {
    setSeloption(selectedItem)
  }

  const cancelEmail = (details) => {
    dispatch(CancelIvMailRequest(details))
    toast.success(<AlertMessage type='success' title='Invitation canceled'
      message={'Invitation  has been canceled'} />, { autoClose: 4000 })
  }

  const buttonFormatter = (row, rowIndex, formatextraData) => {
    return (
      <div>
        {editmode && editid == rowIndex.user_master_id ?
          <a id={rowIndex.user_master_id} onClick={() => updateUser(rowIndex)} >
            <span className='fa fa-save'></span> </a> :
          <a onClick={() => { setEditmode(true); setEditid(rowIndex.user_master_id) }} >
            <span className='fa fa-edit ml-1'></span></a>
        }


        {(rowIndex.is_active == 2) && (
          <a title="Cancel Invitation" onClick={() => cancelEmail(rowIndex)} >
            <span className="fa fa-envelope ml-1" >
              <sup className="fa fa-close fa-xs text-danger small"></sup>
            </span>
          </a>
        )
        }
        {(rowIndex.is_active != 1) && (
          <a title="Resend Invitation" onClick={() => resendEmail(rowIndex)}>
            <span className="fa fa-envelope ml-1" >
              <sup className="fa fa-arrow-right text-success small"></sup>
            </span>
          </a>
        )
        }
      </div>
    )
  }

  const rolesFormatter = (cell, rowIndex) => {
    let userRoles = []
    let role_id = rowIndex.roles.slice(0, -1)
    options.map(option => {
      if (role_id.includes(option.role_master_id)) {
        userRoles.push(option)
      }
    })
    if (editmode && editid == rowIndex.user_master_id) {
      return (
        <Multiselect
          options={options}
          values={options}
          selectedValues={userRoles}
          style={{ chips: { background: '#FF8800', fontSize: '0.6rem' } }}
          displayValue="Roles"
          onSelect={handleSeloptChange}
          id={rowIndex.user_master_id} />
      )
    }
    else {
      return (
        userRoles.map(role => (
          <label className={`${role.css_class_name} ml-1`}>{role.label}</label>
        ))

      )
    }

  }

  const statusFormater = (cell, colIndex) => {
    if (colIndex.is_active == 1) {
      return (
        <span>Active</span>
      )
    } else if (colIndex.is_active == 4) {
      return (
        <span>Invitation Canceled</span>
      )
    }
    else if (colIndex.is_active == 0) {
      return (
        <span>Inactive</span>
      )
    }
    else {
      return (
        <span>Invited</span>
      )
    }
  }

  const firstnameFormatter = (column, colIndex, { text }) => {
    if (!editmode) {
      return (
        <div>
          <input type="text" className='form-control' onBlur={validateFirstname} name="first_name" value={newuser.first_name} placeholder="First name" style={{ 'minWidth': '80px' }} onChange={handleChange} />
          <span className='text-danger'>{error.first_name_err}</span>
        </div>
      );
    }
  }

  const lastnameFormatter = (column, colIndex, { text }) => {
    if (!editmode) {
      return (
        <div>
          <input type="text" className='form-control' onBlur={validateLastname} style={{ 'minWidth': '80px' }} name="last_name" value={newuser.last_name} placeholder="Last name" onChange={handleChange} />
          <span className='text-danger'>{error.last_name_err}</span>
        </div>
      );
    }
  }

  const emailFormatter = (column, colIndex, { text }) => {
    if (!editmode) {
      return (
        <div>
          <input type="text" className='form-control' onBlur={validateEmail} name="email" value={newuser.email} placeholder="E-mail" onChange={handleChange} />
          <span className='text-danger'>{error.email_err}</span>
        </div>
      );
    }
  }

  const phoneFormatter = (column, colIndex, { text }) => {
    if (!editmode) {
      return (
        <div>
          <input type="text" className='form-control' onBlur={validatePhone} name="phone_number" style={{ 'minWidth': '100px' }} value={newuser.phone_number} placeholder="Phone" onChange={handleChange} />
          <span className='text-danger'>{error.phone_err}</span>
        </div>
      );
    }
  }

  const rolesfooterFormatter = (column, colIndex) => {
    if (!editmode) {
      return (
        <Multiselect
          options={options}
          value={options}
          displayValue="Roles"
          onSelect={handleSeloptChange}
          ref={multiselectRef} />
      )
    }
  }

  const invitebtnFormatter = (column, colIndex, { text }) => {
    if (!editmode) {
      return (
        <Button id={`btn-invite-${colIndex}`} className="btn btn-sm btn-warning" title="Click to add user" onClick={() => { inviteUser(newuser) }}>Invite <span className='fa fa-plus'></span></Button>

      )
    }
  }

  const sortCaret = (order) => {
    if (!order)
      return <i className="fa fa-fw fa-sort text-muted"></i>;
    if (order)
      return <i className={`fa fa-fw text-muted fa-sort-${order}`}></i>
  };

  //Table Columns
  let columns = [
    {
      dataField: 'first_name',
      text: 'First name',
      sort: true,
      sortCaret,
      footer: ' ',
      editable: editmode,
      footerFormatter: firstnameFormatter,

    },
    {
      dataField: 'last_name',
      text: 'Last name',
      sort: true,
      sortCaret,
      footer: 'Lastname',
      editable: editmode,
      footerFormatter: lastnameFormatter
    },
    {
      dataField: 'email',
      text: 'Email',
      sort: true,
      sortCaret,
      editable: false,
      footer: 'Email',
      footerFormatter: emailFormatter
    },
    {
      dataField: 'phone_number',
      text: 'Phone',
      sort: true,
      sortCaret,
      footer: 'Phone',
      footerFormatter: phoneFormatter,
      editable: editmode,
    },
    {
      dataField: 'roles',
      text: 'Roles',
      sort: false,
      editable: false,
      headerStyle: (colum, colIndex) => {
        return {
          'minWidth': '250px'
        };
      },
      footer: '',
      formatter: rolesFormatter,
      footerFormatter: rolesfooterFormatter,
      formatExtraData: options
      //formatExtraData: editmode
    },
    {
      dataField: 'status',
      text: 'Status',
      sort: true,
      sortCaret,
      editable: false,
      formatter: statusFormater,
      footer: ''
    },
    {
      dataField: 'Action',
      text: 'Action',
      sort: false,
      formatter: buttonFormatter,
      formatExtraData: editmode,
      editable: false,
      footer: 'Invite user',
      footerFormatter: invitebtnFormatter,
      headerStyle: (colum, colIndex) => {
        return { 'width': '200px' };
      },

    }
  ]

  const paginationDef = paginationFactory({
    paginationSize: 10,
    showTotal: true,
    pageListRenderer: (props) => (
      <CustomPaginationPanel {...props} size="sm" className="ml-md-auto mt-2 mt-md-0" />
    ),
    sizePerPageRenderer: (props) => (
      <CustomSizePerPageButton {...props} />
    ),
    paginationTotalRenderer: (from, to, size) => (
      <CustomPaginationTotal {...{ from, to, size }} />
    )
  });

  const validateFirstname = () => {
    if (!newuser.first_name.match(Configuration.alphabat)) {
      setError({
        first_name_err: 'Invalid First name'
      })
      setformIsValid(false);
    }
    else {
      setError({
        first_name_err: ''
      })
      setformIsValid(true);
    }
  }

  const validateLastname = () => {
    if (!newuser.last_name.match(Configuration.alphabat)) {
      setError({
        last_name_err: 'Invalid Last name'
      })
      setformIsValid(false);
    }
    else {
      setError({
        last_name_err: ''
      })
      setformIsValid(true);
    }
  }

  const validateEmail = () => {
    if (!newuser.email.match(Configuration.emailpattern)) {
      setError({
        email_err: 'Invalid email address'
      });
      setformIsValid(false);
    }
    else {
      setError({
        email_err: ''
      });
      setformIsValid(true);
    }
  }

  const validatePhone = () => {
    if (!newuser.phone_number.match(Configuration.phoneRegExp)) {
      setError({
        phone_err: 'Invalid phone'
      });
      setformIsValid(false);
    }
    else {
      setError({
        phone_err: ''
      });
      setformIsValid(true);
    }
  }

  return (
    <Container>
      <div className="table-responsive">
        {props.userType !== Configuration.userType.productOwner && <ThreeplCompanyAddress company_id={company_id} userType={props.userType} />}
        {/* <div className="p-2" style={{ 'border': '1px solid #000' }}> */}
        <Card>
          {/* <h6 className='m-3'>Manage company users  </h6>
          {props.userType !== Configuration.userType.userManagement && <ThreeplCompanyAddress company_id={company_id} userType={props.userType} />} */}
          <h6 className='m-3'>Manage company users  </h6>
          {!CompanyUsersStatus.isLoading ?
            <BootstrapTable
              table-responsive
              striped
              hover
              bordered={false}
              keyField='user_master_id'
              data={users}
              bootstrap='bootstrap4'
              columns={columns}
              pagination={paginationDef}
              cellEdit={cellEditFactory({ mode: "click", blurToSave: true })} />
            :
            <div style={{ textAlign: "center" }} {...containerProps}>
              {indicatorEl} {/* renders only while loading */}
            </div>
          }
        </Card>
      </div>
      {/* </div> */}
    </Container >
  )
}

export default CompanyUsers;