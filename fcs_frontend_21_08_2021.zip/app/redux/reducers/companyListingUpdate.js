import * as actions from "../actionTypes";

const initialState = {
  isLoading: false,
  isSuccess: false,
  isError: false
};

const companyListingUpdate = (state = initialState, action) => {
  switch (action.type) {
    case actions.COMPANYLISTING_UPDATE_REQUEST:
      return {
        ...state,
        isLoading: true,
        isSuccess: false,
        isError: false
      };
    case actions.COMPANYLISTING_UPDATE_SUCCESS:
      return {
        ...state,
        isLoading: false,
        isSuccess: true,
        isError: false,
        result: action.payload,
      };

    case actions.COMPANYLISTING_UPDATE_ERROR:
      return {
        ...state,
        isLoading: false,
        isSuccess: false,
        isError: true,
        result: action.payload,
      };
    case actions.COMPANYLISTING_UPDATE_CLEAN:
      return {
        isLoading: false,
        isSuccess: false,
        isError: false
      };

    default:
      return state;
  }
};

export default companyListingUpdate;
