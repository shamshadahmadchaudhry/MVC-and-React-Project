import * as actions from "../actionTypes";

const initialState = {
    isLoading: false,
    isSuccess: false,
    isError: false,
};

const resetPassword = (state = initialState, action) => {
    // console.log(action, 'reducer')
    switch (action.type) {
        case actions.RESETPASSWORD_REQUEST:
            return {
                ...state,
                isLoading: true,
                isSuccess: false,
                isError: false,
            };
        case actions.RESETPASSWORD_SUCCESS:
            return {
                ...state,
                isLoading: false,
                isSuccess: true,
                isError: false,
                data: action.payload
            };

        case actions.RESETPASSWORD_ERROR:
            return {
                ...state,
                isLoading: false,
                isSuccess: false,
                isError: true,
                data: action.payload
            };
            case actions.RESETPASSWORD_CLEAN:
                return {
                    ...state,
                    isLoading: false,
                    isSuccess: false,
                    isError: false,
                };

        default:
            return state;
    }
};

export default resetPassword;
