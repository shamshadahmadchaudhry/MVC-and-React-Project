import * as actions from "../actionTypes";

const initialState = {
    buildings: localStorage.getItem('buildings') ? JSON.parse(localStorage.getItem('buildings')) : []
};

const addBuilding = (state = initialState, action) => {
    console.log("addReducer", action)
    switch (action.type) {
        case actions.ADD_BUILDING_REQUEST:
            return state;
        case actions.ADD_BUILDING_SUCCESS:
            return {
                buildings: action.payload,
            };
        default:
            return state;
    }
};

export default addBuilding;