import * as actions from "../actionTypes";

const initialState = {
    isLoading: false,
    isSuccess: false,
    isError: false,
};

const userProfile = (state = initialState, action) => {
    // console.log(action, 'reducer')
    switch (action.type) {
        case actions.USER_PROFILE_REQUEST:
            return {
                ...state,
                isLoading: true,
                isSuccess: false,
                isError: false,
            };
        case actions.USER_PROFILE_SUCCESS:
            return {
                ...state,
                isLoading: false,
                isSuccess: true,
                isError: false,
                data: action.payload
            };

        case actions.USER_PROFILE_ERROR:
            return {
                ...state,
                isLoading: false,
                isSuccess: false,
                isError: true,
                data: action.payload
            };

        default:
            return state;
    }
};

export default userProfile;
