import * as actions from "../actionTypes";

const initialState = {
  isLoading: false,
  isSuccess: false,
  isError: false
};

const companyAddress = (state = initialState, action) => {
  switch (action.type) {
    case actions.COMPANYADDRESS_REQUEST:
      return {
        ...state,
        isLoading: true,
        isSuccess: false,
        isError: false
      };
    case actions.COMPANYADDRESS_SUCCESS:
      return {
        ...state,
        isLoading: false,
        isSuccess: true,
        isError: false,
        result: action.payload,
      };

    case actions.COMPANYADDRESS_ERROR:
      return {
        ...state,
        isLoading: false,
        isSuccess: false,
        isError: true,
        result: action.payload,
      };

    default:
      return state;
  }
};

export default companyAddress;