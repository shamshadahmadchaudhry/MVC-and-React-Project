import * as actions from "../actionTypes";

const initialState = {
    isLoading: false,
    isSuccess: false,
    isError: false,
};

const userData = (state = initialState, action) => {
    // console.log(action, 'reducer')
    switch (action.type) {
        case actions.USER_DATA_REQUEST:
            return {
                ...state,
                isLoading: true,
                isSuccess: false,
                isError: false,
            };
        case actions.USER_DATA_SUCCESS:
            return {
                ...state,
                isLoading: false,
                isSuccess: true,
                isError: false,
                data: action.payload
            };

        case actions.USER_DATA_ERROR:
            return {
                ...state,
                isLoading: false,
                isSuccess: false,
                isError: true,
                data: action.payload
            };

        default:
            return state;
    }
};

export default userData;
