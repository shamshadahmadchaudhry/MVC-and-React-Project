import * as actions from "../actionTypes";

const initialState = {
    isLoading: false,
    isSuccess: false,
    isError: false,
    resetCount: 0
};

const forgetPassword = (state = initialState, action) => {
    // console.log(action, 'reducer')
    switch (action.type) {
        case actions.FORGETPASSWORD_REQUEST:
            return {
                ...state,
                isLoading: true,
                isSuccess: false,
                isError: false,
                resetCount: state.resetCount + 1
            };
        case actions.FORGETPASSWORD_SUCCESS:
            return {
                ...state,
                isLoading: false,
                isSuccess: true,
                isError: false,
                data: action.payload
            };

        case actions.FORGETPASSWORD_ERROR:
            return {
                ...state,
                isLoading: false,
                isSuccess: false,
                isError: true,
                data: action.payload,
                resetCount: resetCount + 1
            };

        default:
            return state;
    }
};

export default forgetPassword;
