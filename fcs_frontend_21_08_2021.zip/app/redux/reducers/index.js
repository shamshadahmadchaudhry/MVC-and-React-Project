import { combineReducers } from "redux";
import loginReducer from "./loginReducer";
import forgetPasswordReducer from "./forgetPassword";
import resetPasswordReducer from "./resetPassword";
import productReducer from "./product";
import changePasswordReducer from "./changePassword";
import profileReducer from "./profile";
import CompanyListingReducer from "./companyListing";
import CompanyListingUpdateReducer from "./companyListingUpdate";
import userData from './userData';
import UpdateProfile from './updateProfile';
import CompanyUsersReducer from './companyUsers';
import CreateCompanyUserReducer from './createCompanyUser';
import CompanyUsersUpdateReducer from './companyUsersUpdate';
import RolesReducer from './roles';
import ResendIvMailReducer from './resendIvMail';
import CancelIvMailReducer from './cancelIvMail';
import userRolesReducer from './userRoles';
import CompanyAddressReducer from './companyAddress';
import AddBuildingReducer from './addBuilding'
import StateListReducer from "./stateList";
import TokenCheckReducer from './tokenCheck';

const rootReducer = combineReducers({
  LoginStatus: loginReducer,
  ForgetPasswordStatus: forgetPasswordReducer,
  ResetPasswordStatus: resetPasswordReducer,
  ChangePasswordStatus: changePasswordReducer,
  ProductStatus: productReducer,
  ProfileStatus: profileReducer,
  CompanyListingStatus: CompanyListingReducer,
  CompanyListingUpdateStatus: CompanyListingUpdateReducer,
  userData: userData,
  UpdateProfile: UpdateProfile,
  CompanyUsersStatus: CompanyUsersReducer,
  CreateCompanyUserStatus: CreateCompanyUserReducer,
  CompanyUsersUpdateStatus: CompanyUsersUpdateReducer,
  RolesStatus: RolesReducer,
  ResendIvMailStatus: ResendIvMailReducer,
  CancelIvMailStatus: CancelIvMailReducer,
  UserRolesStatus: userRolesReducer,
  CompanyAddressStatus: CompanyAddressReducer,
  AddBuilding: AddBuildingReducer,
  stateList: StateListReducer,
  TokenCheckStatus:TokenCheckReducer
})

export default rootReducer
