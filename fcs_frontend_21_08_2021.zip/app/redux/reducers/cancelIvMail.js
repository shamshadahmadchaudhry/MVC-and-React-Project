import * as actions from "../actionTypes";

const initialState = {
  isLoading: false,
  isSuccess: false,
  isError: false
};

const cancelIvMail = (state = initialState, action) => {
  switch (action.type) {
    case actions.CANCELIVMAIL_REQUEST:
      return {
        ...state,
        isLoading: true,
        isSuccess: false,
        isError: false
      };
    case actions.CANCELIVMAIL_SUCCESS:
      return {
        ...state,
        isLoading: false,
        isSuccess: true,
        isError: false,
        result: action.payload,
      };

    case actions.CANCELIVMAIL_ERROR:
      return {
        ...state,
        isLoading: false,
        isSuccess: false,
        isError: true,
        result: action.payload,
      };

    default:
      return state;
  }
};

export default cancelIvMail;