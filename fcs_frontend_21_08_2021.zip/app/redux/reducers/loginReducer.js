import * as actions from "../actionTypes";

const initialState = {
  isLoading: false,
  isSuccess: false,
  isError: false,
  loggedIn: localStorage.getItem('token') ? true : false
};

const loginReducer = (state = initialState, action) => {
  switch (action.type) {
    case actions.LOGIN_REQUEST:
      return {
        ...state,
        isLoading: true,
        isSuccess: false,
        isError: false
      };
    case actions.LOGIN_SUCCESS:
      return {
        ...state,
        isLoading: false,
        isSuccess: true,
        isError: false,
        loggedIn: true,
        result: action.payload,
      };

    case actions.LOGIN_ERROR:
      return {
        ...state,
        isLoading: false,
        isSuccess: false,
        isError: true,
        loggedIn: false,
        result: action.payload,
      };
    case actions.LOGIN_CLEAN:
      return {
        isLoading: false,
        isSuccess: false,
        isError: false
      };

    case actions.LOGOUT_SUCCESS:
      return {
        isLoading: false,
        isSuccess: false,
        isError: false,
        loggedIn: false
      }

    case actions.LOGOUT_REQUEST:
      return {
        ...state,
        isLoading: true,
        isSuccess: false
      }
    case actions.LOGIN_CAPTCHA:
      return {
        ...state,
        isCaptcha: false
      }
    default:
      return state;
  }
};

export default loginReducer;
