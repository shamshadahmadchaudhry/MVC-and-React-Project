import { create } from "lodash";
import { createContext } from "react";
import { createAction, createActions } from "redux-actions";
import * as actions from "../actionTypes";

export const LoginRequest = createAction(actions.LOGIN_REQUEST);
export const LoginSuccess = createAction(actions.LOGIN_SUCCESS);
export const LoginError = createAction(actions.LOGIN_ERROR);
export const LoginClean = createAction(actions.LOGIN_CLEAN);

export const ForgetPasswordRequest = createAction(actions.FORGETPASSWORD_REQUEST);
export const ForgetPasswordSuccess = createAction(actions.FORGETPASSWORD_SUCCESS);
export const ForgetPasswordError = createAction(actions.FORGETPASSWORD_ERROR);

export const ResetPasswordRequest = createAction(actions.RESETPASSWORD_REQUEST);
export const ResetPasswordSuccess = createAction(actions.RESETPASSWORD_SUCCESS);
export const ResetPasswordError = createAction(actions.RESETPASSWORD_ERROR);
export const ResetPasswordClean = createAction(actions.RESETPASSWORD_CLEAN);

export const ChangePasswordRequest = createAction(actions.CHANGEPASSWORD_REQUEST);
export const ChangePasswordSuccess = createAction(actions.CHANGEPASSWORD_SUCCESS);
export const ChangePasswordError = createAction(actions.CHANGEPASSWORD_ERROR);

export const ProfileRequest = createAction(actions.PROFILE_REQUEST);
export const ProfileSuccess = createAction(actions.PROFILE_SUCCESS);
export const ProfileError = createAction(actions.PROFILE_ERROR);

export const ProductRequest = createAction(actions.PRODUCT_REQUEST);
export const ProductSuccess = createAction(actions.PRODUCT_SUCCESS);
export const ProductError = createAction(actions.PRODUCT_ERROR);

export const UserProfileRequest = createAction(actions.USER_PROFILE_REQUEST);
export const UserProfileSuccess = createAction(actions.USER_PROFILE_SUCCESS);
export const UserProfileError = createAction(actions.USER_PROFILE_ERROR);

export const CompanyListingRequest = createAction(actions.COMPANYLISTING_REQUEST);
export const CompanyListingSuccess = createAction(actions.COMPANYLISTING_SUCCESS);
export const CompanyListingError = createAction(actions.COMPANYLISTING_ERROR);

export const CompanyUsersRequest = createAction(actions.COMPANYUSERS_REQUEST);
export const CompanyUsersSuccess = createAction(actions.COMPANYUSERS_SUCCESS);
export const CompanyUsersError = createAction(actions.COMPANYUSERS_ERROR);

export const CompanyListingUpdateRequest = createAction(actions.COMPANYLISTING_UPDATE_REQUEST);
export const CompanyListingUpdateSuccess = createAction(actions.COMPANYLISTING_UPDATE_SUCCESS);
export const CompanyListingUpdateError = createAction(actions.COMPANYLISTING_UPDATE_ERROR);

export const CompanyUsersUpdateRequest = createAction(actions.COMPANYUSERS_UPDATE_REQUEST);
export const CompanyUsersUpdateSuccess = createAction(actions.COMPANYUSERS_UPDATE_SUCCESS);
export const CompanyUsersUpdateError = createAction(actions.COMPANYUSERS_UPDATE_ERROR);

export const UserDataRequest = createAction(actions.USER_DATA_REQUEST);
export const UserDataSuccess = createAction(actions.USER_DATA_SUCCESS);
export const UserDataError = createAction(actions.USER_DATA_ERROR);

export const LogoutRequest = createAction(actions.LOGOUT_REQUEST);
export const LogoutSuccess = createAction(actions.LOGOUT_SUCCESS);
export const LogoutError = createAction(actions.LOGOUT_ERROR);
export const LoginCaptcha = createAction(actions.LOGIN_CAPTCHA);

export const UpdateProfileRequest = createAction(actions.UPDATE_PROFILE_REQUEST);
export const UpdateProfileSuccess = createAction(actions.UPDATE_PROFILE_SUCCESS);
export const UpdateProfileError = createAction(actions.UPDATE_PROFILE_ERROR);

export const UpdateImageRequest = createAction(actions.UPDATE_IMAGE_REQUEST);
export const UpdateImageSuccess = createAction(actions.UPDATE_IMAGE_SUCCESS);
export const UpdateImageError = createAction(actions.UPDATE_IMAGE_ERROR);

export const CreateCompanyUserRequest = createAction(actions.CREATE_COMPANY_USER_REQUEST);
export const CreateCompanyUserSuccess = createAction(actions.CREATE_COMPANY_USER_SUCCESS);
export const CreateCompanyUserError = createAction(actions.CREATE_COMPANY_USER_ERROR);

export const RolesRequest = createAction(actions.ROLES_REQUEST);
export const RolesSuccess = createAction(actions.ROLES_SUCCESS);
export const RolesError = createAction(actions.ROLES_ERROR);

export const UserRolesRequest = createAction(actions.USER_ROLES_REQUEST);
export const UserRolesSuccess = createAction(actions.USER_ROLES_SUCCESS);
export const UserRolesError = createAction(actions.USER_ROLES_ERROR);

export const ResendIvMailRequest = createAction(actions.RESENDIVMAIL_REQUEST);
export const ResendIvMailSuccess = createAction(actions.RESENDIVMAIL_SUCCESS);
export const ResendIvMailError = createAction(actions.RESENDIVMAIL_ERROR);

export const CompanyAddressRequest = createAction(actions.COMPANYADDRESS_REQUEST);
export const CompanyAddressSuccess = createAction(actions.COMPANYADDRESS_SUCCESS);
export const CompanyAddressError = createAction(actions.COMPANYADDRESS_ERROR);


export const CancelIvMailRequest = createAction(actions.CANCELIVMAIL_REQUEST);
export const CancelIvMailSuccess = createAction(actions.CANCELIVMAIL_SUCCESS);
export const CancelIvMailError = createAction(actions.CANCELIVMAIL_ERROR);

export const AddBuildingRequest = createAction(actions.ADD_BUILDING_REQUEST);
export const AddBuildingSuccess = createAction(actions.ADD_BUILDING_SUCCESS);


export const StateListRequest = createAction(actions.STATE_LIST_REQUEST);
export const StateListSuccess = createAction(actions.STATE_LIST_SUCCESS);
export const StateListError = createAction(actions.STATE_LIST_ERROR);


export const TokenCheckRequest = createAction(actions.TOKEN_CHECK_REQUEST);
export const TokenCheckSuccess = createAction(actions.TOKEN_CHECK_SUCCESS);
export const TokenCheckError = createAction(actions.TOKEN_CHECK_ERROR);

















