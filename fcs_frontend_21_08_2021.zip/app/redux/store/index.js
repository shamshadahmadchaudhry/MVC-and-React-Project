import { createStore, applyMiddleware } from "redux";
import createSagaMiddleware from "redux-saga";
import rootReducer from "../reducers";
import rootSaga from "../saga/index";
import { createLogger } from "redux-logger";
const middleWares = [];

import { composeWithDevTools } from "redux-devtools-extension";

const logger = createLogger({
  predicate: () => process.env.NODE_ENV === 'development',
  collapsed: true
});

const sagaMiddleware = createSagaMiddleware();

middleWares.push(sagaMiddleware);
middleWares.push(logger);
const store = createStore(rootReducer, composeWithDevTools(applyMiddleware(...middleWares)));
sagaMiddleware.run(rootSaga);

export default store;


// import { createStore, applyMiddleware } from "redux";
// import createSagaMiddleware from "redux-saga";
// import combineReducers from "./Reducers/rootReducer";
// import { createLogger } from "redux-logger";
// import rootSaga from "./Saga/rootSaga";
// const middleWares = [];
// const sagaMiddleWare = createSagaMiddleware();
// const logger = createLogger({
//   predicate: () => process.env.NODE_ENV === 'development',
//   collapsed: true
// });
// middleWares.push(sagaMiddleWare);
// middleWares.push(logger);
// const store = createStore(combineReducers, applyMiddleware(...middleWares));
// export default store;
// sagaMiddleWare.run(rootSaga);