import { call, put, takeLatest } from "redux-saga/effects";
import { TokenCheckError, TokenCheckSuccess, TokenCheckSuccess } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* TokenCheckSaga(action){
  try {
    const response = yield call(
      axiosCall,
      "POST",
      `api/tokenCheck`,
      action.payload,
    );

    if (response) {
      yield put(TokenCheckSuccess({  response : response.data}));
    } else {
      yield put(TokenCheckError({ error: "Error fetching Token" }));
    }
  } catch (error) {
    yield put(TokenCheckError({ error: "Error fetching Token" }));
  }
}
export function* TokenCheckRequest(){
  yield takeLatest(actions.TOKEN_CHECK_REQUEST, TokenCheckSaga);
}