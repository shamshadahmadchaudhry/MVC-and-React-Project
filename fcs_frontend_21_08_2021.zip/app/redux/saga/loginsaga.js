import { call, put, takeLatest } from "redux-saga/effects";
import { LoginSuccess, LoginError, UserDataRequest, LogoutError } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* loginSaga(action) {
  try {
    console.log('payloads ', action.payload)
    const response = yield call(
      axiosCall,
      "POST",
      `/api/login`,
      action.payload,
    );
    if (response) {
      if (response.data.error) {
        yield put(LoginError(response.data));
      } else {
        localStorage.setItem('token', response.data.token)
        const result = response.data.result
        yield put(LoginSuccess({ response: response.data }));
        yield put(UserDataRequest())
      }
    } else {
      yield put(LoginError({ error: "Invalid  details" }));
    }
  } catch (error) {
    yield put(LoginError({ error: "Invalid  details" }));
  }
}

export function* loginRequest() {
  yield takeLatest(actions.LOGIN_REQUEST, loginSaga);
}

