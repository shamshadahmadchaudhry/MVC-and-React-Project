import { call, put, takeLatest } from "redux-saga/effects";
import { CompanyUsersSuccess, CompanyUsersError } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* __saga(action) {
  try {
    const response = yield call(
      axiosCall,
      "GET",
      `/api/companyusers?company_id=${action.payload.company_id}&user_type_id=${action.payload.user_type_id}`,
      action.payload.company_id
    );

    if (response) {
      yield put(CompanyUsersSuccess({ response: response.data }));
    } else {
      yield put(CompanyUsersError({ error: "Error getting Users" }));
    }
  } catch (error) {
    yield put(CompanyUsersError({ error: "Error fetching users" }));
  }
}
export function* companyUsersRequest(action) {
  yield takeLatest(actions.COMPANYUSERS_REQUEST, __saga);
}