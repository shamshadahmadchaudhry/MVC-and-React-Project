import { call, put, takeLatest } from "redux-saga/effects";
import { CompanyListingUpdateSuccess, CompanyListingUpdateError } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* _saga(action) {
  console.log("ACTION: ", action);
  try {
    const response = yield call(
      axiosCall,
      "PUT",
      `/api/user_company`,
      action.payload,
    );
    if (response) {
      yield put(CompanyListingUpdateSuccess({ response: response.data }));
    } else {
      yield put(CompanyListingUpdateError({ error: "Invalid  details" }));
    }
  } catch (error) {
    yield put(CompanyListingUpdateError({ error: "Invalid  details" }));

  }
}

export function* companyListingUpdateRequest() {
  yield takeLatest(actions.COMPANYLISTING_UPDATE_REQUEST, _saga);
}

