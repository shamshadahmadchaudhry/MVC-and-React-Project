import * as actions from "../actionTypes";
import { UserProfileSuccess, UserProfileError } from "../actions";
import { put, call, takeLatest } from "redux-saga/effects";
import axios from "../../Utils/axios";

export function* userProfileSaga(action) {
    const payload = action.payload
    try {
        const response = yield call(axios.post("/app/login", payload));
        let data = response.data;
        if (data.status === 1) {
            yield put(UserProfileSuccess({ response: data }));
        } else {
            yield put(UserProfileError());
        }
    } catch (error) {
        yield put(UserProfileError());
    }
}

export function* userProfileRequest() {
    yield takeLatest(actions.USER_PROFILE_REQUEST, userProfileSaga);
}
