import { call, put, takeLatest } from "redux-saga/effects";
import { ResendIvMailSuccess, ResendIvMailError } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* _saga(action) {
  try {
    const response = yield call(
      axiosCall,
      "POST",
      `/api/resendivmail`,
      action.payload,
    );
    console.log('TRAILS:: ',action);
    if (response) {
      yield put(ResendIvMailSuccess({  response : response.data}));
    } else {
      yield put(ResendIvMailError({ error: "Error Resending verification email" }));
    }
  } catch (error) {
    console.log("ERRRR");
    yield put(ResendIvMailError({ error: "Error Resending Email" }));

  }
}

export function* resendIvMailRequest() {
  yield takeLatest(actions.RESENDIVMAIL_REQUEST, _saga);
}