import { put, takeLatest } from "redux-saga/effects";
import * as actions from "../actionTypes";
import { AddBuildingSuccess } from '../actions/index'

export function* _addBuilding(action) {
    try {
        const buildingData = JSON.parse(localStorage.getItem('buildings'));
        yield put(AddBuildingSuccess(buildingData))
    } catch (error) {

    }
}

export function* addBuilding() {
    yield takeLatest(actions.ADD_BUILDING_REQUEST, _addBuilding);
}