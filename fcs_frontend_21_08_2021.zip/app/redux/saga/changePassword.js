import * as actions from "../actionTypes";
import { ChangePasswordSuccess, ChangePasswordError } from "../actions";
import { put, call, takeLatest } from "redux-saga/effects";
import axiosCall from "../../services";

export function* changePasswordSaga(action) {
  try {
    console.log(action.payload, "lllllllllllllllllllllllll");
    const response = yield call(
      axiosCall,
      "POST",
      `/api/changepassword`,
      action.payload,
    );
    if (response) {
      let data = response.data;
      yield put(ChangePasswordSuccess({ response: data }));
    } else {
      yield put(ChangePasswordError());
    }
  } catch (error) {
    console.log(error, "lllllllllllllllllllllllllll");
    yield put(ChangePasswordError());
  }
}

export function* changePasswordRequest() {
  yield takeLatest(actions.CHANGEPASSWORD_REQUEST, changePasswordSaga);
}
