import { call, put, takeLatest } from "redux-saga/effects";
import { CreateCompanyUserSuccess, CreateCompanyUserError, CreateCompanyUserRequest } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* createCompanyUserSaga(action) {
  try {
    const response = yield call(
      axiosCall,
      "POST",
      `/api/inviteuser`,
      action.payload
    );

    if (response) {
      console.log('Create user response',response)
      yield put(CreateCompanyUserSuccess({ response: response.data }));
    } else {
      yield put(CreateCompanyUserError({ error: "Error Inviting User" }));
    }
  } catch (error) {
    console.log('errrr::', error)
    yield put(CreateCompanyUserError({ error: "Error Inviting User" }));
  }
}
export function* createCompanyUserRequest() {
  yield takeLatest(actions.CREATE_COMPANY_USER_REQUEST, createCompanyUserSaga);
}