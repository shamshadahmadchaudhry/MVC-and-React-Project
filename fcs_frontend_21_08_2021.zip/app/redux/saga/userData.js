import * as actions from "../actionTypes";
import { UserDataSuccess, UserDataError } from "../actions";
import { put, call, takeLatest } from "redux-saga/effects";
import axiosCall from "../../services";

export function* userDataSaga(action) {
    try {
        const response = yield call(
            axiosCall,
            "GET",
            `/api/userprofile`,
            {},
        );
        if (response) {
            console.log('user data',response)
            yield put(UserDataSuccess({ response: response.data }));
        } else {
            console.log('GOTTTT YOUU',response)
            yield put(UserDataError({ error: "Invalid  details",status:401 }));
        }
    } catch (error) {
        console.log('ERROR FETCHING',error)
        yield put(UserDataError({ error: "Invalid  details",status:401 }));
    }
}

export function* userDataRequest() {
    yield takeLatest(actions.USER_DATA_REQUEST, userDataSaga);
}
