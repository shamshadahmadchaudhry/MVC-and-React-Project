import { call, put, takeLatest } from "redux-saga/effects";
import { UserRolesSuccess, UserRolesError } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* UserRolesRequestSaga(action){
  try {
    const response = yield call(
      axiosCall,
      "POST",
      `/api/userroles`,
      action.payload,
    );

    if (response) {
      yield put(UserRolesSuccess({  response : response.data}));
    } else {
      yield put(UserRolesError({ error: "Error fetching UserRoles" }));
    }
  } catch (error) {
    yield put(UserRolesError({ error: "Error fetching UserRoles" }));
  }
}
export function* UserRolesRequest(){
  yield takeLatest(actions.USER_ROLES_REQUEST, UserRolesRequestSaga);
}