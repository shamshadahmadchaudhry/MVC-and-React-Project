import { fork, all } from "redux-saga/effects";
import { loginRequest } from "./loginsaga";
import { forgetPasswordRequest } from "./forgetPassword";
import { resetPasswordRequest } from "./resetPassword";
import { changePasswordRequest } from "./changePassword";
import { profileRequest } from "./profile";
import { companyListingRequest } from "./comapnyListing";
import { companyListingUpdateRequest } from "./companyListingUpdate";
import { userDataRequest } from './userData';
import { logoutRequestSaga } from './logout';
import { companyUsersRequest } from './companyUsers';
import { companyUsersUpdateRequest } from './companyUsersUpdate';
import { createCompanyUserRequest } from './createCompanyUser';
import { RolesRequest } from './roles';
import { resendIvMailRequest } from "./resendIvMail";
import { UserRolesRequest } from "./userRoles";
import { CompanyAddressRequest } from './companyAddress';
import { CancelIvMailRequest } from './cancelIvMail';
import { addBuilding } from './addBuildingSaga';
import { stateListRequest } from "./stateListSaga";

function* rootSaga() {
  {
    yield all([
      fork(loginRequest),
      fork(forgetPasswordRequest),
      fork(profileRequest),
      fork(resetPasswordRequest),
      fork(changePasswordRequest),
      fork(companyListingRequest),
      fork(companyListingUpdateRequest),
      fork(userDataRequest),
      fork(logoutRequestSaga),
      fork(companyUsersRequest),
      fork(createCompanyUserRequest),
      fork(companyUsersUpdateRequest),
      fork(RolesRequest),
      fork(resendIvMailRequest),
      fork(UserRolesRequest),
      fork(CancelIvMailRequest),
      fork(CompanyAddressRequest),
      fork(addBuilding),
      fork(stateListRequest)
    ]);
    // yield all([fork(forgetPasswordRequest)]);
    // yield all([fork(resetPasswordRequest)]);
    // yield all([fork(changePasswordRequest)]);
    // yield all([fork(profileRequest)]);
  }
}

export default rootSaga;
