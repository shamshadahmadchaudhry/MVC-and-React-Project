import * as actions from "../actionTypes";
import { StateListSuccess, StateListError } from "../actions";
import { put, call, takeLatest } from "redux-saga/effects";
import axiosCall from "../../services";

export function* stateListSaga() {
    try {

        const response = yield call(
            axiosCall,
            "GET",
            `/api/state?country_master_id=1`,
            {},
        );
        if (response) {
            yield put(StateListSuccess({ response: response.data }));
        } else {
            yield put(StateListError({ error: "Invalid  details" }));
        }
    } catch (error) {
        yield put(StateListError({ error: "Invalid  details" }));
    }
}

export function* stateListRequest() {
    yield takeLatest(actions.STATE_LIST_REQUEST, stateListSaga);
}
