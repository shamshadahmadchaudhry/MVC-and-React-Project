import { call, put, takeLatest } from "redux-saga/effects";
import { ForgetPasswordSuccess, ForgetPasswordError } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* forgetPasswordSaga(action) {
  try {
    const response = yield call(
      axiosCall,
      "POST",
      `/api/forgotpassword`,
      action.payload,
    );
    if (response) {
      yield put(ForgetPasswordSuccess({ response: response }));
    } else {
      yield put(ForgetPasswordError({ error: "Invalid  details" }));
    }
  } catch (error) {
    yield put(ForgetPasswordError({ error: "Invalid  details" }));

  }
}

export function* forgetPasswordRequest() {
  yield takeLatest(actions.FORGETPASSWORD_REQUEST, forgetPasswordSaga);
}