import * as actions from "../actionTypes";
import { ProductSuccess, ProductError } from "../actions";
import { put, call, takeLatest } from "redux-saga/effects";
import axios from "../../Utils/axios";

export function* productSaga(action) {
  const payload = action.payload
  try {
    const response = yield call(axios.post("/app/login", payload));
    let data = response.data;
    if (data.status === 1) {
      yield put(ProductSuccess({ response: data }));
    } else {
      yield put(ProductError());
    }
  } catch (error) {
    yield put(ProductError());
  }
}

export function* productRequest() {
  yield takeLatest(actions.RESETPASSWORD_REQUEST, productSaga);
}
