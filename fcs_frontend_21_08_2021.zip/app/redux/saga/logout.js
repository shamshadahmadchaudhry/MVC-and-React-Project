import * as actions from "../actionTypes";
import { LogoutSuccess, LogoutError } from "../actions";
import { put, call, takeLatest } from "redux-saga/effects";
import axiosCall from "../../services";
const publicIp = require("react-public-ip");


const getClientMachineDetails = async () => {
    const clientMachineDetails = {
        ip_address: await publicIp.v4() || "",
    }
    return clientMachineDetails;

} 
export function* logoutSaga(action) {
    try {
        let payload = yield call(getClientMachineDetails)

        const response = yield call(
            axiosCall,
            "POST",
            `/api/logout`,
            payload,
        );
        if (response) {
            localStorage.clear();
            window.location = "/"
            yield put(LogoutSuccess({ response: response.data }));
        } else {
            yield put(LogoutError({ error: "Invalid  details" }));
        }
    } catch (error) {
        yield put(LogoutError({ error: "Invalid  details" }));
    }
}

export function* logoutRequestSaga() {
    yield takeLatest(actions.LOGOUT_REQUEST, logoutSaga);
}
