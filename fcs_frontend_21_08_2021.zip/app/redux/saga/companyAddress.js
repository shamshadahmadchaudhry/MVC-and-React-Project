import { call, put, takeLatest } from "redux-saga/effects";
import { CompanyAddressSuccess, CompanyAddressError } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* __saga(action) {
  try {
    const response = yield call(
      axiosCall,
      "POST",
      `/api/companyaddress`,
      action.payload
    );

    if (response) {
      yield put(CompanyAddressSuccess({ response: response.data }));
    } else {
      yield put(CompanyAddressError({ error: "Error Fetching Address" }));
    }
  } catch (error) {
    yield put(CompanyAddressError({ error: "Error fetching Address" }));
  }
}
export function* CompanyAddressRequest(action) {
  yield takeLatest(actions.COMPANYADDRESS_REQUEST, __saga);
}