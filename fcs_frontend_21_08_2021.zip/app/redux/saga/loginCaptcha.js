import { call, put, takeLatest } from "redux-saga/effects";
import { LoginCaptcha } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* loginCpatchaSaga(action) {
    try {
        yield put(LoginCaptcha({ isCaptcha: false }))
    } catch (error) {
        //yield put(LoginError({ error: "Invalid  details" }));
    }
}

export function* captchaRequest() {
    yield takeLatest(actions.LOGIN_CAPTCHA, loginCpatchaSaga);
}

