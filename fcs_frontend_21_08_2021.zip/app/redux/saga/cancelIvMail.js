import { call, put, takeLatest } from "redux-saga/effects";
import { CancelIvMailSuccess, CancelIvMailError } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* _cancelIvMailsaga(action) {
  try {
    const response = yield call(
      axiosCall,
      "POST",
      `/api/cancelivmail`,
      action.payload,
    );
    if (response) {
      yield put(CancelIvMailSuccess({ response: response.data }));
    } else {
      yield put(CancelIvMailError({ error: "Error Resending verification email" }));
    }
  } catch (error) {
    yield put(CancelIvMailError({ error: "Error Canceling Email" }));

  }
}

export function* CancelIvMailRequest() {
  yield takeLatest(actions.CANCELIVMAIL_REQUEST, _cancelIvMailsaga);
}