import { call, put, takeLatest } from "redux-saga/effects";
import {
  ProfileSuccess, ProfileError, UpdateProfileSuccess,
  UpdateProfileError, ProfileRequest, UpdateImageError, UpdateImageSuccess, UserDataRequest
} from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* profileSaga(action) {
  try {
    const response = yield call(
      axiosCall,
      "GET",
      `/api/userprofile`,
      action.payload,
    );
    if (response) {
      yield put(ProfileSuccess({ response: response?.data?.data }));
    } else {
      yield put(ProfileError({ error: "Invalid  details" }));
    }
  } catch (error) {
    yield put(ProfileError({ error: "Invalid  details" }));
  }
}


export function* updateProfileSaga(action) {
  try {
    const response = yield call(
      axiosCall,
      "PUT",
      `/api/userprofile?id=${action.payload.user_master_id}`,
      action.payload,
    );
    if (response) {
      yield put(UpdateProfileSuccess({ response: response?.data?.data }));
      yield put(ProfileRequest());
      yield put(UserDataRequest());
    } else {
      yield put(UpdateProfileError({ error: "Invalid  details" }));
    }
  } catch (error) {
    yield put(UpdateProfileError({ error: "Invalid  details" }));
  }
}

export function* updateImageSaga(action) {
  try {
    console.log("Action payload form_data=>", action.payload.form_data)
    const response = yield call(
      axiosCall,
      "PUT",
      `/api/updateimage?id=${action.payload.user_master_id}`,
      action.payload.form_data,
    );
    if (response) {
      yield put(UpdateProfileSuccess({ response: response?.data?.data }));
      yield put(ProfileRequest());
      yield put(UserDataRequest());
    } else {
      yield put(UpdateProfileError({ error: "Invalid  details" }));
    }
  } catch (error) {
    yield put(UpdateProfileError({ error: "Invalid  details" }));
  }
}

export function* profileRequest() {
  yield takeLatest(actions.PROFILE_REQUEST, profileSaga);
  yield takeLatest(actions.UPDATE_PROFILE_REQUEST, updateProfileSaga);
  yield takeLatest(actions.UPDATE_IMAGE_REQUEST, updateImageSaga);
}