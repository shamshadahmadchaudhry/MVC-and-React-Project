import { call, put, takeLatest } from "redux-saga/effects";
import { ResetPasswordSuccess, ResetPasswordError } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* resetPasswordSaga(action) {
  try {
    const response = yield call(
      axiosCall,
      "POST",
      `/api/resetpassword`,
      action.payload,
    );
    if (!response.data.error) {
      yield put(ResetPasswordSuccess({ response: response.data }));
    } else {
      yield put(ResetPasswordError({ error: response.data }));
    }
  } catch (error) {
    yield put(ResetPasswordError({ error: "Invalid  details" }));

  }
}


export function* resetPasswordRequest() {
  yield takeLatest(actions.RESETPASSWORD_REQUEST, resetPasswordSaga);
}
