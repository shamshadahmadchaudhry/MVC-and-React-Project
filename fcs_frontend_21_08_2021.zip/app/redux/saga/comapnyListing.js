import { call, put, takeLatest } from "redux-saga/effects";
import { CompanyListingSuccess, CompanyListingError } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* _saga(action) {
  try {
    console.log(action.payload);
    const response = yield call(
      axiosCall,
      "GET",
      `/api/user_company`,
      {},
    );

    if (response) {
      yield put(CompanyListingSuccess({ response: response.data }));
    } else {
      yield put(CompanyListingError({ error: "Invalid  details" }));
    }
  } catch (error) {
    yield put(CompanyListingError({ error: "Invalid  details" }));

  }
}

export function* companyListingRequest() {
  yield takeLatest(actions.COMPANYLISTING_REQUEST, _saga);
}
