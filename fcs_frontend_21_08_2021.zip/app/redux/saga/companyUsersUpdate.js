import { call, put, takeLatest } from "redux-saga/effects";
import { CompanyUsersUpdateSuccess, CompanyUsersUpdateError } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"

export function* _saga(action) {
  try {
    console.log("test =>", payload);
    const response = yield call(
      axiosCall,
      "PUT",
      `/api/updateuser/`,
      action.payload,
    );

    if (response) {
      yield put(CompanyUsersUpdateSuccess({ response: response.data }));
    } else {
      yield put(CompanyUsersUpdateError({ error: "Error updating user" }));
    }
  } catch (error) {
    yield put(CompanyUsersUpdateError({ error: "Error updating user" }));

  }
}

export function* companyUsersUpdateRequest() {
  yield takeLatest(actions.COMPANYUSERS_UPDATE_REQUEST, _saga);
}