import { call, put, takeLatest } from "redux-saga/effects";
import { RolesSuccess, RolesError } from '../actions/index';
import axiosCall from "../../services";
import * as actions from "../actionTypes"


export function* RolesRequestSaga(action) {
  try {
    const response = yield call(
      axiosCall,
      "GET",
      `/api/rolesbyuser?user_type_id=${action.payload.user_type_id}`,
      action.payload,
    );

    if (response) {
      yield put(RolesSuccess({ response: response.data }));
    } else {
      yield put(RolesError({ error: "Error fetching Roles" }));
    }
  } catch (error) {
    yield put(RolesError({ error: "Error fetching Roles" }));
  }
}
export function* RolesRequest(action) {
  yield takeLatest(actions.ROLES_REQUEST, RolesRequestSaga);
}