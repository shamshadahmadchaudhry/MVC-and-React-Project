import Axios from 'axios';
import { CONFIG } from '../config/index';

export {
    CompanyProfileTheme, addCompanyTheme, getUnitofMeasures, UpdateUnitofMeasures, UserCompanyProfile
}

//=================== This method is used for get company profile ====================
const CompanyProfileTheme = async (company_id, user_type_id) => {
    console.log('CompanyProfileTheme', company_id)
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        console.log(`${CONFIG.BASE_URL}/api/companyprofile?company_id=${company_id}&user_type_id=${user_type_id}`);
        const result = await Axios.get(`${CONFIG.BASE_URL}/api/companyprofile?company_id=${company_id}&user_type_id=${user_type_id}`, config);
        return result;
    } catch (err) {
        console.log('Error in company profile service method getCompanyProfileTheme() ', err)
    }
}

//=================== This method is used for add company theme ====================
const addCompanyTheme = async (body) => {
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.post(`${CONFIG.BASE_URL}/api/companyprofile`, body, config);
        return result;
    } catch (err) {
        console.log('Error in company profile service method addCompanyTheme() ', err)
    }
}

//=================== This method is used for unit of measures ====================
const getUnitofMeasures = async (company_id, user_type_id) => {
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.get(`${CONFIG.BASE_URL}/api/unitofmeasures?company_id=${company_id}&user_type_id=${user_type_id}`, config);
        return result;
    } catch (err) {
        console.log('Error in company profile service method getUnitofMeasures() ', err)
    }
}

//=================== This method is used for update unit of measures ====================
const UpdateUnitofMeasures = async (body) => {
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.put(`${CONFIG.BASE_URL}/api/unitofmeasures`, body, config);
        return result;
    } catch (err) {
        console.log('Error in company profile service method UpdateUnitofMeasures() ', err)
    }
}

//=================== This method is used for get user company profile ====================
const UserCompanyProfile = async (company_id, user_type_id) => {
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.get(`${CONFIG.BASE_URL}/api/usercompanyprofile?company_id=${company_id}&user_type_id=${user_type_id}`, config);
        console.log('result', result)
        return result;
    } catch (err) {
        console.log('Error in company profile service method UserCompanyProfile() ', err)
    }
}
