import Axios from 'axios';
import { CONFIG } from '../config/index';
import { Configuration } from '../routes/commoncomponents/configurationfile';

export {
    addContainer, updateContainer, deleteContainer, fetchContainerName, checkContainerName
}


const addContainer = async (body, container_type) => {
    console.log('warehouse_location_id', body.warehouse_location_id)
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.post(`${CONFIG.BASE_URL}/api/warehousestoragecontainer?container_type=${container_type}`, body, config);
        return result;
    } catch (err) {
        console.log('Error in warehouse management service method addTote() ', err)
    }
}

const updateContainer = async (body, container_type) => {
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.put(`${CONFIG.BASE_URL}/api/warehousestoragecontainer?container_type=${container_type}`, body, config);
        return result;
    } catch (err) {
        console.log('Error in warehouse management service method updateTote() ', err)
    }
}

const deleteContainer = async (container_type, container_id, created_by) => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.delete(`${CONFIG.BASE_URL}/api/warehousestoragecontainer?container_type=${container_type}&container_id=${container_id}&created_by=${created_by}`, config);
        return result;
    } catch (err) {
        console.log('Error in warehouse management service method deleteTote() ', err)
    }
}

const fetchContainerName = async (container_type, company_id, no_of_record, warehouse_location_id, addressId, storage_unit_id) => {

    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        let result;
        if (container_type === Configuration.entityType.location) {
            result = await Axios.get(`${CONFIG.BASE_URL}/api/prepopulatecontainer?container_type=${container_type}&company_id=${company_id}&no_of_record=${no_of_record}&warehouse_location_id=${warehouse_location_id}&warehouse_address_id=${addressId}&storage_unit_id=${storage_unit_id}`, config);
        } else {
            result = await Axios.get(`${CONFIG.BASE_URL}/api/prepopulatecontainer?container_type=${container_type}&company_id=${company_id}&no_of_record=${no_of_record}&warehouse_location_id=${warehouse_location_id}`, config);
        }

        return result;
    } catch (err) {
        console.log('Error in warehouse management service method deleteTote() ', err)
    }
}

const checkContainerName = async (container_type, company_id, warehouse_location_id, container_name) => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        console.log('container_type, company_id, warehouse_location_id, container_name', container_type, company_id, warehouse_location_id, container_name)
        const result = await Axios.get(`${CONFIG.BASE_URL}/api/validatecontainername?container_type=${container_type}&company_id=${company_id}&warehouse_location_id=${warehouse_location_id}&container_name=${container_name}`, config);
        return result;
    } catch (err) {
        console.log('Error in warehouse management service method checkContainerName() ', err)
    }
}
