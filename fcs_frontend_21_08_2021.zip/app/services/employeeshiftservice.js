import Axios from 'axios';
import { CONFIG } from '../config/index';

export {
    getAllUserShifts,
    updateUserShift,
}

/* get all user shifts with respect to both company and warehouse location */
const  getAllUserShifts = async (params) => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        return fetch(`${CONFIG.BASE_URL}/api/usershift${params}`, config)
            .then(response => response.json())
            .then((data) => {
                if (data.status === true) {
                    return {
                        data: data.data,
                        totalCount:data.totalCount
                    };
                }

                else
                {
                    console.log("something is fetched"+data.json()) ;  
                }
            })
            .catch(() => { throw 'Data Loading Error'; });
    } catch (err) {
        console.log('Error in shift management service getAllUserShifts()', err)
    }
}

/* update user shifts with respect to both company and warehouse location */
const updateUserShift = async (body) => {
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.put(`${CONFIG.BASE_URL}/api/usershift`, body, config);
        return result;
    } catch (err) {
        console.log('Error updating employee shift', err)
    }
}
