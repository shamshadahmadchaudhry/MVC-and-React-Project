import Axios from 'axios';
import { CONFIG } from '../config/index';

export {
    getLayoutTypes,
    getZoneList,
    getAisleList,
    addLayout,
    zoneTypes,
    addZone,
    updateZone,
    deleteZone,
    addAisle,
    updateAisle,
    deleteAisle,
    fetchLayoutName
}

const getLayoutTypes = async () => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.get(`${CONFIG.BASE_URL}/api/layoutlist`, config);
        return result.data.data;
    } catch (err) {
        console.log('Error fetching Layout types', err)
    }
}

/*Zone List */
const getZoneList = async (params) => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        return fetch(`${CONFIG.BASE_URL}/api/zonelayout${params}`, config)
            .then(response => response.json())
            .then((data) => {
                if (data.status === true) {
                    return {
                        data: data.data,
                        totalCount: data.totalCount,
                        summary: [5, 10, 20],
                        groupCount: 35
                    };
                } else {
                    return {
                        data: [],
                        totalCount: 0,
                        summary: [5, 10, 20],
                        groupCount: 30
                    };
                }
            })
            .catch((er) => { throw er });
    } catch (err) {
        console.log('Error fetching Zones', err)
    }
}

//Aisle List
const getAisleList = async (params) => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        return fetch(`${CONFIG.BASE_URL}/api/aislelayout${params}`, config)
            .then(response => response.json())
            .then((data) => {
                if (data.status === true) {
                    return {
                        data: data.data,
                        totalCount: data.totalCount,
                        summary: [5, 10, 20],
                        groupCount: 35
                    };
                } else {
                    return {
                        data: [],
                        totalCount: 0,
                        summary: [5, 10, 20],
                        groupCount: 30
                    };
                }
            })
            .catch((er) => { throw er });
    } catch (err) {
        console.log('Error fetching Zones', err)
    }
}

/*aDD LAYOUT */
const addLayout = async (body, layout_type) => {
    console.log('warehouse_location_id', body.warehouse_location_id)
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.post(`${CONFIG.BASE_URL}/api/warehousestoragecontainer?container_type=${layout_type}`, body, config);
        return result;
    } catch (err) {
        console.log('Error adding layout ', err)
    }
}


const addZone = async (body, container_type) => {
    console.log('warehouse_location_id', body.warehouse_location_id)
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.post(`${CONFIG.BASE_URL}/api/zonelayout?container_type=${container_type}`, body, config);
        return result;
    } catch (err) {
        console.log('Error adding zone ', err)
    }
}


const deleteZone = async (body) => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.delete(`${CONFIG.BASE_URL}/api/zonelayout?warehouse_zone_id=${body.warehouse_zone_id}`, config);
        return result;
    } catch (err) {
        console.log('Error deleting station', err)
    }
}


const updateZone = async (body) => {
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.put(`${CONFIG.BASE_URL}/api/zonelayout`, body, config);
        return result;
    } catch (err) {
        console.log('Error updating Station', err)
    }
}

const zoneTypes = async () => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.get(`${CONFIG.BASE_URL}/api/zonetypelist`, config);
        return result.data.data;
    } catch (err) {
        console.log('Error fetching station types', err)
    }
}

const addAisle = async (body, container_type) => {
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.post(`${CONFIG.BASE_URL}/api/aislelayout?container_type=${container_type}`, body, config);
        return result;
    } catch (err) {
        console.log('Error adding zone ', err)
    }
}


const deleteAisle = async (body) => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.delete(`${CONFIG.BASE_URL}/api/aislelayout?warehouse_aisle_id=${body.warehouse_aisle_id}`, config);
        return result;
    } catch (err) {
        console.log('Error deleting station', err)
    }
}


const updateAisle = async (body) => {
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.put(`${CONFIG.BASE_URL}/api/aislelayout`, body, config);
        return result;
    } catch (err) {
        console.log('Error updating Station', err)
    }
}

const fetchLayoutName = async (container_type, company_id, no_of_record, warehouse_location_id, warehouse_address_id, storage_unit_id) => {

    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.get(`${CONFIG.BASE_URL}/api/prepopulatecontainer?container_type=${container_type}&company_id=${company_id}&no_of_record=${no_of_record}&warehouse_location_id=${warehouse_location_id}&warehouse_address_id=${warehouse_address_id}&storage_unit_id=${storage_unit_id}`, config);
        return result;
    } catch (err) {
        console.log('Error fecthing name', err)
    }
}