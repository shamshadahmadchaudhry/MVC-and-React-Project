import Axios from 'axios';
import { CONFIG } from '../config/index';


export {
    getImportSheet, UploadLayoutSheet
}
const getImportSheet = async (container_type, company_id, warehouseLocationId, warehouseAddessId) => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.get(`${CONFIG.BASE_URL}/api/excelimport?container_type=${container_type}&company_id=${company_id}&warehouse_address_id=${warehouseAddessId}&warehouse_location_id=${warehouseLocationId}`, { responseType: 'arraybuffer' }, config);
        return result;
    } catch (err) {
        console.log('Error inimport service getImportSheet()', err)
    }
}
//// ==================== This method is used to upload layout sheet =======================  
const UploadLayoutSheet = (form_data, onUploadProgress) => {
    return Axios.post(`${CONFIG.BASE_URL}/api/excelimport`, form_data, {
        headers: {
            "Content-Type": "multipart/form-data",
        },
        onUploadProgress,
    });
};