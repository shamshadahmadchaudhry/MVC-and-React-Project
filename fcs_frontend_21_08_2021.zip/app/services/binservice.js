import Axios from 'axios';
import { CONFIG } from '../config/index';

export {
    getBinList, getEntityList, getContainerTypeList, getBinTypeList
}

//========== This code is used for the bin list ===================
const getBinList = (params) => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        return fetch(`${CONFIG.BASE_URL}/api/warehousestoragecontainer${params}`, config)
            .then(response => response.json())
            .then((data) => {
                if (data.status === true) {
                    return {
                        data: data.data,
                        totalCount: data.totalCount,
                        summary: [10, 15, 20],
                        groupCount: 35
                    };
                } else {
                    return {
                        data: [],
                        totalCount: 0,
                        summary: [10, 15, 20],
                        groupCount: 30
                    };
                }
            })
            .catch(() => { throw 'Data Loading Error'; });
    } catch (err) {
        console.log('Error in bin management service getBinList()', err)
    }
}

///============================ This code is used for the bind entity type dropdownlist =========================
const getEntityList = async (companyId) => {
    console.log('companyId', companyId)
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.get(`${CONFIG.BASE_URL}/api/storagecontainerentity${companyId}`, config);
        return result;
    } catch (err) {
        console.log('Error in warehouse management service getEntityList()', err)
    }
}

///============================ This code is used for the bind bin size dropdownlist =========================
const getContainerTypeList = async (container_type, company_id) => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.get(`${CONFIG.BASE_URL}/api/containersizes?container_type=${container_type}&company_id=${company_id}`, config);
        return result;
    } catch (err) {
        console.log('Error in warehouse management service getBinSizeList()', err)
    }
}

///============================ This code is used for the bind bin type dropdownlist =========================
const getBinTypeList = async () => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.get(`${CONFIG.BASE_URL}/api/bintypes`, config);
        return result;
    } catch (err) {
        console.log('Error in warehouse management service getBinTypeList()', err)
    }
}