import Axios from 'axios';
import { CONFIG } from '../config/index';

export {
    getContainersConfigurationList, addConfiguration, deleteConfiguration, updateConfiguration
}
//=================== This method is used for retriving all the container configuration list based on the container type ====================
const getContainersConfigurationList = (params) => {
    console.log('params', params)
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        return fetch(`${CONFIG.BASE_URL}/api/containerconfiguration${params}`, config)
            .then(response => response.json())
            .then((data) => {
                if (data.status === true) {
                    return {
                        data: data.data,
                        totalCount: data.totalCount,
                        summary: [5, 10, 20],
                        groupCount: 35
                    };
                } else {
                    return {
                        data: [],
                        totalCount: 0,
                        summary: [5, 10, 20],
                        groupCount: 30
                    };
                }
            })
            .catch((er) => { throw er });
    } catch (err) {
        console.log('Error fetching stations', err)
    }
}
//=================== This method is used for add the container configuration based on the container type ====================
const addConfiguration = async (body) => {
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.post(`${CONFIG.BASE_URL}/api/containerconfiguration?`, body, config);
        console.log('result', result)
        return result;
    } catch (err) {
        console.log('Error in warehouse management service method addTote() ', err)
    }
}
//=================== This method is used for delete the container configuration based on the container type ====================
const deleteConfiguration = async (entitysizeid, entity_type, created_by) => {
    try {
        let config = {};
        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.delete(`${CONFIG.BASE_URL}/api/containerconfiguration?entity_sizes_id=${entitysizeid}&entity_type=${entity_type}&modified_by=${created_by}`, config);
        return result;
    } catch (err) {
        console.log('Error deleting station', err)
    }
}
//=================== This method is used for update the container configuration based on the container type ====================
const updateConfiguration = async (body, created_by) => {
    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        const result = await Axios.put(`${CONFIG.BASE_URL}/api/containerconfiguration?created_by=${created_by}`, body, config);
        return result;
    } catch (err) {
        console.log('Error updating Station', err)
    }
}