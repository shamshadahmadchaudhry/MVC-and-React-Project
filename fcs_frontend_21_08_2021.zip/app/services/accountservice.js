import Axios from 'axios';
import { CONFIG } from '../config/index';

export {
    userAccountDetails_Service, userAccountUpdate_Service
}
// const getCookie = (name) =>{
//     var cookieValue = null;
//     if (document.cookie && document.cookie !== '') {
//         var cookies = document.cookie.split(':');
//         for (var i = 0; i < cookies.length; i++) {
//             var cookie = cookies[i].trim();
//             if (cookie.substring(0, name.length + 1) === (name + '=')) {
//                 cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
//                 break;
//             }
//         }
//     }
//     return cookieValue;
// }
// Three PL Company List
const userAccountDetails_Service = async (email) => {

    try {
        let config = {};

        if (localStorage.getItem("token")) {
            config = {
                headers: {
                    "Authorization": "Token" + " " + localStorage.getItem("token")
                }
            }
        }
        console.log('Config: ',config)
        const result = await Axios.get(`${CONFIG.BASE_URL}/api/useraccount?email=${email}`);
        return result;
    }
    catch (error) {
        console.log('')
        console.log(error)
    }
}


// Update account details
const userAccountUpdate_Service = async (body) => {
    let data = body
    try {
        const result = await Axios.put(`${CONFIG.BASE_URL}/api/updatedetails`, data);
        console.log("Result",result)
        return result;
    }
    catch (error) {
        console.log(error)
    }
}
