// import necessary package for the navbarnavigation
import React from 'react';
import { NavLink as Link } from 'react-router-dom';
import {
    Nav,
    DropdownToggle,
    DropdownMenu,
    DropdownItem,
    NestedDropdown
} from '../../../../components';
import { checkPermission } from '../../../../routes/commoncomponents/customhooks/usePermission';
// import { routes } from '../../../../Routes/routes';
import { pathTo } from "../../../../routes/commoncomponents/utils";
import { useSelector } from 'react-redux';
import { check } from '../../../../routes/commoncomponents/customhooks/Can';
/// This function is used for the bind dropdowntoggle 
var count = 0;

let dropDownToggle = (data) => {
    const UserData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data)

    return (
        data.map((item, index) => (
            <>
                {(item.label === "Profile" || item.label === "addthreeplcomapny" || item.label === 'addmerchantcomapny'
                    || item.label === 'addlocations' || item.label === 'importlocation' || item.label === 'none') ? (
                        <NestedDropdown style={{ display: "none" }} key={item.label} nav inNavbar>
                            <DropdownToggle key={item.label + index} nav>
                                {item.label}
                                {(item.routes != "") ? (
                                    <i className="fa fa-angle-down fa-fw ml-1"></i>
                                ) : (
                                        ""
                                    )}
                            </DropdownToggle>
                            {(item.routes != "") ? (
                                item.routes && dropDownMenu(data = item.routes, null)
                            ) : (
                                    ""
                                )}
                        </NestedDropdown>
                    ) : (
                        UserData && check(UserData, item.permission) ?
                            <NestedDropdown key={item.label} nav inNavbar>
                                <DropdownToggle key={item.label + index} data={item.label + index}
                                    tag={item.routes.length > 0 ? '' : Link}
                                    to="/dashboard" nav >
                                    {item.label}
                                    {(item.routes != "") ? (
                                        <i className="fa fa-angle-down fa-fw ml-1"></i>
                                    ) : (
                                            ""
                                        )}
                                </DropdownToggle>
                                {(item.routes != "") ? (
                                    item.routes && dropDownMenu(data = item.routes, UserData)
                                ) : (
                                        ""
                                    )}
                            </NestedDropdown>
                            : null
                    )}
                {/* <NestedDropdown  key={item.label} nav inNavbar>
                    <DropdownToggle nav>
                        {item.label}
                        {(item.routes != "") ? (
                            <i className="fa fa-angle-down fa-fw ml-1"></i>
                        ) : (
                                ""
                            )}
                    </DropdownToggle>
                    {(item.routes != "") ? (
                        item.routes && dropDownMenu(data = item.routes)
                    ) : (
                            ""
                        )}
                </NestedDropdown> */}
            </>
        ))
    )
}
//// This function is used for the bind dropdownmenu
let dropDownMenu = (data, userData) => {
    return (
        <DropdownMenu>
            {data.map((item, index) => (
                userData && check(userData, item.permission) && (
                    (item.routes != "") ? (
                        <NestedDropdown.Submenu key={item.label} title={item.label}>
                            {item.routes && nestedDropDown(data = item.routes)}
                        </NestedDropdown.Submenu>
                    ) : (


                            (item.path != "" && item.path != undefined) ? (
                                <DropdownItem key={item.label} tag={Link} to={item.path}>{item.label}</DropdownItem>
                            ) : (
                                    <DropdownItem key={item.label} tag={Link} to="">{item.label}</DropdownItem>
                                )

                        ))
            ))}
        </DropdownMenu>
    )
}
/// This function used for the bind nested dropdown
let nestedDropDown = (data) => {
    return (
        data.map((item, index) => (

            (item.path != "" && item.path != undefined) ? (
                <DropdownItem key={item.label} tag={Link} to={item.path}>{item.label}</DropdownItem>
            ) : (
                    <DropdownItem tag={Link} key={item.label + index} to="">{item.label}</DropdownItem>
                )
        )
        ))
}
////////// This is the main function for the binding navigation bar
const NavbarNavigation = ({ route }) => {
    let arrData = {};
    const data = pathTo(route).reduce(function (filtered, option) {
        if (option.component === 'Product') {
            filtered.push(option);
            arrData = option;
            return filtered;
        }
    }, []);
    return (
        <Nav navbar>
            {
                dropDownToggle(arrData.routes)
            }
        </Nav>
    )
}
export { NavbarNavigation };
