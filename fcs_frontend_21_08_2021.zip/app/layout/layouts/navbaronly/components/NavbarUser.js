import React from 'react';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from "react-redux";
import PropTypes from 'prop-types';

import {
    NavItem,
    NavLink
} from '../../../../components';

const NavbarUser = (props) => (
    <NavItem {...props} onClick={() => props.handleLogout()}>
        <NavLink tag={Link} to="#" >
            <i className="fa fa-power-off" style={{ fontSize: "19px", marginTop: "3px" }}></i>
        </NavLink>
    </NavItem>
);
NavbarUser.propTypes = {
    className: PropTypes.string,
    style: PropTypes.object
};

export { NavbarUser };
