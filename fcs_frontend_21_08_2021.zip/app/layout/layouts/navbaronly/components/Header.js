import React from "react";
import PropTypes from "prop-types";
import { withRouter } from "react-router";

// A simple component that shows the pathname of the current location 
class Header extends React.Component {
  static propTypes = {
    match: PropTypes.object.isRequired,
    location: PropTypes.object.isRequired,
    history: PropTypes.object.isRequired
  };
  render() {
    const { location } = this.props;
    const paths = location.pathname.split('/').pop();
    { document.title = `${paths} - Fulfyld WMS` }
    return (
      <h1 className="mb-0 h4">
        {paths}
      </h1>
    );
  }
}
export default withRouter(Header);
