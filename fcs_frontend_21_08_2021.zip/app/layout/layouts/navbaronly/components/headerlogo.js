import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { UserCompanyProfile } from '../../../../services/companyprofileservice';
import { CONFIG } from "../../../../config";
import { Configuration } from '../../../../routes/commoncomponents/configurationfile';
import '../../../../styles/common.scss';
import LogoSkeleton from '../../../../routes/warehousemanagement/skeleton/logoskeleton'

const HeaderLogo = () => {
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);

    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            document.documentElement.style.setProperty('--primarycolor', CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].profile_data?.primary_color_theme);
            document.documentElement.style.setProperty('--secondarycolor', CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].profile_data?.secondary_color_theme);
        }
        else {
            document.documentElement.style.setProperty('--primarycolor', CompanyListingStatus?.result?.response?.result[0].profile_data?.primary_color_theme);
            document.documentElement.style.setProperty('--secondarycolor', CompanyListingStatus?.result?.response?.result[0].profile_data?.secondary_color_theme);
        }

    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])


    return (
        <React.Fragment>
            {(CompanyListingStatus?.result?.response?.result.length > 1) ?
                <img
                    src={
                        CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].profile_data?.company_logo === null
                            || CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].profile_data?.company_logo === ''
                            || CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].profile_data?.company_logo === undefined
                            ? CONFIG.BASE_URL + Configuration.blankLogoPath + ''
                            : CONFIG.BASE_URL + CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default)[0].profile_data?.company_logo + '?' + Date.now()
                    }
                    className='d-block navbar-logo-size'
                /> :
                (
                    <img
                        src={
                            CompanyListingStatus?.result?.response?.result[0].profile_data?.company_logo === null
                                || CompanyListingStatus?.result?.response?.result[0].profile_data?.company_logo === ''
                                || CompanyListingStatus?.result?.response?.result[0].profile_data?.company_logo === undefined
                                ? CONFIG.BASE_URL + Configuration.blankLogoPath + ''
                                : CONFIG.BASE_URL + CompanyListingStatus?.result?.response?.result[0].profile_data?.company_logo + '?' + Date.now()
                        }
                        className='d-block navbar-logo-size'
                    />
                )
            }

        </React.Fragment>
    )

}
export default HeaderLogo;