import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
    Avatar,
    DropdownToggle,
    Navbar,
    Nav,
    NavItem,
    NavLink,
    NavbarToggler,
    UncontrolledCollapse,
    UncontrolledDropdown,
} from "../../../../components";
import { NavbarUser } from './NavbarUser';
import { NavbarNavigation } from "./NavbarNavigation";
import { Logo } from "../../../../routes/components/LogoThemed/Logo";
import { Configuration } from '../../../../routes/commoncomponents/configurationfile';
import { LogoutRequest } from '../../../../redux/actions/index'
import { useSelector, useDispatch } from "react-redux";
import { CONFIG } from "../../../../config";
import '../../../../styles/common.scss';
import { usePermission } from '../../../../routes/commoncomponents/customhooks/usePermission';
import HeaderLogo from './headerlogo';
import {checkUserToken} from '../../../../services/tokenCheck'

const LayoutNavbar = ({ route, props }) => {
    const PageBody = route?.component || props.component;
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus);
    const [defaultData, setData] = useState([])
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data)
    const dispatch = useDispatch();
    const ProfileStatus = useSelector(state => state.ProfileStatus);
    const [totalCompany, setTotalCompany] = useState(0);
    const { isAuthorized } = usePermission('p-profile');
    //const { isAuthorized } = usePermission('View Profile');

    
    const handleLogout = () => {
        dispatch(LogoutRequest());
    }
    const checkToken = async () =>{
        // console.log('USERS DATA', userData)
        const user_id = userData.user_master_id
        // console.log('USERID',user_id)
        const tokenState = await checkUserToken(user_id)
        // console.log('TOKEN STATE',tokenState)
        if(tokenState == 401){
            localStorage.removeItem('token')
            window.location.reload()
        }
    }
    useEffect(()=>{
        checkToken()
    },[])

    useEffect(() => {
        if (CompanyListingStatus?.result?.response?.result.length > 1) {
            setTotalCompany(CompanyListingStatus?.result?.response?.result.length);
            setData(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default))
        }
        else
            setData(CompanyListingStatus?.result?.response?.result)
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])

    return (
        <React.Fragment>
            <Navbar light expand="lg" themed>
                <Nav pills>
                    <NavItem>
                        <NavLink
                            tag={NavbarToggler}
                            id='navbar-navigation-toggler'
                            className='b-0' >
                            <i className='fa fa-fw fa-bars'></i>
                        </NavLink>
                    </NavItem>
                </Nav>
                <Link to='/Dashboard' className='navbar-brand mr-0 mr-sm-3'>
                    {/* FULFILLMENTWMS */}
                    {/* <Logo checkBackground /> */}
                    <HeaderLogo />
                </Link>

                {/* Navigation with Collapse */}
                <UncontrolledCollapse navbar toggler='#navbar-navigation-toggler'>
                    <NavbarNavigation route={route} />
                </UncontrolledCollapse>

                {/* END Navbar: Left Side */}
                {/* START Navbar: Right Side */}
                <Nav className='ml-auto' pills>
                    <div style={{ alignSelf: 'center' }} >
                        <span className="firstLastname username-font captalize">
                            {

                                userData && userData.first_name + ' ' + userData.last_name}<br />
                        </span>
                        <span className="username-font">
                            {
                                totalCompany > 1 ? <Link to="/companyListing"> {defaultData?.length > 0 ? defaultData[0].company_dba_name : ""} </Link> : defaultData?.length > 0 ? defaultData[0].company_dba_name : ""
                            }
                        </span>
                    </div>

                    {/* START Navbar: Dropdown */}
                    <UncontrolledDropdown nav inNavbar>
                        <DropdownToggle nav>
                            {isAuthorized === true ? (
                                <Link to='/Profile/Profile'>
                                    {userData &&
                                        <Avatar.Image
                                            cache={false}
                                            src={`${userData.profile_img_src ? CONFIG.BASE_URL + userData.profile_img_src + '?' + Date.now() : CONFIG.BASE_URL + Configuration.blankImagePath}`}
                                        />
                                    }
                                </Link>
                            ) : (
                                    userData &&
                                    <Avatar.Image
                                        cache={false}
                                        src={`${userData.profile_img_src ? CONFIG.BASE_URL + userData.profile_img_src + '?' + Date.now() : CONFIG.BASE_URL + Configuration.blankImagePath}`}
                                    />
                                )}

                        </DropdownToggle>
                    </UncontrolledDropdown>
                    {/* END Navbar: Dropdown */}
                    <NavbarUser className="d-lg-block" handleLogout={handleLogout} />
                </Nav>
                {/* END Navbar: Right Side */}
            </Navbar>
            {/* <Navbar light expand='lg' className='py-3 bg-white breadcrumb-shadow'>
                <Header route={route} />
                <ThemeConsumer>
                    {({ color }) => (
                        <div>
                            <Nav className='d-md-block'>
                                {route.parent && <Breadcrumbs route={route} />}
                            </Nav>
                        </div>
                    )}
                </ThemeConsumer>
            </Navbar> */}
            <PageBody />
        </React.Fragment>
    );
};
export default LayoutNavbar;
