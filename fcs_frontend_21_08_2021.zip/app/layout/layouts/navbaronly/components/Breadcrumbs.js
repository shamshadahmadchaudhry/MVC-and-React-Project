import React from "react";
import { NavLink } from "react-router-dom";
import { pathTo } from "../../../../routes/commoncomponents/utils";
import {
  NavItem,
  Label
} from '../../../../components';


const Breadcrumbs = ({ route }) => (
  <>
    {pathTo(route).map((crumb, index, breadcrumbs) => (
      <React.Fragment key={crumb.label}>
        {index < breadcrumbs.length - 1 && (
          <>
            {(crumb.path != "" && crumb.path != "/blank" && crumb.path != "/" && crumb.path != undefined) ? (
              <>
                <span className="navbar-text">
                  {(crumb.label == "Home") ? (
                    <NavLink key={crumb.label} to="/">
                      <i className="fa fa-home"></i>
                    </NavLink>
                  ) : (
                      <NavLink key={crumb.label} to={crumb.path}>{crumb.label}</NavLink>
                    )}
                </span>
                <span className="navbar-text px-2">
                  <i className="fa fa-angle-right"></i>
                </span>
              </>
            ) :
              (
                <>
                  {(crumb.label == "Home") ? (
                    <i className="fa fa-home"></i>
                  ) : (
                      <Label>{crumb.label} </Label>
                    )}

                  <span className="navbar-text px-2">
                    <i className="fa fa-angle-right"></i>
                  </span>
                </>
              )
            }
          </>
        )}
        <span className="navbar-text">
          {index === breadcrumbs.length - 1 && crumb.label}
        </span>
      </React.Fragment>
    ))}
  </>
);
export default Breadcrumbs;
