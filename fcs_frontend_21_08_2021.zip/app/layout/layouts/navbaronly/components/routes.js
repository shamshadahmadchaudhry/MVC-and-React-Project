
import UserProfile from '../../../../routes/profile/userprofile';
import Dashboard from '../../../../routes/dashboard/dashboard';
import ThreePLCompany from '../../../../routes/threeplcompany/threeplcompanylist'
import ApplicationRolesManagement from "../../../../routes/roles/apllicationroles";
import AddThreePlComapny from '../../../../routes/threeplcompany/addthreeplcompany';
import AddMerchantCompany from '../../../../routes/merchantcompany/addmerchantcompany';
import MerchantCompanyList from '../../../../routes/merchantcompany/merchantcompanylist';
import UserList from '../../../../routes/productowner/userlist';
import WarehouseManagement from '../../../../routes/warehousemanagement/warehousemanagement';
import WarehouselocationList from '../../../../routes/warehousemanagement/warehouselocationlist';
import NamingRules from '../../../../routes/warehousemanagement/namingrules';
import Stations from '../../../../routes/warehousemanagement/stations/stations';
import LocationDropdown from '../../../../routes/warehousemanagement/common/locationdropdown';
import Layouts from '../../../../routes/warehousemanagement/common/layouts';
import AddShelf from '../../../../routes/warehousemanagement/storageunit/addShelf';
import AddBay from '../../../../routes/warehousemanagement/storageunit/addBay';
import CompanyUserList from '../../../../routes/threeplcompany/companylist/threeplcompanylisting';
import ContainerConfiguration from '../../../../routes/warehousemanagement/common/containerconfigurationheader';
import CompanyThemeSetting from '../../../../routes/companyprofile/companythemesetting';
import ZonePreview from '../../../../routes/warehousemanagement/preview/layoutpreview/zonepreview';
import StorageUnit from '../../../../routes/warehousemanagement/storageunit/storageunit';
import AislePreview from '../../../../routes/warehousemanagement/preview/layoutpreview/aislepreview';
import ContainerPreview from '../../../../routes/warehousemanagement/preview/containerpreview/containerpreview';
import StationPreview from '../../../../routes/warehousemanagement/preview/stationpreview/stationpreview';
import LocationStorageUnitPreview from '../../../../routes/warehousemanagement/storageunit/locationstorageunitpreview';
import { CompanyListing } from '../../../../routes/company/comapnylisting';
import Trip from '../../../../routes/warehousemanagement/trip/trip';
import ShiftMasterComponent from '../../../../routes/warehousemanagement/shiftmanagement/shift';
import EmployeeShiftComponent from '../../../../routes/warehousemanagement/shiftmanagement/employeeshift';
import Package from '../../../../routes/packagemanagement/package';
import UserTrip from '../../../../routes/warehousemanagement/usertrip/usertrip';
import TripDetails from '../../../../routes/warehousemanagement/usertrip/tripdetails';



export const routes = [
  {
    path: "/",
    label: "Home",
    component: "Product",
    permission: 'home',
    routes: [
      {
        path: "/Dashboard",
        label: "Dashboard",
        permission: 'p-dashboard',
        component: Dashboard,
        routes: [
        ]
      },
      {
        path: "/3PLCompany",
        label: "3PL Company",
        component: ThreePLCompany,
        permission: 'p-manage-3pl-company',
        routes: [
          {
            path: "/3PLCompany",
            label: "3PL Company Management",
            permission: 'p-manage-3pl-company',
            component: CompanyUserList,
            routes: [
            ]
          }
        ]
      },
      {
        path: "/warehouse",
        label: "Warehouse Setup",
        component: 'Warehouse Setup',
        permission: 'p-manage-warehouse',
        routes: [
          {
            path: "/namingrules",
            label: "Naming Rules",
            permission: 'p-manage-warehouse',
            component: NamingRules,
            routes: [
            ]
          },
          {
            path: "/locations",
            label: "Locations",
            permission: 'p-manage-warehouse',
            component: WarehouselocationList,
            routes: [
            ]
          },
          {
            path: "/layouts",
            label: "Layouts  ",
            permission: 'p-manage-warehouse',
            component: Layouts,
            routes: [
            ]
          },
          {
            path: "/storageunit",
            label: "Storage Units",
            permission: 'p-manage-warehouse',
            component: StorageUnit,
            routes: [

            ]
          },
          {
            path: "/movablecontainer",
            label: "Containers",
            permission: 'p-manage-warehouse',
            component: LocationDropdown,
            routes: [

            ]
          },
          {
            path: "/stations",
            label: "Stations",
            permission: 'p-manage-warehouse',
            component: Stations,
            routes: [
            ]
          },
          {
            path: "/containerconfiguration",
            label: "Container Configurations",
            permission: 'p-manage-warehouse',
            component: ContainerConfiguration,
            routes: [
            ]
          },
          // {
          //   path: "/employeeshifts",
          //   label: "Employee Shift",
          //   permission: 'p-manage-warehouse',
          //   component: EmployeeShiftComponent,
          //   routes: [
          //   ]
          // }
        ]
      },
      {
        path: "/operations",
        label: "Operations",
        component: 'Operations',
        permission: 'p-operations',
        routes: [
          // {
          //   path: "/mytrips",
          //   label: "My Trips",
          //   component: 'Warehouse Setup',
          //   permission: 'p-manage-trips',
          //   routes: []
          // },
          {
            path: "/trips",
            label: "Trips",
            component: Trip,
            permission: 'p-create-trips',
            routes: []
          },
          // {
          //   path: "/tripscheduling",
          //   label: "Trip Scheduling",
          //   permission: 'p-trip-scheduler-on',
          //   component: EmployeeShiftComponent,
          //   routes: [
          //   ]
          // },
          {
            path: "/shifts",
            label: "Shifts",
            component: ShiftMasterComponent,
            permission: 'p-manage-shift',
            routes: []
          },
          {
            path: "/employeeshifts",
            label: "Employee Shifts",
            component: EmployeeShiftComponent,
            permission: 'p-employee-shift',
            routes: []
          }
        ]
      },
      {
        path: "/MerchantCompany",
        label: "Merchant Company",
        component: ThreePLCompany,
        permission: 'p-merchant-company',
        routes: [
          {
            path: "/MerchantCompany",
            label: "Merchant Company",
            permission: 'p-manage-merchants',
            component: MerchantCompanyList,
            routes: [
            ]
          },
          {
            path: "/packages",
            label: "Packages",
            permission: 'p-manage-merchants',
            component: Package,
            routes: [
            ]
          },
          {
            path: "/usertrip",
            label: "UserTrip",
            permission: 'p-manage-merchants',
            component: UserTrip,
            routes: [
            ]
          }
        ]
      },
      {
        path: "/Settings",
        label: "Settings",
        permission: 'p-settings',
        component: 'Settings',
        routes: [
          {
            path: "/productownerprofile",
            label: "Company Profile",
            permission: 'p-manage-company-profile',
            component: CompanyThemeSetting,
            routes: []
          },
          {
            path: "/usermanagement",
            label: "User Management",
            permission: 'p-manage-company-profile',
            component: UserList,
            routes: []
          },
          {
            path: "/rolemanagement",
            label: "Role Management",
            permission: 'p-product-owner-role-management',
            component: ApplicationRolesManagement,
            routes: []
          }
        ]
      },
      {
        path: "/Security",
        label: "Security",
        permission: 'view-security',
        component: 'Security',
        routes: [
          {
            path: "/ApplicationRoles",
            label: "Application Roles",
            permission: 'view-application-roles',
            component: ApplicationRolesManagement,
            routes: []
          },
          {
            path: "/WarehouseListing",
            label: "warehouse locations",
            component: WarehouseManagement,
            routes: []
          },
          {
            path: "/userlist",
            label: "Users",
            permission: 'view-users',
            component: UserList,
            routes: []
          }
        ]
      },
      {
        path: "/addbays",
        label: "none",
        permission: 'p-manage-warehouse',
        component: AddBay,
        routes: [
        ]
      },
      {
        path: "/addshelf",
        label: "none",
        permission: 'p-manage-warehouse',
        component: AddShelf,
        routes: [
        ]
      },
      {
        path: "/importlocationstorageunit",
        label: "none",
        permission: 'p-manage-warehouse',
        component: LocationStorageUnitPreview,
        routes: []
      },
      {
        path: "/Profile",
        label: "none",
        permission: 'p-manage-profile',
        component: UserProfile,
        routes: [

        ]
      },
      {
        path: "/addthreeplcomapny",
        label: "none",
        permission: 'p-manage-3pl-company',
        component: AddThreePlComapny,
        routes: [

        ]
      },
      {
        path: "/addlocations",
        label: "none",
        permission: 'p-manage-warehouse',
        component: WarehouseManagement,
        routes: [

        ]
      },
      {
        path: "/addmerchantcomapny",
        label: "none",
        permission: 'p-manage-merchants',
        component: AddMerchantCompany,
        routes: [

        ]
      },
      {
        path: "/zonepreview",
        label: "none",
        permission: 'p-manage-warehouse',
        component: ZonePreview,
        routes: [
        ]
      },
      {
        path: "/aislepreview",
        label: "none",
        permission: 'p-manage-warehouse',
        component: AislePreview,
        routes: [
        ]
      },
      {
        path: "/containerpreview",
        label: "none",
        permission: 'p-manage-warehouse',
        component: ContainerPreview,
        routes: [
        ]
      },
      {
        path: "/stationpreview",
        label: "none",
        permission: 'p-manage-warehouse',
        component: StationPreview,
        routes: [
        ]
      },
      {
        path: "/companylisting",
        label: "none",
        permission: 'p-company-listing',
        component: CompanyListing,
        routes: [
        ]
      },
      {
        path: "/tripdetails",
        label: "none",
        permission: 'p-manage-warehouse',
        component: TripDetails,
        routes: [
        ]
      }
    ]
  }
];
