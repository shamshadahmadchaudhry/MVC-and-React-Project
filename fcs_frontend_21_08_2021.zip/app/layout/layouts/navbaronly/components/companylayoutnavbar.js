import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from "react-redux"
import { Link } from 'react-router-dom';
import {
    Avatar,
    AvatarAddOn,
    DropdownToggle,
    Navbar,
    Nav,
    UncontrolledDropdown,
    NavItem
} from '../../../../components';
import { NavbarUser } from './NavbarUser';
import { CompanyListing } from '../../../../routes/company/comapnylisting';
import { Logo } from '../../../../routes/components/LogoThemed/Logo';
import { Configuration } from '../../../../routes/commoncomponents/configurationfile';
import { CompanyListingRequest, LogoutRequest } from '../../../../redux/actions/index'
import { useHistory } from 'react-router-dom';
import '../../../../styles/common.scss';


const CompanyLayoutNavbar = (props) => {
    const dispatch = useDispatch();
    const history = useHistory();
    const CompanyListingStatus = useSelector(state => state.CompanyListingStatus)
    const userData = useSelector(state => state.userData && state.userData.data && state.userData.data.response && state.userData.data.response.data)
    const isLogged = useSelector(state => state.LoginStatus && state.LoginStatus.loggedIn)
    const [defaultData, setData] = useState([])
    const handleLogout = () => {
        dispatch(LogoutRequest());
    }

     !localStorage.getItem('token') && history.push("/");

    useEffect(() => {
        localStorage.getItem('token') && dispatch(CompanyListingRequest());
    }, [])

    useEffect(() => {
        setData(CompanyListingStatus?.result?.response?.result?.filter(val => val.is_default))
    }, [CompanyListingStatus?.isSuccess && CompanyListingStatus?.result])


    return (
        <React.Fragment>
            <Navbar expand="lg" themed>
                <Link to="/Dashboard" className="navbar-brand mr-0 mr-sm-3">
                    <Logo className="mb-1" checkBackground />
                </Link>
                

                { /* END Navbar: Left Side */}
                { /* START Navbar: Right Side */}

                <Nav className="ml-auto" pills>
                    <NavItem>
                        <span className="firstLastname username-font captalize">
                            {userData && userData.first_name + ' ' + userData.last_name}<br />
                        </span>
                        <span className="defaulyCompany username-font">
                            {
                                <Link to="/companyListing" >{defaultData?.length > 0 ? defaultData[0].company_name : ""}</Link>
                            }
                        </span>
                    </NavItem>


                    { /* START Navbar: Dropdown */}
                    <UncontrolledDropdown nav inNavbar>
                        <DropdownToggle nav>

                            <Avatar.Image
                                src={`${Configuration.baseURL}${Configuration.imagePath}`}
                            />

                        </DropdownToggle>
                    </UncontrolledDropdown>
                    { /* END Navbar: Dropdown */}
                    <NavbarUser className="d-lg-block" handleLogout={handleLogout} />
                </Nav>
                { /* END Navbar: Right Side */}
            </Navbar>
            <Navbar expand="lg" className="py-3 bg-white breadcrumb-shadow">
                <label><h5>Select Company</h5></label>
            </Navbar>
            <CompanyListing />
        </React.Fragment>
    )
}
export default CompanyLayoutNavbar;
