export const CONFIG = {
  // BASE_URL: 'http://dev.stits.co:8030'
  BASE_URL: 'http://127.0.0.1:8000'

};
